(()=>{var e,t={4911:(e,t,r)=>{"use strict";var i=r(7294),a=r(1565);a.ZP.div`
  position: inherit;
  margin: 0;
  top: auto;
  left: auto;
  flex-wrap: wrap;
  width: 4.2em;
  height: 4.2em;
  display: grid;
  grid-template: "a a a" 52% "c c c" 34% / 1fr 1fr 1fr; /* 30px */
  grid-gap: 14%;
`,a.ZP.div`
  font-size: 16px;
  width: 100px;
  height: 100px;
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 1;
  margin-bottom: 1rem;

  .item-logo-block1 {
    margin-top: auto;
    height: 61%;
    background-color: ${({theme:e})=>e.colors.blue};
    clip-path: polygon(0 0, 100% 40%, 100% 100%, 0% 100%);
    animation: component-loader 1s 0.15s ease-in-out infinite;
  }

  .item-logo-block2 {
    height: 61%;
    margin-top: auto;
    background-color: ${({theme:e})=>e.colors.blue};
    clip-path: polygon(0 40%, 100% 0%, 100% 100%, 0% 100%);
    animation: component-loader 1s 0.3s ease-in-out infinite;
  }

  .item-logo-block3 {
    clip-path: polygon(0 25%, 100% 0%, 100% 100%, 0% 100%);
    background-color: ${({theme:e})=>e.colors.blue};
    animation: component-loader 1s 0.45s ease-in-out infinite;
  }

  .item-logo-block4,
  .item-logo-block5,
  .item-logo-block6 {
    background-color: ${({theme:e})=>e.colors.darkBlue};
  }

  .item-logo-block4 {
    animation: component-loader 1s ease-in-out infinite;
  }

  .item-logo-block5 {
    animation: component-loader 1s 0.15s ease-in-out infinite;
  }

  .item-logo-block6 {
    animation: component-loader 1s 0.3s ease-in-out infinite;
  }

  @keyframes component-loader {
    0% {
      transform: scale(1);
    }
    30% {
      transform: scale(0.2);
    }
    60% {
      transform: scale(1);
    }
  }
`,Object.entries({"www.amazon.com":"com","www.amazon.com.au":"au","www.amazon.ca":"ca","www.amazon.com.mx":"mx","www.amazon.de":"de","www.amazon.es":"es","www.amazon.fr":"fr","www.amazon.it":"it","www.amazon.co.uk":"uk","www.amazon.in":"in","www.amazon.nl":"nl","www.amazon.co.jp":"jp"}).map((([e,t])=>({value:t,label:e})));const n="en-US";var o,s,l,c;function d(){return(d=Object.assign||function(e){for(var t=1;t<arguments.length;t++){var r=arguments[t];for(var i in r)Object.prototype.hasOwnProperty.call(r,i)&&(e[i]=r[i])}return e}).apply(this,arguments)}function u(){return(u=Object.assign||function(e){for(var t=1;t<arguments.length;t++){var r=arguments[t];for(var i in r)Object.prototype.hasOwnProperty.call(r,i)&&(e[i]=r[i])}return e}).apply(this,arguments)}function g(){return(g=Object.assign||function(e){for(var t=1;t<arguments.length;t++){var r=arguments[t];for(var i in r)Object.prototype.hasOwnProperty.call(r,i)&&(e[i]=r[i])}return e}).apply(this,arguments)}Object.defineProperty,Object.getOwnPropertySymbols,Object.prototype.hasOwnProperty,Object.prototype.propertyIsEnumerable,Object.defineProperty,Object.defineProperties,Object.getOwnPropertyDescriptors,Object.getOwnPropertySymbols,Object.prototype.hasOwnProperty,Object.prototype.propertyIsEnumerable;const p=a.F4`
  from {
    opacity: 0;
  }
  to {
    opacity: 1;
  }
`,m=a.ZP.div`
  width: 16px !important;
  height: 16px !important;
  text-align: initial;
`,h=(0,a.ZP)((function(e){return i.createElement("svg",u({width:16,height:16,fill:"none",xmlns:"http://www.w3.org/2000/svg"},e),s||(s=i.createElement("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M8 8L0 0h16L8 8z",fill:"#222"})))}))`
  width: 16px !important;
  height: 16px !important;
  position: absolute;
`,w=(0,a.ZP)((function(e){return i.createElement("svg",g({width:16,height:16,fill:"none",xmlns:"http://www.w3.org/2000/svg"},e),l||(l=i.createElement("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M8 7L1 0h14L8 7z",fill:"#fff"})),c||(c=i.createElement("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M0 0l8 8 8-8h-1.414L8 6.586 1.414 0H0z",fill:"#DEE2E6"})))}))`
  width: 16px !important;
  height: 16px !important;
  position: absolute;
`,b={dark:{background:"#222",color:"#fff",boxShadow:"none"},light:{background:"#fff",color:"#343a40",boxShadow:"0px 0px 0px 1px rgba(222, 226, 230, 1)"}};a.ZP.div`
  max-width: ${({maxWidth:e})=>e?e+"px":"auto"};
  padding: 8px 12px;
  border-radius: 4px;
  color: #fff;
  animation: ${p} 0.2s ease;
  transition-property: transform, visibility, opacity;
  text-align: center;
  ${({colorType:e})=>`\n    background: ${b[e||"dark"].background};\n    color: ${b[e||"dark"].color};\n    box-shadow: ${b[e||"dark"].boxShadow};\n  `};

  &[data-placement^="top"] {
    ${m} {
      bottom: 0;
    }
    ${h}, ${w} {
      top: 16px;
    }
  }

  &[data-placement^="bottom"] {
    ${m} {
      top: 0;
    }
    ${h}, ${w} {
      bottom: 16px;
      transform: rotate(180deg);
    }
  }

  &[data-placement^="left"] {
    ${m} {
      right: 0;
    }
    ${h}, ${w} {
      transform: rotate(-90deg);
      left: 16px;
    }
  }

  &[data-placement^="right"] {
    ${m} {
      left: 0;
    }
    ${h}, ${w} {
      transform: rotate(90deg);
      right: 16px;
    }
  }
`,Object.defineProperty,Object.getOwnPropertySymbols,Object.prototype.hasOwnProperty,Object.prototype.propertyIsEnumerable,a.ZP.div``,a.ZP.div`
  margin-right: 4px;
`,a.ZP.div`
  display: flex;
  align-items: center;
`,a.ZP.div`
  width: 18px;
  height: 18px;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
`,(0,a.ZP)((function(e){return i.createElement("svg",d({width:11,height:11,fill:"none",xmlns:"http://www.w3.org/2000/svg"},e),o||(o=i.createElement("path",{clipRule:"evenodd",d:"M5.5 7.319a1.02 1.02 0 100 2.04 1.02 1.02 0 000-2.04zm.148-5.5c-1.209 0-1.98.509-2.585 1.414a.266.266 0 00.06.36l.77.584c.115.087.28.066.37-.047.395-.503.667-.794 1.27-.794.453 0 1.013.291 1.013.73 0 .333-.274.503-.721.754-.522.293-1.212.657-1.212 1.567v.089c0 .147.12.266.266.266h1.242c.147 0 .266-.12.266-.266v-.03c0-.631 1.845-.657 1.845-2.365 0-1.287-1.334-2.262-2.584-2.262zM11 5.5a5.5 5.5 0 11-11 0 5.5 5.5 0 0111 0z"})))}))`
  fill: ${({theme:e,color:t})=>e.colors[t]};
`;const f=a.iv`
  font-stretch: normal;
  font-style: normal;
  line-height: normal;
  font-weight: normal;
  letter-spacing: normal;
  margin: 0;
  padding: 0;
  text-transform: initial;
`,M=a.ZP.h1`
  ${f};
  font-weight: bold;
  color: ${({theme:e})=>e.colors.darkBlue};
  font-size: ${({theme:e})=>e.fontSize.headerBig};
`,y=a.ZP.h2`
  ${f};
  font-size: ${({theme:e})=>e.fontSize.headerLarge};
  font-weight: bold;
`,v=(a.ZP.h3`
  ${f};
  font-size: ${({theme:e})=>e.fontSize.headerMedium};
  font-weight: bold;
`,a.ZP.h4`
  ${f};
  font-size: ${({theme:e})=>e.fontSize.headerSmall};
  font-weight: 600;
`),x=a.ZP.span`
  ${f};
  font-size: ${({theme:e})=>e.fontSize.medium};
  font-weight: normal;
`,z=a.ZP.span`
  font-size: ${({theme:e})=>e.fontSize.extraSmall};
  font-weight: 600;
`;Object.defineProperty,Object.defineProperties,Object.getOwnPropertyDescriptors,Object.getOwnPropertySymbols,Object.prototype.hasOwnProperty,Object.prototype.propertyIsEnumerable,a.ZP.div`
  line-height: 1 !important;
  background-color: ${({theme:e})=>e.colors.white};
  border-radius: ${({theme:e})=>e.borderRadius.small};
  border: ${({theme:e,haveBorder:t})=>t?`1px solid ${e.colors.middleBeige}`:"1px solid rgba(255, 255, 255, 0)"};
  padding: ${({theme:e})=>e.padding.default};
`,(0,a.ZP)(z)`
  text-transform: uppercase;
  color: ${({theme:e})=>e.colors.grey};
`,(0,a.ZP)(y)`
  line-height: 1 !important;
  padding-top: 3px;
  color: ${({theme:e})=>e.colors.darkBlue};
  text-transform: uppercase;
`;const N={colors:{white:"#ffffff",blue:"#0081ff",lightGrayBackground:"#e4e5e7",darkBlue:"#003873",middleBlue:"#0150a4",darkGrey:"#343a40",black:"#000",grey:"#646464",lightGrey:"#ebf0f2",lightBeige:"#ede8e4",beige:"#ede8e4",middleBeige:"#cbcbcb",lightBlue:"#f7f9fa",middleGrey:"#a8aab7",mediumGrey:"#d1d4d8",lightOpacityGrey:"#8c8c8c",lightRed:"#e74c3c",green:"#35a854",yellow:"#eba646",gold:"#f4c005",asphalt:"#313a47",alibabaGrey:"#eef2f7",alibabaOrange:"#ff6700",alibabaOrangeBackground:"#ffece0",scroll:{track:"#ede8e4",thumb:"#cbcbcb",thumbHover:"#c1c1c1",thumbActive:"#b9b9b9"}},fontFamily:{Neuton:"Neuton",NunitoSans:"Nunito Sans"},fontSize:{smallLabel:"8.3px",label:"11px",extraSmall:"12px",small:"13px",medium:"14px",large:"18px",headerSmall:"16px",headerMedium:"20px",headerLarge:"24px",headerBig:"27px"},fontWeight:{small:"normal",middle:"500",large:"600"},lineHeight:{small:"120%",middle:"140%",large:"160%"},padding:{modal:{default:"11px 16px"},small:"4px",default:"16px",middle:"20px",large:"24px",section:"36px",button:"10px",footerBottom:"40px"},borderRadius:{small:"4px",middle:"8px",large:"35px"}};Object.defineProperty,Object.defineProperties,Object.getOwnPropertyDescriptors,Object.getOwnPropertySymbols,Object.prototype.hasOwnProperty,Object.prototype.propertyIsEnumerable,N.colors.white,N.colors.blue,a.ZP.a`
  display: flex;
  align-items: center;
  flex-wrap: nowrap;
  border: none;
  transition: all 0.2s ease-in-out;
  cursor: pointer;
  font-weight: bold;
  color: ${e=>e.colorSchema.fontColor} !important;
  font-size: 14px;
  outline: none;
  text-decoration: none;

  &:hover {
    text-decoration: none !important;
    color: ${e=>e.colorSchema.fontColor} !important;
  }

  svg {
    margin-left: 8px;
  }
`,Object.defineProperty,Object.getOwnPropertySymbols,Object.prototype.hasOwnProperty,Object.prototype.propertyIsEnumerable,a.ZP.div``,a.ZP.div`
  background-color: ${({theme:e})=>e.colors.white};
  border-radius: ${({theme:e})=>e.borderRadius.small};
  border: 1px solid ${({theme:e})=>e.colors.lightGrey};
`,a.ZP.div`
  padding: ${({theme:e,noPadding:t})=>t?0:e.padding.default};
`,a.ZP.div`
  padding-bottom: 8px;
`,a.ZP.div`
  border-top: 1px solid ${({theme:e})=>e.colors.lightGrey};
  padding: 10px;
  display: flex;
  justify-content: center;
`,a.ZP.span`
  ${f};
  font-family: ${({theme:e})=>e.fontFamily.Neuton}, serif;
  font-size: ${({theme:e})=>e.fontSize.headerMedium};
  letter-spacing: 0.5px;
`,a.ZP.span`
  font-size: ${({theme:e})=>e.fontSize.headerSmall};
  font-weight: 600;
  letter-spacing: 0.5px;
`;const j=a.ZP.span`
  font-size: ${({theme:e})=>e.fontSize.large};
  font-weight: bold;
  line-height: 1.39;
  letter-spacing: 0.82px;
  color: ${({theme:e})=>e.colors.darkBlue};
`,D=a.ZP.span`
  font-size: ${({theme:e})=>e.fontSize.headerSmall};
  font-weight: 600;
  line-height: 1.56;
  letter-spacing: 0.73px;
`,O=(a.ZP.span`
  font-size: ${({theme:e})=>e.fontSize.large};
  font-weight: bold;
  line-height: 1.39;
  letter-spacing: 0.82px;
`,a.ZP.span`
  font-size: ${({theme:e})=>e.fontSize.small};
  line-height: 1.15;
`,a.ZP.span`
  ${f};
  font-size: ${({theme:e})=>e.fontSize.smallLabel};
  font-weight: bold;
`);Object.defineProperty,Object.getOwnPropertySymbols,Object.prototype.hasOwnProperty,Object.prototype.propertyIsEnumerable,a.ZP.div`
  display: flex;
  align-items: center;
  padding-top: 3px;
`,(0,a.ZP)(y)`
  line-height: 1 !important;
  color: ${e=>e.theme.colors.darkBlue};
`,(0,a.ZP)(z)`
  line-height: 1 !important;
  text-transform: uppercase;
  color: ${e=>e.theme.colors.grey};
`,a.ZP.div`
  display: flex;
  align-items: center;
`,(0,a.ZP)(O)`
  color: ${e=>e.theme.colors.white};
  background-color: ${e=>e.theme.colors.asphalt};
  padding: 0 8px;
  border-radius: 3px;
  height: 11px;
  line-height: 11px;
  margin-left: 5px;
`,a.ZP.div`
  display: inline-block;
  padding: 16px;
  border: 1px solid ${({theme:e})=>e.colors.middleBeige};
  border-radius: 4px;
`,a.ZP.div`
  position: absolute;
  top: 0;
  left: 0;
  height: 100%;
  display: block;
  overflow: hidden;
  width: ${({rating:e})=>e>5?100:20*e}%;
`,a.ZP.div`
  position: relative;
  margin-right: 4px;
`,Object.defineProperty,Object.defineProperties,Object.getOwnPropertyDescriptors,Object.getOwnPropertySymbols,Object.prototype.hasOwnProperty,Object.prototype.propertyIsEnumerable,a.ZP.div`
  transition: 0.2s;
  opacity: ${({state:e})=>"entered"===e?1:0};
  display: ${({state:e})=>"exited"===e?"none":"flex"};
`;const A=a.F4`
  0% {
    background-position: 100% 50%;
  }
  100% {
    background-position: 0 50%;
  }
`;var I;function C(){return(C=Object.assign||function(e){for(var t=1;t<arguments.length;t++){var r=arguments[t];for(var i in r)Object.prototype.hasOwnProperty.call(r,i)&&(e[i]=r[i])}return e}).apply(this,arguments)}a.ZP.div`
  border-radius: 4px;
  background: linear-gradient(
    90deg,
    ${e=>e.colorOne||"#e6e6e6"} 25%,
    ${e=>e.colorTwo||"#f3f3f3"} 50%,
    ${e=>e.colorOne||"#e6e6e6"} 75%
  );
  background-size: 400% 100%;
  animation: ${A} 1.5s infinite;
  height: calc(100% - ${e=>e.heightShrinkAmount||18}px);
  width: 100%;
`;var S=Object.defineProperty,P=Object.defineProperties,L=Object.getOwnPropertyDescriptors,T=Object.getOwnPropertySymbols,k=Object.prototype.hasOwnProperty,E=Object.prototype.propertyIsEnumerable,Z=(e,t,r)=>t in e?S(e,t,{enumerable:!0,configurable:!0,writable:!0,value:r}):e[t]=r;const B={small:{height:"28px"},middle:{height:"34px"},large:{height:"40px"}},G=a.ZP.input`
  font-size: 14px;
  box-sizing: border-box;
  height: ${({sizeSchema:e})=>B[e||"small"].height};
  padding: 0 8px;
  background: #fff;
  display: block;
  width: 100%;
  border: none;
  text-align: ${({textAlign:e})=>e};

  &:focus {
    outline: none;
  }

  &::placeholder {
    color: ${({theme:e})=>e.colors.grey};
  }

  &[type="number"]::-webkit-inner-spin-button,
  &[type="number"]::-webkit-outer-spin-button {
    -webkit-appearance: none;
    margin: 0;
  }

  &:disabled {
    cursor: not-allowed;
    background: #fbfbfb;
  }
`,R=a.ZP.div`
  box-sizing: border-box;
  padding: 0 8px;
  display: flex;
  align-items: center;
  justify-content: center;
  position: absolute;
  left: 0;
  top: 0;
  bottom: 0;
  width: 26px;
  border-right: 1px solid #e2e2e2;
  color: #929292;
  font-size: 13px;
  overflow: hidden;
`,F=a.ZP.div`
  position: relative;
  display: ${({expanded:e})=>e?"flex":"inline-flex"};
  border: ${({theme:e})=>`1px solid ${e.colors.middleBeige}`};
  border-radius: 4px;
  transition: border-color 0.2s ease;
  overflow: hidden;

  ${R} + ${G} {
    padding-left: 34px;
  }

  &:focus-within {
    border-color: ${({theme:e})=>e.colors.blue};
  }
`;Object.defineProperty,Object.defineProperties,Object.getOwnPropertyDescriptors,Object.getOwnPropertySymbols,Object.prototype.hasOwnProperty,Object.prototype.propertyIsEnumerable,a.ZP.div`
  justify-content: space-between;
  display: flex;
  align-items: center;

  & > div {
    width: 100%;
  }
`,r(9119),r(1193),r(9429),(0,i.createContext)({current:null});var U=r(3935);const V=a.ZP.div`
  font-family: ${({theme:e})=>e.fontFamily.NunitoSans}, -apple-system, "Neuton", sans-serif;
`,W=a.ZP.button`
  width: 24px;
  height: 24px;
  background-color: ${({theme:e})=>e.colors.middleBlue};
  border-radius: 50%;
  border: none;
  cursor: pointer;
  background-repeat: no-repeat;
  background-position: center;
  outline: none;
  box-sizing: border-box !important;
  padding: 0;
  transition: none;

  &:hover {
    background-color: ${({theme:e})=>e.colors.middleBlue};
  }
`;Object.defineProperty,Object.getOwnPropertySymbols,Object.prototype.hasOwnProperty,Object.prototype.propertyIsEnumerable,(0,a.ZP)(W)`
  background-image: url(${"data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPHN2ZyB3aWR0aD0iMTBweCIgaGVpZ2h0PSIxMHB4IiB2aWV3Qm94PSIwIDAgMTAgMTAiIHZlcnNpb249IjEuMSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB4bWxuczp4bGluaz0iaHR0cDovL3d3dy53My5vcmcvMTk5OS94bGluayI+CiAgICA8dGl0bGU+MTc1NUIyRjctRUQyMy00NzE2LUI0NkYtNDM3NTFBNTI2QUNCPC90aXRsZT4KICAgIDxnIGlkPSJBbGliYWJhLURlbWFuZC1GaW5kZXIiIHN0cm9rZT0ibm9uZSIgc3Ryb2tlLXdpZHRoPSIxIiBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPgogICAgICAgIDxnIGlkPSJBbGliYWJhLURlbWFuZC1GaW5kZXItLS1kZW1hbmQtZmluZGVyLShuby1yZXN1bHRzKSIgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTExNDkuMDAwMDAwLCAtMTc5LjAwMDAwMCkiIGZpbGw9IiNGRkZGRkYiPgogICAgICAgICAgICA8ZyBpZD0iR3JvdXAtNSIgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoMTE0Mi4wMDAwMDAsIDE3Mi4wMDAwMDApIj4KICAgICAgICAgICAgICAgIDxnIGlkPSJpY29uLXN5bmMiIHRyYW5zZm9ybT0idHJhbnNsYXRlKDcuMDAwMDAwLCA3LjAwMDAwMCkiPgogICAgICAgICAgICAgICAgICAgIDxwYXRoIGQ9Ik0wLjQ4Mzg3MDk2OCw1LjgwNjQ1MTYxIEwzLjE4NjY3MzM5LDUuODA2NDUxNjEgQzMuNjE3NzYyMSw1LjgwNjQ1MTYxIDMuODMzNjQ5MTksNi4zMjc2NDExMyAzLjUyODgzMDY1LDYuNjMyNDc5ODQgTDIuNjg3MDk2NzcsNy40NzQyMTM3MSBDMy4zMTczNzkwMyw4LjA2NDM5NTE2IDQuMTM1MzgzMDYsOC4zODc5MDMyMyA1LjAwMzE0NTE2LDguMzg3MTE2OTQgQzYuNTYzOTkxOTQsOC4zODU3MDU2NSA3LjkxMjcyMTc3LDcuMzE1NjY1MzIgOC4yODUxNDExMyw1LjgyOTY3NzQyIEM4LjMxMjIzNzksNS43MjE1NTI0MiA4LjQwODU2ODU1LDUuNjQ1MjAxNjEgOC41MjAwNDAzMiw1LjY0NTIwMTYxIEw5LjY3NTM2MjksNS42NDUyMDE2MSBDOS44MjY1MzIyNiw1LjY0NTIwMTYxIDkuOTQxMzcwOTcsNS43ODI0Mzk1MiA5LjkxMzQwNzI2LDUuOTMxMDA4MDYgQzkuNDc3MTU3MjYsOC4yNDc1IDcuNDQzMjg2MjksMTAgNSwxMCBDMy42NjAzMjI1OCwxMCAyLjQ0MzcyOTg0LDkuNDczMDY0NTIgMS41NDYwNjg1NSw4LjYxNTIyMTc3IEwwLjgyNjAwODA2NSw5LjMzNTI4MjI2IEMwLjUyMTE4OTUxNiw5LjY0MDEwMDgxIDAsOS40MjQyMTM3MSAwLDguOTkzMTI1IEwwLDYuMjkwMzIyNTggQzAsNi4wMjMwODQ2OCAwLjIxNjYzMzA2NSw1LjgwNjQ1MTYxIDAuNDgzODcwOTY4LDUuODA2NDUxNjEgTDAuNDgzODcwOTY4LDUuODA2NDUxNjEgWiBNNy4zMTI5MDMyMywyLjUyNTgwNjQ1IEM2LjY4MjYyMDk3LDEuOTM1NjQ1MTYgNS44NjQ2Nzc0MiwxLjYxMjEzNzEgNC45OTY5MzU0OCwxLjYxMjkwMzIzIEMzLjQzNTI4MjI2LDEuNjE0Mjc0MTkgMi4wODcwOTY3NywyLjY4NTA0MDMyIDEuNzE0ODU4ODcsNC4xNzAzNjI5IEMxLjY4Nzc2MjEsNC4yNzg0ODc5IDEuNTkxNDMxNDUsNC4zNTQ4Mzg3MSAxLjQ3OTk1OTY4LDQuMzU0ODM4NzEgTDAuMzI0NjU3MjU4LDQuMzU0ODM4NzEgQzAuMTczNDg3OTAzLDQuMzU0ODM4NzEgMC4wNTg2NDkxOTM1LDQuMjE3NjAwODEgMC4wODY2MTI5MDMyLDQuMDY5MDMyMjYgQzAuNTIyODQyNzQyLDEuNzUyNSAyLjU1NjcxMzcxLDAgNSwwIEM2LjMzOTY3NzQyLDAgNy41NTYyNzAxNiwwLjUyNjkzNTQ4NCA4LjQ1MzkzMTQ1LDEuMzg0Nzc4MjMgTDkuMTczOTkxOTQsMC42NjQ3MTc3NDIgQzkuNDc4ODEwNDgsMC4zNTk4OTkxOTQgMTAsMC41NzU3ODYyOSAxMCwxLjAwNjg3NSBMMTAsMy43MDk2Nzc0MiBDMTAsMy45NzY5MTUzMiA5Ljc4MzM2Njk0LDQuMTkzNTQ4MzkgOS41MTYxMjkwMyw0LjE5MzU0ODM5IEw2LjgxMzMyNjYxLDQuMTkzNTQ4MzkgQzYuMzgyMjM3OSw0LjE5MzU0ODM5IDYuMTY2MzUwODEsMy42NzIzNTg4NyA2LjQ3MTE2OTM1LDMuMzY3NTIwMTYgTDcuMzEyOTAzMjMsMi41MjU4MDY0NSBaIiBpZD0iRmlsbC0xIj48L3BhdGg+CiAgICAgICAgICAgICAgICA8L2c+CiAgICAgICAgICAgIDwvZz4KICAgICAgICA8L2c+CiAgICA8L2c+Cjwvc3ZnPg=="});
  transition: 200ms linear;
  transition-duration: 0.2s;
  margin-right: 8px;

  &:active {
    transform: rotate(-180deg);
    transition: 0s;
  }
`,(0,a.ZP)(W)`
  background-image: url(${"data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPHN2ZyB3aWR0aD0iMTBweCIgaGVpZ2h0PSIxMHB4IiB2aWV3Qm94PSIwIDAgMTAgMTAiIHZlcnNpb249IjEuMSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB4bWxuczp4bGluaz0iaHR0cDovL3d3dy53My5vcmcvMTk5OS94bGluayI+CiAgICA8dGl0bGU+NUM4NjIyMUMtOTg0MC00RjE1LTk0OEItMzU0QzJFRTU5MDlCPC90aXRsZT4KICAgIDxkZWZzPgogICAgICAgIDxmaWx0ZXIgaWQ9ImZpbHRlci0xIj4KICAgICAgICAgICAgPGZlQ29sb3JNYXRyaXggaW49IlNvdXJjZUdyYXBoaWMiIHR5cGU9Im1hdHJpeCIgdmFsdWVzPSIwIDAgMCAwIDEuMDAwMDAwIDAgMCAwIDAgMS4wMDAwMDAgMCAwIDAgMCAxLjAwMDAwMCAwIDAgMCAxLjAwMDAwMCAwIj48L2ZlQ29sb3JNYXRyaXg+CiAgICAgICAgPC9maWx0ZXI+CiAgICAgICAgPHBvbHlnb24gaWQ9InBhdGgtMiIgcG9pbnRzPSIwIC0xLjQ3MjYyNzQzZS0xNSA5Ljk1MzM2Nzg4IC0xLjQ3MjYyNzQzZS0xNSA5Ljk1MzM2Nzg4IDkuOTUzMzU3NTEgMCA5Ljk1MzM1NzUxIj48L3BvbHlnb24+CiAgICA8L2RlZnM+CiAgICA8ZyBpZD0iQWxpYmFiYS1EZW1hbmQtRmluZGVyIiBzdHJva2U9Im5vbmUiIHN0cm9rZS13aWR0aD0iMSIgZmlsbD0ibm9uZSIgZmlsbC1ydWxlPSJldmVub2RkIj4KICAgICAgICA8ZyBpZD0iQWxpYmFiYS1EZW1hbmQtRmluZGVyLS0tbG9nZ2VkLWluLShhZnRlci1zZWFyY2gtb24tYWxpYmFiYS1saW1pdC1yZWFjaGVkLW1vZGFsKSIgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTEwNDMuMDAwMDAwLCAtMTEzLjAwMDAwMCkiPgogICAgICAgICAgICA8ZyBpZD0iR3JvdXAtNyIgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoMzU3LjAwMDAwMCwgODIuMDAwMDAwKSI+CiAgICAgICAgICAgICAgICA8ZyBpZD0iR3JvdXAtNCIgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoNjc5LjAwMDAwMCwgMjQuMDAwMDAwKSI+CiAgICAgICAgICAgICAgICAgICAgPGcgaWQ9Ikdyb3VwLTMiIHRyYW5zZm9ybT0idHJhbnNsYXRlKDcuMDAwMDAwLCA3LjAwMDAwMCkiIGZpbHRlcj0idXJsKCNmaWx0ZXItMSkiPgogICAgICAgICAgICAgICAgICAgICAgICA8Zz4KICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxtYXNrIGlkPSJtYXNrLTMiIGZpbGw9IndoaXRlIj4KICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dXNlIHhsaW5rOmhyZWY9IiNwYXRoLTIiPjwvdXNlPgogICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9tYXNrPgogICAgICAgICAgICAgICAgICAgICAgICAgICAgPGcgaWQ9IkNsaXAtMiI+PC9nPgogICAgICAgICAgICAgICAgICAgICAgICAgICAgPHBhdGggZD0iTTkuNzc0NTkwNjcsMS40Njg5MDE1NSBMNi4yNjY4NzA0Nyw0Ljk3NjY3MzU4IEw5Ljc3NDU5MDY3LDguNDg0NDQ1NiBDMTAuMDEyOTg0NSw4LjcyMjc4NzU2IDEwLjAxMjk4NDUsOS4xMDYyMDcyNSA5Ljc3NDU5MDY3LDkuMzQ0NTQ5MjIgTDkuMzQ0NTM4ODYsOS43NzQ2MDEwNCBDOS4xMDYyNDg3LDEwLjAxMjk0MyA4LjcyMjc3NzIsMTAuMDEyOTQzIDguNDg0NDg3MDUsOS43NzQ2MDEwNCBMNC45NzY2NjMyMSw2LjI2Njg4MDgzIEwxLjQ2ODg5MTE5LDkuNzc0NjAxMDQgQzEuMjMwNjAxMDQsMTAuMDEyOTQzIDAuODQ3MTI5NTM0LDEwLjAxMjk0MyAwLjYwODgzOTM3OCw5Ljc3NDYwMTA0IEwwLjE3ODczNTc1MSw5LjM0NDU0OTIyIEMtMC4wNTk2MDYyMTc2LDkuMTA2MjA3MjUgLTAuMDU5NjA2MjE3Niw4LjcyMjc4NzU2IDAuMTc4NzM1NzUxLDguNDg0NDQ1NiBMMy42ODY1MDc3Nyw0Ljk3NjY3MzU4IEwwLjE3ODczNTc1MSwxLjQ2ODkwMTU1IEMtMC4wNTk2MDYyMTc2LDEuMjMwNTU5NTkgLTAuMDU5NjA2MjE3NiwwLjg0NzEzOTg5NiAwLjE3ODczNTc1MSwwLjYwODc5NzkyNyBMMC42MDg4MzkzNzgsMC4xNzg3NDYxMTQgQzAuODQ3MTI5NTM0LC0wLjA1OTU5NTg1NDkgMS4yMzA2MDEwNCwtMC4wNTk1OTU4NTQ5IDEuNDY4ODkxMTksMC4xNzg3NDYxMTQgTDQuOTc2NjYzMjEsMy42ODY1MTgxMyBMOC40ODQ0ODcwNSwwLjE3ODc0NjExNCBDOC43MjI3NzcyLC0wLjA1OTU5NTg1NDkgOS4xMDYyNDg3LC0wLjA1OTU5NTg1NDkgOS4zNDQ1Mzg4NiwwLjE3ODc0NjExNCBMOS43NzQ1OTA2NywwLjYwODc5NzkyNyBDMTAuMDA3NzUxMywwLjg0NzEzOTg5NiAxMC4wMDc3NTEzLDEuMjMwNTU5NTkgOS43NzQ1OTA2NywxLjQ2ODkwMTU1IiBpZD0iRmlsbC0xIiBmaWxsPSIjMDAwMDAwIiBtYXNrPSJ1cmwoI21hc2stMykiPjwvcGF0aD4KICAgICAgICAgICAgICAgICAgICAgICAgPC9nPgogICAgICAgICAgICAgICAgICAgIDwvZz4KICAgICAgICAgICAgICAgIDwvZz4KICAgICAgICAgICAgPC9nPgogICAgICAgIDwvZz4KICAgIDwvZz4KPC9zdmc+"});
`,(0,a.ZP)(W)`
  transition: 300ms linear;
  background-image: url(${({active:e})=>e?"data:image/svg+xml;base64,PHN2ZyB2ZXJzaW9uPSIxLjEiIGlkPSJDYXBhXzEiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgeG1sbnM6eGxpbms9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkveGxpbmsiIHg9IjBweCIKICAgICB5PSIwcHgiCiAgICAgd2lkdGg9IjQzOC41MjlweCIgaGVpZ2h0PSI0MzguNTI5cHgiIHZpZXdCb3g9IjAgMCA0MzguNTI5IDQzOC41MjkiCiAgICAgc3R5bGU9ImVuYWJsZS1iYWNrZ3JvdW5kOm5ldyAwIDAgNDM4LjUyOSA0MzguNTI5OyIKICAgICB4bWw6c3BhY2U9InByZXNlcnZlIj4KPGc+Cgk8Zz4KCQk8cGF0aCBmaWxsPSIjZmZmIiBkPSJNMTgwLjE1NiwyMjUuODI4Yy0xLjkwMy0xLjkwMi00LjA5My0yLjg1NC02LjU2Ny0yLjg1NGMtMi40NzUsMC00LjY2NSwwLjk1MS02LjU2NywyLjg1NGwtOTQuNzg3LDk0Ljc4N2wtNDEuMTEyLTQxLjExNwoJCQljLTMuNjE3LTMuNjEtNy44OTUtNS40MjEtMTIuODQ3LTUuNDIxYy00Ljk1MiwwLTkuMjM1LDEuODExLTEyLjg1MSw1LjQyMWMtMy42MTcsMy42MjEtNS40MjQsNy45MDUtNS40MjQsMTIuODU0djEyNy45MDcKCQkJYzAsNC45NDgsMS44MDcsOS4yMjksNS40MjQsMTIuODQ3YzMuNjE5LDMuNjEzLDcuOTAyLDUuNDI0LDEyLjg1MSw1LjQyNGgxMjcuOTA2YzQuOTQ5LDAsOS4yMy0xLjgxMSwxMi44NDctNS40MjQKCQkJYzMuNjE1LTMuNjE3LDUuNDI0LTcuODk4LDUuNDI0LTEyLjg0N3MtMS44MDktOS4yMzMtNS40MjQtMTIuODU0bC00MS4xMTItNDEuMTA0bDk0Ljc4Ny05NC43OTMKCQkJYzEuOTAyLTEuOTAzLDIuODUzLTQuMDg2LDIuODUzLTYuNTY0YzAtMi40NzgtMC45NTMtNC42Ni0yLjg1My02LjU3TDE4MC4xNTYsMjI1LjgyOHoiLz4KICAgICAgICA8cGF0aCBmaWxsPSIjZmZmIiBkPSJNNDMzLjExLDUuNDI0QzQyOS40OTYsMS44MDcsNDI1LjIxMiwwLDQyMC4yNjMsMEgyOTIuMzU2Yy00Ljk0OCwwLTkuMjI3LDEuODA3LTEyLjg0Nyw1LjQyNAoJCQljLTMuNjE0LDMuNjE1LTUuNDIxLDcuODk4LTUuNDIxLDEyLjg0N3MxLjgwNyw5LjIzMyw1LjQyMSwxMi44NDdsNDEuMTA2LDQxLjExMmwtOTQuNzg2LDk0Ljc4NwoJCQljLTEuOTAxLDEuOTA2LTIuODU0LDQuMDkzLTIuODU0LDYuNTY3czAuOTUzLDQuNjY1LDIuODU0LDYuNTY3bDMyLjU1MiwzMi41NDhjMS45MDIsMS45MDMsNC4wODYsMi44NTMsNi41NjMsMi44NTMKCQkJczQuNjYxLTAuOTUsNi41NjMtMi44NTNsOTQuNzk0LTk0Ljc4N2w0MS4xMDQsNDEuMTA5YzMuNjIsMy42MTYsNy45MDUsNS40MjgsMTIuODU0LDUuNDI4czkuMjI5LTEuODEyLDEyLjg0Ny01LjQyOAoJCQljMy42MTQtMy42MTQsNS40MjEtNy44OTgsNS40MjEtMTIuODQ3VjE4LjI2OEM0MzguNTMsMTMuMzE1LDQzNi43MzQsOS4wNCw0MzMuMTEsNS40MjR6Ii8+Cgk8L2c+CjwvZz4KPC9zdmc+Cg==":"data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPHN2ZyB3aWR0aD0iMTBweCIgaGVpZ2h0PSIxMHB4IiB2aWV3Qm94PSIwIDAgMTAgMTAiIHZlcnNpb249IjEuMSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB4bWxuczp4bGluaz0iaHR0cDovL3d3dy53My5vcmcvMTk5OS94bGluayI+CiAgICA8dGl0bGU+REM0Mzk0Q0MtQ0JCRS00NDM3LTg3N0ItRkVGQzZCN0IzQzE5PC90aXRsZT4KICAgIDxnIGlkPSJBbGliYWJhLURlbWFuZC1GaW5kZXIiIHN0cm9rZT0ibm9uZSIgc3Ryb2tlLXdpZHRoPSIxIiBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPgogICAgICAgIDxnIGlkPSJBbGliYWJhLURlbWFuZC1GaW5kZXItLS1kZW1hbmQtZmluZGVyLShuby1yZXN1bHRzKSIgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTExODEuMDAwMDAwLCAtMTc5LjAwMDAwMCkiIGZpbGw9IiNGRkZGRkYiPgogICAgICAgICAgICA8ZyBpZD0iR3JvdXAtNSIgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoMTE0Mi4wMDAwMDAsIDE3Mi4wMDAwMDApIj4KICAgICAgICAgICAgICAgIDxnIGlkPSJHcm91cC0zIiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgzMi4wMDAwMDAsIDAuMDAwMDAwKSI+CiAgICAgICAgICAgICAgICAgICAgPGcgaWQ9Imljb24tc2hyaW5rIiB0cmFuc2Zvcm09InRyYW5zbGF0ZSg3LjAwMDAwMCwgNy4wMDAwMDApIj4KICAgICAgICAgICAgICAgICAgICAgICAgPHBhdGggZD0iTTkuODk1NDAxNzksMS4xNzYwMjY3OSBMNy42Nzg1NzE0MywzLjM5Mjg1NzE0IEw4LjQxMzQxNTE4LDQuMDg1NDY4NzUgQzguNzUwOTM3NSw0LjQyMjk2ODc1IDguNTExOTE5NjQsNSA4LjAzNDY0Mjg2LDUgTDUuNTM0NjQyODYsNSBDNS4yMzg3NzIzMiw1IDUsNC43NjAxNTYyNSA1LDQuNDY0Mjg1NzEgTDUsMS45NjQyODU3MSBDNSwxLjQ4NzAwODkzIDUuNTc1OTM3NSwxLjI0Nzk5MTA3IDUuOTEzNDE1MTgsMS41ODU0Njg3NSBMNi42MDcxNDI4NiwyLjMyMTQyODU3IEw4LjgyMzk3MzIxLDAuMTA0NTk4MjE0IEM4Ljk2MzQxNTE4LC0wLjAzNDg2NjA3MTQgOS4xODk1NzU4OSwtMC4wMzQ4NjYwNzE0IDkuMzI5MDQwMTgsMC4xMDQ1OTgyMTQgTDkuODk1NDAxNzksMC42NzA5NTk4MjEgQzEwLjAzNDg0MzgsMC44MTA0MjQxMDcgMTAuMDM0ODQzOCwxLjAzNjU2MjUgOS44OTU0MDE3OSwxLjE3NjAyNjc5IE0wLjEwNDU5ODIxNCw4LjgyMzk3MzIxIEwyLjMyMTQyODU3LDYuNjA3MTQyODYgTDEuNTg2NTYyNSw1LjkxNDUzMTI1IEMxLjI0OTA2MjUsNS41NzcwMzEyNSAxLjQ4ODA4MDM2LDUgMS45NjUzMzQ4Miw1IEw0LjQ2NTMzNDgyLDUgQzQuNzYxMjI3NjgsNSA1LDUuMjM5ODQzNzUgNSw1LjUzNTcxNDI5IEw1LDguMDM1NzE0MjkgQzUsOC41MTI5OTEwNyA0LjQyNDAxNzg2LDguNzUyMDA4OTMgNC4wODY1NjI1LDguNDE0NTMxMjUgTDMuMzkyODU3MTQsNy42Nzg1NzE0MyBMMS4xNzYwMjY3OSw5Ljg5NTQwMTc5IEMxLjAzNjU2MjUsMTAuMDM0ODQzNyAwLjgxMDQyNDEwNywxMC4wMzQ4NDM3IDAuNjcwOTU5ODIxLDkuODk1NDAxNzkgTDAuMTA0NTk4MjE0LDkuMzI5MDQwMTggQy0wLjAzNDg2NjA3MTQsOS4xODk1NzU4OSAtMC4wMzQ4NjYwNzE0LDguOTYzNDM3NSAwLjEwNDU5ODIxNCw4LjgyMzk3MzIxIiBpZD0iRmlsbC0xIj48L3BhdGg+CiAgICAgICAgICAgICAgICAgICAgPC9nPgogICAgICAgICAgICAgICAgPC9nPgogICAgICAgICAgICA8L2c+CiAgICAgICAgPC9nPgogICAgPC9nPgo8L3N2Zz4="});
  background-size: 10px;
  transform: rotate(${e=>e.active?"360deg":"90deg"});
  margin-right: 8px;
`,a.ZP.div`
  display: flex;
`;var q=r(9101),Y=r(2694);const Q=new Y.Z({en:{plans:{Helium10_ALaCarte:"A La Carte",Helium10_ALaCarteAnnual:"A La Carte",Helium10_Diamond:"Diamond",Helium10_DiamondAnnual:"Diamond",Helium10_Elite:"Elite",Helium10_Free:"Free",Helium10_Gold:"Gold",Helium10_GoldAnnual:"Gold",Helium10_Platinum:"Platinum",Helium10_PlatinumAnnual:"Platinum",Helium10_Platinum_FastAction:"Platinum",Helium10_Starter:"Starter",Helium10_StarterAnnual:"Starter",Helium10_Enterprise:"Enterprise"},common:{month:"mo",freeLaunchesLeft:"Free launches left:",pleaseWait:"Loading Product Data",verified:"Verified",selected:"Selected"},placeholders:{min:"Min",max:"Max",anyKeyword:"Enter any keyword..."},errors:{default:{required:"This field is required",min:"This field requires min value",minLength:"This field requires min length",noData:"Data is not available. Please try again later.",limit:"You’ve run into your backend limit to access Historical Sales data. Please contact Support for more information."},minMax:{validate:"Min should be less than Max",required:"This field is required",min:"This field requires min value",minLength:"This field requires min length"}},buttons:{upgrade:"Upgrade",noThanks:"No, thanks",upgradeForUnlimited:"Upgrade for unlimited",seeAnalysis:"See analysis",show:"Show",hide:"Hide",cancel:"Cancel",rateUs:"Rate Us",notNow:"Not Now",switchLanguage:"Switch Language",no:"No",yes:"Yes",understand:"I understand"},upgrade:{discount:{title:"You've used up your 50 free launches",subTitle:"Unlock access to Xray and other great tools for <b>{discount}% off</b> your first month",subTitleWalmart:"Use code for <b>{discount}%  off</b> your 1st month of Diamond"},title:"Upgrade now for full access to the Chrome Extension",titleWalmart:"Need more Walmart insights?",subTitle:"Get unlimited launches for Xray, Demand Analyzer, and much more",essentialFeatures:"Full access to these essential features:",essentialFeaturesWalmart:"For a very limited time unlock:",proposals:{chromeExtension:"Unlimited Access to the Chrome Extension",freedomTicket:"Freedom Ticket Amazon Training Course",blackBox:"Black Box Product Research",trendster:"Trendster Amazon Trends Finder",magnet:"Magnet<sup>2</sup> &nbsp; Keyword Research",scribbles:"Scribbles Listing Optimizer",indexChecker:"Index Checker"},proposalsWalmart:{chromeExtension:"Unlimited Xray for Walmart launches",magnet:"Unlimited Magnet<sup>2</sup> &nbsp; for Walmart launches",cerebro:"Unlimited Cerebro for Walmart launches",profits:"Unlimited access to Profits for Walmart",sorting:"Unlimited access to advanced sorting & filtering",more:"More future Walmart tools and features"}},subscriptionRequired:{title:"Subscription required",text:"Historical Search Volume is only available to subscribed Helium 10 members. Please upgrade to the one of our plans for unlimited access"},notFoundResult:{title:"No results found",text:"Please go back and try searching with another keyword",buttonText:"Back to Alibaba"},modals:{rateUsHeader:"Like using Helium 10 Extension?",rateUsLike:"I like to use the extension. I really use all the functionality of the extension.",rateUsDislike:"I don't like working with the extension, I don't like how it develops and its functionality",rateUsNegativeHeader:"Thanks for your feedback!",rateUsPositiveHeader:"Thanks You",rateUsMessage:"We are trying to improve and refine our application, your feedback will help us with this. If you have any suggestions on how to make our extension better, you can contact support.",rateUsPositiveMessage:"We are so happy to hear that you like our extension! It would be super helpful if you rate us. Thanks",localizationHeader:"New languages for extension",localizationMessage:"The extension is now available in the language of your browser. All available languages can be viewed in the settings. Change the language to yours? Page will be reloaded.",notShowAgain:"Don't show again"},hour:{one:"Hour",other:"Hours"},day:{one:"Day",other:"Days"},year:{one:"Year",other:"Years"},allTime:"All Time",localizationModal:{header:"New languages available now",message:"We are happy to announce Chrome Extension language support in German, Italian, and Spanish. Switch your language preference at any time in Settings.",notShowAgain:"Don't show again"},charts:{time:"Time",price:"Price",rank:"Rank",rating:"Rating",salesRank:"Sales Rank",newPrice:"New Price",listPrice:"List Price",values:"Values",sales:"Sales",trendLine:"Trend Line",movingAverage:"7-Day Moving Average",reviews:"Reviews",numberOfReviews:"Number of Reviews",searchVolume:"Search Volume",reviewCount:"Review Count",downloads:{csv:"Download CSV",xls:"Download XLS",png:"Download PNG image",jpeg:"Download JPEG image"},resetZoom:"Reset Zoom"}},de:{plans:{Helium10_ALaCarte:"A La Carte",Helium10_ALaCarteAnnual:"A La Carte",Helium10_Diamond:"Diamond",Helium10_DiamondAnnual:"Diamond",Helium10_Elite:"Elite",Helium10_Free:"Free",Helium10_Gold:"Gold",Helium10_GoldAnnual:"Gold",Helium10_Platinum:"Platinum",Helium10_PlatinumAnnual:"Platinum",Helium10_Platinum_FastAction:"Platinum",Helium10_Starter:"Starter",Helium10_StarterAnnual:"Starter",Helium10_Enterprise:"Enterprise"},common:{month:"Mon",freeLaunchesLeft:"Verbleibende kostenlose Suchanfragen:",pleaseWait:"Produktdaten werden geladen",verified:"Verifiziert",selected:"Ausgewählt"},placeholders:{min:"Min",max:"Max",anyKeyword:"Geben Sie ein beliebiges Keyword ein …"},errors:{default:{required:"Dieses Feld erfordert eine Angabe",min:"Dieses Feld erfordert einen Mindestwert",minLength:"Dieses Feld erfordert eine Mindestlänge",noData:"Daten sind nicht verfügbar. Bitte versuchen Sie es später erneut.",limit:"Sie haben Ihr Back-End-Limit für den Zugriff auf historische Verkaufsdaten überschritten. Bitte kontaktieren Sie den Support für weitere Informationen."},minMax:{validate:"Min sollte kleiner als Max sein",required:"Dieses Feld erfordert eine Angabe",min:"Dieses Feld erfordert einen Mindestwert",minLength:"Dieses Feld erfordert eine Mindestlänge"}},buttons:{upgrade:"Upgrade",noThanks:"Nein, danke",upgradeForUnlimited:"Upgrade auf Unbegrenzt",seeAnalysis:"Analyse ansehen",show:"Anzeigen",hide:"Ausblenden",cancel:"Abbrechen",rateUs:"Bewerten Sie uns.",notNow:"Nicht jetzt",switchLanguage:"Sprache wechseln",no:"Nein",yes:"Ja",understand:"Ich verstehe"},upgrade:{discount:{title:"Sie haben Ihre 50 kostenlosen Suchanfragen aufgebraucht",subTitle:"Schalten Sie den Zugang zu Xray und anderen tollen Tools frei, mit <b>{discount}% Rabatt</b> im ersten Monat",subTitleWalmart:"Verwenden Sie den Code für <b> {discount} % </b> Ihren ersten Monat Diamond"},title:"Erwerben Sie jetzt ein Upgrade für vollen Zugriff auf die Chrome-Erweiterung",subTitle:"Erhalten Sie unbegrenzten Zugriff auf Xray, Demand Analyzer und vieles mehr",essentialFeatures:"Voller Zugriff auf diese wesentlichen Funktionen:",proposals:{chromeExtension:"Unbegrenzter Zugriff auf die Chrome-Erweiterung",freedomTicket:"Freedom Ticket Amazon-Trainingskurs",blackBox:"Black Box Produktrecherche",trendster:"Trendster Amazon Trend-Recherche",magnet:"Magnet<sup>2</sup> &nbsp; Keyword-Recherche",scribbles:"Scribbles Listing-Optimierer",indexChecker:"Index-Prüfer"},titleWalmart:"Benötigen Sie weitere Walmart-Einblicke?",essentialFeaturesWalmart:"Für eine sehr begrenzte Zeit freischalten:",proposalsWalmart:{chromeExtension:"Unbegrenzte Markteinführungen von Xray für Walmart",magnet:"Unbegrenzter Magnet <sup>2</sup> &nbsp; für Walmart-Starts",cerebro:"Unbegrenzter Cerebro für Walmart-Starts",profits:"Unbegrenzter Zugang zu Profits für Walmart",sorting:"Unbegrenzter Zugriff auf erweiterte Sortier- und Filterfunktionen",more:"Weitere zukünftige Walmart-Tools und -Funktionen"}},subscriptionRequired:{title:"Abonnement erforderlich",text:"Suchvolumen-Verlauf ist nur für Helium 10 Mitglieder im Abonnement verfügbar. Bitte upgraden Sie auf einen unserer Tarife für unbegrenzten Zugriff"},notFoundResult:{title:"Keine Ergebnisse gefunden",text:"Bitte gehen Sie zurück und versuchen Sie es mit einem anderen Keyword",buttonText:"Zurück zu Alibaba"},hour:{one:"Stunde",other:"Stunden"},day:{one:"Tag",other:"Tage"},year:{one:"Jahr",other:"Jahre"},allTime:"Alle Zeit",localizationModal:{header:"Neue Sprachen sind jetzt verfügbar",message:"Wir freuen uns, die Sprachunterstützung der Chrome-Erweiterung in Deutsch, Italienisch und Spanisch ankündigen zu können. Ändern Sie Ihre Spracheinstellung jederzeit in den Einstellungen.",notShowAgain:"Nicht mehr anzeigen"},charts:{time:"Zeit",price:"Preis",rank:"Rang",rating:"Bewertung",salesRank:"Verkaufsrang",newPrice:"Neuer Preis",listPrice:"List-Preis",values:"Werte",sales:"Absatz",trendLine:"Trendlinie",movingAverage:"Gleitender 7-Tage-Durchschnitt",reviews:"Bewertungen",numberOfReviews:"Anzahl der Bewertungen",searchVolume:"Suchvolumen",reviewCount:"Bewertungsanzahl",downloads:{csv:"CSV-Bericht herunterladen",xls:"XLS herunterladen",png:"PNG-Bild herunterladen",jpeg:"JPEG-Bild herunterladen"},resetZoom:"Zoom zurücksetzen"},modals:{rateUsHeader:"Like using Helium 10 Extension?",rateUsLike:"I like to use the extension. I really use all the functionality of the extension.",rateUsDislike:"I don't like working with the extension, I don't like how it develops and its functionality",rateUsNegativeHeader:"Thanks for your feedback!",rateUsPositiveHeader:"Thanks You",rateUsMessage:"We are trying to improve and refine our application, your feedback will help us with this. If you have any suggestions on how to make our extension better, you can contact support.",rateUsPositiveMessage:"We are so happy to hear that you like our extension! It would be super helpful if you rate us. Thanks",localizationHeader:"New languages for extension",localizationMessage:"The extension is now available in the language of your browser. All available languages can be viewed in the settings. Change the language to yours? Page will be reloaded.",notShowAgain:"Don't show again"}},es:{plans:{Helium10_ALaCarte:"A La Carte",Helium10_ALaCarteAnnual:"A La Carte",Helium10_Diamond:"Diamond",Helium10_DiamondAnnual:"Diamond",Helium10_Elite:"Elite",Helium10_Free:"Free",Helium10_Gold:"Gold",Helium10_GoldAnnual:"Gold",Helium10_Platinum:"Platinum",Helium10_PlatinumAnnual:"Platinum",Helium10_Platinum_FastAction:"Platinum",Helium10_Starter:"Starter",Helium10_StarterAnnual:"Starter",Helium10_Enterprise:"Entreprise"},common:{month:"me",freeLaunchesLeft:"Usos libres restantes:",pleaseWait:"Cargando datos del producto",verified:"Verificado",selected:"Seleccionado"},placeholders:{min:"Mín",max:"Máx",anyKeyword:"Ingresa cualquier palabra clave..."},errors:{default:{required:"Este campo es obligatorio",min:"Este campo requiere un valor Mín",minLength:"Este campo requiere una longitud Mín",noData:"Los datos no están disponibles, por favor, intenta de nuevo después.",limit:"Se ha topado con su límite de backend para acceder a los datos de ventas históricas. Comuníquese con Soporte para obtener más información."},minMax:{validate:"Mín debe ser menor a Máx",required:"Este campo es obligatorio",min:"Este campo requiere un valor Mín",minLength:"Este campo requiere una longitud Mín"}},buttons:{upgrade:"Ampliar",noThanks:"No, gracias",upgradeForUnlimited:"Ampliar al plan ilimitado",seeAnalysis:"Ver análisis",show:"Mostrar",hide:"Ocultar",cancel:"Cancelar",rateUs:"Califícanos",notNow:"Ahora no",switchLanguage:"Cambiar idioma",no:"No",yes:"Sí",understand:"Entiendo"},upgrade:{discount:{title:"Has agotado tus 50 usos libres",subTitle:"Desbloquea el acceso a Xray y otras herramientas buenísimas para un <b>{discount}%</b> de descuento el primer mes",subTitleWalmart:"Use el código para obtener un <b> {discount} % de descuento </b> su primer mes de Diamond"},title:"Ampliar ahora para tener acceso total a la extensión de Chrome",subTitle:"Obtén usos ilimitados a Xray, Demand Analyzer y mucho más",essentialFeatures:"Acceso total a estas funciones esenciales:",proposals:{chromeExtension:"Acceso ilimitado a la extensión de Chrome",freedomTicket:"Acceso libre al curso de capacitación de Amazon",blackBox:"Búsqueda de productos con Black Box",trendster:"Búsqueda de tendencias con Amazon Trendster",magnet:"Magnet<sup>2</sup> &nbsp; Búsqueda de palabras clave",scribbles:"Optimizador de listings con Scribbles",indexChecker:"Verificación con Index Checker"},titleWalmart:"¿Necesita más información sobre Walmart?",essentialFeaturesWalmart:"Desbloquear por un tiempo muy limitado:",proposalsWalmart:{chromeExtension:"Lanzamientos ilimitados de Xray para Walmart",magnet:"Magnet<sup>2</sup> &nbsp; ilimitado para los lanzamientos de Walmart",cerebro:"Lanzamientos ilimitados de Cerebro para Walmart",profits:"Acceso ilimitado a Profits para Walmart",sorting:"Acceso ilimitado a la clasificación y el filtrado avanzados",more:"Más herramientas y funciones futuras de Walmart"}},subscriptionRequired:{title:"Se necesita suscripción",text:"El historial de volumen de búsqueda está disponible solo para miembros suscritos de Helium 10. Por favor, amplia a uno de nuestros planes para tener acceso ilimitado"},notFoundResult:{title:"No se hallaron resultados",text:"Por favor, regresa e intenta buscar con otra palabra clave",buttonText:"Volver a Alibaba"},hour:{one:"hora",other:"horas"},day:{one:"día",other:"dias"},year:{one:"año",other:"años"},allTime:"Todo el tiempo",localizationModal:{header:"Nuevos idiomas disponibles ahora",message:"Nos complace anunciar que la extensión de Chrome es compatible con los idiomas alemán, italiano y español. Cambie su preferencia de idioma en cualquier momento en la Configuración.",notShowAgain:"No volver a mostrar"},charts:{time:"Tiempo",price:"Precio",rank:"Rango",rating:"Calificación",salesRank:"Rango de ventas",newPrice:"Nuevo precio",listPrice:"Precio de lista",values:"Valores",sales:"Ventas",trendLine:"Línea de tendencia",movingAverage:"Media móvil de 7 días",reviews:"Reseñas",numberOfReviews:"Número de reseñas",searchVolume:"Volumen de búsqueda",reviewCount:"Cuenta de reseñas",downloads:{csv:"Descargar informe CSV",xls:"Descarga XLS",png:"Descargar imagen PNG",jpeg:"Descargar imagen JPEG"},resetZoom:"Restablecer zoom"},modals:{rateUsHeader:"Like using Helium 10 Extension?",rateUsLike:"I like to use the extension. I really use all the functionality of the extension.",rateUsDislike:"I don't like working with the extension, I don't like how it develops and its functionality",rateUsNegativeHeader:"Thanks for your feedback!",rateUsPositiveHeader:"Thanks You",rateUsMessage:"We are trying to improve and refine our application, your feedback will help us with this. If you have any suggestions on how to make our extension better, you can contact support.",rateUsPositiveMessage:"We are so happy to hear that you like our extension! It would be super helpful if you rate us. Thanks",localizationHeader:"New languages for extension",localizationMessage:"The extension is now available in the language of your browser. All available languages can be viewed in the settings. Change the language to yours? Page will be reloaded.",notShowAgain:"Don't show again"}},it:{plans:{Helium10_ALaCarte:"A La Carte",Helium10_ALaCarteAnnual:"A La Carte",Helium10_Diamond:"Diamond",Helium10_DiamondAnnual:"Diamond",Helium10_Elite:"Elite",Helium10_Free:"Free",Helium10_Gold:"Gold",Helium10_GoldAnnual:"Gold",Helium10_Platinum:"Platinum",Helium10_PlatinumAnnual:"Platinum",Helium10_Platinum_FastAction:"Platinum",Helium10_Starter:"Starter",Helium10_StarterAnnual:"Starter",Helium10_Enterprise:"Enterprise"},common:{month:"m",freeLaunchesLeft:"Lanci gratuiti rimasti:",pleaseWait:"Caricamento dei dati del prodotto",verified:"Verificato",selected:"Selezionato"},placeholders:{min:"Min",max:"Max",anyKeyword:"Inserisci una parola chiave..."},errors:{default:{required:"Campo necessario",min:"Questo campo richiede un valore minimo",minLength:"Questo campo richiede una lunghezza minima",noData:"I dati non sono disponibili, riprova più tardi.",limit:"Hai raggiunto il limite del tuo backend per accedere ai dati storici delle vendite. Si prega di contattare il supporto per ulteriori informazioni."},minMax:{validate:"Min dovrebbe essere inferiore a Max",required:"Campo necessario",min:"Questo campo richiede un valore minimo",minLength:"Questo campo richiede una lunghezza minima"}},buttons:{upgrade:"Esegui l'upgrade",noThanks:"No, grazie",upgradeForUnlimited:"Esegui l'upgrade per avere accesso illimitato",seeAnalysis:"Visualizza analisi",show:"Mostra",hide:"Nascondi",cancel:"Annulla",rateUs:"Dai un voto",notNow:"Non adesso",switchLanguage:"Cambia lingua",no:"No",yes:"Sì",understand:"Capisco"},upgrade:{discount:{title:"Hai esaurito i tuoi 50 lanci gratuiti",subTitle:"Ottieni l'accesso a Xray e altri fantastici strumenti con uno <b> sconto del {discount}% </b> il primo mese",subTitleWalmart:"Usa il codice per <b> {discount} % di sconto </b> tuo primo mese di Diamond"},title:"Esegui l'upgrade ora per l'accesso completo all'estensione di Chrome",subTitle:"Ottieni lanci illimitati per Xray, Demand Analyzer e tanto altro",essentialFeatures:"Accesso completo a questi strumenti indispensabili:",proposals:{chromeExtension:"Accesso illimitato all'estensione di Chrome",freedomTicket:"Corso di formazione Amazon Freedom Ticket",blackBox:"Ricerca dei prodotti con Black Box",trendster:"Ricerca degli Amazon Trends con Trendster",magnet:"Ricerca di parole chiave via Magnet<sup>2</sup> &nbsp;",scribbles:"Ottimizzazione dei listing con Scribbles",indexChecker:"Index Checker"},titleWalmart:"Hai bisogno di ulteriori informazioni su Walmart?",essentialFeaturesWalmart:"Sblocca Per un tempo molto limitato:",proposalsWalmart:{chromeExtension:"Lanci illimitati per Xray per Walmart",magnet:"Magnet<sup>2</sup> &nbsp; illimitato per i lanci Walmart",cerebro:"Lanci illimitati di Cerebro per Walmart",profits:"Accesso illimitato ai Profits per Walmart",sorting:"Accesso illimitato all'ordinamento e al filtraggio avanzati",more:"Altri futuri strumenti e funzionalità Walmart"}},subscriptionRequired:{title:"Accesso richiesto",text:"La cronologia del volume di ricerca è disponibile solo per gli abbonati ad Helium 10. Passa ad uno dei nostri piani per un accesso senza restrizioni"},notFoundResult:{title:"Nessun risultato trovato",text:"Torna indietro e prova a cercare con un'altra parola chiave",buttonText:"Torna ad Alibaba"},hour:{one:"ora",other:"ore"},day:{one:"giorno",other:"giorni"},year:{one:"anno",other:"anni"},allTime:"Tutto il tempo",localizationModal:{header:"Nuove lingue sono ora disponibili",message:"Siamo lieti di annunciare il supporto linguistico dell'estensione Chrome in tedesco, italiano e spagnolo. Cambia la tua preferenza di lingua in qualsiasi momento in Impostazioni.",notShowAgain:"Non mostrare più"},charts:{time:"Tempo",price:"Prezzo",rank:"Classifica",rating:"Valutazioni",salesRank:"Classifica delle vendite",newPrice:"Nuovo prezzo",listPrice:"Prezzo di listino",values:"Valori",sales:"Vendite",trendLine:"Linea di tendenza",movingAverage:"Media mobile di 7 giorni",reviews:"Recensioni",numberOfReviews:"Numero di recensioni",searchVolume:"Volume di ricerca",reviewCount:"Numero di recensioni",downloads:{csv:"Scarica il rapporto in CSV",xls:"Scarica XLS",png:"Scarica l'immagine PNG",jpeg:"Scarica l'immagine JPEG"},resetZoom:"Ripristina zoom"},modals:{rateUsHeader:"Like using Helium 10 Extension?",rateUsLike:"I like to use the extension. I really use all the functionality of the extension.",rateUsDislike:"I don't like working with the extension, I don't like how it develops and its functionality",rateUsNegativeHeader:"Thanks for your feedback!",rateUsPositiveHeader:"Thanks You",rateUsMessage:"We are trying to improve and refine our application, your feedback will help us with this. If you have any suggestions on how to make our extension better, you can contact support.",rateUsPositiveMessage:"We are so happy to hear that you like our extension! It would be super helpful if you rate us. Thanks",localizationHeader:"New languages for extension",localizationMessage:"The extension is now available in the language of your browser. All available languages can be viewed in the settings. Change the language to yours? Page will be reloaded.",notShowAgain:"Don't show again"}}},{logsEnabled:!1}),H=({children:e})=>i.createElement(q.DO,{strings:Q,TranslateContext:X},e),X=(0,i.createContext)(null);var K,J,$,_,ee;function te(){return(te=Object.assign||function(e){for(var t=1;t<arguments.length;t++){var r=arguments[t];for(var i in r)Object.prototype.hasOwnProperty.call(r,i)&&(e[i]=r[i])}return e}).apply(this,arguments)}function re(){return(re=Object.assign||function(e){for(var t=1;t<arguments.length;t++){var r=arguments[t];for(var i in r)Object.prototype.hasOwnProperty.call(r,i)&&(e[i]=r[i])}return e}).apply(this,arguments)}function ie(){return(ie=Object.assign||function(e){for(var t=1;t<arguments.length;t++){var r=arguments[t];for(var i in r)Object.prototype.hasOwnProperty.call(r,i)&&(e[i]=r[i])}return e}).apply(this,arguments)}var ae=Object.defineProperty,ne=Object.defineProperties,oe=Object.getOwnPropertyDescriptors,se=Object.getOwnPropertySymbols,le=Object.prototype.hasOwnProperty,ce=Object.prototype.propertyIsEnumerable,de=(e,t,r)=>t in e?ae(e,t,{enumerable:!0,configurable:!0,writable:!0,value:r}):e[t]=r;const ue=a.ZP.span`
  padding-left: 5px;
  padding-right: 5px;
`,ge=a.ZP.label`
  cursor: pointer;
`,pe=Object.assign((e=>{var t,r=e,{label:a,children:n,innerRef:o,almost:s}=r,l=((e,t)=>{var r={};for(var i in e)le.call(e,i)&&t.indexOf(i)<0&&(r[i]=e[i]);if(null!=e&&se)for(var i of se(e))t.indexOf(i)<0&&ce.call(e,i)&&(r[i]=e[i]);return r})(r,["label","children","innerRef","almost"]);return i.createElement(ge,null,i.createElement(be,(t=((e,t)=>{for(var r in t||(t={}))le.call(t,r)&&de(e,r,t[r]);if(se)for(var r of se(t))ce.call(t,r)&&de(e,r,t[r]);return e})({type:"checkbox"},l),ne(t,oe({ref:o})))),s?i.createElement(we,null):i.createElement(he,null),a&&!n&&i.createElement(ue,null,a),n&&i.createElement(ue,null,n))}),{Text:ue,Label:ge}),me=a.iv`
  width: 11px;
  height: 11px;
  border-radius: 2px;
  fill: transparent;
  border: 1px solid ${({theme:e})=>e.colors.lightGrayBackground};
`,he=(0,a.ZP)((function(e){return i.createElement("svg",ie({width:12,height:12,fill:"none",xmlns:"http://www.w3.org/2000/svg"},e),ee||(ee=i.createElement("path",{d:"M5.68 8.805l4.242-4.242a.476.476 0 00.14-.352.486.486 0 00-.14-.36l-.711-.703A.48.48 0 008.859 3a.48.48 0 00-.351.148L5.32 6.328 3.555 4.563a.48.48 0 00-.352-.149.48.48 0 00-.351.149l-.711.703A.487.487 0 002 5.625c0 .14.047.258.14.352L4.97 8.805a.48.48 0 00.351.148c.141 0 .26-.05.36-.148z"})))}))`
  ${me}
`,we=(0,a.ZP)((function(e){return i.createElement("svg",re({width:12,height:12,fill:"none",xmlns:"http://www.w3.org/2000/svg"},e),_||(_=i.createElement("rect",{x:2,y:5,width:8,height:2,rx:1})))}))`
  ${me}
`,be=a.ZP.input`
  display: none;

  &:checked + ${we} {
    fill: white;
    border: 1px solid ${({theme:e})=>e.colors.middleBlue};
    background: ${({theme:e})=>e.colors.middleBlue};
  }

  &:checked:disabled + ${we} {
    fill: white;
    border: 1px solid ${({theme:e})=>e.colors.lightGrayBackground};
    background: ${({theme:e})=>e.colors.lightGrayBackground};
  }

  &:checked + ${he} {
    fill: white;
    border: 1px solid ${({theme:e})=>e.colors.middleBlue};
    background: ${({theme:e})=>e.colors.middleBlue};
  }

  &:checked:disabled + ${he} {
    fill: white;
    border: 1px solid ${({theme:e})=>e.colors.lightGrayBackground};
    background: ${({theme:e})=>e.colors.lightGrayBackground};
  }
`;a.ZP.div`
  ${pe.Label} {
    display: flex;
    align-items: center;
    justify-content: center;
  }

  ${pe.Text} {
    line-height: 14px;
  }

  ${z} {
    line-height: 12px;
  }
`;var fe=Object.defineProperty,Me=Object.defineProperties,ye=Object.getOwnPropertyDescriptors,ve=Object.getOwnPropertySymbols,xe=Object.prototype.hasOwnProperty,ze=Object.prototype.propertyIsEnumerable,Ne=(e,t,r)=>t in e?fe(e,t,{enumerable:!0,configurable:!0,writable:!0,value:r}):e[t]=r;const je={white:{fontColor:N.colors.blue,standard:N.colors.white,hover:N.colors.white},blue:{fontColor:N.colors.white,standard:N.colors.blue,hover:N.colors.darkBlue},"light-blue":{fontColor:N.colors.blue,standard:"#e5f2ff",hover:"#cde1f5"}},De={small:{fontSize:N.fontSize.medium,padding:"6px 16px 7px 16px"},middle:{fontSize:N.fontSize.headerSmall,padding:`${N.padding.button} ${N.padding.default}`},large:{fontSize:N.fontSize.headerLarge,padding:`${N.padding.large} ${N.padding.section}`}},Oe=a.ZP.button`
  display: flex;
  align-items: center;
  flex-wrap: nowrap;
  border: none;
  transition: all 0.2s ease-in-out;
  border-radius: ${({theme:e})=>e.borderRadius.middle};
  cursor: pointer;
  background-color: ${e=>e.colorSchema.standard};
  font-weight: bold;
  padding: ${e=>e.sizeSchema.padding};
  color: ${e=>e.colorSchema.fontColor};
  font-size: ${e=>e.sizeSchema.fontSize};
  outline: none;
  line-height: 1.5;

  &:hover {
    background-color: ${e=>e.colorSchema.hover};
  }

  &:active,
  &:focus {
    color: ${({theme:e})=>e.colors.btnPrimaryText};
    background-color: ${({theme:e})=>e.colors.btnPrimaryHover};
  }

  :disabled {
    cursor: auto;
    opacity: 0.5;
    background-color: ${e=>e.colorSchema.standard};
  }
`;var Ae,Ie,Ce,Se,Pe,Le,Te;function ke(){return(ke=Object.assign||function(e){for(var t=1;t<arguments.length;t++){var r=arguments[t];for(var i in r)Object.prototype.hasOwnProperty.call(r,i)&&(e[i]=r[i])}return e}).apply(this,arguments)}function Ee(e){return i.createElement("svg",ke({width:110,height:18,xmlns:"http://www.w3.org/2000/svg"},e),Ae||(Ae=i.createElement("g",{fill:"none"},i.createElement("path",{d:"M34.533 17.756V12h-6.377v5.754h-2.543V3.892h2.543v5.754h6.377V3.898h2.525V17.76l-2.525-.004zm13.15-.737c-.812.561-1.979.894-3.541.894-1.96 0-3.586-.58-4.505-1.947-.547-.755-.866-1.79-.866-3.087 0-1.229.319-2.245.919-3.018.902-1.242 2.437-1.982 4.433-1.982 2.102 0 3.542.755 4.364 1.913.723 1.016.988 2.483.865 3.965h-8.25c.024.559.265 1.086.673 1.473.458.473 1.325.807 2.367.807a4.164 4.164 0 002.012-.456c.513-.281.76-.668.796-.912h2.331c-.21.958-.781 1.8-1.598 2.35zm-1.237-6.403c-.477-.439-1.183-.807-2.315-.807-1.058 0-1.835.317-2.348.772a2.17 2.17 0 00-.708 1.421h5.919a1.88 1.88 0 00-.548-1.386zm4.733 7.14c-.052-.035-.07-.157-.07-.72V4.846c0-.474-.017-.896-.036-1.054h2.369c.054.295.078.595.07.894v12.176c0 .507 0 .807.053.894h-2.386zm4.367-10.771v-2.35h2.5v2.35h-2.5zm2.544 10.77h-2.367c-.09-.034-.125-.245-.125-.947v-8.7H58v8.65c0 .7.019.946.09.998zm9.12 0l-.052-1.367c-.69 1.122-2.156 1.525-3.568 1.525-2.225 0-3.621-.859-3.621-3.068 0-5.86-.019-6.685-.09-6.737h2.413c.035 0 .054.35.054 6.087 0 1.333.917 1.806 2.17 1.806 1.574 0 2.563-.755 2.563-1.947V8.108h2.367v8.086c-.01.521.007 1.043.052 1.562H67.21zm17.26-5.858c0-.965-.37-1.825-1.995-1.825-1.183 0-2.137.65-2.137 1.876v5.808h-2.26v-6c0-1.035-.726-1.684-1.945-1.684-1.36 0-2.208.93-2.208 1.93v5.754H71.54V8.108h2.333v1.544c.417-1.089 1.731-1.738 3.18-1.738 1.447 0 2.595.58 3.02 1.754.387-1.175 1.625-1.754 3.231-1.754 2.473 0 3.334 1.316 3.334 3.14 0 4.054.016 6.621.087 6.702h-2.142c-.112 0-.112-2.446-.112-5.86zm9.76 5.859V6.722l-3.428.474V5.214c2.898-.414 3.71-.86 3.958-1.386h1.96v13.928h-2.49zm15.443-10.368c.208.964.231 2.104.231 3.439 0 1.088-.125 2.702-.337 3.49-.625 2.483-2.402 3.615-5.298 3.615-2.986 0-4.63-1.035-5.3-3.631-.265-.948-.336-2.386-.336-3.493 0-1.316-.016-2.21.248-3.403.477-2.262 2.244-3.68 5.404-3.68 3.127 0 4.894 1.576 5.388 3.663zm-2.56.561c-.23-1.262-1.184-2.034-2.828-2.034-1.677 0-2.666.772-2.879 2.034-.087.62-.158 2.123-.158 2.878-.003.993.073 1.984.23 2.965.264 1.35 1.237 1.998 2.807 1.998 1.571 0 2.5-.718 2.773-1.998.125-.544.209-2.123.209-2.984.008-.955-.043-1.91-.154-2.859z",fill:"#003873"}),i.createElement("path",{d:"M.125 3.896v5.756H4.54v-3.36L.125 3.896zm6.958 2.396v3.36H11.5V3.896L7.083 6.292zm6.96-3.774v7.134h4.415V.124l-4.414 2.394z",fill:"#0081FF"}),i.createElement("path",{d:"M.125 12.002H4.54v5.754H.125v-5.754zm6.958 0h4.415v5.754H7.083v-5.754zm6.96 0h4.415v5.754h-4.414v-5.754z",fill:"#003873"}))))}function Ze(){return(Ze=Object.assign||function(e){for(var t=1;t<arguments.length;t++){var r=arguments[t];for(var i in r)Object.prototype.hasOwnProperty.call(r,i)&&(e[i]=r[i])}return e}).apply(this,arguments)}function Be(e){return i.createElement("svg",Ze({width:145,height:24,xmlns:"http://www.w3.org/2000/svg",xmlnsXlink:"http://www.w3.org/1999/xlink"},e),Ie||(Ie=i.createElement("defs",null,i.createElement("path",{id:"logo-h10-light-window_svg__a",d:"M.094.091h111.322v18.943H.094z"}),i.createElement("path",{id:"logo-h10-light-window_svg__c",d:"M0 23.743h144.983V0H0z"}))),Ce||(Ce=i.createElement("g",{fill:"none",fillRule:"evenodd"},i.createElement("g",{transform:"translate(33.567 4.709)"},i.createElement("mask",{id:"logo-h10-light-window_svg__b",fill:"#fff"},i.createElement("use",{xlinkHref:"#logo-h10-light-window_svg__a"})),i.createElement("path",{d:"M107.73 5.724c-.304-1.683-1.564-2.712-3.734-2.712-2.215 0-3.522 1.03-3.803 2.712-.116.828-.209 2.83-.209 3.837a24.925 24.925 0 00.302 3.954c.35 1.8 1.635 2.664 3.71 2.664 2.074 0 3.301-.957 3.661-2.664.166-.726.276-2.831.276-3.978a30.695 30.695 0 00-.204-3.813zm3.38-.747c.276 1.285.306 2.805.306 4.584 0 1.451-.165 3.603-.446 4.654-.825 3.31-3.172 4.82-6.996 4.82-3.943 0-6.114-1.38-7-4.842-.35-1.263-.443-3.18-.443-4.656 0-1.755-.022-2.947.327-4.538.63-3.016 2.964-4.908 7.138-4.908 4.13 0 6.463 2.102 7.115 4.886zM90.716 18.8V4.088l-4.527.632V2.077c3.828-.551 4.9-1.147 5.228-1.848h2.59v18.57h-3.291zm-12.888-7.812c0-1.286-.49-2.433-2.636-2.433-1.563 0-2.823.865-2.823 2.502V18.8h-2.985v-8c0-1.38-.958-2.245-2.567-2.245-1.797 0-2.917 1.24-2.917 2.573V18.8h-3.15V5.937h3.081v2.057c.55-1.45 2.287-2.317 4.199-2.317s3.428.773 3.99 2.34c.511-1.567 2.146-2.34 4.267-2.34 3.266 0 4.402 1.755 4.402 4.188 0 5.404.022 8.827.116 8.935h-2.829c-.148 0-.148-3.26-.148-7.812zM55.03 18.8l-.068-1.823c-.911 1.495-2.848 2.033-4.714 2.033-2.938 0-4.782-1.145-4.782-4.091 0-7.813-.024-8.913-.118-8.982h3.186c.047 0 .072.466.072 8.115 0 1.777 1.21 2.409 2.867 2.409 2.077 0 3.384-1.007 3.384-2.596V5.937h3.125v10.78c-.013.695.01 1.39.07 2.083H55.03zm-12.046 0H39.86c-.119-.047-.165-.328-.165-1.263v-11.6h3.172V17.47c0 .933.025 1.26.118 1.33zM39.626 4.438h3.302V1.305h-3.302v3.133zM33.86 18.8c-.069-.047-.093-.21-.093-.96V1.586c0-.631-.022-1.194-.047-1.404h3.128c.073.393.104.792.094 1.192v16.234c0 .676 0 1.076.068 1.192h-3.15zm-6.251-9.52c-.63-.585-1.563-1.076-3.057-1.076-1.398 0-2.424.422-3.1 1.03a2.902 2.902 0 00-.936 1.894h7.816a2.52 2.52 0 00-.723-1.848zm1.634 8.538c-1.073.748-2.614 1.192-4.677 1.192-2.59 0-4.735-.773-5.949-2.596-.723-1.007-1.145-2.386-1.145-4.116 0-1.639.422-2.993 1.214-4.025 1.191-1.655 3.22-2.643 5.855-2.643 2.776 0 4.677 1.007 5.764 2.552.955 1.355 1.304 3.31 1.142 5.286H20.55c.032.745.35 1.449.89 1.964.604.631 1.75 1.076 3.125 1.076a5.457 5.457 0 002.658-.607c.677-.375 1.004-.891 1.05-1.217h3.08a5.1 5.1 0 01-2.11 3.134zm-17.367.982v-7.674H3.453v7.671H.093V.315h3.36v7.671h8.422V.323h3.335v18.483l-3.335-.006z",fill:"#EDE8E3",mask:"url(#logo-h10-light-window_svg__b)"})),i.createElement("mask",{id:"logo-h10-light-window_svg__d",fill:"#fff"},i.createElement("use",{xlinkHref:"#logo-h10-light-window_svg__c"})),i.createElement("path",{d:"M18.382 23.509h5.83v-7.672h-5.83v7.672zm-9.192 0h5.83v-7.672H9.19v7.672zm-9.19 0h5.83v-7.672H0v7.672zM18.382 3.192v9.511h5.83V0l-5.83 3.192zM9.19 8.223v4.48h5.833V5.03L9.19 8.223zM0 5.03v7.674h5.83v-4.48L0 5.03z",fill:"#0081FF",mask:"url(#logo-h10-light-window_svg__d)"}))))}function Ge(){return(Ge=Object.assign||function(e){for(var t=1;t<arguments.length;t++){var r=arguments[t];for(var i in r)Object.prototype.hasOwnProperty.call(r,i)&&(e[i]=r[i])}return e}).apply(this,arguments)}function Re(e){return i.createElement("svg",Ge({width:168,height:28,xmlns:"http://www.w3.org/2000/svg",xmlnsXlink:"http://www.w3.org/1999/xlink"},e),Se||(Se=i.createElement("defs",null,i.createElement("path",{id:"logo-h10-window_svg__a",d:"M.108.105h128.98v21.85H.109z"}),i.createElement("path",{id:"logo-h10-window_svg__c",d:"M0 .296h28.053v14.652H0z"}),i.createElement("path",{id:"logo-h10-window_svg__e",d:"M0 27.704h167.98V.318H0z"}))),Pe||(Pe=i.createElement("g",{fill:"none",fillRule:"evenodd"},i.createElement("g",{transform:"translate(38.892 5.75)"},i.createElement("mask",{id:"logo-h10-window_svg__b",fill:"#fff"},i.createElement("use",{xlinkHref:"#logo-h10-window_svg__a"})),i.createElement("path",{d:"M124.817 6.602c-.35-1.94-1.81-3.127-4.326-3.127-2.566 0-4.08 1.186-4.405 3.127-.134.955-.242 3.265-.242 4.426a28.622 28.622 0 00.35 4.56c.405 2.078 1.894 3.073 4.297 3.073 2.404 0 3.826-1.104 4.243-3.073.192-.837.319-3.265.319-4.588a35.247 35.247 0 00-.236-4.398zm3.918-.862c.32 1.483.354 3.236.354 5.288 0 1.674-.191 4.156-.517 5.368-.956 3.818-3.675 5.559-8.106 5.559-4.568 0-7.083-1.591-8.11-5.584-.405-1.458-.513-3.67-.513-5.371 0-2.024-.026-3.399.379-5.234.73-3.478 3.434-5.66 8.27-5.66 4.784 0 7.488 2.424 8.243 5.634zm-23.631 15.944V4.716l-5.244.728V2.396c4.434-.636 5.677-1.324 6.057-2.132h3v21.42h-3.813zm-14.933-9.01c0-1.483-.567-2.807-3.054-2.807-1.81 0-3.27.999-3.27 2.886v8.93h-3.459v-9.226c0-1.591-1.11-2.59-2.974-2.59-2.082 0-3.38 1.432-3.38 2.969v8.848h-3.65V6.847h3.57v2.374c.638-1.674 2.65-2.673 4.866-2.673 2.215 0 3.972.891 4.622 2.698.593-1.807 2.487-2.698 4.945-2.698 3.784 0 5.1 2.024 5.1 4.83 0 6.233.026 10.182.134 10.306h-3.277c-.173 0-.173-3.76-.173-9.01zm-26.41 9.01l-.08-2.103c-1.055 1.725-3.3 2.345-5.461 2.345-3.405 0-5.54-1.32-5.54-4.719 0-9.01-.03-10.28-.138-10.36h3.692c.054 0 .083.538.083 9.36 0 2.05 1.402 2.779 3.322 2.779 2.406 0 3.92-1.161 3.92-2.994V6.847h3.622v12.435c-.016.802.011 1.604.08 2.402h-3.5zm-13.957 0h-3.621c-.138-.054-.192-.378-.192-1.457V6.847h3.676v13.304c0 1.075.029 1.453.137 1.533zM45.912 5.12h3.825V1.505h-3.825V5.12zM39.23 21.684c-.08-.054-.109-.242-.109-1.107V1.83c0-.729-.025-1.378-.054-1.62h3.625c.084.453.12.914.108 1.375V20.31c0 .78 0 1.24.08 1.374h-3.65zm-7.243-10.98c-.73-.675-1.81-1.241-3.542-1.241-1.62 0-2.808.487-3.592 1.187a3.341 3.341 0 00-1.084 2.186h9.056a2.899 2.899 0 00-.838-2.132zm1.894 9.847c-1.244.863-3.029 1.375-5.42 1.375-3 0-5.486-.891-6.892-2.994-.838-1.161-1.326-2.752-1.326-4.747 0-1.89.488-3.453 1.406-4.643 1.38-1.909 3.73-3.048 6.784-3.048 3.216 0 5.419 1.162 6.678 2.943 1.106 1.563 1.511 3.819 1.323 6.097H23.81c.037.86.406 1.671 1.03 2.265.701.728 2.027 1.241 3.621 1.241a6.346 6.346 0 003.08-.7c.784-.433 1.163-1.028 1.218-1.403h3.567a5.88 5.88 0 01-2.445 3.614zm-20.122 1.133v-8.852H4v8.849H.108V.363h3.893V9.21h9.758V.372h3.864v21.319l-3.864-.007z",fill:"#003873",mask:"url(#logo-h10-window_svg__b)"})),i.createElement("g",{transform:"translate(0 .022)"},i.createElement("mask",{id:"logo-h10-window_svg__d",fill:"#fff"},i.createElement("use",{xlinkHref:"#logo-h10-window_svg__c"})),i.createElement("path",{d:"M21.298 3.977v10.971h6.755V.296l-6.755 3.681zm-10.65 5.804v5.167h6.758V6.096l-6.759 3.685zM0 6.096v8.852h6.755V9.781L0 6.096z",fill:"#0081FF",mask:"url(#logo-h10-window_svg__d)"})),i.createElement("mask",{id:"logo-h10-window_svg__f",fill:"#fff"},i.createElement("use",{xlinkHref:"#logo-h10-window_svg__e"})),i.createElement("path",{d:"M21.298 27.434h6.755v-8.849h-6.755v8.849zm-10.65 0h6.755v-8.849h-6.756v8.849zM0 27.434h6.755v-8.849H0v8.849z",fill:"#003873",mask:"url(#logo-h10-window_svg__f)"}))))}function Fe(){return(Fe=Object.assign||function(e){for(var t=1;t<arguments.length;t++){var r=arguments[t];for(var i in r)Object.prototype.hasOwnProperty.call(r,i)&&(e[i]=r[i])}return e}).apply(this,arguments)}function Ue(e){return i.createElement("svg",Fe({width:110,height:18,xmlns:"http://www.w3.org/2000/svg"},e),Le||(Le=i.createElement("g",{fill:"none"},i.createElement("path",{d:"M34.533 17.756V12h-6.377v5.754h-2.543V3.892h2.543v5.754h6.377V3.898h2.525V17.76l-2.525-.004zm13.15-.737c-.812.561-1.979.894-3.541.894-1.96 0-3.586-.58-4.505-1.947-.547-.755-.866-1.79-.866-3.087 0-1.229.319-2.245.919-3.018.902-1.242 2.437-1.982 4.433-1.982 2.102 0 3.542.755 4.364 1.913.723 1.016.988 2.483.865 3.965h-8.25c.024.559.265 1.086.673 1.473.458.473 1.325.807 2.367.807a4.164 4.164 0 002.012-.456c.513-.281.76-.668.796-.912h2.331c-.21.958-.781 1.8-1.598 2.35zm-1.237-6.403c-.477-.439-1.183-.807-2.315-.807-1.058 0-1.835.317-2.348.772a2.17 2.17 0 00-.708 1.421h5.919a1.88 1.88 0 00-.548-1.386zm4.733 7.14c-.052-.035-.07-.157-.07-.72V4.846c0-.474-.017-.896-.036-1.054h2.369c.054.295.078.595.07.894v12.176c0 .507 0 .807.053.894h-2.386zm4.367-10.771v-2.35h2.5v2.35h-2.5zm2.544 10.77h-2.367c-.09-.034-.125-.245-.125-.947v-8.7H58v8.65c0 .7.019.946.09.998zm9.12 0l-.052-1.367c-.69 1.122-2.156 1.525-3.568 1.525-2.225 0-3.621-.859-3.621-3.068 0-5.86-.019-6.685-.09-6.737h2.413c.035 0 .054.35.054 6.087 0 1.333.917 1.806 2.17 1.806 1.574 0 2.563-.755 2.563-1.947V8.108h2.367v8.086c-.01.521.007 1.043.052 1.562H67.21zm17.26-5.858c0-.965-.37-1.825-1.995-1.825-1.183 0-2.137.65-2.137 1.876v5.808h-2.26v-6c0-1.035-.726-1.684-1.945-1.684-1.36 0-2.208.93-2.208 1.93v5.754H71.54V8.108h2.333v1.544c.417-1.089 1.731-1.738 3.18-1.738 1.447 0 2.595.58 3.02 1.754.387-1.175 1.625-1.754 3.231-1.754 2.473 0 3.334 1.316 3.334 3.14 0 4.054.016 6.621.087 6.702h-2.142c-.112 0-.112-2.446-.112-5.86zm9.76 5.859V6.722l-3.428.474V5.214c2.898-.414 3.71-.86 3.958-1.386h1.96v13.928h-2.49zm15.443-10.368c.208.964.231 2.104.231 3.439 0 1.088-.125 2.702-.337 3.49-.625 2.483-2.402 3.615-5.298 3.615-2.986 0-4.63-1.035-5.3-3.631-.265-.948-.336-2.386-.336-3.493 0-1.316-.016-2.21.248-3.403.477-2.262 2.244-3.68 5.404-3.68 3.127 0 4.894 1.576 5.388 3.663zm-2.56.561c-.23-1.262-1.184-2.034-2.828-2.034-1.677 0-2.666.772-2.879 2.034-.087.62-.158 2.123-.158 2.878-.003.993.073 1.984.23 2.965.264 1.35 1.237 1.998 2.807 1.998 1.571 0 2.5-.718 2.773-1.998.125-.544.209-2.123.209-2.984.008-.955-.043-1.91-.154-2.859z",fill:"#ede8e3"}),i.createElement("path",{d:"M.125 3.896v5.756H4.54v-3.36L.125 3.896zm6.958 2.396v3.36H11.5V3.896L7.083 6.292zm6.96-3.774v7.134h4.415V.124l-4.414 2.394zM.125 12.002H4.54v5.754H.125v-5.754zm6.958 0h4.415v5.754H7.083v-5.754zm6.96 0h4.415v5.754h-4.414v-5.754z",fill:"#0081FF"}))))}function Ve(){return(Ve=Object.assign||function(e){for(var t=1;t<arguments.length;t++){var r=arguments[t];for(var i in r)Object.prototype.hasOwnProperty.call(r,i)&&(e[i]=r[i])}return e}).apply(this,arguments)}function We(e){return i.createElement("svg",Ve({width:128,height:128,xmlns:"http://www.w3.org/2000/svg"},e),Te||(Te=i.createElement("g",{fill:"none"},i.createElement("path",{d:"M0 28.259v40.847h30.545V45.253L0 28.259zm49.455 16.994v23.853H80V28.259L49.455 45.253zm48-26.393v50.246H128V2L97.455 18.86z",fill:"#0081FF"}),i.createElement("path",{d:"M0 85.153h30.545V126H0V85.153zm49.455 0H80V126H49.455V85.153zm48 0H128V126H97.455V85.153z",fill:"#003873"}))))}var qe=Object.defineProperty,Ye=Object.defineProperties,Qe=Object.getOwnPropertyDescriptors,He=Object.getOwnPropertySymbols,Xe=Object.prototype.hasOwnProperty,Ke=Object.prototype.propertyIsEnumerable,Je=(e,t,r)=>t in e?qe(e,t,{enumerable:!0,configurable:!0,writable:!0,value:r}):e[t]=r;const $e={small:i.createElement(We,null),largeDark:i.createElement(Ee,null),largeLight:i.createElement(Ue,null),logoModalLight:i.createElement(Be,null),logoModalDark:i.createElement(Re,null)},_e=e=>{var t,r=e,{type:a="small"}=r,n=((e,t)=>{var r={};for(var i in e)Xe.call(e,i)&&t.indexOf(i)<0&&(r[i]=e[i]);if(null!=e&&He)for(var i of He(e))t.indexOf(i)<0&&Ke.call(e,i)&&(r[i]=e[i]);return r})(r,["type"]);return i.createElement(et,(t=((e,t)=>{for(var r in t||(t={}))Xe.call(t,r)&&Je(e,r,t[r]);if(He)for(var r of He(t))Ke.call(t,r)&&Je(e,r,t[r]);return e})({},n),Ye(t,Qe({href:"https://www.helium10.com/",target:"_blank",rel:"noreferrer"}))),$e[a])},et=a.ZP.a`
  line-height: 0;
`;Object.defineProperty,Object.getOwnPropertySymbols,Object.prototype.hasOwnProperty,Object.prototype.propertyIsEnumerable,(0,a.ZP)(V)`
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: ${({dark:e})=>e?"rgba(0, 0, 0, 0.5)":"rgba(0, 0, 0, 0.2)"};
  overflow: hidden;
  display: flex;
  overflow-y: auto;
  padding: 24px 0;
`;const tt={small:"477px",large:"727px"};a.ZP.div`
  flex: 0 0 auto;
  margin: auto;
  border-radius: ${({theme:e})=>e.borderRadius.small};
  width: ${e=>e.width?`${e.width}px`:tt[e.size||"small"]};
  overflow: hidden;
`,a.ZP.div`
  background-color: ${({theme:e})=>e.colors.white};
`,a.ZP.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: ${({theme:e,small:t})=>t?e.padding.modal.default:e.padding.large};
  background-color: ${({theme:e})=>e.colors.darkBlue};
`,a.ZP.div`
  display: flex;
  align-items: center;
  justify-content: center;
  padding-top: ${({theme:e})=>e.padding.large};
  padding-bottom: ${({theme:e})=>e.padding.footerBottom};
`,a.ZP.div`
  text-align: center;
  padding: 30px;
`,a.ZP.p``,a.ZP.div`
  display: flex;
  justify-content: center;
  margin-bottom: 8px;

  button {
    margin: 4px;
  }
`,Object.defineProperty,Object.defineProperties,Object.getOwnPropertyDescriptors,Object.getOwnPropertySymbols,Object.prototype.hasOwnProperty,Object.prototype.propertyIsEnumerable,(0,a.ZP)((function(e){return i.createElement("svg",te({height:"512pt",viewBox:"0 0 512 512",width:"512pt",xmlns:"http://www.w3.org/2000/svg"},e),K||(K=i.createElement("path",{d:"M373.852 308.297c-1.446-4.82-7.391-7.074-13.497-7.074-5.945 0-11.89 2.254-13.335 7.074l-31.012 101.062c-.16.645-.32 1.286-.32 1.606 0 5.144 7.55 8.676 13.175 8.676 3.535 0 6.266-1.121 7.07-4.176l6.102-21.371h36.797l6.11 21.37c.8 3.056 3.53 4.177 7.066 4.177 5.625 0 13.176-3.692 13.176-8.676 0-.48-.16-.965-.32-1.606zm-27.477 69.406l13.977-49.324 13.984 49.324zm0 0"})),J||(J=i.createElement("path",{d:"M456.836 208.867H303.129V143.22l49.953-35.68a14.998 14.998 0 000-24.41l-50.555-36.11C298.578 20.45 275.613 0 247.965 0H55.168C24.746 0 0 24.746 0 55.168v192.8c0 30.419 24.746 55.165 55.168 55.165h153.703v65.648l-49.953 35.68c-3.941 2.816-6.281 7.363-6.281 12.207s2.34 9.39 6.281 12.203l50.555 36.11C213.422 491.55 236.387 512 264.035 512h192.8C487.255 512 512 487.25 512 456.832V264.035c0-30.422-24.746-55.168-55.164-55.168zM55.168 273.133c-13.879 0-25.168-11.29-25.168-25.168v-192.8C30 41.288 41.29 30 55.168 30h192.797c13.875 0 25.164 11.29 25.164 25.164 0 4.848 2.34 9.395 6.281 12.207l39.145 27.961-39.145 27.961a15.005 15.005 0 00-6.281 12.207v73.367h-9.094c-30.418 0-55.164 24.746-55.164 55.164v9.102zM482 456.832C482 470.711 470.71 482 456.836 482h-192.8c-13.876 0-25.165-11.29-25.165-25.168 0-4.844-2.34-9.39-6.281-12.203l-39.145-27.961 39.145-27.961a15.005 15.005 0 006.281-12.207V264.035c0-13.879 11.29-25.168 25.164-25.168H456.836c13.875 0 25.164 11.29 25.164 25.168zm0 0"})),$||($=i.createElement("path",{d:"M197.652 138.277c4.668 0 8.457-3.789 8.457-8.46s-3.789-8.462-8.457-8.462h-37.629v-20.539c0-4.671-3.789-8.46-8.46-8.46-4.668 0-8.458 3.789-8.458 8.46v20.54h-37.628c-4.668 0-8.457 3.789-8.457 8.46s3.789 8.461 8.457 8.461h11.66c1.863 17.864 9.566 34.008 21.152 46.512a63.681 63.681 0 01-32.812 9.07c-4.668 0-8.457 3.786-8.457 8.457s3.789 8.461 8.457 8.461c17.117 0 32.996-5.351 46.085-14.453 13.094 9.102 28.973 14.453 46.09 14.453a8.459 8.459 0 000-16.918 63.606 63.606 0 01-32.812-9.07c11.586-12.504 19.289-28.648 21.152-46.512zm-46.09 35.942c-9.253-9.606-15.539-22.078-17.378-35.942h34.761c-1.84 13.864-8.125 26.336-17.382 35.942zm0 0"})))}))`
  width: 100px;
  height: 100px;

  path {
    fill: ${({theme:e})=>e.colors.darkBlue};
  }
`,Object.defineProperty,Object.defineProperties,Object.getOwnPropertyDescriptors,Object.getOwnPropertySymbols,Object.prototype.hasOwnProperty,Object.prototype.propertyIsEnumerable,N.borderRadius.small,a.ZP.div`
  display: flex;
  cursor: move;
  justify-content: space-between;
  align-items: center;
  padding: 11px ${({theme:e})=>e.padding.default};
  background-color: ${({theme:e})=>e.colors.darkBlue};
  flex: 0 0 auto;
  opacity: 1 !important;

  * {
    user-select: none;
  }
`,a.ZP.div``,a.ZP.div`
  display: flex;
  flex-direction: column;
  overflow: hidden;
  flex-grow: 1;
  background-color: ${({theme:e})=>e.colors.white};
  opacity: ${({transparent:e})=>e?"0":"1"};
  transition: opacity 0.1s ease-in-out;
`,a.ZP.div`
  text-align: center;
  display: flex;
  flex-direction: column;
  padding: 40px 40px 0 40px;
`,a.ZP.div`
  width: 80px;
  height: 80px;
  display: flex;
  background-color: rgba(0, 129, 255, 0.15);
  border-radius: 50%;
  margin: auto;
`,(0,a.ZP)(D)`
  color: ${({theme:e})=>e.colors.darkGrey};
`,a.ZP.img`
  margin: auto;
`;var rt=r(7563);Object.defineProperty,Object.defineProperties,Object.getOwnPropertyDescriptors,Object.getOwnPropertySymbols,Object.prototype.hasOwnProperty,Object.prototype.propertyIsEnumerable;const it=a.vJ`
  @font-face {
    font-family: "Neuton";
    src: local("Neuton"),
    url("https://fonts.gstatic.com/s/neuton/v13/UMBTrPtMoH62xUZCz4g6.woff2") format("woff2");
  }

  @font-face {
    font-family: "Nunito Sans";
    src: local("Nunito Sans"),
    url("https://fonts.gstatic.com/s/nunitosans/v6/pe0qMImSLYBIv1o4X1M8cce9I9s.woff2") format("woff2");
  }

  body, button, h1, h2, h3, h4, h5, h6, a, span, p, div {
    font-family: 'Nunito Sans', -apple-system, 'Neuton', sans-serif;
    line-height: normal;
  }

  p {
    margin: 0;
  }

  * {
    
    &::-webkit-scrollbar {
      width: 7px;
      height: 7px;
    }

    &::-webkit-scrollbar-button {
      width: 0;
      height: 0;
    }

    &::-webkit-scrollbar-track {
      background: #e5e5e5;
      border: 0 none #fff;
    }

    &::-webkit-scrollbar-thumb {
      background: rgba(100, 100, 100, 0.3);
      border: 0 none #fff;
      border-radius: 3px;

      &:hover {
        background: rgba(100, 100, 100, 0.4);
      }

      &:active {
        background: rgba(100, 100, 100, 0.45);
      }
    }

    &::-webkit-scrollbar-corner {
      background: transparent;
    }
  }
`;var at,nt,ot;function st(){return(st=Object.assign||function(e){for(var t=1;t<arguments.length;t++){var r=arguments[t];for(var i in r)Object.prototype.hasOwnProperty.call(r,i)&&(e[i]=r[i])}return e}).apply(this,arguments)}function lt(){return(lt=Object.assign||function(e){for(var t=1;t<arguments.length;t++){var r=arguments[t];for(var i in r)Object.prototype.hasOwnProperty.call(r,i)&&(e[i]=r[i])}return e}).apply(this,arguments)}a.vJ`
  @font-face {
    font-family: "Neuton";
    src: local("Neuton"),
    url("https://fonts.gstatic.com/s/neuton/v13/UMBTrPtMoH62xUZCz4g6.woff2") format("woff2");
  }

  @font-face {
    font-family: "Nunito Sans";
    src: local("Nunito Sans"),
    url("https://fonts.gstatic.com/s/nunitosans/v6/pe0qMImSLYBIv1o4X1M8cce9I9s.woff2") format("woff2");
  }
  
  #h10-style-container {
    button, h1, h2, h3, h4, h5, h6, a, span, p, div {
      font-family: 'Nunito Sans', -apple-system, 'Neuton', sans-serif;
      line-height: normal;
      letter-spacing: 0;
    }

    p {
      margin: 0;
    }

    * {

      &::-webkit-scrollbar {
        width: 7px;
        height: 7px;
      }

      &::-webkit-scrollbar-button {
        width: 0;
        height: 0;
      }

      &::-webkit-scrollbar-track {
        background: #e5e5e5;
        border: 0 none #fff;
      }

      &::-webkit-scrollbar-thumb {
        background: rgba(100, 100, 100, 0.3);
        border: 0 none #fff;
        border-radius: 3px;

        &:hover {
          background: rgba(100, 100, 100, 0.4);
        }

        &:active {
          background: rgba(100, 100, 100, 0.45);
        }
      }

      &::-webkit-scrollbar-corner {
        background: transparent;
      }
    }
  }
`,a.ZP.span`
  text-decoration: ${({discount:e})=>e?"line-through":"unset"};
`,a.ZP.div`
  color: ${({theme:e})=>e.colors.darkGrey};
  padding: 40px 40px 0 40px;
`,a.ZP.div`
  text-align: center;
  margin-bottom: 40px;
`,a.ZP.div`
  display: grid;
  grid-template-columns: 1fr repeat(2, 131px);
`;const ct=(0,a.ZP)(D)`
  padding: ${({theme:e})=>e.padding.default} 24px;
  border-bottom: 1px solid ${({theme:e})=>e.colors.lightGrey};
  position: relative;

  sup {
    position: absolute;
    font-size: 10px;
    font-weight: bold;
    top: unset;
    line-height: initial;
  }
`,dt=((0,a.ZP)(ct)`
  color: ${({theme:e})=>e.colors.darkBlue};
`,(0,a.ZP)(ct)`
  text-align: center;
`);var ut,gt,pt,mt;(0,a.ZP)(dt)`
  color: ${({theme:e})=>e.colors.darkBlue};
`,(0,a.ZP)(dt)`
  color: ${({theme:e})=>e.colors.white};
  background-color: ${({theme:e})=>e.colors.darkBlue};
  border-bottom: 1px solid #ebf0f261;
`,(0,a.ZP)((function(e){return i.createElement("svg",st({xmlns:"http://www.w3.org/2000/svg",width:13,height:10},e),at||(at=i.createElement("path",{fill:"#fff",d:"M11.613.1L4.135 7.57 1.387 4.827a.34.34 0 00-.483 0L.1 5.629a.341.341 0 000 .482L3.893 9.9c.134.132.35.132.483 0L12.9 1.384a.341.341 0 000-.482L12.096.1a.342.342 0 00-.483 0",fillRule:"evenodd"})))}))`
  fill: ${({theme:e})=>e.colors.white};
  display: inline-block;
  width: 15px;
  height: 15px;
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
`,(0,a.ZP)((function(e){return i.createElement("svg",lt({width:10,height:10,fill:"none",xmlns:"http://www.w3.org/2000/svg"},e),nt||(nt=i.createElement("g",{clipPath:"url(#icon-close-alt-blue_svg__clip0)"},i.createElement("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M9.775 1.469L6.267 4.977l3.508 3.507a.607.607 0 010 .86l-.43.43a.607.607 0 01-.86 0L4.977 6.268 1.469 9.775a.607.607 0 01-.86 0l-.43-.43a.607.607 0 010-.86l3.508-3.508L.179 1.469a.607.607 0 010-.86l.43-.43a.607.607 0 01.86 0l3.508 3.508L8.485.179a.607.607 0 01.86 0l.43.43a.616.616 0 010 .86z",fill:"#003873"}))),ot||(ot=i.createElement("defs",null,i.createElement("clipPath",{id:"icon-close-alt-blue_svg__clip0"},i.createElement("path",{fill:"#fff",d:"M0 0h10v10H0z"})))))}))`
  fill: ${({theme:e})=>e.colors.darkBlue};
  display: inline-block;
  width: 10px;
  height: 10px;
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
`,(gt=ut||(ut={})).AlaCarte="Helium10_ALaCarte",gt.AlaCarteAnnual="Helium10_ALaCarteAnnual",gt.Diamond="Helium10_Diamond",gt.DiamondAnnual="Helium10_DiamondAnnual",gt.Elite="Helium10_Elite",gt.Free="Helium10_Free",gt.Gold="Helium10_Gold",gt.GoldAnnual="Helium10_GoldAnnual",gt.Platinum="Helium10_Platinum",gt.PlatinumAnnual="Helium10_PlatinumAnnual",gt.PlatinumFastAction="Helium10_Platinum_FastAction",gt.Enterprise="Helium10_Enterprise",gt.Starter="Helium10_Starter",gt.StarterAnnual="Helium10_StarterAnnual",(mt=pt||(pt={}))[mt.Diamond=199]="Diamond",mt[mt.Free=0]="Free",mt[mt.Platinum=99]="Platinum",mt[mt.Starter=39]="Starter",ut.Free,pt.Free,ut.Starter,pt.Starter,ut.Platinum,pt.Platinum,Object.defineProperty,Object.getOwnPropertySymbols,Object.prototype.hasOwnProperty,Object.prototype.propertyIsEnumerable,a.ZP.div`
  padding-bottom: 30px;
`,a.ZP.div`
  display: flex;
  align-items: center;
  justify-content: center;
  padding-top: ${({theme:e})=>e.padding.large};
  padding-bottom: ${({theme:e})=>e.padding.footerBottom};
`,a.ZP.div`
  display: flex;
  justify-content: space-around;
  align-items: center;
  margin: auto;
`,a.ZP.div`
  display: flex;
  align-items: center;
  flex-direction: column;
`,a.ZP.div`
  padding: 24px 0;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  text-align: center;
`,(0,a.ZP)(D)`
  padding-bottom: ${({theme:e})=>e.padding.large};
`;var ht=r(9446);const wt=[{point:49,color:"#e74c3c"},{point:87,color:"#ffbc00"},{point:100,color:"#157846"}];(0,i.memo)((({value:e,maxValue:t=100,title:r,backgroundColor:a="#f1f3f6",color:o,labelStyle:s,lineWidth:l=16,customColors:c=wt,className:d})=>{const u=r||(({value:e,locale:t=n,options:r})=>{try{return null==e?"n/a":new Intl.NumberFormat(t,r).format(e)}catch(e){return"n/a"}})({value:e,options:{minimumFractionDigits:0}}),g=e/t*100,p=o||((e,t)=>{let r=null;for(let i=0;i<t.length;i++)if(e<=t[i].point){r=t[i].color;break}return r||t[t.length-1].color})(e,c),m=(0,i.useMemo)((()=>({fontSize:36,fill:p,fontWeight:500})),[p]);return i.createElement(ht.PieChart,{data:[{value:e,title:u,key:1,color:p}],reveal:g,lineWidth:l,animate:!0,rounded:!0,startAngle:165,lengthAngle:210,label:({dataEntry:e})=>e.title,labelStyle:s||m,labelPosition:15,viewBoxSize:[100,70],background:a,className:d})})),Math.PI,a.ZP.circle`
  stroke-dashoffset: ${e=>e.range};
  stroke-dasharray: ${e=>e.circumference};
  stroke-width: 9px;
  stroke: ${({progress:e,theme:{colors:t}})=>e>=75&&t.green||e>=50&&t.yellow||t.lightRed};
  stroke-linecap: round;
  fill: none;
  transition: 0.9s ease;
`,a.ZP.circle`
  stroke: #cbcbcb;
`,a.ZP.span`
  position: absolute;
  top: 50%;
  left: 50%;
  font-weight: bold;
  font-size: 14px;
  transform: translate(-50%, -50%);
`,a.ZP.svg`
  transform: rotate(-90deg);
  width: 100%;
  height: 100%;
`,a.ZP.div`
  position: relative;
  flex-direction: column;
  display: flex;
  width: 55px;
  height: 55px;
  flex-shrink: 0;
`,Object.defineProperty,Object.getOwnPropertySymbols,Object.prototype.hasOwnProperty,Object.prototype.propertyIsEnumerable,a.ZP.div`
  position: absolute;
  top: 0;
  left: 0;
  height: 100%;
  display: block;
  overflow: hidden;
  width: ${({rating:e,maxRating:t})=>{return null!=(r=e)&&"number"==typeof r&&-1!==r?5*Math.ceil(100*e/t/5):0;var r}}%;
`,a.ZP.div`
  position: relative;
`,a.ZP.div`
  transition: 0.4s;
  opacity: ${({state:e})=>"entered"===e?1:0};
  display: ${({state:e})=>"exited"===e?"none":"block"};
`,a.ZP.div`
  display: flex;
  align-items: center;
  justify-content: center;
  height: ${({withHeight:e})=>e?"auto":0};
  margin: auto;
`;const bt={small:"24px",large:"32px"};var ft;function Mt(){return(Mt=Object.assign||function(e){for(var t=1;t<arguments.length;t++){var r=arguments[t];for(var i in r)Object.prototype.hasOwnProperty.call(r,i)&&(e[i]=r[i])}return e}).apply(this,arguments)}a.ZP.div`
  width: ${({size:e})=>bt[e]};
  height: ${({size:e})=>bt[e]};
  animation: spin 1.2s infinite linear;
  background: url(${"data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iaXNvLTg4NTktMSI/Pgo8IS0tIEdlbmVyYXRvcjogQWRvYmUgSWxsdXN0cmF0b3IgMTYuMC4wLCBTVkcgRXhwb3J0IFBsdWctSW4gLiBTVkcgVmVyc2lvbjogNi4wMCBCdWlsZCAwKSAgLS0+CjwhRE9DVFlQRSBzdmcgUFVCTElDICItLy9XM0MvL0RURCBTVkcgMS4xLy9FTiIgImh0dHA6Ly93d3cudzMub3JnL0dyYXBoaWNzL1NWRy8xLjEvRFREL3N2ZzExLmR0ZCI+CjxzdmcgdmVyc2lvbj0iMS4xIiBpZD0iQ2FwYV8xIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiB4PSIwcHgiIHk9IjBweCIKCSB3aWR0aD0iNDU2LjgxN3B4IiBoZWlnaHQ9IjQ1Ni44MTdweCIgdmlld0JveD0iMCAwIDQ1Ni44MTcgNDU2LjgxNyIgc3R5bGU9ImVuYWJsZS1iYWNrZ3JvdW5kOm5ldyAwIDAgNDU2LjgxNyA0NTYuODE3OyIKCSB4bWw6c3BhY2U9InByZXNlcnZlIj4KPGc+Cgk8Zz4KCQk8cGF0aCBmaWxsPSIjMDE1MGE0IiBkPSJNMTA5LjY0MSwzMjQuMzMyYy0xMS40MjMsMC0yMS4xMywzLjk5Ny0yOS4xMjUsMTEuOTkxYy03Ljk5Miw4LjAwMS0xMS45OTEsMTcuNzA2LTExLjk5MSwyOS4xMjkKCQkJYzAsMTEuNDI0LDMuOTk2LDIxLjEyOSwxMS45OTEsMjkuMTNjNy45OTgsNy45OTQsMTcuNzA1LDExLjk5MSwyOS4xMjUsMTEuOTkxYzExLjIzMSwwLDIwLjg4OS0zLjk5NywyOC45OC0xMS45OTEKCQkJYzguMDg4LTcuOTkxLDEyLjEzMi0xNy43MDYsMTIuMTMyLTI5LjEzYzAtMTEuNDIzLTQuMDQzLTIxLjEyMS0xMi4xMzItMjkuMTI5QzEzMC41MjksMzI4LjMzNiwxMjAuODcyLDMyNC4zMzIsMTA5LjY0MSwzMjQuMzMyeiIKCQkJLz4KCQk8cGF0aCBmaWxsPSIjMDE1MGE0IiBkPSJNMTAwLjUwNSwyMzcuNTQyYzAtMTIuNTYyLTQuNDcxLTIzLjMxMy0xMy40MTgtMzIuMjY3Yy04Ljk0Ni04Ljk0Ni0xOS43MDItMTMuNDE4LTMyLjI2NC0xMy40MTgKCQkJYy0xMi41NjMsMC0yMy4zMTcsNC40NzMtMzIuMjY0LDEzLjQxOGMtOC45NDUsOC45NDctMTMuNDE3LDE5LjcwMS0xMy40MTcsMzIuMjY3YzAsMTIuNTYsNC40NzEsMjMuMzA5LDEzLjQxNywzMi4yNTgKCQkJYzguOTQ3LDguOTQ5LDE5LjcwMSwxMy40MjIsMzIuMjY0LDEzLjQyMmMxMi41NjIsMCwyMy4zMTgtNC40NzMsMzIuMjY0LTEzLjQyMkM5Ni4wMzQsMjYwLjg1NywxMDAuNTA1LDI1MC4xMDIsMTAwLjUwNSwyMzcuNTQyeiIKCQkJLz4KCQk8cGF0aCBmaWxsPSIjMDE1MGE0IiBkPSJNMzY1LjQ1NCwxMzIuNDhjNi4yNzYsMCwxMS42NjItMi4yNCwxNi4xMjktNi43MTFjNC40NzMtNC40NzUsNi43MTQtOS44NTQsNi43MTQtMTYuMTM0CgkJCWMwLTYuMjgzLTIuMjQxLTExLjY1OC02LjcxNC0xNi4xM2MtNC40Ny00LjQ3NS05Ljg1My02LjcxMS0xNi4xMjktNi43MTFjLTYuMjgzLDAtMTEuNjYzLDIuMjQtMTYuMTM2LDYuNzExCgkJCWMtNC40Nyw0LjQ3My02LjcwNyw5Ljg0Ny02LjcwNywxNi4xM3MyLjIzNywxMS42NTksNi43MDcsMTYuMTM0QzM1My43OTEsMTMwLjI0NCwzNTkuMTcxLDEzMi40OCwzNjUuNDU0LDEzMi40OHoiLz4KCQk8cGF0aCBmaWxsPSIjMDE1MGE0IiBkPSJNMTA5LjY0NCw1OS4zODhjLTEzLjg5NywwLTI1Ljc0NSw0LjkwMi0zNS41NDgsMTQuNzAzYy05LjgwNCw5LjgwMS0xNC43MDMsMjEuNjUtMTQuNzAzLDM1LjU0NAoJCQljMCwxMy44OTksNC44OTksMjUuNzQzLDE0LjcwMywzNS41NDhjOS44MDYsOS44MDQsMjEuNjU0LDE0LjcwNSwzNS41NDgsMTQuNzA1czI1Ljc0My00LjkwNCwzNS41NDQtMTQuNzA1CgkJCWM5LjgwMS05LjgwNSwxNC43MDMtMjEuNjUyLDE0LjcwMy0zNS41NDhjMC0xMy44OTQtNC45MDItMjUuNzQzLTE0LjcwMy0zNS41NDRDMTM1LjM4Nyw2NC4yOSwxMjMuNTM4LDU5LjM4OCwxMDkuNjQ0LDU5LjM4OHoiLz4KCQk8cGF0aCBmaWxsPSIjMDE1MGE0IiBkPSJNNDM5LjY4NCwyMTguMTI1Yy01LjMyOC01LjMzLTExLjc5OS03Ljk5Mi0xOS40MS03Ljk5MmMtNy42MTgsMC0xNC4wODksMi42NjItMTkuNDE3LDcuOTkyCgkJCWMtNS4zMjUsNS4zMy03Ljk4NywxMS44MDMtNy45ODcsMTkuNDIxYzAsNy42MSwyLjY2MiwxNC4wOTIsNy45ODcsMTkuNDFjNS4zMzEsNS4zMzIsMTEuNzk5LDcuOTk0LDE5LjQxNyw3Ljk5NAoJCQljNy42MTEsMCwxNC4wODYtMi42NjIsMTkuNDEtNy45OTRjNS4zMzItNS4zMjQsNy45OTEtMTEuOCw3Ljk5MS0xOS40MUM0NDcuNjc1LDIyOS45MzIsNDQ1LjAyLDIyMy40NTgsNDM5LjY4NCwyMTguMTI1eiIvPgoJCTxwYXRoIGZpbGw9IiMwMTUwYTQiIGQ9Ik0zNjUuNDU0LDMzMy40NzNjLTguNzYxLDAtMTYuMjc5LDMuMTM4LTIyLjU2Miw5LjQyMWMtNi4yNzYsNi4yNzYtOS40MTgsMTMuNzk4LTkuNDE4LDIyLjU1OQoJCQljMCw4Ljc1NCwzLjE0MiwxNi4yNzYsOS40MTgsMjIuNTZjNi4yODMsNi4yODIsMTMuODAyLDkuNDE3LDIyLjU2Miw5LjQxN2M4Ljc1NCwwLDE2LjI3Mi0zLjE0MSwyMi41NTUtOS40MTcKCQkJYzYuMjgzLTYuMjgzLDkuNDIyLTEzLjgwMiw5LjQyMi0yMi41NmMwLTguNzYxLTMuMTM5LTE2LjI3NS05LjQyMi0yMi41NTlDMzgxLjcyNywzMzYuNjEsMzc0LjIwOCwzMzMuNDczLDM2NS40NTQsMzMzLjQ3M3oiLz4KCQk8cGF0aCBmaWxsPSIjMDE1MGE0IiBkPSJNMjM3LjU0NywzODMuNzE3Yy0xMC4wODgsMC0xOC43MDIsMy41NzYtMjUuODQ0LDEwLjcxNWMtNy4xMzUsNy4xMzktMTAuNzA1LDE1Ljc0OC0xMC43MDUsMjUuODM3CgkJCXMzLjU2NiwxOC42OTksMTAuNzA1LDI1LjgzN2M3LjE0Miw3LjEzOSwxNS43NTIsMTAuNzEyLDI1Ljg0NCwxMC43MTJjMTAuMDg5LDAsMTguNjk5LTMuNTczLDI1LjgzOC0xMC43MTIKCQkJYzcuMTM5LTcuMTM4LDEwLjcwOC0xNS43NDgsMTAuNzA4LTI1LjgzN3MtMy41NjktMTguNjk4LTEwLjcwOC0yNS44MzdTMjQ3LjYzNiwzODMuNzE3LDIzNy41NDcsMzgzLjcxN3oiLz4KCQk8cGF0aCBmaWxsPSIjMDE1MGE0IiBkPSJNMjM3LjU0NywwYy0xNS4yMjUsMC0yOC4xNzQsNS4zMjctMzguODM0LDE1Ljk4NmMtMTAuNjU3LDEwLjY2LTE1Ljk4NiwyMy42MDYtMTUuOTg2LDM4LjgzMgoJCQljMCwxNS4yMjcsNS4zMjcsMjguMTY3LDE1Ljk4NiwzOC44MjhjMTAuNjYsMTAuNjU3LDIzLjYwNiwxNS45ODcsMzguODM0LDE1Ljk4N2MxNS4yMzIsMCwyOC4xNzItNS4zMjcsMzguODI4LTE1Ljk4NwoJCQljMTAuNjU2LTEwLjY1NiwxNS45ODUtMjMuNjAxLDE1Ljk4NS0zOC44MjhjMC0xNS4yMjUtNS4zMjktMjguMTY4LTE1Ljk4NS0zOC44MzJDMjY1LjcxOSw1LjMzLDI1Mi43NzksMCwyMzcuNTQ3LDB6Ii8+Cgk8L2c+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPC9zdmc+Cg=="}) no-repeat center center;
  background-size: cover;

  @keyframes spin {
    0% {
      -moz-transform: rotateZ(0deg);
      -webkit-transform: rotateZ(0deg);
      -o-transform: rotateZ(0deg);
      -ms-transform: rotateZ(0deg);
    }
    100% {
      -moz-transform: rotateZ(360deg);
      -webkit-transform: rotateZ(360deg);
      -o-transform: rotateZ(360deg);
      -ms-transform: rotateZ(360deg);
    }
  }
`,a.ZP.div`
  overflow: hidden;
`,a.ZP.div`
  padding: 24px 16px;
  cursor: pointer;
  border-top: 1px solid #e4e5e7;
  display: flex;
  align-items: center;
  justify-content: space-between;
`,a.ZP.div`
  font-size: 14px;
  font-weight: bold;
  color: #343a40;
`,a.ZP.div`
  height: ${({open:e,itemHeight:t})=>e?t+"px":0};
  overflow: hidden;
  transition: all 0.3s;
  padding: 0 16px ${({open:e})=>e?"24px":0};
`,(0,a.ZP)((function(e){return i.createElement("svg",Mt({xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 448 512"},e),ft||(ft=i.createElement("path",{d:"M6.101 359.293L25.9 379.092c4.686 4.686 12.284 4.686 16.971 0L224 198.393l181.13 180.698c4.686 4.686 12.284 4.686 16.971 0l19.799-19.799c4.686-4.686 4.686-12.284 0-16.971L232.485 132.908c-4.686-4.686-12.284-4.686-16.971 0L6.101 342.322c-4.687 4.687-4.687 12.285 0 16.971z"})))}))`
  width: 20px;
  height: 10px;
  transform: rotate(${({open:e})=>e?0:180}deg);
  transition: transform 0.3s;

  path {
    fill: #0081ff;
  }
`,a.ZP.div``,Object.defineProperty,Object.getOwnPropertySymbols,Object.prototype.hasOwnProperty,Object.prototype.propertyIsEnumerable,a.ZP.div``,a.ZP.div`
  display: inline-block;
`,a.ZP.div`
  display: flex;
  justify-content: center;
  align-items: center;
  width: 100%;
  height: 150px;
`,a.ZP.img`
  max-width: 130px;
  max-height: 130px;
  margin-top: 10px;
`,a.ZP.div`
  display: flex;
  padding: 10px 0;
  font-size: ${({theme:e})=>e.fontSize.extraSmall};
  font-weight: bold;
  margin: 0 16px;
  word-break: break-word;
`,a.ZP.div`
  margin: 0 16px 8px;
  display: flex;
  align-items: center;
  justify-content: space-between;
`,a.ZP.div`
  display: flex;
  justify-content: center;
  align-items: center;
  height: 48px;
  border-top: 1px solid ${e=>e.theme.colors.lightGrey};
  color: ${e=>e.theme.colors.darkBlue};
  font-size: ${({theme:e})=>e.fontSize.headerLarge};
  font-weight: bold;
`,a.ZP.div`
  display: inline-block;
  margin-left: 8px;
  margin-top: 4.5px;
  font-size: ${({theme:e})=>e.fontSize.extraSmall};
  font-weight: 600;
`,a.ZP.div`
  width: 200px;
  box-shadow: 0 2px 4px 0 rgba(0, 0, 0, 0.25);
  background: ${({theme:e})=>e.colors.white};
  color: ${({theme:e})=>e.colors.darkGrey};
`,r(184);var yt=r(8840),vt=r.n(yt),xt=r(2929),zt=r.n(xt),Nt=r(195),jt=r.n(Nt),Dt=r(9662),Ot=r.n(Dt),At=r(8393),It=r.n(At);r(5708),It()(vt()),Ot()(vt()),zt()(vt()),jt()(vt());var Ct=Object.defineProperty,St=Object.defineProperties,Pt=Object.getOwnPropertyDescriptors,Lt=Object.getOwnPropertySymbols,Tt=Object.prototype.hasOwnProperty,kt=Object.prototype.propertyIsEnumerable,Et=(e,t,r)=>t in e?Ct(e,t,{enumerable:!0,configurable:!0,writable:!0,value:r}):e[t]=r;const Zt=({children:e,onChange:t})=>{const r=(0,i.useCallback)((e=>{t(e.target.value)}),[t]);return i.createElement(Bt,{onChange:r},e)},Bt=a.ZP.div``,Gt=a.ZP.label`
  display: flex;
  cursor: pointer;
`,Rt=a.ZP.div`
  width: 16px;
  height: 16px;
  border-radius: 8px;
  border: 1px solid ${({theme:e})=>e.colors.middleGrey};
  position: relative;
  top: 2px;
  box-sizing: border-box;
  transition: all 0.15s ease-in-out;
`,Ft=a.ZP.input`
  display: none;

  &:checked + ${Rt} {
    border: 5px solid ${({theme:e})=>e.colors.blue};
  }

  &:checked:disabled + ${Rt} {
    border: 5px solid ${({theme:e})=>e.colors.middleGrey};
  }
`,Ut=a.ZP.span`
  padding-left: 10px;
`;a.ZP.iframe`
  width: 100%;
  height: 440px;
  border: none;
`,(0,a.ZP)(v)`
  color: ${({theme:e})=>e.colors.white};
`,Object.defineProperty,Object.getOwnPropertySymbols,Object.prototype.hasOwnProperty,Object.prototype.propertyIsEnumerable,a.ZP.div`
  cursor: pointer;
  display: flex;
  align-items: center;
`,a.ZP.img`
  width: 100%;
  height: auto;
  max-width: 87px;
  max-height: 19px;
`,Object.defineProperty,Object.getOwnPropertySymbols,Object.prototype.hasOwnProperty,Object.prototype.propertyIsEnumerable,a.ZP.div`
  padding: 24px;
`,a.ZP.div``,a.ZP.div`
  overflow: hidden;
  transition: height 0.2s ease;
  height: ${({height:e,open:t,auto:r})=>t?r?"auto":e+"px":0};
`,a.ZP.div`
  padding-top: 16px;
`,r(9852);const Vt={com:"0 93.38843%",ad:"0 .413223%",ae:"0 .826446%",af:"0 1.239669%",ag:"0 1.652893%",ai:"0 2.066116%",al:"0 2.479339%",am:"0 2.892562%",an:"0 3.305785%",ao:"0 3.719008%",aq:"0 4.132231%",ar:"0 4.545455%",as:"0 4.958678%",at:"0 5.371901%",au:"0 5.785124%",aw:"0 6.198347%",az:"0 6.61157%",ba:"0 7.024793%",bb:"0 7.438017%",bd:"0 7.85124%",be:"0 8.264463%",bf:"0 8.677686%",bg:"0 9.090909%",bh:"0 9.504132%",bi:"0 9.917355%",bj:"0 10.330579%",bm:"0 10.743802%",bn:"0 11.157025%",bo:"0 11.570248%",br:"0 11.983471%",bs:"0 12.396694%",bt:"0 12.809917%",bv:"0 13.22314%",bw:"0 13.636364%",by:"0 14.049587%",bz:"0 14.46281%",ca:"0 14.876033%",cc:"0 15.289256%",cd:"0 15.702479%",cf:"0 16.115702%",cg:"0 16.528926%",ch:"0 16.942149%",ci:"0 17.355372%",ck:"0 17.768595%",cl:"0 18.181818%",cm:"0 18.595041%",cn:"0 19.008264%",zh:"0 19.008264%",co:"0 19.421488%",cr:"0 19.834711%",cu:"0 20.247934%",cv:"0 20.661157%",cx:"0 21.07438%",cy:"0 21.487603%",cz:"0 21.900826%",de:"0 22.31405%",dj:"0 22.727273%",dk:"0 23.140496%",dm:"0 23.553719%",do:"0 23.966942%",dz:"0 24.380165%",ec:"0 24.793388%",ee:"0 25.206612%",eg:"0 25.619835%",eh:"0 26.033058%",er:"0 26.446281%",es:"0 26.859504%",et:"0 27.272727%",fi:"0 27.68595%",fj:"0 28.099174%",fk:"0 28.512397%",fm:"0 28.92562%",fo:"0 29.338843%",fr:"0 29.752066%",ga:"0 30.165289%",gd:"0 30.578512%",ge:"0 30.991736%",gf:"0 31.404959%",gh:"0 31.818182%",gi:"0 32.231405%",gl:"0 32.644628%",gm:"0 33.057851%",gn:"0 33.471074%",gp:"0 33.884298%",gq:"0 34.297521%",gr:"0 34.710744%",gs:"0 35.123967%",gt:"0 35.53719%",gu:"0 35.950413%",gw:"0 36.363636%",gy:"0 36.77686%",hk:"0 37.190083%",hm:"0 37.603306%",hn:"0 38.016529%",hr:"0 38.429752%",ht:"0 38.842975%",hu:"0 39.256198%",id:"0 39.669421%",ie:"0 40.082645%",il:"0 40.495868%",in:"0 40.909091%",io:"0 41.322314%",iq:"0 41.735537%",ir:"0 42.14876%",is:"0 42.561983%",it:"0 42.975207%",jm:"0 43.38843%",jo:"0 43.801653%",jp:"0 44.214876%",ke:"0 44.628099%",kg:"0 45.041322%",kh:"0 45.454545%",ki:"0 45.867769%",km:"0 46.280992%",kn:"0 46.694215%",kp:"0 47.107438%",kr:"0 47.520661%",kw:"0 47.933884%",ky:"0 48.347107%",kz:"0 48.760331%",la:"0 49.173554%",lb:"0 49.586777%",lc:"0 50%",li:"0 50.413223%",lk:"0 50.826446%",lr:"0 51.239669%",ls:"0 51.652893%",lt:"0 52.066116%",lu:"0 52.479339%",lv:"0 52.892562%",ly:"0 53.305785%",ma:"0 53.719008%",mc:"0 54.132231%",md:"0 54.545455%",me:"0 54.958678%",mg:"0 55.371901%",mh:"0 55.785124%",mk:"0 56.198347%",ml:"0 56.61157%",mm:"0 57.024793%",mn:"0 57.438017%",mo:"0 57.85124%",mp:"0 58.264463%",mq:"0 58.677686%",mr:"0 59.090909%",ms:"0 59.504132%",mt:"0 59.917355%",mu:"0 60.330579%",mv:"0 60.743802%",mw:"0 61.157025%",mx:"0 61.570248%",my:"0 61.983471%",mz:"0 62.396694%",na:"0 62.809917%",nc:"0 63.22314%",ne:"0 63.636364%",nf:"0 64.049587%",ng:"0 64.46281%",ni:"0 64.876033%",nl:"0 65.289256%",no:"0 65.702479%",np:"0 66.115702%",nr:"0 66.528926%",nu:"0 66.942149%",nz:"0 67.355372%",om:"0 67.768595%",pa:"0 68.181818%",pe:"0 68.595041%",pf:"0 69.008264%",pg:"0 69.421488%",ph:"0 69.834711%",pk:"0 70.247934%",pl:"0 70.661157%",pm:"0 71.07438%",pn:"0 71.487603%",pr:"0 71.900826%",pt:"0 72.31405%",pw:"0 72.727273%",py:"0 73.140496%",qa:"0 73.553719%",re:"0 73.966942%",ro:"0 74.380165%",rs:"0 74.793388%",ru:"0 75.206612%",rw:"0 75.619835%",sa:"0 76.033058%",sb:"0 76.446281%",sc:"0 76.859504%",sd:"0 77.272727%",se:"0 77.68595%",sg:"0 78.099174%",sh:"0 78.512397%",si:"0 78.92562%",sj:"0 79.338843%",sk:"0 79.752066%",sl:"0 80.165289%",sm:"0 80.578512%",sn:"0 80.991736%",so:"0 81.404959%",sr:"0 81.818182%",ss:"0 82.231405%",st:"0 82.644628%",sv:"0 83.057851%",sy:"0 83.471074%",sz:"0 83.884298%",tc:"0 84.297521%",td:"0 84.710744%",tf:"0 85.123967%",tg:"0 85.53719%",th:"0 85.950413%",tj:"0 86.363636%",tk:"0 86.77686%",tl:"0 87.190083%",tm:"0 87.603306%",tn:"0 88.016529%",to:"0 88.429752%",tp:"0 88.842975%",tr:"0 89.256198%",tt:"0 89.669421%",tv:"0 90.082645%",tw:"0 90.495868%",ty:"0 90.909091%",tz:"0 91.322314%",ua:"0 91.735537%",ug:"0 92.14876%",gb:"0 92.561983%",uk:"0 92.561983%",en:"0 92.561983%",um:"0 92.975207%",us:"0 93.38843%",uy:"0 93.801653%",uz:"0 94.214876%",va:"0 94.628099%",vc:"0 95.041322%",ve:"0 95.454545%",vg:"0 95.867769%",vi:"0 96.280992%",vn:"0 96.694215%",vu:"0 97.107438%",wf:"0 97.520661%",ws:"0 97.933884%",ye:"0 98.347107%",za:"0 98.760331%",zm:"0 99.173554%",zr:"0 99.586777%",zw:"0 100%"},Wt="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACwAABx6CAMAAABT87djAAAC0FBMVEVHcEz8blE2SqFDSlT1+PtSwWI7r9rtVWVHWKlXqGPS0dRKidz212D/z1Pwh3/8q1dOi5LtVGX+//+zKjjuVWSwsrTot0SMuuLmR1K6V3hHvlZFV6nSs8NXqGNCntz3+fv6z1dRwWGlRHdObb9CSVQwPk6RuOGpRGPTxcyXv3Xpqa/19/pHWKntVWVXqGP///9SwWI7r9pDSlRKidz31mD/z1MBJH4BAWX2///PECmMu+T3vEE7WqLsPlDtSFntT2LvKTT+3wfy1mABfwDuUmT/3VHsRGcCInD11to/Uqk/ht3dKA8CeF42e9H7+vv3AwPbIB7+zjgBAAD80RgRhwD9VF1Gty0xWLL54+UtQZ3wh5HLAwYCesDtGSIBDlXi4+MBJFWlRHY/m0wYN4j0klz88O3+SWX/218wSLRpebkFGaopq9/tYWsyZv7wc370qrFNoljM4fTym6Pc5fHR6Nbq8fM4P03552D/JzcbjEEBMJn0x80GiTBUaK7TJTcgIWH+WGl+kL9AwGPOVmTL1Oj2ur+Txp+irdIjQo69vb7wc2BBo2XbAQopMj5tV5n4vlyQkpO2vtsvSlJNqWO/CjAx8BEqOlR3epIXGXKz27yajFsIlsoZO3FDs2NmrGb/7VKQnMjeNjo90GJfapzvOERTaWcyhu4DUPG2dWL90QEyO3aovF/+/gL10FHfwl9qUVkljRj54ZecV4aDsV6rnX50ueGk064FYbPGrWr5SVLPO0ulyOu2lkt/wYvTz2joz2A7uk1HT4t+k2R9c07Fx09sunzxXDDTxQv4pS6lp6GIx2BPkMezCRmSS1z57AT368FsnuE/uOSAKB7f3RD7gRP76/0UExCVria+nrIpeq+cgw4aOa3Kx5VKsM/GeorAphGVdqROujNNNkVotr5nYxUsZiE3gYHbdYqs8qi4UxAvJxNLp5ZknBNq8VbXZX1QP3CehJUSAAAAK3RSTlMA/f7v7u7u7u7u/u7u7iX+JfXv/aH99+/3/v6h/qGhoaGh7v6h76GhoaBmgP35vAAA39tJREFUeNrsvY97U1W28H+MIFoRKFAtiOp80Xnve9NwsC0lBZoApm3CXDJU7Usa1N6hDW0kTwJJQ7+am9KQhLS9YFt9XgqMQEraeRi8UOpFplAAC4IIhWJ1pAK3+DDoc+Uy/8O79jknyfl99nFkRrALmpzkfLKy9tr7rJxz9t5rE8Q/Z+HJP00iiH9uxpZJRBY8ZiX/s7ezmnl7mv+J4H44S+oVpZPISm2iv6wsDpXF/QiRxX6VlQEvWOZkJPfRnyJYr7KyMkhtVuqjWVmVZGUW6wtSMPWykiTTdBb10s8uBZHVnPoHihFNW5CV5UevMugX9D+CW/o0nWZZmjPY0kzptqJNiq1s5uzmwiAMraVY3j4WXJemtX4xlobrUiQSK0lLJUtJnbgZGYwJVpEdLLgyqYADVzJ/abhSoBi5jSN1omYgk61ahq6Td52VxqxC3Wk46RBKb2UGz9HMFxCVHKF9Rok1vZkUQoplaL8krOUqo02S1OznfrGV1MqYUemXfcmD5UUd/Bw++0/EJHwYgt2kf8rAEhQYiSlPP5qS2sP1E9lSnTkhJdMBnvJoTlpqD+/JZ0l9dYkuLZmTiKdzcGHddOJRfHiCGjjznmkeg8fgMfgffcCqCjKqwpeqwEhMms68WnN673gZ+dUUYDOTXwPwXDkZP4WYrsOF5/6KmIAPjycy1cAT7nd4prywYMOsOgVhwUVmUl6msuGAXisr48ZgKViNn8tH2xSEBTfe2qogbLjnvVxZefgewpn3TPN0fPgFVvhSgh+ewgqMjT0vPiwjL0xB56IvpN948VLjBJas2bfrsZQ8A/CUh1nf9N6lRnaoB3hOWh6bQryQiwvPeYZ4GB9+7IGATQYTTZoMyrDRrTMZDQajSec2KsFH7VaPQWe36wweq/2oArzGTNoNXofDa7CTZiXYTZq7dJ5AwKPrMpONCrCd9Ba5vDqd11XkJe2KsMdj9xoMXrtXGXaTDo/bo9N57B4b6VaAywFxebxej8tN2pRdR9rcBqPR4LaRiq5rNHhI0mO3o0eDcg2Cl1HIBE8blRuSsUgHnrDrioxYrc5YBGJ8UI8UWVhVkFEVvlQFRg6sFHInKcX7lIk9k4jp4Vws+r3c8HRiQuMlPrxhG4gAhuIQmSbeb8mGbT1ndu48k7uNZ0SjKRN+2hqNbEM25B5fWFZWtvB4zzaOEcZGuECA38HGMFvH8bKFSMoWcuhwo46GdSyzt+2kWaCf5FcWA6fM3pD7ZBJeWHZmW9rgNIwM2XCLUtyTYheWHafhWxsoI1KwrnzG7y/S8heWMG/9fka5jg2bykNf0LKWJcxboXITB9aVGy+ufUlU1l40luu4sO5o+CVReu1L4aM6Pqw7OioOjx7VCWHT0ZAIvTZ01CQC68p1/yWg1/6XrlwnBouY/UXaYD6sO/otD1777VGdFGwsD63lSKjcKAnrjmb2cyTzqE4a1kHgZ4mdwwpgU5EndRKt9xSZZGGd0WhmaL3ZaNTJwzqDy0HReofLoOPDmbx3dEV2PdB6vb2IvydToBl+JKIIjhYZdQLN0/lv6QxgNhhsEOyYzjoXTdNuvd4tZNEVfepcNC3ZXm+24E3qit6qTWyvApnV2TkLPVc5Rzs9TVV8aXL6CMKR7SHj20sLCmY1FM4qKCit+taYbfMViEiVjwiNZGc6fAPzabg0ONppJ9urxOACJ1FVgL4WlI80FI5UhTKzzdrE/FJRuIloqtq+aKTTTUZmFRZmjGTbyUgTFEEUriKovgdb1OYIFBYGzAGrg7olXCUOdzYkpbAwtdkgoRkYEdlO7f2gtLR0//75pRs/wNDcfePw50NDn7fd6GBg6u68w2q2mcFmq8Ps8FVW2ippm7tJcqgXndd0M3BTVUFThLQXjWSAN2Cjc2RRQdIbALd+1drqSMFV8xN+c7bx2yrk54I46ekcdRYwfh4gyfOtQ0MszTHS2zkaZKp7/oDPkZk90sTAQ0Otvb3nh8iBpM227Oxvq1DbWLECtY3tlPIqBm7tBeXnh5KwpwGpBaHMAJmf48sI067bb+0FGTrfu5+Bt2+v4rWE0lQBP/D3fvUV4JWlyQIWSEtpBtgx1Eo2Y8Ft6NRxiGzDgQv2R1DEi+wvwIFLTyP4dCkWXLBxc3//5o0FeHDBtiM7thXgwgX79xfgw5zGf+/gJny4iXDiw07Ch20HhC/C5xRGQRGhAqNYyBUVFHJFgrmEQDCfrsOW6cIfIGkR+WmTsYOnGX5UjYYi+PGBB6OO9xPL+4U1ul0Gtydq1+nsUY/b4HIbZWCD1+xyRUlSpyPJqMtl9hpkNXs8gajdFo3a7NGAxyOv2e3x2kivnSTtXtLm9dgNsnAgaiZtZpI020hzNOBWMAM0MwKaZc0wur1s2Ktksyd1P9AMBZQ3I8qGo/JmuLyeaJTCoXger0sBjsKtAqvDYfXaPVF52GT02LvspAduWZCw4TGaZDWjexBRt8PhjoJqj4IZHqB1AZIM6ICVh8EdOoPBHrBaA3aDQec2yp8Eolbs8tpsqGz8E7AJYoeV0RQI6Ixih5XYMWhwi5ypScFg909+wCqEAlVBRlX4UhUYf2FRVEHzzwTOLMeWTOJdFUI8uhJbHuX2lsrLLwCuVSFEhwohnijGlXlPEE/Mw5ZfAPw8Pvw8MQlb9RMo2D3/BJY8j6Ior8fQvCIl/M5FASsHk6LwFuo/FrzlR2jeci80M7pxYUzNtjdSIoSDPMnZv3Hjxv3UQw5/HyG8HqkINRW8owm9I9xDoPfYfwUFQe0iuNrxVzAEaycBD+8U0P/fofdVaeCiiHoo4O58h2CItOZ3Cjjfk9oJDwT70/Dtsao0XhVzFnC+FplB769CD6FI+tsLqiKhlOYqRnP6G98p4Nzngcuv1NfSBXwn+ZopIDw2MQ9sm99Jak4Xj3ozGAHXaSLBlIaqpGEilaJpBxdXtC8SqRR+xF60PyWL+PvEGtIK1IpWbHnjJ26iP+IYxD5S1B6DdODAgreo1SweNwh8myGK2lwNfCmk/vPEZQNW/FagiDTYCHchtriJY/jwMaIBH274+8Mrzq3Ahs9d/o+vsOEV584vefUcHnzuHFJ+Hgde8dX5V79aUXhuyVc4ms9dvoxMOL9kBQ58/jyCv3oVQ/O5aYOF8PbguctfDXLhO6/w5esvb9Mbty/f5uy4Q3wtgF+5yUC3P+NpEYPvLKF131xyRxl+5c7NJde+fuX2kmvKmu9QFty88+XNVxThO0tu3r7z9e2bn127rQy/cu0/lixZcvnanZvXvlaGv7595+bNO7df+fraZzgFTMptLi0Pv3L7tgqYb/MdfPgO0Y0PdxMZ2HZ8nUEQGT1fY0kPsIT/yrLlGLLsip8gfHmC96/k5YnheT7iCv+9fp9Vq/VHRPgrBN+GBUyY90f6BTzBe32R9bOwvv+KPLyA+zOyvl8Ip9/q5/3oaPMEcCSS/EK/MnyFJBfkiVgBskBo8xU/qb2StyCiFcARIXxRm5x1gwEvv+KTGLzYL+a6K1pxWMuqmxScpyUVdafg9eRPAi8QFlDSCtKfJ7Q5IgX7RBqSlG7rArFWJ+HpiGgT7dcq1Qq7PedB04BDSqtY3Qx+BQ7WvAXr+9Mt9YrMkcI/BvqXK8PrBW6ThpPHwHruEUuIhqMr/RG/v79/AT8UXJEIVyJR6QrhW44tKNjhBkbUuzTl109hya/REKqnFmDKU1OIXy/All8TT+HDT/1s4I+x5SlivQ9b1hNTSWyZSowTGfat19r0erHR4ONE0N7WhflDeixY23t+4cLzC4W0CKwfOo/GZp1vxdGs72WGcglU/82wGjNUFVCl66QrRVV1q2pIqpro/XgMqgoyqsKXqsBIVCbQ/TYZuQWXWsfsAXT5XymP3hoeXNXgjjromwUJeXKwMOxBpLW5krQS0opvDaKvR7ci9BmfXxrOAFjm64+5o2iCsHZk3zBIpQSMSPh6qsvZP3IJocOXSFF4mPp6Gz0nXEujw8PNIjAoLTzmDiRnj5OVDNvj58OUn5ivZ2SEYdHMaDZMfb3XxjmSMoaHf0DwYRjElYb5X8/IrEttw8PTEJ3R7Kdh5usdImdTlRmohNOG22iY9pNXdPaNtrlSv5My+vPmZq2VmAb3Wrxmq/jBX9lcWdmMVO/T+lGlINhjk4gUfTdgzjfy3k6S9ganXfHkxg30CKoPIzZVwMJjowGBxTcOUvQl1DDYfkal5DvZeuP8zeMw7/34tREyrZlVfVEOf6Ovr+/mjZs3mG8SVDeYw3LNjeaMvmvXoJxWUqQhUebYk063Hr/Zd/jatePHr90QaN4oqM4bN4/37Tx840ZfJUnKNP4GdwDxlX03b9487hexmXP8r6KPfzLjxvHDfr43xM1Bcwz8zDmvDJw2h/GOVS4UsMIR3dCsskGGdaijyrUqhS+W+QEU7BIb31QU4MO2sT76n2UffbYBW7IJswohpuqxRfyESnLO4wMPq3DdVHWVoqq678sxJw/8SKd/HuessMxyz3pU82jEVj5j5aMS8jScuP7zYo/eeR3glZr1jiJ3hkZ6YMgUYpxncVQ/OwZwxGHQkf0V6b0WHv00ESIRndE4a70VsRo2YeGPOakIkd7FUdLoANbKZjXOmIYPa95x6r1FHlfABew7Fan9llCEbHeilxZLCm5vj/lINNTTZSPbY+1xTUoxSfqQIRXOoCYJu93uRqPLZDK4XCa3u8W9MgkHIxGww5ITjMSCSXgWSCAKw1S95uisqGckqdkSDGqCqIwRkozRljxKzJ69cj3pdrncJrP/4srZs1OOsGgob2hiJOnUJAtY0U/qTGaXw7s44A9WWPhO04Ti8TTcT7oMDtJoJu2LA9ogXScWSyyY4jWatDdIV5Fj/azGWVeANvupkmuc7WQkZBEOBJqK2Ipm96zrcUSvr6AK5yetTo0QdpU71lsqMloCKyuALveupKxoj7TTdls0bPijb+M5mhznu054PxR6913qbeS2IF1Q1hc8SqxciTygWYneq6hYydSJhtGb0+5P264w0smiiZDxCiFsEaU1zlDQgj2GSsNqtAxsqchpt1RYsEZnWYLOOBl3Bi14MLo168vBgqmWTgY1OZiwtt3nxIQtTqfG6bRgDj+DJqCxKA8/exp/rNrT3Gwk8oqncLORyAkKjIR/QR6WLPAThD9vGUjqQeYvz08sQNiyfoqWxZctW0BcoSD7FSUUHq4QaOsPV7rif1DWnIfgvCujhaNX5A2BhzyA8xbYu6BjeLGdZTf/md5GZuRdic8oDMevpN2C1LCe85itPNrm+GK2zfwPsDWjF+4rnLfFjEhqXpbXztaSx3tOfgujmVuD4pqTruPjye087rcJNC8TRdOa8zieF7g6/W1SmvN4n8tL2Sz8cu577IaUx1XM2WR/lKUZQ1BDwhei7FVsKSM+VSHEH1QI8aEKIV5dgi2vEqGL2BJS5+cF+PACJnxhKfarC4yqQq6qYK7qZ2JsgDcHtghkpQXOX0TkUWJGWPgvPDo6Gha+P4MQDts/2hggA163yIB+4bUVTJYm7QajzmDCuMQzeEhvl8HltZtMGLAZzpGNUdIqMgtbAjaTpNuAawZMjzLi2KyDAhqNoF0IrxEIcp3Z4xbuWEOExYSqFKEQj70vIuvWrRN59zHisTnY8guAn8GHIRsJtmoqG8kzj2EJnY0ERVGNpY2bQI+R+rZafhRFly61fZzcfIzsaavlRVENXNE5K3IO7pGH6ShqCUb8Tk1tIr9GHqYjElzPwQVubVtNDQYM1wfBSHuQl1JQCoaLfdIa1FgEhRSFc3JioRxNbfBUMRZsqQiC/zp4ZkvBlhjZrqlt24MD51ji2phFw6sbSTgHXQ/W5hwsxoDBf5ZYxFmbYJstCYNuHxkHs4trMGDwdsyp0bDrRgYGSyqccGmfLqQcjC45Sef1xNJiHBgufeGuRbpuZOEc6oZCum7kYbiEd0ZilmTdKMA5mjjptyTrRgm2BKkGSNeNEpxsgG3FeLClnYzRdYMDx+AWiMYCh7syjO7E5ISCKxNLazBgsDoENyWgbniw+KmaJuSPQHA4zAsyEieBFie6pWY5eLgW+4rekuiwcK7oufBBTgw9XCtzLmrJOcgOBXtYRgjPRWVh/rmoPPzoAwTXYMJwhNQc7AO6vkYZ7jtVX78zFx4OHlSEAeyr6dm2E54x4JrcM/U7Hz64dMPOemUz6o/31Pf11PT1nMKwuebUwwcB3nmmHssbZ4739eSfOY4D59fvPHO8p6/nIB58fANKmQVbGDBUyc6evr6leNUNDsnNr8dtG+C9UzXYDenUQRWtrqbmwTmsVAUZVeFLVWBUdeKq6pRY1cn23/cCAV0bYcLv70o/KsG75uzcF84M7zst0C6Ed53OhCs/I/zt271LAd61c80aJmPGmvCc92XhXaeTLEqaGJaH39+3hpWNY83OXTLw+6c5OSxA9fvSMFjMvow3Ze6Wg9lWAGw6vQsfNsrCasxQVUBVrlNXKaqqm9OQ5uz6SZuousav7rB64K7o2clId3Kv6/kd+pw0p3ACw86436ozcYcKcBKoysIwCOFhfHiCHJzPgzN/Ms1/kxkTxswYM2PMjJ/+gFUVZFSFL1WBcWy86D9wfJ3RhA+bXPiaja7WFiMuXNLCW6BGEjaWlJRU17eiJ+XOl4eqq6vRQQJPws6XfTzpq69HbRoe+/i79hF7ebJp7in6WuzCJv6uvcR4/vormy4guObDTSIrswjhszVIMOELNUs/PFlzci4WfPLU3E1zP0QPyvDcC4Bt2jQXS/PcTdJLz4yfiy33J/wrfPhXxBRs1ePRueivxmMJWkqJmPTcOCx5DkVR7GHK4yYRz+EPaX5ubID3j58SeEKFEDM/wZaZD/4xeO/gvSpE8JsiJyJDBaRlbNT93y2/aCqKerIVz0XTsUAfFU/JmjaDFUX1+qhYYlhWAdlBRjSHP9t149hzk+0G+UphmWxzF5l0mJr1Adny8c1QoCdwC2h2GfFhrQpvONzYZoARRTp8bxjVeMPsUuMNG34BVcFqzFBVQFWuU1Up6qpbVUNS00RVNX5Vh5WqAxYjFKgKMqrCl6rACCE3O1sx3mZP8FDnolP1AVeRUdbBhiK3Wa+fClGU1OsdXoOMsaYik0evt5L+/02crSNJvT7gllROqyXJHXNnEjPnHtECrfUaU40ZEtgXFTHDGE1FOlrt5pkz4RRi5icp5QZ6GRej2253uygc1NpotZ8w5xufzNxMKffoQLnB5DVD9ehtkDTeUKSLUmpPfDIzdXKSVG52F1EG6rXUFECPgaWWdSYzc+ZmP2nV671ubSoxBWjXgtpKWi3ntOeTuTuQcq2ewjzMs9WaVMs9R5r5CSinGK05qvMG0IY1rZZ/QgXKrfQKPDCz0Is+R9Z9Inn29clmkmnWi03Ud5DaszOl4Jk7aNgBqeapxXus5OZPJOE6GkbKaa+QR+RhvdZMoWbKaBkYmQFVY0P63VG9Vs4MKCC0KIi7Hn3UZTDZHaRfqoCo0q2g2LDYaIMY2QXrAoHrxOFPZh6xQhUC5rajhYbc0Eqs/iPpCkzDMz85UUdXt82st4HRZr3DhlpcXboOk/Ancym1Drs76TXKIajRWVPKk030RCVqc1FXsokiT0MYoZtzsoHQjR/aBKUWHbYGHd34HSjpPqTfp5TTTY86rE74GbVGwWFlZB8r4wmmHdvs6WjAPmB1jHJ0uIwnGLU6yVDAOr6pIGO2FxkUAxJJ/hMKX3BUm+RPQ6mYNJU6F83OVD4TzXbT69FzuqIOTpQSlNKZ18l1qiZfSiZO4nefycD5z/M75uTgiWPw/QDXS4sAPjhZRvhweE2JpEwQwnJnMmPwzw7OVKf5GXx4Oj98ycBU7xInMIYzZc9FrVpnAW/1umxPtiBJ8zG3jSAcRV4yVkCtXtdAr16XnW3zN4hnaQ59W+Ry+BaVMnAOtXpd06B4luamgkS402MNwXJmDSNIbcCfKC1ldKWUMlmaNVVVOdSidRn06nVWyDle1SSRSxnWgYPV6wL06nU2swNWr4N3GsTh7M7OTu4ac+gNeu8gEupROVn04CVYOvwj9NAxqKh5sJkkyX2DGSRZOciy2eEw25DNDjC+MmXzYBaVLWqUJOsYGDLPL4pY7dnJ1euyR3KqGG8geNbg4L40XFCa8AfQMnPIzwVxq6cznCgoZWCrDeBRrSOluZ20d47mMNVdusjncBV9qxmkba4c3nfmzJnhrKTNflsms3od3TYKYpC+IEzb3OzvOP0/f/nL95Ek7GmAr92+fTtV3WijNFFpzma8kXH6ePc3H19MaYaU4YPJ+mc8hvKI0/DID2fObO3o2ZcxqJhnezDr2PDV28M9l1ZlTVOGRy6d2Xl7+Mzp4VEM+POMrOa2MxlZbc1sMxpSJqefAO4+cfpMc2Vb97p1yjYXfncIkmZlDQ8e+i4Np/kG7hEy/N3wd93d8DDMyYbdwAeppxXD3x0CYVjFFOWDdw4dujMolmebZwRjyjA/rbqYFQ0ixyAnYbuo7tQ7x1ip4EXIBl6QkUwyL3QoSknvPtaAIVRgVLW8iKqFS56fV1aGvSTKuKHe/HllmIutjIOrEoovw4GpCxitrbdGkX+CuSeDrnocSgY9QfUBJS/KKR7pnzy5WBTuaK5M4dQXAF/c2jJZFH5xw8MdWVT2NhbfYpxcXCYCP5y7YevW3O7PM7RJXq//M1w4DqESCzRT6zhv3bChu63ZT/Nmr93ugStTvkdB87ZtG3KZD3Qjg6Kuo11FRV1Frii60GPzTxAHj59Bi1/T+KWe9zpG3V6P1+v1ugEOeKEGhnrn0QbB2jrF8w4cP9OzYduGDbnvhXUbtk7r6chCS7ub7Xqt0aVneZRaiActOQQj3HO3betpDPdk9mzdeiyzLSPD5bAX0cv9InuAT63aA/zBnWfeu2TqMcHq1ZnhrbCi9QhaQZ7tUdYSP/AFB1uMPeHwe+/B34Zw9q3s0c8rqczXyS4/TtvfU13yZPWa8CWd7lK48VJP46VUDViFcHFLybx5RrRKdmNjY25u44z3oMaSNWDlwfNaJ0+GARZw3WnSNf7uVg9dAckamMqDi4urXXAObkTjJh6qRjWQqrHcjizBGkbF8yZXt7hcLdWT4ZMHaI8yX/CiyIJHxcWcxz60WDn1BQ8rr46EaoBqEhsexlpKCfhWaBIvYq+7hAqgYt2l4nu67tLYSKefXyaxCUYRQUPMhTKBaBWVyaLvEhNFLrDhuKpuFbvunpifv5T7P7+lpMRUYpxcz99DwVypn1yCbkGVuEQu/4UwPdjKZGyt/6lhNWawC6gM1+dXt+hahCyCa4RSX9MKfwKZSFxQIcQmFTI20unvNdJJDSxixqYLS5de2CRmhqCAmzZdQLPPLggHwv1K4LpNcz9FE9Vqaj4VDIcT+HnT3JN76Klte07yaT686UJxfV9bRyLR0dZXX8wznAtv2vThnoMdFnpRR0vHwT0fcgznwGDunr6c2mRWutqcvj0cw9nwpgun9hy0XK8AoXN/1cLM41MsU9Iw5bFTA7XOeAyy2wWpfGq1MPOY5cMUDObW1BR/nlxzQgtZ/yBlWe3hejT8cRMXBo/V1Byo8UdiIafTGYr5SLIdsuRBDgPweNKHDAzmgnOLbzgtFRqQigqLM0L6IZtiDpqRWsMYTsFgLj2Z+/B1S2rauyZkJUMV9DT5mhrKcFrzSXomImfqnaXCqSWD1+k59TXUUExpGFLfBa0+Gl7KgilPwHvFfRZObjWYih0/XEwp/jBtBmrBVEG4eeYsFe1+at7mUlYBGdeB6o5a7sTt2c2gmO86phkXH+TaYbH0FbMaNq+6oYgsGiaDF4tWN1MzNW1pmsoqId6QGMOLD+fUIh4adQ7oPSnVRGkf7jnYlgA+J9F2cE+NTOOnTMmv37P0YF/fwaV76vNlD6tk8yves6e4pkbxgFUIBaqCjGj4ys8XD18qo+izj2DJs0hx90tfvIQlj0whXrjV/V+Y9LNwWXor9yIe/Qia3XAr95svvsCFAf8eh2bg3Fs4xUzCWHQKxilmGqaLuVZOWDBclp0+KS+ciSG3dpbBLQLJf0/wZpGcOVAsd3+DA+duyz1YjA0DfRwfzt3Ygw1v2HbmFC68YdvOYlybweDieZje2HBmYXGZjLDhW99vVpAUvAHa9FoFSTVRjKMl1fhxjsPkYYUVDyh4A94hSMG4BzfAL2CHDQgyqsKXqsAIl/8TsYS6LzoxH0fq6ye74L4oHptfbSyZTkzEUtvqgquzCZLwgfwDB9hqqSt6Sc29QzUHgD/Q29vaQl30SWvuHbKS5FBv74H8IbuhJHndPVGaRTI0RJrtzHg+Cbh3KL0KhsetAOfXpFiHPTXeTAI+MERx0QBJOmwetwyMfECZDIMgzQ6b2eXSScIHKB/3Ugv4etEKHgEZM3odjqGh/IlMCW0k6UkObBHCQ/RyEWagzB7Sa7LbjUYJMw7ks5beCBipQThGnZTNoHio1R6lFpiwF3FHxAhgB+modnd1Gd02KFiXy84efsiDDyA44IDxOLqA1RHw2jiDQjkwOJguHumFsXNuaqEUs9EoCveiFmELkJ4AjAoyGQ2GrijJyRaYhg9QTrO5oqS7izHU4A7YoiZRzWCtA4bPugMOb3KIKYw6Ymc4TMH1DqvH7Ybd4AaH15BKWGAScV19rxeGNqFciV6oX8k7VBOpo7faxQx0MupspLtI6hbcRDQfs6XEmJ6I5zZKan4eYo2uhGWa9MhKGC/KVvvTjrq3wcGLxOXoX37xoj9qMIqKy466rRYzS6gvdvT/6U9/0nvekJLFNsL9Bi78hp3owoeNamCDOLxY5E8SVqX57w8v5sO/lYSLiGhKSARrbVFJCRDpJTC0AL/uk1skg7j4TVpA8zcycpFABKZ8ow6+mF6dEX1ObvXGi6wCIm+87qc3xYWIehhJus4jKdF0pbyhWCld92WrkzqseP/vtRmqgoyq8IUCIxVRXY7IRRQYJeIvFRjVXdE/8tJL2KfEz76ELc8Sj+DDj/wC4LXY8gjx8RcfY/7/4mN1c0szVAiMK8CWFwUX6TLysDr4Rej9xvz3ItGtQlSu1KlC1FX32JHChlUFGVXhS+UV/fTKqVG7Nxurj97tipo9Bsw+ekfU7XHbAkVYffQunQMmg7hMWH30HnvU4bF7DTh99NmQjdzrDkSL8DrHDTZ9oMiI1ZOebYsG9FFzAE8zzF3xwswVI1YB7e4oXIfbDZhmmPUB7AIavR67AbuA3oDdjKc5E02jMWPaDN7wRnG9AWbYo3ZcPxsMMJulC7OAZg8UENN1mWhEGNQhXgFdOi12e852RD02L24BTSbKCBPOPPrsqNesh5Po7NPKQmRCbeujXm940y5FQWNOwAwjP82feP46KGDUAQU8hgMzoaARS/N0D1SKG2x+HyMz3iSobrM3EFU2A2XGQ4Ex0GUIY2XGUzXSqRxbJhH/6yNs+V+w6Bi+iGTDplcDs2g0ykt1QNbxWOTPf/ZF4jkVFgVYE2wn/Ts2n9hcR/45zltMS5BWPejXnli3++zZs3Pm7IAM9RYZWBO01q07W4e60/1H1p0lIxyalwpe4/OvPkENdLSSZOWcs6wl1QSwJk7OOUGNiaRmUvrXHbGyu555mn071mlJrQNGZmodDi25Y501ViEBQ9L4szAHVN+Lbt7l2/SkdveOiMUiDlfE/XPqEFyG7lQ79FZy8wl/UAqO+ddVIpi6pe3Qa8nNu61BDQZ8QAlmzBiibuc6tLJmMAWEBenRfUxQLFfApOtgQXpqOXpZ17EqxaFXrhRU3ZtRdeuVq1tVQ1LXRFmNf4dy41d3WMkfsKpCgaogoyp8qcxGwoKzPZw0TmbZ8aJFHj0nTQQnFQB/vKgszB8vKg/zxovKw5nqNP/tsF4FrFehGSawB/SYMJpZ7I6imdWKMIi3y1TkQhvKmmEylcEIc+4DDq0CHNW7dS6vzmiEfiJXQKsEQ2eZgZldrQhrYYI3OsUzwWztqFbJ5qjOQPdRFHm1DkVvQAcM1S/gwfEGJCBwuaDHBst1WofZETWj2fFYNQgTFRzU7Hi8hhS16fGbqONeted/wAGrKsioCl+qAiNRufsQluyuJIi6117GlNfqiN3UxqGrn3129ZACvY6giLtfXgZZclVa613gXqPgu0uWfLnks0OfXZak717+DMxF8GufXf7y7tW7L3+2ZMkhRfguGHD3ZSiwtGrKDAq+evkzavvlQ19+JltCGr56FfBDr9398su0Iw/dPfSaGLxkyeUldw/dBDNSmg99tuTyl3xnMjYv+fLqzc++/DJl893LYNprr4nAh9C6jJdvfnZ5yeW7THm+pEqPtg6xjKH8fBVUL/kBvjhpBbyR/NhnXx7iwuDoy5/98MfLqffTxh/6MvltSfjl16gypsrzWtr4l+/e5ZlBef1u+uvYMMuVrxGiFczyYbrGvzwkDqcLyK7yl8XhtOsEfhZtZVKVIkqDN0WrW1wkGhK2YMLpxo8h6cPqp4aZULAbv3zr1IUvog43MNbhrAFqsbRNhDFGVK57hZUsLbUJWJ+rBYZxQDB/mhliLIXmHK7fQ41SMMFIJ3qNuY6EKF1b23FyDz1KwVjiaqWWuqutPXj4eq1F1IIaGOWE1Oqqa+oRnMjpqDmVSPCUW2phyb49k9HgKV1JScu8Pac6ALa0LaVWpuEOq+ZaMHlPPQxfRnBOHxps3WbhqA0e3lNcbaIsMFbX7OlL1FqoixoY1L5nD2cENliwFFlgpCxoBQvALfQVEIyg7uvLT5tMWTCvBeVHZiwIUqVn4Lba2raO9KD/w3vqKQt0lAUnE4yjmGurWoulNm3BqT2tLrpgYMHSttQuweJuyLW0BeDayXv2HE7USqzATldutS5tQUet1AplULBTrMrdU9+WI7UQD21BdQlTuVwLuDBY0JZqXqhyuRZwYLHKtUis7c5tXsVU5Uos+cptXqhyBRYk4aQFJXIWMHCyeelYzUtyMdlU86Iq91S6csXg+nktRmULGJhVuX0dtRb5NW0zRZqXJDwhWbnBWuXF66eXGMUrV2yh4UktUDBFC5LrLk16HlyLux69IIomqPPU8hmSKymz4sDKd6nb5+UzVkqspGzp6LAowszqdZa2mqUpWhqm23Ntx56aRC0mbEm0pQO0HKxBM4oqrlMTi+jNAQZOv8WIhggJ5Ftq0eDysHCPSA+vgxqBV2QX6eEVwrb7EP6zNFwnkAwKNriFewhhAul1lJ/X7BPuEc4f3LubhsN7MSYb3gewYJrn3jmMN/YKZ4AKVqg/2UfBJS0ii9cLZq3WtzJwvXDWqnCmbQqWmDy7lPWnCLNkqRycHJS+VNmM54XD3SXhiZNEBtK30lfwLSID6XEmOl04lcyMpzARdRM1P24pCJihMMUVlk9YSrNLlz4vP3l2EzULcSkjE+XgTdR8sSS6tF4OZluA2FMtkjBYcJKtdmk13MAZL6WWYwE1gniCOLxp7gWOBUtbjNS0gvE4FlBnOaIwFIyFLk2PYRbCXNcitaaS1Nh43iy/TWc5FtTT51miMFiQz1ZLn2eJwjIW8GGqefEsMPK6sMdLVC7XAg6sZAEL5jev+smi47gpmF+5p4QWJGGR5lVikuij51Zufb3MSPIJBLdgp6iTaOmx8WwL2JUrCos0L0VY3LX8UfcizUt61L1U5YqOup+IY0HqvujzBydk/pjepbFsJGI5YUFMeLBJZwfRmbBgyDLIzGfBgaMIjmLCHmoylDKMyraYhhcLSimAURJe2gy0JQvTZUsLt5SCDiMuHP3HwAY3dP7YqKlWDtgwuw1y3jAaTaakn00mo1G+UqDDqouGu4w89m+rQdVtA2YkORxiCwZILOAFYsTNrmM0GIx/5wP2Z7NiyPPphLjnezldUVOPfMKddD+Jkz63l93JBaM9PuFO53+ezZ6XgyFRwGRszXBRMxlf8/gxzWOaxzQ/sJqfx9f8K274Oq8QvjiBcbJCYCRsHm1s45tvvunMXuUegOf9Mxrc1sSbAhmAPnp/B8rKDDudLgT/a0e4M6DveFNENkaI0JsDo51eMvZmAsH7Rztd1sj+N0VlgAAlH3x7LOyobAczYuHOqD70ppQQkXYQf9RMkgA7ojbS3wxvJMRheyeSY/C3atUK6hmk6xbryzem4fAqEdkyzOwODezXZm3sSODAA9r4m6HERm0zrZ0ww5zKWdFAwBM4tiociHqigVnwzrtoXyK+cQA5Bh4H4miDCA0M7A/pHS63L7zK7SOj2V7n/gHazix/yoffkqi+CDAnpIdsywNUpXT4o53hd5lK2DiQrhDq48TA/ojD1Tm6n6nB/REr9QqqneO/jbH4xjeJdj3oQtULsB2pCpHwPUDv97MrfWNGFmh2uGlFKRiU21qGkRUbOS0DXhEdd/aX0q9u3dm/kTEQWTgQ4sDoJZGQaghxcoDzUjsgA28c4Jox8KYM/OZAx0beCxmYY0ec3C8L709sTNbgxv3wQhZ+880OP617Y7yS+pgsnGjfn8jamGje2JG1URFGOv37k/oVYbD2zZTlijD3GFQFd6iB4/jsAFGJD0Owq+wY2I8hAx2Vwt6l4Lip0muAThGM4iWl1wB9OtmzyjxJw7AGKK/zXw4ex3ToV+S0W6gBvsqwJRiMk5BazoIH+0iS9OVgwTBaG2CnJgcT1rb7cWGL06lxOvEKiAYw59Ajo3FgTD/zhjjXztaTUtPopxL/H2+Q8wyvtBCCUc5FkpJ9f2aIHYN/UVf06d6lvTvXCJBqTkpnVu8SwPyvLqkuZieLZvUuKcDzOL1LSvATv1DYdI80m0zVyYmKijCMhFkIfQkmLBiSP5edb2lpwYCNroW0tBgxNBtb0qyyGSXVZQvLzpeYcOHzCxe6sGCT7nxLiasa0wxAUnmRMCqFqpixxq8EqwoyqsKXqsD4N/YumfB7l9DSgPi9Sy3VLuWfNvrb4aAqq5awJPXTZnRVm+iPnIc4IE6nfmFLWhYyBCyvAI3ZJN27ZDLBgQeZ9RCCOhlaIP25VO8S9EK44IBO7gdTyha6xGGTq7q6Go7nheerz9NlK6leWC1hhklXXVZGBZaysha6lC0ul1QBweBkyKJDi8nYIl1AU8l5iqXTy6OvWljtkuw+oyIWUky7BhVQxhvny85XowBHVaSppOV8taQZUCPndSVQd6ivg2obJdI1aGppgfxwJaYWVDTUNoxyJ1R0ny1KKMe0DbyzLxPVNnBP1Uwmk2nsXPRB7l16Ekuo/KILsQXyi+LDzxNP4sNPEgtViDrN9wr+mZhxL21eWIYtC4m+4/j/iFoVQjyagy2P3pewqmnmM1QIUa5CxqIo74r+6UexJD3qHqu2p6Tui2LI0w9+49dUYIuGiKsQdRnbPCqEyC7Clvv07qUJWyQWwxKXCQQaNIUpZrQaI66MI4IqhIB0H7j/78/DSlWQURW+VAVGVfCkGTkrsc2YXh5OrMQt4ARdue7dlRYceRT9tJWbPlqJ52d0WJUftftwhLnEK/diRaQJzJhLt0OvVZBxqaO7yGXWY8M6gzGg1+PCkOfbI09TMFxZ0pk/iuxaxQKaigz0vQGgI3ICsNHu9UaZW39HwwO1GkkB2OBy6B3JzHjluo8scjVosEMAiSYvzMvDORYZ2Gj3aD0Majz6O42sGTpDl51Ju24oH5092ykptJ+Z7PCQ4V6vt0oKu1JMqMZlWDYMTnbgVrfB4FVoGmnYYIrqMVud6ajbhtv4gY34lY+qCHXAln+Ug3vAAosbCiDIvIsdZFSFr3sXRcfORX8a2GLBhy3yNHuaOWQMONwWlOHT08wtMEkZ5mNDtoBgreL5c0dfx/XEwb6Kira+hOT5cwwNP2uPZdSU9VJbqQ2hxFLnz0P1zGIavb0OyQPWzojbrizJ82dDS5GB2SoyPiR7/mxsac2vTt1iz8+vFr2DOSEJJ1cgRdv1qW1BylD6Kx56yJj8NsNDDxkkzPAwqwt4khswEM4jvgCBJ+26pMeGeq2SrktOQD64p8/pjIecbQf2HA5JSKq6D59su57o2zmg6TvZcV2qupOtDsa9QEPaAzO3LUHFJgqBr7aj7zB6tmA1/qBFxbmoRf6wuqfnopVn/321vLyNHv79RCVB+K7/y9sKso55riScb71VpQBfvUo/nyBq33rrrXfkla8uo3X/O3H9LSTyyp98kv4QA8srv1p2lQO/9dYHEjYgE578lAdLKF9d9uTdtz99kgPPvi6lfHVZ2dUnOXAtGWcrX3eXTT8JtxfZ8PVIKG052vvkarY3yijnpcxImV71L2hf2cJPuZYsXHiXU8CknEZ3P1evu8qBkfNoOKm9ltro+/Tqk1ffXs1S/WnZ1dU81701WzsbPT159d9QRSxM18mnq1M1mMJn+xF8/dOr69A3L+S3IwRfbw8lLamlPnMc+eJqGZixDuTq1ZRfAK61tvMKCMVZd7Vs579AVV+9y3IhMmM2rTBey8DXwXVXP114/S1+9bMKGEvCbw2gShkQNlyBn6mX17u7r4u0rVR1vyUhH0hqFvsISzkLFmxc5ytPwbXXhabzlads9sVELbnOVr6aqOXCEkIp/3cUZFJm8MzmOOpfUJDx8V0g5cWqt1Gwc9Zex5Da2b6fzwxQNTedVN2sVnWHaqqaO1Tj+BdFqVWKRC6XxglYswfOrqJavTKs13qNXUVwKua16ZVgvd7eVWSHa0i9GQP2FMFlPZXHUtEMvc1VpKPTWOoDggtEPhw1FNn1dDJLyIHvkIe9RQY6h6oHdZV79HiwFgrKv5kiYoaXNtluMnoVbLbB7RZUHXqHx2GOKrnOWwSqadcJnCeAtW6oFBuqFAdGdTvshi4DVLdHq8dpSAGv3W0P6DEaUqqJil7Rq2j8U9UdVup6l9SEgp9NH/1z47CEGnUfJ61aLEGj7jVxksSjYdS9pQKXRkPHsWlqnDkuzYy6rwiRJC6MSaeGu1eErCQ2jEOzBtJXOJVo9qj7ipCWxIYVdXPH81c4/SQ2TNFyByz3ZkjFR7JX9JybISs/Msj2iD3KZmeUm2S7otLwSos8y4YRq9TJlYRX5iixaXhlTrhchwnjsEl4ZQKDZeCV7+rKdZgwJgtR9FGUda0cs3/w6ZXvlpfjRtEpH+Gy6vvoX3gYS15AtwqwFxJ7GNajx1907IV7uJzZfQm/hy0PE2EVQjSqkLEJOH/DCMkSbMkkqlWIuhFlP5PxdfduaKKq4ZSqBmqqGgJKTPn1U1jya9RHH1mAKU9NIZ4j13+MSf+aGGfFpp+C6xSg8WEtrm4KxtX9FHO5hEUnYS3pUwEj+ilsGEM3A1NXdEB/rAzD9aIZ4Uo0rVlvt+sdypYgWO9x63SuKL08VL8cjWCbu4jpvraSR87KCGWzHfVfI8XkkZkyMh5p1nrM1NU7SW7+RC4743i6gNTVMGmVZxmYrhTrCXmWBZN+JTYNk9qzSmwKJv3KbBImKzFYBibr5mKwNIzJIthK1s2cORcPfo7cgcmibCTYLMpGgpEyNJ2NJHXiapsK4s7GuS9q1FH9g24Dzn1RZZg1dwkDTt8XxYAz1Wl+4OHUEFADBeu65C54053jFCzbSa5u2OrPBE7fu6NzUMtJanCpIelnnMGlDOwyyN3ce+Bb3b07YFUFGVXhS1Vg5IfcTRcWPnH8xRe7p04dJwy5/CzNAJcd37ahmyStc2fygzk/S7M0DD8T40XhrWLweBG4jIH1yvDeC+erW+Di1hvQ7lWC987dV15iamwsNxjcO/fKw3t3h9ckb5YZ1uyThffuzmRN4zVBmnIezMlYvo8z5de05jQ7qfl4bj5z/sgbo46bz5xz2fJQiWAqcRn72uoJ9tWhYCZnSQtr9xPEGZbsa+TDpkz2fuLFbSn5155GfhtuNG5I73+R2MoSIawzsvcTbSwZFdy9NLnY+zkh16rjH1ScLP28+GznZfM0FQWkk/nP4mk2uLjJ/DlnyILq3rmXvVtlQ/rRTVRd41d3WKk7YGVDgaogoyp8qQqMwmFRFTEUez3ZIiFXOOCqIiaeTjZzksh4USlYN11k7KUkPEENnHnPNN+fsHAK1TuxVJZm/rmocOh5sJ2sqyMDbrxzUesRED3mGeOOI3ABvgMTPlJHknVHMOG6zX4/rIUtey6aEuuOzZt3aEVnZAhOOSGXMlyqspdQTg8dF5xy0lmaYxUiQ8elsjSLa74P4cx7pnk6Pvy0SB+9FEytu8TvXcr2oMAYqxAddf+MyEr146YKhOqjf2yOQNbtFpsBM3US8cwcXJh8jngMH576U8B6TPj9Xe9jw7vmnN4XDts9Ngx41+nwmjVrMt1ut8eqBO86bVqzJnwazHAEHArwrtNGYOfswvHG+++H1xgz5+yiXOdQ0Lzr9Bo4LdpF+9njUdC8D855Tr8PsMNqdbkcDqs8DBYDfNbsdkE+F5cZB94No5jggjmqYIYxczcFk+6iLjdmAWHIk8fjsslqnhOm3AzesIG5Zpt8pewE1fve34XXRFERobrn6NEtBkV4105oHMaw12O3K8JAQwuFnDlujwOn8e96f87u0zbsw+r9dXP09+yAlYBVBRlV4UtVYBQu0iQhVDaS9GorCgLrLj2/FFueJybiwxMl4AN48IH004ED8vCB3l7EDDl6D6AnJVjvGBqCHhD90NCQVqsEa3sB7V06pAdcGV6atJbZlofpcoHNvXiaBdv3MZzPWWWtuNeaahcHeq3Fxeyd+UQHRxId/t4UPBRJcPfyk6JcjwylmpI1dF0+KYrGSdYfYBT7LBaFSXCamDWfrmw9lYxWFrZoIo56VNdkvEI5dUlt7QL9UL1j/ePXhalL3v1I8G9gxEYGvh0Q7hFNXXLU5TYcFUtdIjpO02AwPUDZSJ59BEueRbcKHnkJUx6ZQjz7ErY8SzyCDz/yC4C/wJZHiG4VQrx4a8OtDXj/Xxwbfvbj4a0qhMhSIfdlL969g5/Dh58jJmGrRueik56biiXPja1e93cbQKgqP5J4hniPRzRvvHjTsKpookNlQ/hwb5kDE7b29uaX1fQO4WmuKZs3r6wMEx4CeF4Nrs2guqwXF+6FvjIHLuzo7R3620NBmwpRF58f+F8rVYPSVQ13VzWQnjB3b/366zuK/7Z2VxKEecvg169gydeVhGvVllV38OhuYgW1ZBEWfIeCV+GZ8jUN45mShLFMScMYprBgZVPY8KotW4Zv5d7iSC779cNsGPBs7l1FMhBgx1MuDAtRsW9wmrO5tyT58KpV7pQuW2E2aQvIwquOJW+puVcFrG6X1SEHrypkTOlsiB5btarTIwuv8iZh0rNqld0qB3cGUmbYvHDfWs5ml4NVQHBGQFpzITvxl/mYnOu2dAoqRRLeMrx6HTeNxTr26zmchnT7ZVk5xG6i372MC28ZfvllTFjRBBasbEIaxjCBhl14JiDZjcLXd3jsa3UEUbn7EJbsrkPnos+M34s7uBTORfft3L1pL9aw1ek66OjQ7Ts9d+/eTYoDYunk52vWuCheYahtZnJgB9yF3/efsvx49hkjug2/c7c0P557egn6TdI8G4YuWLhnb6KKu1usuGnYaHTBGhotkLLdZEzy0ppb8lurq/NbXVSaIdQdJXBPEja6YKXClsktLa2tTIIipJ/nHgaGhPX5kNO9Gpa0n5xfbUwXl+MeBja68ifrIPM+pC8Ca1j5jlBxw6g1bOLAsIgGGA0LhE/O5w6OoopL8UkYrDBCRqXJ4IzJrYIk8yZU3J27Z6aSKYEB1ZPRAh2T81uE2euPHl3jGv1LCp5cUr0HvFFiyufDpqNHj7pGR9B4fsYb4ARd9WQoIPxxEjoZkySaKZD0c359S0n1ZB2oTy/DDjoNSZIFw8gqqI7q6smtqfUBTLTOGHsOQhKGtlENa6vrGL0Ckg1To9igGZlEdQphSOlvpA0VI/kwrVMnTgo0y5EUnJn2pyyZ1mxSJil4OiZJTe2ZlGly45DUpCFi0q+fWoA7HemBv6JXMRevhKiePLka9x9RrEKIJ+ZhyxM0XDwPPjevGAue3DqvtRr+JmPAxS1GOFB18FiMAVeXwIIaphLOCjYysHC5m585PK+VWnukRNeK4+fiyeAO+IEoxqvBya4S12S8GgQaaq8Ys21QzQOjIalqolTjp/9SGxJ/1WoOq1/W6nXK56L8Yauy56K/mostwlH3sueiYjA1JBkPBgzmCs4V4kJ45twTf6F+nP5ydqbS8OCZZ/+S+i37C38ULw+eeZbmbojRvFH3M+fSbGwp/TP6l5mbOKPuD7Ll0ywazmpmNm58yt7NDeb5C5JW3KBVN4sfsJQgU2NZsRvNH2fdyMqKwQdOScPw5TdOxbKQDcCeOgkvy+Tg2MlmeoIpKI8t+FgGpgw9Sfut+ST6hLxmRMfSjzLwjWSNPJWsF5kCnqJqpBlKeYMpplz42gGFyzp5A1DgkS288MWRlqco51HG3Fjw8chD3Hn03PB11M0+hYqZeDP0eRHpqCvGTOT9eMGI8ajCff6jplHKitjI6FGjYqeA6ajRNTo66jp61IRz2oOuCI4aH5x1l+icTlPHBdEQUt9UuZxOk5hJvFZtUANJgX2kXE6n57S4MOR0GocPjxuDfzyc7vWgYK1sr0c6kz3KxZvTLpvrPp1Cnh6tIyf3cmUWNWakpxPQOYGdMgLzu2khk36WS1+vDh5roj8WVhVkVIUvVYGR+OdxzgrLLPesRzWPRmzlM1bKpXT+58UevfM6wCs16x1F7gyNXLLocZ7FUf3sGMARh0FH9lfIpaEOkYjOaJy13opYjUXuSIFkdN7FUdLoANbKZ/mD8TTvOCEXpMcVcAH7ToUmnbIMpQyj/ltSMORh95FemLDnspHtsfY4TVve/QgSab8bnoEeP0rBMGS+0Qi3LA0ul8ntbnHTqxGsfPdo9owZxvLy8IwZR7MtSXgWSCCqg3yX5uisqGeE0ZxwoexJJhN6HE3Bs2evXE+6XS63yey/uHL2bGYYYRBVsL2oyAMNIWJJZ6TvJ3Ums8vhXRzwByssyRGKKHMGwJAKlFyfhvtJl8FBGs2kfXFAG6wQgX0puJ10FTnWz2qcdQVosz/IBKagGcSNSmI2z0rBUxFb0eyedT2O6PW06pUJAwiccxgNhqPhFOwqd6y3VGS0BFZC0kJ7uTfpOgSb+PBH38ZzNDnOd50wNjIUevddpp6DLhC4mQ6PjTMs6RGSyAOalcjWioqVK5ONImJNuo6MaRTiM9jEeIMknUowqCYZuF2jGPmhDkkEk5EcZRhyBvrsRV3R9SlW9jdFMxvOGb+drcH7AdJY3k2wDx2FX6uVK8fWXZLJdW/VOqtAmmZ1ds5qQlvO0WxPRRVfmpw+gnBke8lYVWlBwayGhlkFBaVV32Zn23wFIlLlI0LfZrscvpxSBs4Z7bKT7VVicIGTqCpIhDs91njBSEPDCFIb8CdKS0XhJkJTVZUzkm0nIxmFhRmwYY0MgIXM7lJGGDuIysrKjEpbwOYIFBYGbGaHIyMD3qHpqpxFiyivMS+J7M7OzgZKCgvpZ/TGdmqvZtmV5a+/vvz1ZRoGBkYogzRccaUy9joSDYbmiisZlRkZGaEUTNnscJhtyGYHGF+Ztlnzehz1fbenYPDGQMRqzx5B3oiQsJGT8obm9RDoAlOScFVpwh/Izv62ivJz3OrpDCcKSpPw8uZYrPlKCq5oJ+1dozlMdZfm+Byu7G+bknBV4vsPvv8gBfttSC1qGytWUG0jRnq7ZtB2VOR13OnuvnP6YgUDexpmJKhNZAZVawmfOUx5o3SR3nr4xo3DpH5RKQ3v386Upmo7s1VawBSwNGfBxYPH+w5eXJDDwOINjGk5y785feb06eXLmwqU4YKsQFvWrLYbzQUYcGko1BeP9+0MlWLAVZ8vP3OmZ9/Fz6uU4dJEX1uoujre3jegDFdlNe+LabXtzWcuVSnDhw8f7sjK6hgePqwMF3Tvazt8GGVI6MYp4EDVQCIBD1U4fi4oYB/nVURTAbY0EU582En4qnBZCF+Ez9lUhSFUYHxwRt2vVQN/oQL+wvfxWly43w953jDhtV9oSf/H2PD69euxbf7ii5c+xi/gWtp3a+Xhtf/FMUdB83q2z9b3r5WB2T5bu8Bn1fZ/IQmvfclPatOq15PkAmnNyGc+lhXr/V+slTbjiy/Wfpz+4o/ZL8S8wXbXWp7vxP28dm3/S9gNaUE/pHPEhkmSxG514EEfrhlrP17wcb+KhrT27z0/RVWQURW+VAVGIn0jzL/8m+yuruxvlvvFb5SxWdL/+p86Fy/u/NPrEjA5Bv/9YW0SlrrfSVxMy7IkfFFCiNf/xBYKlpLXifAxtiwGOSYlYaJrMbZ0qYNVmaGqgCzPLE+6brmU61RVylh7/hnCqgIj5/JfE+PcQzXL5nSCzEHcVWuMMjmdZGF+Tid5eIIaOPOeaR6Dx+Ax+B99wKoKMqrCl6rA+KCMdHqw4E3YMp44qUKIiTXYMvGnSBHzAMH1e/YUY/6rIfpUCCw6hi2P/sLWHL9fepd+9Kj7kpZWmHQCY5tbdekn3qh7mDBBS4mrGqZkwFML9dTSYkruMCZH3Rsbq1uTMlnsCaaBNBrp4WdG039+WK8gpz6EiR1o+Bnkrt104STk8MlfKvY/H9IAfTp3LyTHhVFwJuPuvXM3zf0wvyZfVGpqTl7YtGnvbiPKZ24yATx306a5lHIhm/8hqILcuKY0jPALpwQ4qEV6BDDgcz9laCgSjZ66MHcTk3WXByPlyJb6+tbW/Hq6YJtSKXr5MFL+4dL6/BaYkFNNF2yuDIzwky1QXzAE/8O5m9jJf8XguXt3rjG2VBvXGOfsnasMh9fAsvCTWyAFNR5cv6fVhAfvXOOCuUNrjLuVYXCfq0RXYlrTxy6fOAy+q0dzr3TVUCFpz4nBoHZpqlI4jhZWN9NSWdWd8jUfBgt4DWlpTcoWLrxpLlhQI9Ga0zDV+FMWiODIFqbxU4dVqnGK0ksvbKIPK3TAnr6gdMCe3MkcsEBLhYJWXijgBBmYzEU/udhPKMiYhONFYSYeE75couGLFxhb2E+uFuF4UX6SEpSgmc5Iyk9dkkyKwkpGiXIBF6UmPZvt9OISKCkKk27FrEsngeTC9sWLo8l0K4ziaFeXXQx2mGHhHa/Nykr1YPbaDQa3NyCAHS5qsAydqZyGra4uGL0EqxHb+LC5i4aNVj5cJIStbnrAsJdlRsDuNhhddo9IAR1oZI2Dm54i2lVkF/eGd/HiAC+XhdmQ3s2Fbd5kWtJ04gubWaJSFLJkRBEcFYPNQvEi2Cuyg8g2CIRqlkbh+9n3MuuLGjPcQkGHlNElskPMdar8rAhbPV4bdnUHFi/24jYkB1ow20FiNVEvPWaeSU3Abvx2QeO3wnED7xi6zBiHFQzwomAmVYH8AUtabbBStdvsUAoFTJCJLl5sVw4yTPhy2O1m5fClKjASlWffxpKzlQThWHL33/Dk7UqifsmSzw7h0WeJsiVLlnyJp3w1sYSSq2/j2EG8StM4yt9mNCPl+JqR8v+Dr1lZOVvzEiUnUppfFSj/7jtZza9ylA8PK9uccuLgoJLNzNYfv/pheMWK4eHh7xRtBvnqjS0rVryx4raCzfT25T+u2LKl8Dssm8EQgFfclbKZa8flr1acP7/iq6symll2fHX+8uU/fnX5s/+j7A3p6hd6Q6b6xbzBkbtK3lgioZzRnHYJs8XyUfoYUtbMOkApzVyHvCosLaP8bSoUUO/+kcO8KuLE1SjISDma/T3oAD0L4WuJpJt5lqNgV78ES+odY5nxfp6L9hqxZQLRqkKIiaKXUkvF3oXbhsK7H/U1Zw7W1wjvi1AwT07l9207s/TgUsEOEbhmZ27uhtzcM0trcOClZ7blbus5WIOjeWn9QVjFaWd9Pg6cX78z9/iZM/misPDW8UHwxUHRW8oi96RPnYI/0ZvVqm6Dj/UgyK27JNv5oqpbR90aoPiJENWw3HEFqSuTykp/ZaVNEbYC5h8dHpw2ODyqhW2rHOyYBjI6bdXgKngE8cuaMTI4OJgxOjg8OFoJW6PyNmes+m2hPgynU2F94W9XBeThwKrBQm148M4gwIOK8PArw3o3PLhIeJCFzZVeQPxheAj74cFbaZaGR6YNQtmOrYKHLcfgYXDaiDSs3TdIyyrmeZ9WxuZZkKUPnIxkEDa3zJIr4AgiVm357W9/u4XaGsGAh+8M48Bbhr8e3jIIGQQHqS1ZeNaWr1+5w8B3Xvl6i1feDEgBuQplORyktuQ0Z4CfkXvBZup5cFoGB3awZdY+mGA+bVrDtNvwNw22981i7yY6uVJEPQLMepUSYouI/HBt+NqgyPui8KoffvhhFS4MtOjb4vAKNbAazWCyOGwULd81MdZImFeIwNfE4BVmgjC7Vgik4Qfhey7z3zmK3hOYv6qPNBx1Zx9rOGb02pThQHZyMlKD26EAe9lzl46ZZWE7d6ZTg1kGjvLnRR2zSsLWY4JZVHZJ2COcctXgkIKN1G7mj5GoBOzgTOdiXrglYJvIzK9VYRHYji9egvpiMadGVwnKTMNircFeKA6LlZwMC+BjNOwSOY8olNJcKGwK7kIpzYVGPhso5FYRWzO/CmwN7Cpq4GoGmt3MAsfEZuilNBcWZqdOARz2QlFJa0a4N2C2maPuhkKhwZQ1vCmBDQ2F0nKMcAlLzVeYKhZhltPF/aANRVEsvIGKomNX9D+/K3qRLhIpyeae9igI8VQ/tjxFVKiQ+3RQjQVNhFf6h/4/qm480rg/Y8s44r9VCPGJChm7ov97XdGzV6+rr85kB05YCpuXpZl9I6meu/b5Gs6a1WDG8/m4MBRwIj48fgweg8fgMRjBqoKMqvClKjAS/r/+Xyz5q58g6v4vttQRf8WH/0r8XxWiDlb1Q6/qvO6oCiH+fxXCwIvVwF91qYAvn8OEu86d++o/zp976BwWfP4/kLx6Ds+Mr4A9vxjT5nMIxi3g+VfPnX8VU/PirxbjOe/H1OA/HFZxM8Su7q7aX1XIPTy6VQUZVeFLVWBUN3fpoopT4mfzLs6diXuy/XheXt7ZmZin8QjO+5+ZKuC8/1ED511UA+MUMw1jFJMNg+Ez5YUNL/tLnbyw4bxl/QqrqrHhvOVX/LKZHjlw3vI8ueyNPBjofqsVFwZLtLjwsuUf+62YZixD/sC0eVke5EHRSwrHdX94fJbNLCdpeNkfnJnlCjdwHk+x35aXK90aYuA/5I0qsSn4DxdnHDXp8GAw9yjOHarHscxlbsE9nveHZR9hsaD5WSxzkzNAna5y7BuSaldSfvzxx6/A6NHI8sflhMrphHy37AocYuuX58nK4yiK8uDlkvIsXSls+Iq08OFleVrJJLjQnpeBLM+jYGrLqhg3KM3LqC2/1i8hqXSyqG+H2vBfkXaHYBi2NQ9ZIypCmFwm7TvCRwkamaClN2VdR3njStob0q5j4sZylp8VQy67BuWWy3kcv20sF8IyzY5f3XLyOBFZTwmqu/UKEklWCsry+xMvB/zUAmx5iliuQgQ/QMquw5OU63Akcg9XUv41vut+TUzB99wUJjBiyLNMftECQX5RjUx+0YJ0ftGmH59fdP/+3A+E+UVD4vlFt53pkcsvSkY0BVXp3IHD29jpCjn5Rc3c/KIgW4eHS9MwygLayc4C2pnOAgqyfXh4exqWyy86EFq0cevWjYmOKgzNA5XxjbdufdAcKsDIL1paFRxIDLyTkzJDU1WgodKKiuQXLSh4q6qn5623UnABO79oATe/aMHAdUtPT+1bd5I5JDUx6fyi+3v2d/T0JPbf2srOL9qUbhsFVH5RRnHHB9tgPKim+xXl/KIF+7u7u2/fPu1re4WfX7Rg+/ZkQsom5q3urbnf372bCG145V+VU1l25G5NAFz1Cga8v3tDT+j0VefAhq3KcC64ovv7bk1VR7dymtN/hSVcezo6YgOfb1CGt9+5dev2e/9S5+g7o2xG6a0NW2+992/fhxIJjMSe26/lfnDr9obt125hwLdgRNC1M/A3jKP5zM1ceLp27QMM+INr5xB884dcnPyiG4eRzlu3fnb5RX/NWs8uwkldMjXCW+puCvtX8+P1nOsfSIfIXUSP8zMhC8PPxFP48FNjsDLMXCDjwFbS76fOpjFgq3bHhQs70AU1Bkwe+bCs7MMjJA5M+i6gBYsu+EgtBlz3IYI/rMOBrf4LC+fNW3gBruxxbK678OmnF+pIPNeRdUeO1JG4lcKcyY410Z8QVhVkVIUvVYGRMJe/8VsMeaMcDUT93SJM+Z2ZMPT8/nUs+f0lA/FGz+uYcukNYgs+vEUc/kYF3NMwbQAXnpYda86+hAdPG11won+BkBaDe8Kb//Pq6RP9RQPK8DcNsf+8e/Xq1QXt05ThntG/nL577erdeH94QBGeNtK/4PTt07G2/tFLynB7f//m03EYMjUyTRE+1g9j0XeOjoRH2qdhaM5qGzn9edZI+4iyGZdG+tv7T7ft2HEk3KMId//u97GM7tvff//vKxYpV8q0Rd93d+f+6ZszGH5+fWDaY99/c+baZ4sX4bSNS+dOf7/7j4sH8FpdTwPMWh3Abc+Lpl1aiX+kqDqsfhL4Dfy48QZhvPQNplwyEuY3sAWCnW30GMzhGZymJGEbb7xoZvVESXlekNOpuj5fUibyxovKwvnPc4dTysMTueNFleAJvxC40YQPN4aNuDCsCNXzu8ZGPDhTF87tyQxnmjDgxhm5SHrCjbAMvGyCvgnIikvv5b6XG27UrTn+1wsyQpnRaMx9770ecAgkfZKbTknDM3IvXerJbOQPjBF0+VFwONzYGM7UYcE65LZGHSYsMT7ngYAz75nm6fjwr7jhSxamRjpNlxjaJDZedMr/Hj8Tu4/+4c93bJ77yUysPvrpt7Z1ZNQdwcF/RTTqLm3d9jlJ7jg7U4mHSoGW3LO1O4Mk68CaT+YqVUpj4+82bO0YIkn/EVn145m4kXlp64bDQ1ZSX3dC2vpkdYMtuVt7DvaCet+Rs5+I86m2YYKCbtt2ZmH9kENSPashoYJuyz1eXMOoF1rPaXWNjZc2bDvzZNm8fLBeu0OgnttEGxuNPdveOz6vuGwerX4uRz2vPVMFhcnrxcUp9SycDzMF3XmgeF4ZqLdRVTXzEwmYKWjP8QNwoQ7qex2kH6yXhf/14YPosh5pJ0myjh75IIAR+t623J0HaBK1gaRiYQF1l3Khbg4WMybo61htne86sADsTSr1cdstG05ZUDavhmpT/AMoDZsYC56E+naI13cKTlpQ3Cte1Zxgjiy4tTNdpplSTZSyYOvWMzcYR0m1fgRTFmztbhYrk+CADV/asDX3c6vSEUhpBgs2dPyZlDv4UvALWyHI+P9bOWpQo+6723b8N274UhUYCVvLb7CkBU2K+g22mIkWfLiFEH+/M1vsXVE4O+pw48JuK2n7DSacjfrTcc0IkNEA6cGDOx2k205GleDszi3IQaTNbCVbftNit7fIwN5odkvLb7KtwNqzqRmF5hZJmMoHFu2EDjdXpw31ZMGBa5eC7SRptpF2t9WzJWoDOhtNhcyWspkk3W7S/BuvvdPr9oKzraTH7pbyRpSE7jOr+zeo/+03MJ/Qav/NFknXdUKpYAqhNxsq3OxFn5D1s9cByu0rWjohyZqtc4tCpXRmt2SvaLG1dFoDpFmxBlvADofNDVXjIFsUYDQF0xp1tERJb1TQQPhwFPwMvaCdAdLtFTQQQtCKolCR9i3UfF95zS02OsMd8ouVJOVt7rRHzWYPVcNbWoSHCyFz5GergDt/owIWOVJUBRlV4Ysw4wZGNAPU6gsFQXLa7YXhSJCSb0c97UGeOON+gvDPsAfaQ4s0mph78Fg73P4MfjTqMbc7hfdFc6CPflFihjsaCTFw4iN7NCOeU6FJQ8E488k4EXLOvhgatTvWrwfYN+Ixr4/PDs52BtNwnIzk0J8iAoFAFJYljgYC4cFjAXiaNQseAiNpOOSLJeGGQTFZdYlla5D5Ghw4aXkoSERB4JujniiYEUXPs9BbIzxWEyL9TlTA2aGIwzNCFXC91TMSujjbyS4gLc5Iu5OAArQHvKOJRZTrNM5IwP5RYlHSczksO4JBor0yivYuovwcAcoJn53RQVMhTuUECc/oR9RXpmpQowHc/hGlN0LGkmAMwYnkN+XkDOTQlmo0wdl8zcEQgoOYd8w1PDikwKfhoHMRNFAnHpzTHtFGIkE8GKqIJNs1opAAjvu0pNXXLqLaGUm1upQZiyI+fzAnRwjHSV+QB4PRi2JOMTOgvS0SwEHNoiCm63gHpxpY9CP41S0F56i0WfQjQSKu9OXpD8UJXw6uyRC+CH/cGcQQKjA+OGuAPkjwWmx5hOCNzvPJvFrPH4xnlXk1NTkglu70h5U511MbVL++Fvo4rZxB6RzY+vHv+6kufR/1+MXvOR2iXBi6R/uhAx1UfoFUWqlXkrCW6uhOfoE2OVZXAvb1+7UplfCklYatWlCJhjZQKq1+BZv7X2LttoLpXPhvGC/a3y/9Cnql16qQB/9I+bmsAfoAZCMx0cnM09sy2UiMBqPJBNnpqSeDfM4Qg92jAybqgKz6JrfHZZKDIf82nB7bPFG9OeoJaPnLbGUXsWWx3evyRO2GInvU4/Jqi7rYO7MJL0fsAW+XAdkKD11ePXenl5jKmzhjLzJRhppMRXbeLn6Q0QKcst+u12rlItL9CXvTsFcRjhqYKjYZooqw1s00H0jfLoAFUdRcRNHGooAwisZ5EuqPUtVd5NHH+PsIDT8PjCYSKC8qMkTJuGCPMDeLxtJvg4Tu+lAFTiIXiybkIyPBCsysLxVBp0aDnSLGonmA1l1SA6syQ1UBf1FrcmmEKZE0UrDFSR08MUaoF06NBFwRI6lzSj89l4p6EauQguPUydzZt1evm7N69ds70BjJuBxsJckdJzafXX1i84lKktTKwtbKzZuPHDlydjU8whYfXpmW63FQ+29vr169et1ueFj9b6sBvs4CiBlp+d2I3urfUbdjxw7QDI876rT6kd+xAKI8LUe9euSAzet2z5mze/e6OtjWe4+yAPbvYJGXbG8nyRNzzgJ8ds4O0hrzeYokfjQBjldAgAHlbyO17c6K9fJwRU7cT8ERp6bCoqAZGkiwffPq5rhFAymlZGAP+RTyVG3t9zO/oVxW649KwUa3fZTx1D7GWXa3UeqswFDEOGrNGsZZRYYfn6Ps3iVhU3WqpuokUN0M0LHMePd5ZjyzChGcuMqI4OxLTsZg7Y+/ot+sQojVKoR4bA62PHZfws/gw88QU7BVP4ZOGZ95DEuemTIWRX+eK4bcj5G/CFuy1eUaUhH5p44F818W/Bw+DKvXYaseR61eNw5LqNXr2CF39RHORKdxnnMPJaUFRVFOMF+9gzOFSs+CQSZxfybk4encHyB5+KExeAweg8dgBKsKMqrCl6rAeA/vi2qw5WnCqULUXS6NQ92/gn9Wsfd+ih9N8eRq4jDpi5G4sJUMVURIHBgVO2KpcJIkrwNbBLa2wx3XoAZ6EeCWq88qD0MumQpNRU7QUqGpsvDS5Ak1kyGNxenzt8OdvXZS0WZfDpSOJENNIUWbVcGUGUGfP2bJ0SiaQcbUFFCN61RVSrK6feS9aEjqmqh047dii8r7G6pCgaogcw97lyZNb3kIQ6iQO+khbIErenx4OvGQCvkFwOcgMTL/3znRdx8SvS9qAxG9LzpOeBVM+vv7/STefVGy3aLRCKKi+DFI+mCgK3SmCGO/GBzP8ZOkPyeOBTuD6IBzOrHgGAq5kYoYFuwPVsTjFUE/Dgx0KCcn5Cdx74tarfj3RaFr7sjYfdH75r6oLwEJoJrMnYVeJ5XoKW5PrtcWiccjJLMVatei1ev8odL5pQUZhavswfnzS3NGjjV4YGfE154ohdeauA+2qmCryqkl7FEykpjPwE1xF6yKpQ9tn19ailD4q2obKO2Av/nz5yeI0cKwmYwNINiZGF0BU1hiTRQFn4xEQgPB3d3OdWcrfbFEVRXhzHAdi5LaSoD97k4PqQ81NTUlwMgY6pY+Mse3e92JdVSfsr8dsszZAgGUY26VG+bIUMHFZralCrh69+a34W93Wzvg6WR37KXOpsWggE6wpWPzd3O+e3n16tD20qZQO1G4ipHUBloes7SgChUw8fZ3b3e//N2cxHZUCMiMR2XDg7x4qwrpDWqdR2pfPFK5o333dy+//HmoPRJLFGwnIj4H6YA0flBAEiXG00cqIW9oewhG+CK7K797+7vVLx9Bm74Y4fTBEmPZs5A3fKTD3TAabyqoWkTSe9szVq9b/d2RI6ubYxFUQNIG9dDRRFXKQISMNnSO5Mwvjfn8EWfB/NK2tvYjO0+0xyAp4UAoQnhXhD/XJGuwIKQl7YXhz5vm0wUsXdRUFfyoDeqIKeBoMN02Suc3xUhbeMUMal+ovd1ZNb/0cNN2Z3t7fKB0OxFHKfQK6FYHW6WlTj/pCceggD4q81F7vC+LbnuRGOGjE7pGspoddLbX9lg7s1ipr70dfeDDIajpdvQBYlE84tdGnNDKmkKw5QtVlUJrbPf7YWt+aVPGjYxPb+y4AYWA0fMEtMamJlSY+ajN8rcGbnw02tf30edt86kCoiZOFSaeKKC3YnHU2AF1xuKxvlWrjheu2pcRC6ECQttKJOja8sEW1Z8P1eFMhKhi9f2AZB8qaiSeTDLva48wYdYPUwbSW0PXrt28dq2PLiqRiEesVqgtqKJ4RGulCghFhR+tONpqu/nhhx/e3AlZJRMxVMACqoCUlU1NBaktyu75iYysrKzmEP1eqoCx+CJqqwCKRb9XmoCtpoHEzkTCGYs5m6gChpLFgq1FdLGgqDD1gNoKOfd1xOi6DCUL6I/40ltMUWFqBCrqPhtpjUSQvwgnOopRsQoGUGvwo2LBlpX0Q6uhirrPHBuAWk20+4nE/CqNhilWwcBAFVNA1ta+AWbLSfgK6GLFQwNMsdhbi+AA6N4+f1EcarXURxDaWLJYkdCiASezlRhwttOxIzGQaKfTdI31Lj1gffS2P1M/FPD4Z+qM9M826T56cscRSHWk96FHnx497iAlz0XJ3TAY6W3/EfR4xI8ed0sPSifPrpszZ51/x2p0+8mPts/eB/BqLrxaCV6dhFcLYc65qF6r16Pr6NSjnnsu2saWz5HQT6kXLCG2qhDi4Vxsefi+hF/Ah1+ANCDYitG56AsPY8kLUwh1J66qTolVnWz/XK4m0NjJOdTDOsmH1dQDwJtP7N48Z/OJOf+Pvbdxa+pKF773RFuVflBq7cGOZ6bztL3mmieErQgYq5COkwDptJlhRl8DatMCAXNIQ4QE3x4ePKaEBLDK11wiiggTM1VUEaWUqmgRUR1r7Yw9ozp+XVU5l7XX+/4Lz73W3jvZO9kfa7e1Y1tuIOTjlzv3+tgre691r/sOpI5I3gDQPRKYQbkhDgPt9nR206nsTSrceOCmE2662Rs3PT7kdVNuFUKJZQapqpLIGCJ2pZlXb5WYUo69UgVP86zsOO918Qte5JUOW913itAicB64ucOGAadWTwDXZ+XBSFRhsJLA1my098Dp0hPA4KS/s7DCmVVDYjMMhxVOg6tGtDZE/Qq0En4FlZACujDmpgJttxB5gUp2ObNdWS5nFnvjjLlxsTfZTlcylWyvcOkN1nqn3pgHN7q8GripqdHpnTV5cFOfZ4Qbq0HvqrAnU9OcOp1T53Qq3uiccFZgMOiydUQ3PwZ/0cgk6tTK5GnTkvOOaJRXl8wpeE9IVp6/QNnrXhnmed0TwNMnYQEcdd1nYOuRTOl8x9FEySzsfVkylTJljWTqy0P7dLIqrJKp/Kz882fsyy17/vydnMYrm+GKihNog9MlLfwvILR7Kn4TkvgSCduCa2qll0i49Y8CDdeCxZJrJJOdX3TvEtEgo2r4UjUwyi/oJwuHXHlXgSzhYC7vhJAl/JqYQQ5PUwMnPTDNk/AkPAn/qw9YVYOMquFL1cBIPfmrR94lCaP3K3SS+0TG8b+++65CcL53/7o/44knqedNKKvDXFn63bko94PpeWrKURPgcsrfRWozTKajU6iXcBDIjIyTUspZtfvHql+CaRYUoFNSeUQtYHhOphrF0BRXHlG7uToygQORIzNElIPa45xa3myPqPJ3556MqhVMDbHK90WUx6gVziOB8mFUUFZ5rNrYSafN1Sj6JygHrYzajKjauBmqqPJ4tSLTWZzyfUjtVr5a0bkvaKIMLMP9ArXi8OYxBt66ebPCrBq2moFN+2NVx8CsyRl//Ssy2hRjtADm1fS7YtXBh0FttA2houOUR2HcO0y83iHocEJYoFbQOaKtyMLV4odLjHIGRg0heqzwjxMGrpY7Clnl+8Y248NKUm2c8peolxQObp7yl6hfKQ0bc9kmMpl+hYYvpQEJK9+Hhi/IR/9XgoHx3Ueex1f0KiZRn5wNAcdJp2efgai+baQTvxD0VdffRjilnIQiu59vI4OnMdGL29pIYRyOuI0URvHPlekIrFufpFjMKbwozcb+tmpZeYkfENhww+9PkBMMZzNboo3rKxQ896ahSBuFLjaMhsuul3MgnKbLdsFEZSWjO8uZp5eDjdkwn6jXOpnN2RDxRRbGM6B6LvrHTpdWL2dGBUw25jHRYAxZhdJWI9hgrLDWMIqz0RtlCwihbIxM0JssXY1eoTagEgwotomx1PXfyvXMBkEp3RUYUtgBysGlpbvaFT2dWLjUeGJ7u+KiwDTGhKQT2wlWEHABS+tSt5MsNyQx5m4nWpuYpis1bFU0l4WfKXWeIGNh8eXJuu7tKjydfqFmB6iKjU6qtlCp2pz1Q9mqxqwikMF6PcQ71hMuZNQUOnWuSqL1FJj0yTIYsrMMcQsfInBFFhORItuYpxjFyGrMJg+mVMHFR4KRKsZsuTBNutilnW8IqzJDTQFVVZ26RlHV3Oo6ksouOrkDlHQHqIpzUTFXgTbRszw4FxVxQmhLOy96JvaiiHtDG+TCWS92winqC1G3zLhsmYhuERgy8hS6CtfXkcF162sqawqz41XDxEKsY8kXumXWyrzCj87HuZy8RPlj5ezhZfYKa+HOg3Gv+FEYaoHktfRjeGa4Jk7iN7D3pxmtAJ+vPvxR3Ab22Lweuv7qujywuR8KqrSssz4prW12fWGF64u22UTw+fXZ6ET9LWUYEiWdX+ZC8Hky2OWtP0wEYzMqXMkkZhiTEJW1DD5AuYBQdW11sG7uEq26JEOM4HquQfW8LOaV+FXp9efTDLgF00SWz6b+t1Asjedx3zjcYol55b+nxvvzjySX4l43SOLP764rRWZknyDx599+ohQK6KprJ/GTaW/HVSdy1ivmVLO921launU7odd9e/fWE+3EXvft27f/wKORGI3k/qJGo9FA4jiBdBqNJc1NBuXlYKMBrskMuowdiTlwKpNjlIONupJEuDFgzcamJp1cMNKcph07SkBnTk4OcBn4viRscCY2Ow05BmcT8LpmeRh9rCGnKTEjo7lElwNvkR8KDMacJpgygt9mUC5bwBwDWJLBTDKaEqGMOQZJGMpvyClhJyQzMpw5uqYmowSc02QCIDECN+WU7GjmRWf9+rAqM+IKaJQrIKq6HOKq0xlR23GN0lQi2zeMRtTEbHM3meSbm4GZjgTGQ30omcF1UdBvVOgbOfzOT+A4IX1YfZMDVn4o+F5GxltGLE9SvzxILL/kB5xUlO86ZKjZrEZzrZkYhr1eKWYCGDOwDdynibcmDq5FLGxhhA3sKeZaoTUxMGwwh1ClGoeF9pshKmhra4EMXOCjgxrYCa4FGOJeer0pkjFRIShqFdpLWeunLZagGd5paeUbEhNtFSitvxXdwkaXVtiSLh25NAXvJ2XzuqPdL3jDuSQcu+uT1kqGZk2J2yJKWxxSmjW1sXvcLVA54rC5IH7DrMBoPowis4psNK3ViMAah/g8a1Wkh/BgCFPrExUJm8XlO4nEq2ooUDXIqBq+JuOLKny1GZEQuiYaDNFbBdiY4yw5s+jMmRJnjlHxetDQtCh/EUj+ohKDUQHOKcEoxksUzgpymiIs0MJzk/jz5zOLeHJG9hwJDBZIU2ww/2wDL8bvT/7IZ//4E16MXwM4aha6jNykIriIF6Y3R9nm9ELwJmdwQ5bRhSLj5VXitATZugormtO7wOLNF9AknxUSEuDFoco8FBkPnqk3wN4AVx6e/YObAcQOaNmHeWjjgKEeb84CF1D0hLNQq2c2JFr0+oHm5gF95KG20IkUoTWgINqBiVa59GhfajDo19J65qEWP6SZh2gnZxBcQGt7LDSOUuBDUbnNaN8gGv9bHWYUk9uHIxfQlp5a5AJq1hQ40OZIf0qBGUeB1/Sgj++BmAV4TEtB2w+rHAUa83SIdQ8RUGphqzB8laFw3xoUEAU2ScM//BCeDvpbUZgUiHXfGnQgDDEpsA+3tacWP0IaeuAhmMa8aHYEW6E24MuuAH2eg9mp6e1BoevBGCbeNxiAvmxrYa80CvKDnyhAluKYI1C0FBhnWyMPe8AcpIiLRqIN+lp5g310fzmWVl9Qy7ra+rj9vbBl1udwRDF/j8PhC3K7SGFrKY5G4sDfv/DpjEOtT0ujr0sf8wjZA19aEM6BiUbCGNjDhuRnSsqUKwWXlClG1F/UByHRI56hmuk9PdN5D+GbKeIv+otjj5MIWtB/6hHkTVGWvkRRIB/9L8Bt4OO5e9IJ8OepR+bOfW587sd/PVZWpqga4OfGtVpQrmwLhj20dui5595VtAXg58Zp79zxuePPgX/EsTLw1JGUJ6hHPh6iOz9+bsg7hH01BuQENHfSgY8/9sA7sDtFp9yi7SNzPfTIx8+NB5j8wM99PO6Rg2FD4nNQJVyG2I+fC3ilYCifdu5zczstQ5xnB6Q37rRIwl54vZMeimarlrCFhUH1yFx+ptqPnxvxSsJz5wYETiZ//nP3HJGJX8YMqLHOqOZ3/9y9q/QjkcilAFsgry40SsTmP8/dCqvUYl+aj8z10uN8cwGFKTjx726mUeaOD42zxh6qE0cx/ByqNeh5yGZsbKn0WQHqSJ6PPw54QD021iBzCvHIcyO0dnyEMXZZqewZFdP5LZ2QOnlD6ODBTbKC4BGanvtc+0SKWfEkkDlgt0+kmAlOLx9BPWEDAcrC7YvNZrIT11+0T5ChjNe9mfSMWHXGEMVJ1EPPPrFoK7O6pLCdckPqnvz8o5BBHa0uye8Abd9w6Nn8RWOMa9uL8vs0o2qRvCQHt7djtdWbWQe8MRl4Q+pJUMs514FL2yJJeEP7oUX5z46x/onV1ZDz/YwE3L6hO0Ztfn7JNHF4Q/serLaadQEcW5R/pskgCmO1izg/Q/AsRGp1OUYxGKs9yrlHgtMpqMXnx/Ew0wxbw2msZ2E/PAK1Is7SuBmQ2o0d3sZqrDYfrGVPu2NgULuIaYZG2jsFpVjPX9RkzBF1w2aa4YuNoLOjsaOtGgp2hnc2z4c3MK0bBkHmbsRqc3LEHLy5ZtjYYfGGq9lm0AkuEiIw1wyb087S2o6Nm5lmMOhEXMcZtWwznO2ININOBI5pXUZtjiF+YJyB1D4r1roio+gM3AzPCltXRC2GcX1tjRwN/YJmiIX5BxnTus4co9RgDs2wOXKQIbWGHOmRP+ZokFSLLx6nROoLt65B9rL0RZ5anYxaxut+SsRaWbWs1z0sux99YlGJuh2g/9K8S5oCYtFQQRWiMhipnVimUk4VQiXBjkRuZ6LCD3spbeA2MRJskMyGXdOu2GR8EnA27JyusNQ4swngbJ2VtmZbabsSjeFK2gL70CH5fLZR2YxClwsWqJ26QqcibNTlFcIEAGTjszoNijCYC7kJs5203WBQtrkQtnPC5T9dSVBAg6HSWZkH6QZ1BoJ6Bp/ZGtg6m2UgakEjam+dkWA6izxSTZK6Lqqq86s6rFQdsKqGgocle9134C9qEQ0LS0v4i3q1FpGgtRYxjzK6MRwX3ZGmGzsslnjYQofD2o5Gmu8xR89qTNjYSMfD9KyN2lkbbSgAj15rt+M5Nbqlmm5Ji5gdgWlLWgtdfRaxNZUup7OwAhy9LVr2yVj4LFICM2bWQsjbCJLlhGyT9Kxq7dlqrigcTNs2ztJunAWsM4s9vLIhaAdtmdJBg/YYOKFDGw7TtNbFelMasj7aCVE76MaN3llpbG5iXgG94QQaPB4ZvdmuyooKFziz0+EObUJ81Wm9lkjKy+zCVt+5c8HCGj2d0EjTIm5+MJ1oZeadDa7W5TA5tdqXp+fHBhb6BEIkEgx/VImXfswxAUljYKZ8hmVzXjBHU/CJwjA/VzVnPVTyR5U9msgCkqgZtNYGkeV8l8EDriJoZpcU/TRta/HSdBzsTZtF08HlEKTZx15NFsACHd2R5m20CesZ+qcWd5na/9Rw2TE1GqR4Y6ON63gcbLFV4y4DeerZeTpgg7SF7ghD17XEtCB0GQvqMszkJNqEDzN+FlCckLAxIdZmmma7DJp/hCzrKIQkzCWGkWLuyOIVELpMI1KCQkt6vRY8odu40RZVLH5YWbgI1JaEs97qjsghyz9gE8K2+APW1mGjxVoQsjDqFYYCpUHG8i/IGKIY02lKmDym04tp1WmE+L9jR01CfAa3mzLNTQ6DhN0qYGVbZgi2BAI+lxRW0j4j1m21OiwX0ynWx7W6utEjJfEOsXBkSJ5CxMHVCbSk//MkLAtv9NOSuaKmxHpg9xdWSokQBnS27iPp/FZTBOhbsC1P5ix3ShRNOy+H8mBlNAIjNEkBxVf0jGN5nSLKXNEToswVfT8ZylzRP+MkX6O3eDu2dIFcnjlzFvrf1bFr5uWGrljpC1VRlDW5kg5CMNPMOb///RyIE9twKznZWgV34qS4ivLd6nXaqxYvyJyzcOGc3NzQjd5CyDmRKyYhqi83VLeuwtJTfHnhwsvFoLbGG0KhgDl14VDknQ3UaHFx7WXQtiZh4cKEy8mFljWLM4sjrxefffbZa33sgy4qwWZLsOXV59nrVyyEtQq7FTZC2hI4mwv2nTm9L8S9kzq8DstCCKaMoikvRBGV182MGDF2587W4ojmT1aIhGn+hIPT/vGPf2wcjdUMgsM0M8Jpzu27e3fj3VGhzRBJyVoDNkOYZrsNPcPZ7PCB10pDJqd5tDhzcZXFlXwZ1YafLuy9XFvM1UZm/+G6urpdM/s5zVsWOLw1vcm3cD1n9lgq1tVBIF4WnolCB5/6bX9Ecyvt6oXgy9CCv5+Tu2Bxld3Ze6shAt+8efPUqf5MVrM3LxnU5nJ9Y0FmkK7snc28mnn+3tF792beO89pvjFzNq70zMuffDILM6E1CVxttNbkVdTn5fVEbM7lSoN/GRVcM9SeDR/5t/DZxZzmrlwZcdz98kroy3Atp1kWDg6GExLCZ30EmovP//3KlXD4yvKZ5xU193UcPRW0fTm25uypo6FMec2Z/bv2LGkMnmg5cu34nro+Jc0lSy51LH799cUtR027MhXgzJbBwZODZ89uPTk42BFbwEzhDX55cM/RkydbioVVlymlfTQc7ou8Vb6ehdJFNZDDKLI0qWSGqKpiUhiGLwhf39dFIHhgpJ762aNE8jN0LvroPEJ59CnqZ/OI5WfUo+Two+rhchBCuPw62sdxnY+LvxfDt00gt8ujZPnt22KfxcDHQCKay28HrpnKrgVul0vYzPvc8uvpJlN6GfxdLxe1+RoI+1L57eOmdCym47G6Y21GetNZMS2J0R2rufx2Gceml5WJwMjmeezT5YGIYlAdKJevjWN8+JiCzYqaeS3Itzm97Ha5bEcqv14WrQ2TWG3cXnL8+BJOS8BUxlVGQLxvlJVxfaMcrEY4NGGgXKRR5l2/DXI90o0Cx46bTMePxbGszddB+M9Cia9Ld1FhycvLxY8GBgYPmfTb5WSHFbb5QRyDKo5uVYOMquFL1cA4Gev+IYx1n0TuHpxEbVIh1HQxt5V//pN4d4PZ7HCYzWSe1Wbkm9cq4t8iBiN/c4vA3V4ORh7ykFCJCGa80/nu9nLe4BpfVZVPQ+oNvhr/ilSdqkZR1dzfy/78g4/S/JCMogZiUdkoOJMbmeSpSX3+beQA7ewkTt1IeyGdBWFSSIt2pKhoRGSRTjQFWydKpdFJk8EeFO/fRgRb6ADSHIjfjSOWNq4Tz1qL2BEPW7zjDDzutRBoHlKh2cJptihrpoeK3KiARUVDtBIMLdI9Pp6aOj7eHdcuIjZ74R3d3RZ8R7me4dtnaAj5un/DHKAqOv/T6g4rdaOomqHgoYl1//Be0ZerOee/Tg6Xz6v6oJwYfpleQwqXz4M+/UE5IXzE0mFdQwaX/w0WSc/SH5QTwWvo8MY0+xoSGCtOE1UtAq+xgOtl9RQR1XFw+Qfg54BWVURUx8NYMVpGi1cdd939AX12I7NgE686Dl5jR+6H6HeKZY08zCquRnS86ljYa4dlPIiwuXVzdbzVQhh6UMvG6s1bYVLiaPXmONUxmr22tI1pOCiqaRjuaaukYaT4TSZgLY6fCv4cAtV8uHye3gZxWbmgAhCcM81bJaW5/AjdMWaKBCCAWAFjQqt5MFJ8NIoyUWIFqvnwEfu+jBjJT7fzVEfh8g8G8kXEdOFv5fFX9DA/JiYjvLk53hV9uYR8/Sv6B+svauZ2fpvlXbmms9eAZhCFPQ74QswcGk5ZbR4cNq9OGQ6ZleCURcPLW/LzB1cPLiKAh/OfRXsGn81/NkUJTjGDuy/ea5k/TAAPsrsz84fNivDqrWy3+ePgasVNylAdzzLSsVx5R7M5Iv+q7c+qLniXqZDv5QXvDx7+EVzRP/8EkTzPxLonFBTrPoNYnqdA8aHuQ4cOdR/9/MyZM5+fKcsocTbFi7MJVCO4ewOSo59jKTM5c8TEGYFReC0GPlNmahLbZZHTNAlPwpPwQwGnkhzdOgTDIHNyD5JnzyTCz6KMjMQSMUlEg0xk+CpjBJ1kiwob6558YIRz0a5c5InA/jH/vvhTrKzDeZd84Pfh78tt8Ofm+oJwN5Tb5e+Kh//0p8NPUj/t6nJ0Rf5Co/hf7q0aEXmGgleCo125rbldo8Hcrp4Q3IWnesT8GK1UbhVw2tHcUS1gVbm5Xl9ug7Zv0/+ICQW5qUe7Ql2jffCH78KfI1fM5j/9iUJ+NrhMuaFW8HVBpQXHi/46MaFybWCqF8zwghlQI15HboO3T9Rmmsp1hPpye8Axoie3K+SAoo325QZzfaITScgMP2sG6G31wV0wQ8pmP5hRBWZUQR0CXgVmVDVIwUFfF7RgF7Rgl68H7Iaa9ufeyhMTCTMkCvimA1rY14X/oIBdvgZ0t///ExMq1wcuKkHoeNCJQlDLKL94q1QB/39ReUtcM61CqDwVQv1JhaiDrSpEXQHrVIg6m/9HhVBWcpOtlLWGWKzUz/+H1OL/QV73FXUkaF2Feq/7h2IH6Hcc7O5hhzXEMj0+/rOMqNwPK7rjLH4VQ3JFTBueRbp8RsPcYZqNbPnMgiYwN4a9RItcMD27sXoj0ASLLxZbeArepN8oshQlWXUWkarzqBB1ibMflpzjDwesKl27qkTwKqM0P/8skeAr+kXEAlf05PDz1LPk8LPUIhWiTvODghc9wAIeUiFU+wZymTxgBTBERSeVduqECqGSSoll0tNp0tNp0l+UDE4mjziRrO6y9Ju7cn0Pk2F9O7Cq0/g1KoR6tJxYHn3A+1O+b/BD43X/y5lE8ks0is4kFoh1Tw7/kpqpQtTB6gYZHDuX6O/pyUFmEv7xfk2oOqwe3NGtapBRNXypGhgnz0Ufxiug9fECIeKzRZ5Oovrj5Yv+gy1jIs/3Uy+1xcrGcKu+tSW8Oe6Fl0Tib6R56Y5q7FGpnPgPHCPBTTLc0kECQ2SP8MZqmI4MV5PCCTRNArNmNJ6tJjEDpmZbqquniBYQF5z/szHcSCecDcc9Xw3wlLSw4HfKlLa0cAeERYXPjHlFfGLBXeT+cc6cfD/nRSdH0W9zYJRKsyWuWQVcunVXKSlsNKaeIIZL67an6koJYCOamNu6ffsu9F8hy4nRuWvXrq0Q1Th1K0idQRYuTUrd3o6zim/f/m53kjysQxnIubSTxlKlApbqmISQ7ScMpcq1AUnTMVxXqiOCYa60vX0XEXzi3fatW1PfPUEAG5NSUyGOft2J1CSjMlwH4flROXcRwKgNmX+T86KT86I/8HPR7+VcbhaxQN4lFaJuZ+LkRfqPCn5o8tH/7LGI/OWsSZBrqSRJOIo+9dj8qACczpO1grxqMIr+bD4pDKPoY+TwNDVw0gPT/B3DjJ8wGbx2uL9/rH8MklIpw2uPQ24GkP1rSTSPvYk3ag4TwGX7x8b6EbyVRPOSsrVbIavE5jEiM8rKxhDcX0YEL+lHO0D7j5eRwPvxdtG0/WVE9VyN4M3Da0la8Ph+LMfJmnstlrLvUxf9VxywqgYZVcOXqoFR5d4lE6HgvUvi2whE9hXA3iVTSQ6RlJiewDDJCZI4jLPM4xtlGF+fM2HbFWGjETZIlKD9FzFZucVglMscMn2X7DBlJAqu60U164Bu1iWaTCVGRTMMSHWGE+DEHEHKDDG4yYnStZc0g3rYGSYLGw2J/O1mibz6E9GMEsdHt2Hzd6qIwAZdc4Q28dPLi1ddNMN83AvxtdEUNaNJqTagiKxqU6JBqVGiRYzZiCMKc0UUFk+qi7JFFHlaDG5iDrkmEhi6EhadkQCGrLZYSI4UdcegEkw8FKgaZFQNX+r2LglPXF3Jslf0MckbsuWu6AUn27IwfE1MJYenqYGTHpjmSVgWXv+RjNdjLHxjl4wIYYt2XM5TMw52y61NTMLfd/jn5PC/C4cvWRitLgkHxnH51aUHsndp9fQnSfcumVd37H+ecGvP6pTBMtPjEdicUisZUGM1qN1Rlv54JM5Jba1D0oKUQRM6vX+C01zr6Olx+GpF4ouA2uOgNn3fkgssXOsI+qv8QUdtvNraQRSZd9++AfvTLOwIenGa7VhTVptbloBahCI3EgzX+lCibQtkMK8Vqg0NmxD6+AXG52Q6Y3AVTn0DKbtrBWrTdwC65IKFjsKMZgttafXVxqhFqDbizcIWsAfZ4e+pjVW7BBnLZgr3sXFOaiGbuD/Y4+Cr3VHGlIvZ6AMJ2TWRFoT84o6IwRBdJn0HoBdY1Bt0QDah6LYvUM61COo0O0yRctFVPSkFKHc7f49YrTnSumWmaLn8PkAlNpQxarly4c83S+w+YzrNvgErmzi9lskdLwqbUaeBcumFny8G405jWoJRbasjkq1JDEZ90ZSOy4U+Xy7aKqiF1h3Q4qTuTFVJwqtXtxw3oSpATVVglg1rgzoNqgKvsPyi0XXMLfvWXkBNVavRyO/yQ2oRiqpKIWDOT1enbF1ygakqs2L2uo7hAQtuKpLsdU/+fA0/+7xC9jo4cU0UnHUyJ6qCpxJ50Ujg4i9yjm/UoWsgU/Si1JjThC9dItFITHCRa+BfqERP7plrz0g0EvZSSpfDu2CKXKbkGEvYSF1wGl/SzN3nTGEu3NhLthwne2FmMjWXwFJUUyLzMZwpRri6gisrI98EuLBuwrENc3KaGPUm1hQDujY2YLYkAz+fUQJpYw3M4gsERSjB6k3NKD8sXKLvQOXLYeoFPt+JE/1yKzXwvqYSFAMhownNFuArKyPUmAl9PrxoFC7rwBWVE9TvyHAa4EX00JC4A5QCaoyuAUXdApD6REgtDCXOaIbMsk2JcBO9NoW0yyh4I1wMGZipCrjkRxVgQpYCyDSUkSGggIlwtQQRYJw6fAGFMnay7YUueDEFZkDQGLheSqTw1RJ8LHoTvIt/4e00sFAzE//hiWhz4/dkJOYkRuAmHUuxz0Rh5g07mgWwycSPysbAXEyJ5ubEEr4ZuogF+E0MjKASFOgG1R6/gNGyNWO4BF8IR+ovx8ivOqPRwNQR8yYqCTNMy6BWRAcG2yg6J9t66HV4F38BFF4BrAQ9b8DNU4L6JS/tb6RvGNmet6OZ60gwowTzQ+gTuM7BJZPFSlGhS3SRLmrUlZgi3Y6DjdHuzBwrXOfn+j62BtQDjHoycxwyXZ93WHGDANv/YTkYf35G9KASHLDMwYKPrMSmJCpycEdGDmYoYMcNdCXPAYlcyCPemCQcZKJjTCQaSXSIiR++cpzMxEvkir5EfmAsiUQj4blFbdjzuPzqkiCP+J4y2elZgSuXLAxX9DPI4Wlq4KQHpnkSnoQn4X/1AatqkFE1fKkaGGHIfZxI8Lno4+mE8jici8Y+t4T3K5TnKVnFwjc+juElcvp4dohr3qcGHiCH9w3QA/tUwBck4LI4ybhA29Pjny57XGQfffchLU2PdIvtoxfulC8CeSdA03RnERbZffQQrL07gC+LPSNIZJyl3Z2QBFcQpKPbLQ2PxGyMCbhl3LCLxr08FIL6y/psF3V7Jdl4B++iqCWBIuV99DZukmL8Y+V99BxMDyruo//IFam6yiylffTZlYDVF1baabrGYFDwVcuqp+2QwTtLV0HTzmwFj99sq9WFMm1nZxXmubKVvOBcrD5jdraya2KUMfwA/UWX3frLYzz5y61lMv6iH936i8DN4NZHMv6isnCsv6g8HNMo8nCSOs3qYSN7/UQCG51nSvDFAwFs1J3Jzy8xkMIQJvoMGQwGNy1a1ITMVoSNziadwenMgX9GRTinJB8vrpbkN+WQwE05TU3kcFN+fhMxfGZR/hliuESNZmOJGpsTzzjJa+NMCZlmnc6JJwPgH1FzG9ElvzHnQXT+f/0Bq2qQUTV8qRoYqar7rxHJ/SqKsr1GLDbqPjl8n3pNhYjDRUXkcNHp00VEMFZ6+rSo+jj49E24eecduLl5mkyzhOHiBezsJCjgpUsYDdB0oDP6WALeil6c8Hho2uOZUIKZhkrw0rQ34T5RPU94UIofrFkenhgK3J/oRHDnxP3A0IQcPDLU2dkZCCAzAgG4OzQiDU/gU1CvB8EeLz6NnpDRHLtZPCBrBnOSa2POMb1yZrw2ERjyeC1eMLvTC5ZAaWVr434gMMQkvIB/92Vrg82LAczECHNfTvP9+xNImNuJ+/flW/B+YGTk9ggjgftKzX1/CCQIP0ND9wn6xv1AZ4KnM3Cf9OiemBDv/KoGmSpyGA12pAOjDY2ivpTFBFLrQymaiVAkKZCPXlRNSu1ijSb2WR8Vo1izuLZl1uWDB2+dbXEsjsFTqBjW0TK4a9fRXbvGdh0dntUSo1oAa1J6Lu+6NzxgS2gcShi+d/TCrBSNJJwSvAVEgs8RCoV8rReG7x1rlYQ1wTn3hj2+xaMdIKOLHbOu3ZsT1IjDGseFXcMJsKYYajl7tiUEtRE8em+OQyMOB6/dGapFr7U0JoBmeKbnzuyguOaQbdcJrEcTttk78B3HiXuXHaKwY/jeLFTrmoYWiNfZgJ/r2VXj04jBvhtHoTg+vz/BhkZRv79nsabl6HCjqGbf7KM98C/IjUZgraZDAtb4buGKKnDg4cjmKEDPJdwKisOzbLPQnQYf1tuAq8PbcUu8gO5GbwhUaxJQwlAbfi4h4O4RhWvHT9ih6JqQ1nu2xUY7NFB1FneLQ7Q2ND2NCbYQ/EtoAWlE9rcmzGqU6kgJ12wJoLkDwR2hxQ2t1msWieaGT004Zm0NNTBww+JW+3CCTyOlucBxbb/V1sjAPTb78ECPdH+GQl4bHmDhhIHhaz7NYhlY42gc2MrAR/fPcmgWy8GobVoY6Yg7YONhGAI6cGXEDwWLKeIxBg0FPnLYp274osCZgEh6UD76KsfigoIGRuAO3E2x0LSltqEA/7DPFyx2IMUa5nFPa2twcTG6V7wYwcz9hgZf5HkNjKL4KXCU6fH5W+Ng/Hyrn3mjj1rMWlC8uMfvE9FcrOnx9zD3F3MwEEFNpgjc4G1dnBkDNxT4/a09KSJwq781WBsDFxcjbyCExJgBz7fStcUCM2qDfvDuidOMn29t1fA0F2c6aC/3cXw4s1ar9ftZMzQMXOuoAi8nh6+qVWhGrcMPPiAOGNL4NsOzVWCGNxhjc4rDD5/or2pl4IJiLJlQjh5fCr7Pwrzna/H9Airi28T0LHTHgWDH4tjnU2rVxWB/SGDuQMBDDHOPLWD0+RSW4aqueLHDwdZWsYZXdej5WvZuAdsoi2uhUdh+y2+UxbWt8HxQ2EXRbW1rMA7WoEMy2Brb+aHf+hqKRftzT4PIkVKb0hDfRQvARaiWoTX8YxDMKxA7BuH5xcLO3wAdxu+NO1KY57WCI6V4sR91ckzw4WKNX1vFPs/BixdDJw8Gg60+oWb4vmKe72FgPMgshmMSHRFafwzsC1qq4PkqLzPI4OELmqe21c9+nsAMdMCyz2uq2IERD40FuBUKIgNjAf95PDCqCl2iKiiKqnAr3zjqS3u7CnhP9wYxXhRuP34stfsQGbwh9XjZ8fST7QRwe/fJJWh3Yrci3I5htCvwWDvzUA7e093evqH7OKw77dnQfuhQuwy84a/H8FuWHD+0Zw98xjGhLUK4/fgelDkn9SRkvAJswzHmoSjcfqjs0AZeo2w4eVxgtgDewMHRtdNuaXjPWsHnbjgmfHMMXMb/3A3dS8q6N8iYUcZTDe9dIm1GO6hKP7SBeb19wyFoGukCprafhK27eyA+NvrdUyb4nHi4G60hHtsDS4F7jsG943KNgswsAx7WV/F/QV3E9zpMp5cxN0Ij4mEo1nF2BfN4jF6x/rwh9dDJY8ePnTyUuoHgSGnHdde+oZ3wgI3r9g9bTCdw6x7tg4REjvrDh+eEUGqi0GVnnTU4GiPoit6a7LK3jr7xxhsNlSvem1P8xhu5m2b3uvL8o28siBUb5eio661EeEPFihVztiwYnZ3clOf1bVkQLw5qyxt9Bw8frrD31FYCHDqYnFxf5dvyxhsi8CjV4/P5/BWFVloPmmvslRXINd3n6xmNh/uoQhcjTtfhFSvqmHsghf1i8Apxee/vcewbfdTvZeEtfX19zN8WpLm+vn7OnPqamooa14oVlTX1FRU18Li+ZhNmz23bVr5torx827ZzWwAebWgI+el6p8uPCuinrU7nZXSeiutuy5Vt2yZe2/jaxLZtVxD8xgJHVY2zd/ZoA6q6vlG/3dVbt2kLU3UIfm2i7XwbCzuqrK7e2fAqbpS+N7Z0VOXBE6GI5m23N3bfZ2F7ZW9dB3pltOK99+obEOHz5jX9pD8CX994gIPPz+xowB/ZcOOTT25tYeoo2Hrjiwi8rW2Qg7eI9QLAFkQ1nzjAFVCc5d6C4BNf/uY1EngBqrqJO2Twlv6xsatf3DlwF+IBKGvuv3fv3t+//D937t3rX6AI9wF8787/uXvvXp8yvCCM4Dtb74UXEMALwrsA3xXeQgQvKA4fDG9hO78izD9SHgp4lAqRww7KTw7bKMoW6iOSkI0SD11SmEywA5Tbv1eYRbADVBbm7QBF58wKcHSzoc1m8yrA3A5QS1VCQmsCoWbalgBCBFssdBWCLbTFogjb/EgxzC2ydsvAFm8CRpHVrTYLAexn8AQ/AdzK0oqaozb7/Tavhbg22NxMJPXsJ2wUVS1I1DeisF5NryPoz5Pw14aT1GlWNcioGr5UDYyTkfH4mlWlPp+tQtSla//Bp+dbrUKoYRVCrd1B/LOWInZ/lvQl/hfAZcTyOHWcXB6nZnQTC1x3txPLZJTm73QUNSrK1xtFlx1MCSlIysFlrBfcsk0wjpmFvzHPLN8UgQ8uVxoylh+UhmHKWrj7VxrWmB3BoK/WTAJrav00XQWLWGZlWFPrpf0Ojbm2lkCz2U9XpcB+bTOBGRoHTfsKCGujoIfW1moeBKzKDFRAP9plTdQoGoeW9tcSVh3Q0Ch+skZBze0jbm4wF3Uk4l4n10U3KX/H8zo/HFabBD+xj9nDKok8RHmSuqHgYfG6f+rFKUTyIhqe41IspKXh7BLxCRaeol6MR9P6z58/3x+Pvxifu6Gtv84ICTF0dWltioke2s4jUqeDtBr9bQowsFzrrdfF6I6F29J06yMVu75OAT4vyOQhNCTOjNlJvEzghvOxsDB3h1iNczJFXc7x9SpEcBpv/NGHoS5VIeoa5SE5r5vMGPL1z0X5cNHQ04JpgIpkmX30RZ2CpN36iiyZffSycOw+enl4mho46YFp/o5hvZ75I4H19gEQu54E1l+AmE/79qVf0CvDeus+RtKtemXNAyg804UL6fkDyprtsB0WxaqH7bN2Ajj9gh3KRgRr0RZegC/kpxMU8ALYrEfwAEEBtVA0vfZCejpRPdsH8KZfrZ6sb1wYGLig1RN2JFR137P+/C0dsKoGGVXDl6qBMT4y3ibpE9e4yHjLNxklT4l/ygXlWr2ag7Mk0gE/wwXaSgl1hJjLRXPIJSUYNptb9psyhgdDZuayTTKFxHTEDu4wDYaQbga2SCUgAHh1i8nUsXq1GcwwK2k2p+zfMbgaXQC2DHbAdVVtjYTUA7y6IwMUA9wCUWY6zFAbkgk1EGzC8OphiBo0uFqynqEjARzKMLUgGDTvD4HmnTKazebhHcNQ0+ZQx2AHlLG2QkpwbXRkIJqpD5namMpEP0MR4AYHiRoF6FDL8H6oN2ZiQarqarjYhmiO1Mx1JJkCknZRqDpNQYz8c1RaczBepGquUiyfpnSWE1UpUWpUiLo0Lg8uQUylCqGmqkn2/dBkDPkF+Ynrk7tStxOfEj9TWte9nfRkexpKM7ad8DQepjdKjVu3txPBqG9A0rX2dlIYUnuRFJOFga5TpmdEumhp0ontRQoS7c+lhsEhBeHHVVtf2CEv/CPFkHV+o5y8JLyiXx8/tyKYhRAeg+uT+tuIYZg3OU8Ow9wKuRnrZxPbvH79+TZSm9fr+ttIayP78Bek9WzMLpx1dpasRGAIVrd2QEE4OMeYuDZ9n7w8wcWFcDavJVjkmsaEwUxfS7IiloTN5bFLIvGEeP/wH9IM8R/XEq61PRNv7hLBP37IoyeJzGWDKakK06QcpRmmxadWVYqfi8aulqT06PU1rmwj71xUCgW1em+lIZs52Z4uOGuNkYKUoFZf48xiwl/i8w189mcWV0t7C9mgMdnZhfjsa3DHjvQ42lyQ0qrX17NqDRDoZio+r4MQyHD6FavWV0XbeGptek8E3m8Wqq0FtRXOLCbwaZazXq/vnMGeBO4oE5ihMfd49XmuLE5tpVfvGXG7xQoIBWultRU6Tq2rRq8dSi1KnSFSdaAW6iui1lDppT3jbncqCwvXt9hmMDIWgFpvILWIGflj4hJraoNepJZphixDpVbvGWfz/cbAYG0VbgZObR6odbsj3ynTBc0QFDaDVt85Hk0jzIdFmqEqqlYAI2v5anEzdBcJv9qmc2p74lp3xO1OFYFBLdO6PLXQDO5UERjUemlB67LNEA/jZtBWGpjWzUat6x1KLRL7Op4OB5mwGVCnkUi7jI+GyphmKJL4og9qI2qZZkgYL3JLnRU8Lawvb8Dtlj6FmBOtL9S63UVuufMNnlrbiNste3LyDK91U4sUTtXQ6hKJWjbW/TPTXHOmTh2a4SaYF6164T8i0jDa8B9S8gLaFBV5NHby4t69n148vVXqDVUUp3cMyL0Xr95B/y7B4y0xf0g3xd4/uRfJnT98if9fHBVVTTH/TmNm78077J1PG6ThSywCmi8ydy/2icG/AznFAKdP/+EPf7h6k8HP/C5eMLybga+eBs2nr37KPJKAV+1l4S/vfHnnzlX20efi8Ofsy5/eBJhTvHe3OHxmb5S+ejHyQBzezb1+58t//IOrDiUYau4PUEJ5OGrG1Ttcq0jCXAH3niYo4CmOhYoDXL7qIo3yJSrgnYuyjcKpvvkPKOAf7sg09wGQpZc4m//w5c1PsdGffrX0QJxQS7GwH336H1xjf7VURFh4Ka6xm1/+4R93PmX0ysFgCW4T3CqnDyyVh8FEXL4//OHu/7N0qRIM8hskS6WFWqpCHiD8HDn7HOVhikUgSz0U5e0cIpJOL/Z0avoJgTRhT6efEAt4OpHDz1A/USE/AvjUqZ+Q/lB5KkTdpJOYk7I+L49ZyVBOgAsnV6dOVWr1ZHD9qZ/85FQ9IVyJ4EpCOA9VUx4ZDKdjJSU1ogV8mnyD/tOUR4VQbhUyuUb/UK7Re1LZL7LfuLlOYImEttUe4L6QDqTC8OyJfOdFYW9nFI4O/Ac8VPfSeNjTbRGBl6ZSB+JhS6dbFD7A+7aKwLbuooBFBF4qBnemHkj1CuC7fPguH/Z2Fx1wewg1DxUVHTjQSQZb4HLpQFGADNbCRRD82GLguyx8VwB7DoAZqUUMraR5qGh8/MCB36Ty4Lsx8F0O9o4cKEo9ULSUsVpBs+3Abw5AbSxdiptcyYxuZPOBpUUjHuUCerphhfUAVB5uRAXNnnHohwju9ijDQ91FuOqYEor1DfwIw5ZAN3BQxKLuEYuSZrACnckuXVrk7rYpwN5A0dLfgMUHwOzuIYXa8IBaZAbAqakBJTM63UUHlv5mKXS7EaFmcZvHOztHDthkjhRe38DH1QEtTXoM0kMHvOLwATH4Nx7xoUB8kLGJDzJiwxcv4veB3/CHL8rTfYAEPtDtkfV0etomG41E6CpA22SjkcjCsdFI5OEZ3ybsfmCav4/wZG1M1sb3qzZUDTKqhi9VA6Mgeb2c/Awpfmw+oTz2FPWz+cTyM+oxcvixHwH8KrE8RvnXEItf3WWpmGPIQEbGgJbwin4gf2AAuVQSwHp7xgW9/kKGXU8CW4GDd1j1RBfpGeD8OZBBaPMFlLzsgp7wih4cc+2iVaeqUVQ19+SRwodVDTKqhi9VA+PkPvqHcJtMcjaxJKubF336G86LSjrY/fBhVV9Ak6Poj3QUnTp1uv9pVzLJKGrQWbTmNbQrm2QUVYZ5oygBHB1FCeAkdZp/8HDEWTobw7qdcs7Shay4CgH20/BfWgSDjLlKYZBpjUrQHGyVFWq6OSopZlmZzvuasFSZ/Vp5D3arnRNaCzbbZcSKMlZjyebqWXqPN5OxGgkLO7MNkvIj6HUP7oBVNcioGr5UDYyqXPSfdIosdUo5/z+T7bTqSbcVTNNlkdJTUaOQ0lNxoxDSDExII9hISgNsQJ6bThIaYMioCLnJCglqEOAKV4W1RldRuNNp1ytWXU2FnaYr8wrBJ1FB91QqGVJG0ha7HdI7ZrnkdaNGsaIRshB1TQV6KvIJrKipZ7txlkurl69nQ9Yrr3Dj/Ss6mT6IYR1vJ0xhvQJsqOAPrAp9w5BVqCfvSIasSr2eGM4mojGcDWaT0KjXOSvzapwkulGjuFDa0WwC3VGYoJTQN4w6CKnrNBDUCVNAg4F1i67Qy3ckGEWNXOpTBfrnwktpQ3aFXn7vkuAiPblCfu+Sktc9Kz99Stnrnhf87CkFr3uB/PSHHwtuMtgdP9hdhwqhdqgQalCFRG3+J4HNbG0U1Do0ZrKqMzscDr/PpyGCNQ4vnMH3EMHg+o9Ww6uCKWZl2GxuZdJfaQg0m1PwZYS2lUgzJGMDuLWWrIAp/qDWH1SoPK7X1dYW9NQq97qfctt9NGaz4iCjavhSNTBSFrqnrwtJY/LCSge+F7qRXDjwx3yhrLVTlD3LZakKvflmbm5j7+8rQ2/mvtlwK7m3nj62+4+xYqd8tyBgPR3seyO38fMzlaE3ckM3euHto2O/joPLqL43R2/0Jlm9HW82go9hqO9WlqFG63tzgQj8R2q0q6vBd+NwBe1PWPdJZeuNrEraD88VbxWDIVxvQoI3r8ZqT6j+YpMd/lsTUJzkx3eLwMm9SNaB9I/dTJuJ7qGn1n0upnndwoULPz8DNwu/OP3rsb+/t3DhqT/+Hh6d+rW45nWnToG+3i+QZnTnc0nNNmR0nt2eZ01Ie6MF/tfYbWBzlajNUPI+n97qNFyG2ij0ay3O5MshqdroeqOv1YJC2DMt2NdKowdd4vXc16OtSU6+1fAm24Jvhrx2Z++NUVHYCyH2b4RyUd9IPoX6xhtdPdr65LpnxWyu701u6XsT97reFQB3db35ZjjBXihaG3/8Y/7p06cjj/G906fz8/8oIpTosxLyPYB3825l4d1ij1l4N/d4t1ozdn+9Au4WvvvbqQ0xW6i1Sup28wYZO7kVaLBbm08kaGCk/vdUR4F5jmvOdM10v3XZ7OVyQ+7/fqVC7/gnwMs1a2BETdDIDeZTK16p178QBNhvz9bRRwrkviZ8NKIT1s9ZY0Gs3BfWdKrAR1e+Uk8b7MBa+Kw5FBtMcTql+U+HvjKrwlnjBPY/eWEYN9XpZm8yp/CiZU6H+bpgFbpM0TmtdCukyOJo86Zly+pwbItQynIOhsAo6w1OmChzOo0uV5OL+2hzyuy6g1jn7IMRzXNAauphc19lXv2c+orLvKpbzrxn2bKDHPzCC8th2sbpdBnzvOeWv/ACb78kPkeAgJAQCZIrYMERWmfMc9orX6nx1hbE1Zx5E4iZg4/AHJ2dNuTRha/UaGvZNjEf5FmzPFobtDPLvmbO+jmfAZ3nxTE9zZtmG2dvMsc3ytOILWh0zflnD6LXFGBr65bpQiKwc5l9jbkgoalmOQQLLVxWuZyxom42ewpk5sMHb/XAyYZjkwP2X/p8mzYxz4ciLc2zZjpEw0Y1oFmObC0o4Apj5jQe1G0iPtlePpsXm1MJNoc2Ra1WPI03L5+8qPlWYFUXvA/wXDRy+Z9cozwvGplYyKrRK86L6khhPC+Ktg+jLceKMJ4XzS6sqIApOAIYNO+soen6nYRwlho4u7KmppLUDPICTuNXnVKQH140EpeSCKJkoAhbMn/JP/yQod8JrByMNAqX7jqxVV74cPefFYQPn/jzXFl55AHCSQ9M8zPk8C94w5cS/MhTvIER4Edk5BdPSa0uOVXkXbI7DeR5l0RhXt4l8H+1KMD8NC5VWos8HEnjYqFpCJBBE2m2QE5iDaR5tpDAdFUtmpVppYlspv3mgoIgmRmg2uwwE8P+oMXfaiGtOjqaaoignhVbUCUs7jVk2CnqKuATFYlYcHHB7pCY9bRkNL+400QI/i8VNVEW1pPDem1NdPlNGXbWRFZN5GF9XmVhtquSW1FTgO2uLFgbzSOCgTZkZdWTmYFCB1W6Kklh2FNszyOuDb1Wz6u6n5K34M9Fz0XFYbS6JHouWvW0+OoSfykqZiEqT9ZfNEuwxqW36gwy/qKycKy/qDwc4y8qDyep0zwJT8KT8LcOP7gDVtUgo2r4UjUwUlbnOiJxWoFFCypEss5KuRYSi4s6TA4fptaRw+vUwQtXEMtCdbFnxTa+WG/MuSC29SUetlxY1PSJ7cyZAQsBPHCmuWnhjcTmMwPK8MCZ4cTChQv3nxk+c0EJtgwsqispWbEwsaRuUZwhsbD1zKLDiRWHFzYDfMauAF9obj58Y86cy9du1DU3X1CCzyyqu4GW2G8cPnNGCbYn9My8cf7y4Pkb52cleBVgrePcwYWHax3rFt56waFUQNqf4ri8yeHYdPkFlOZKqVGCy5c7UmpfWF4bJGhBGlIu+Ry1viBJ36Bpr++zcz6tWEeqEOmKFfg3/ml1nf/BHYOqhgJVg4yq4SsyMC6U/WUGRlV7l546z0tEpJNLSQWD+YuQOmm9PG4wcl8TUyCbkLxyYwl7dTgN5zCSVW5wpifmGJmvtilMBqXzRik6p2ltelNOVLOcciPEj13bjB3UIjBSHkMbkTc1xLuFeK9rS3IEcJxyo7PJiQLelkAAWcYQPhxjORQsvbk5saQZWDAEcnhF4OrqOOWgE2RHibGpqSSxuckQgTemTdnIKo/UuTEHh7ttysnJYbz1WLg6PKsxjO+08ZSjsq1txt/fOJMYB3fQ9NlqZEt1Nc9yZEhiDu8UgoHTEhLCYEdHYwdKJsUpNxqbmUoTwIifAm+x0Ta4jdY5BApuMsTA6OMRVD3LNospJ6vcaGhyGoXwxnDaRmxLWnhKOKZBDUadEA6DwfB6GH1EdTQNVlxvQXB1C013VFeHtWerY5J5xfQWDIcbZ4UBtrVUx+bYAuWxZqRVV0uEh25Le4unnIXTpN4hUB7tSFM6qpWUc3B1OMEyK00UjyqPwNB4jUqWJ0Wau6WlQwpGypPWo87PJXerlqwSRvns9eufEU0bJ2H5k+oS0qlainqyNUVDvMj1c5gxLCBdPpuqhTOBAjPZwtxUNHvaQ0RjWIuc5TSkMNAkxZzOTaJCHsgCUhiUexWLOZ03e6n1FZhJYeVisjAzsQTFNGuUYMgrxMzgKRQTw5A9Kf1CtJjyMGRNgrxJkWLK5JUGGND0fdwuAdoqk7F6KsrHtG9fGTeLVuOUyYWNamMgfcDOshXZ2TILRlN5c596bWGW7J6aqfyLRVeWUUcEI3OzFNatpkZYOXOFsIK5AhiZa9ARwcrmRmGImK1kbmQhQw9ONSQsykdPZC53RU9k7tfKARpZXXp6xK2YMSR6eI8UKQXoi64uKcEQbmUqOTzjW4JRtEZCGMDu7vFuEthdND5ks3g7AwSw2z1kobVD490Emt3uThTzq8jtbncrw0M0bWNCf490K8DucQttQfch9B4EZeMHmReBkRGo2sbHAxA6bWS8XRrGMeA6ixhrYBT2jrtl4HEghoqYjwC2W84MMNmCNacWjaBIaEWpsrDXwtjs7vQGOm3jsppTPTR7fwTqelzWjNSiIZqNdoTUQ9A72arrhmUM2sPExS9yDwXcci2ICga6A0jliMej0JFQVEgLTXs9Hi8/+pJEFy0a9zCX/4IA9VKd3+0eH+rsHBoRBPSXPqzcKOWN2/0gDlgxWNUgo2r4UjUwqtsBqib9k6rEUpOBL35ckT3U5GsrVCEPMF/bJPy14QcXPuhhyUdvG3yl127vXTWz6J1tcvJBFUXZ3nlnbJXd/srf33nnzkpZelsV5UKU3R5+552/LxTAK1dOTLThO1cmWN2UYeeuou1e7faiXTsPR7G0bdvart68Gd62Mu3SzassXE5ZkKDlDotFyzz3Gqa2XblyZWPXym1t4Ym7H7IfSVnz8mw2C22zwX/mqbYTE22vfdg2sW3jl2kTE9tWfti2Mq2NgXtXjb3zjleLirmOVbCyOC18586VD7uq79557cOJ8J2r4ZUsfAc4qx3ecYct4Mo7V6/CyxNpkBAkPHEVCVsYCqph5iqrZdXMd95h3z9xevfuSyvDwNy8+iHYf/PmFSjzNigltb3oMDSKpfeVw2yjrLz061+fnlh5czdI+LXTv969+8S2iZuXxsBsCvY2tZyl6RNzoK6x5iunf/3rSx+eQOzuK2Nwg94J778CcILFkgC1kQDnZ41Mze2+eXqi+DRib36I9F/6cGU4fDWMbKZnzaLpWY205WyCHlsxcbXtzsQEVnzpCnrPiQ/h6fAVBgYjWhrhL0GLW29lWzj8WpiB4T2nd4c/DIPg2qAbkeYEmES1Ic0fbvsQ6uEOC7eBKTdPoOpjYNDZ2Ihxy6xtV9pWgh03b95BKm9Cp9h9805b2x2owysYnmVBVoPFtKUFqiIcvrLy9K9vTlwK34VPmLh5B1qH6SsIhqnLs8hqMKQDqg4+MgylutoFbyq+E564MxG+itqIgaEL0bTNS9M2LVPA8E1UBVfvTHRNrEQmnN6N6xjD9lln7fazs6Bp5niZp9Ku3jx9+irYfJW7c5fror28ZQ22v4RRh4AdWzevoht4z+kTLLzwt/dWnFrx21P3frviE6gK9IEfhm/uRvRNrBnYS3CsTFzB8Jl7N898fvPzeys+mZjo6Ji4MtEBherouHn6xLkTNy+dO7f16rlzExPoD1aX7t08ferU6TOnfvvJuXmg99w59q+DvbON+7uO4FP3PgEj7v0WzNh2fd628uvz8OH5t3Loxdc/mBc94PG61W9XALoC2bxt27wPPkDPX//gg+svfwA3865/sG3lNriD4HX3wOZTp8BmrBmpvL6NVTgP0G0ryz9gtZdTdStO3YQCgs1IM3o/UnYdQGgh9v42xrAPqLyF9858/sm9U7+9dw/BL19n9cxDb4C/cmwAO3xReXW/h2U0vJaGPop7rRzfvc7+sQMjZfE6MouLixvm9PbOaYA7xY4byRWa4lhpcABsT66kg5m5mZlz1q2bk5mZC/s/DdaqTBEprkI7QJ32qsW5DJybcmNnId1aLAZnOqjizFBdb4XFl3l53brLxbB3tMYbys2NALy7mQ0UWJdyObkQNoAuXJgAdyxrFkMRIsDmzV/0RezAO0BtVtj4WbNwYY0VtlWi/Z8JEbrr7n/x4GRuAyis5uF/+DF+MQ2wrr6+vq7MzFwGFl3x+2QLvDZ28W5mZrhlMJyZeelum4Lmsa+AaAuPdWV2nb57N2oz2gCKbLaD8baIzZvv3m0Lf/VV29ilS325GNYUZ2rWWAqTL6PagMhLyZdTinFt5LbdBbhlbCzc/+nF/i4MZ+aGvGhXZzGq58weS0VvXYgpD6C5XV/0j93NTLt08RKjuZUu3HkjhW3u3MVVdifsB2Vqra0rPNYBpv/HlIt9GPZaDfBitG9kBunKnbOZ1vvq9KeXOlqOftX2VR9TdRXrZofwS9gMhISq8uq2YNWXLnWHO0KhMK44BHdtie01uZkN+Kmui6cn3l+55wp8Ed69yxRQvIMhCV/qem3llUvd718Zy7wbVoChml9b2X3o0MoPL42dHlOAoe7+c+WhhD0TH/bdPK1kBlTvf97/auzuoQ9zscny8KWL4e6vbn711ZW7dzcrwl2X+r66e+mrr8K5d3MV4cyxrrt3v4JW79qcqQx3pW0GxV9ljmUSwJk3u+5cugRdlAi+1JULR8BYRHNDprwIhgJHJrE4qKpiUrYYJZlzNBQTCB4YKeuyVb8jkFXL8kDx+6sX/o5IVuVR899///3R3xPRH1Fvv4/kLQL2vd9R7zOyeiYBzmpG+Lr/9xWQVZI/r7zCaUYyv8pilxU+/P77L2tlg8FFzcDy9hFZ+P0YeXsNgea3346arqj5yGc8063iEoG1R/i2QCOtihdsxvwjLx+htS+//HK0tKIdhtH8MuNeNJ9f0tGFEvD78y00XSWsRc1CqeZ+G8368VEZM94/UvX2fJ4Vb4v3QhZ+GRGfRasuT7zq3o5tQpJGUdXc6juSUhcVdn554R1WM/FhJSdf54B9i2jgYAYZsjEpW93wxR8Y3/vdKviRuEUDYzQw/vZdpYqeTpGQ+wArTSxEg/krwTBlMYMcnqYGTnpgmn9McHv3rlIDIdy+Z5+p2Wkggtu7IbC8KZEM3nAIwc2EmlOPZ5hMPIcpeZu7TzaXGI2ktQFVZ5zsGw/FAatqkFE1fKkaGCGk86NEgjOGPDqPUB6FjCHziOVn1KPk8KPfHC4HIYQBvH59nggeD5eX3w4cO378WOB2HB4Hl88LlJlMZegvMK9cHi6fdw3S3mMpM12LoePga6b0iJiuycLltzm9jO7b5XIwX3GcaiFcfv14GR8uO369XBq+LWCBvv1twdfThWaky5kx7xi/gEtMx+aVy9RGQFgbAdmqu76E3yhLrpfLtiCvVWLbRKQjBUwMDl0pUK7YRW8fSzeBpB+7Xa7c+cvn3Q5cuxa4Pa+c6LAqLxc/rh59gEe3qkFG1fClamCczBgymTGEPGMIOCnqdGKxcMXzHWdVwi9Z3iUrCpdcbyBKpaTPy0Z5l7LziGCtE0IrFzq1REma9DXgqJhdQ5p3yVpZaZ3MGDKZMYTnFjXnf8nJL4WeTvSct+Tkfwk8nSwK9C8F/Zmmb8iq5sO09sZbpLDeJs8KYDrhLXJYkf5fwgLmHVQBa2eTm+GdraI2Dj6w2rCpqg3v7AcDqzFDVQFpNVWnqlHUNbeqjqSmi6qqDVWHlaoDlmAoUDXIqBq+VA2MlP3a/LdjZP7evfHPXUOBS/fuvXgu9pVPP4195oWLe/faqZf37N37aUvMSxcvxjzR8unevXtepua/7YA37ZGHQeFFx9vzKfZ9QlNOnowxgflsaj731hYpuAU++HV8j2KfAVv2iMN7kAVMhVDzowouvhAB9vBMiH4kFVXx+slIrUTglk9Pvh6taopf+46L7Me3jLDmcBbEacYqT+JXW/BHOE4Ka1SoGdm4B3EOH3rHntiWpWLbFWs9d47TLoTjegzofX3+/Ncd8c/Pp/Z++ulFkJMnT+7Zs2ewpcXnODf/3Hz4PefwtbQMwpPwEiI+/XQvtZehT2Ia4BaAX5g58wWAWzB8koGB3QvndXEfVwtLCgtr456G87p409hFjbfeVi7gC5GVioUvxBVQXK24cqHmF9YJFzrWvSCt+WD8ushBKc2iKzszRTVvklhvXrUpXrPMgtHMGM0h2WXsVSG+ZsXFpbcYzZ8xzaskqPk/o6reJluzAuVVKpbdrTGZlP9y9gm+NMetLvFPif9yNj8jKqZmnVF4RS842RbCGUIYrugfm0+qGS54HyPXnPTANE+b1DypeVLzt605SZ3mn5FrfkZu+MqIG75UDYw/lnlRI0TZMBrQjfLspUFXkpioa0pMLNEZlWCIT7LDtKOpBG5KDEYlGJRmmEpKTBklTToZOAnt8jZChBJTRiJ6Q47RKLUXPInaxEhovymjGfrOcMomaaHwzvTB4cF9TN85PjjcIr2BHYVjXD24wxTplztaVsuGKF8d4ndiydQ9bDzz1cNRzYOrFYKfr+6IwBkdSrA5pZlTvF86gRAXVn31IKvaJFk8HswVcV9IDmbDnP6TKaJp6z8LJEVDBVm5xqSgaET3WyV+I9OzlgEs8rlWeTv05ZPzfV83wanaIKlq66WqTZ2TO0C/76nPP1Mh1OsqZHIhQwC/+hdieZVyqBDmS5NMkiZ3gD6UO0B/mJ5O5fMY9wwSGNw/jmMnEQK4/HZGfn4GchMhgQNw0ZB/jRC+jeBAOaHNgYyMa+S1cZvxViFzI2G9VQCGe7I/5Yx3C9xV6aDy+HFieZx6IoNYnpiEvyP4kAqhNqgQnr+ooszg+Ysqyr/z/EUVFT/F8xdVEByNRA2sygxVBVRVdSIwRJGJjdAkgLujRLe7e5x77GZDO7n5sHtkZCQwNBJwdw+NjEBAmyGPp3N8JBAYd0MQo5FxNxPoJ6IZXvZovanjnsCId2TI09kJwY6GvLaRca/HZhvyYJqB3SPjwAZsnnHPSMCj7e4cGhrRasch0NBIkYfu9HRqx/lwJ+hFHx0AeMgGygIBG1jTGYA3dA6Ne3hwe3dnp8XmGRqCgD1g+xAgQ27vUGonxmmP2zPi5hXQPWIbCoD6TvjzpI6MeOjxTss4mOMOdGpt7s5AEQ8GVZ1e2qK1DY10dgZGPLahoiH4fLDd4wHtQ3wYIiEhyzyB8aKRzhEvTXvhI0agfJ3ucbBO6xHARSPaESjleHenFhgUAsrTOTJuC4BSUOyx8GCoOqhnm6cTAkQFoGY7oUXcneOpnqGAx+sdGnd7hqJwEZhsg6JBEb1DXmgI7zi03ogX1V93IDAy4uXX83igu9MzBLXgDnhGIHDRyHg3qOss6u4cL4JSeAL85nYzwvzHcbDwP/htxzGP3NJdVCAj/GhRM6LRkMTETQfegX/CLhqQEroTvdbNb+6ARfZyxsaHU1H4MjFJ7aaH3PBP0Pm5+oiTVO8ICj9GWBtKR/f3YBQliC+6evrgE88/SZSP3ry6AyboMp54EqdE4dJriiaLNq9OGczA80bPM5NOPQ4c79LRY5ZSy3wPToe5riBdBbQGcinFJuUGtcMmbhLtJNJc0IqSI5k1tdrYfN+ro2oz9u2ZgWCzw+cwm30pKT5frUagNsRT271hBpOSuwDlBm9NKdAI1bbs49Djhza0p85gZ9XM5irabzZLqd2TugH3DSaNeIq5J+jj59lebY6q3Y/URmBUdWaIRBqpOlC7P0YtC6Oq8/OrLtoMPLWcZlx15hSu6njNwFPLwbjqcJpyH7yHrxbqqz1VCKeY2cipEBJV2AztG4RHynRh69YKmqE9VRqG+oqqPSRUGwPHtm57qjQs1gwSsEjrSsISzSAGSzaDCAxqIxbs75ZQy8DCZpBUi2G+2pMyajHcIdcMsfAThGox/Dx3kCmoZSLjPcGqJRpFn3z+CWiGrzGKrh4ULEU1xa3R8/oofyUBWr8pJ3ZigZ9YireQABvzmmKXeJ6hJBXHsTAZwu/8fMXxLEyzROHVHbJ6hZr5Sx8lYktSPJi38iHO8mFzRLEEy7M5qlicNWZnOyMHrJnrqqKsMTvLVWHl4IhiMdaQle2qt8CM63ShYhEWoTUWPD07XaAYWEMsaiis4eZyp/MVx7HZgOZFJ36Z1aUWUTY7y8n3e3+a/QLCik2JfNYYg3Iwo1ioF9WVPXb+GX1NpCDFfL1sXdEiMFYM21sNcqjXMzSCv9qaTTyWV1d8sBtO8gBGq2ERVlBXURDHiYWB0VzbbOLY7CxdZRRFMXAhaGgkFigaRQdZVlhXts7AeKq7SBhf1BzatyPRmINbgK0rLQZjo4viIXdwR6Iux5ANFYA/2sNoFLt6nEGFYHE9B1CoAL0Nrk1SBZ8cA/8qw5CzvrBGjzS64yMGx4yiy9YXzmFtJBhFfzU+AxSSjaKqMoac0JUST8/++/YTdQr7jfn76LenEtJ4W+72dqWd3fxtue3bt5aWEmpGNEkxI7uDt59IUjQ8upWYoJi8fce4mAp7l6KXKe3us1ar/N4l3jVN+/Yh0dSY0b1LggugohHRzIqRFTHh1VJRt4cmhuEqsdNiIYVh0kJLCrvBaguhGW4cTZoMLkrtpIlrY0SvsD7Ig90dZ1tkhQdDrhMFicLhaqU8GVMicJoiy8Fz3QQsB4dJWBYOVxPl9piCrujTyNi0F6mn3KTslKfUZgzh3KL2o9PPc6/KbXTiHK5enX8cnRic+4vcFirOlUsZhs1Zj5HDj03CXx+OriNjeL7cSjMvhTGGfXICaxMm/MO/QJH4eaBLJCaTwJB8k+TvE9T+iDAXvHKitlFeZX84+FWpn8ku+g1gVYOMquFL1cCo3l8U8lIrZzph/EWN2U7INwgJw7INyv6i2YVafX1loc7gUooIlKTLdsH2aMjNkqWzVu40yDtOGGFbdGEWuGdWFha6Kl0GWf8NI+zkdmZDljhr5SugO1sBztNDTm9IQFfodBUaFTxRsyv1NVBzWU5rYX19trwZOoOhRl9T6AJxulyKPifZhkqrtb4Q/hsMyg4qBvThBqPyybaquPH1KuSbbuefzCkwCT9c/qLWeroqtGXBgi0JvQsrQwsWLBi9nHy4ng4uEMqWkI2iqi5nJdfQrX0LFiSsW1GZsqD4lqvXZdE6FsTJFhsVWhC6AWlG6Z5iBIdCN3qT8+jglgUiEqJGIfByozO5nvZaAa5yJVfQWkdfcZ8IvgXF30iACMY18LduRWFePcR4hCfy8i6Lwb1MNtRIMHF8AzJTDF7HSxa7MJpZ9r1PxOCk5OTkwyBwAyoPY4Gnss5zyH+NXTp68uSl8BaAbX5/go2mLTVWVECattdYtX6/39bDwSf37j0Jf3u3AgylHvXT9cmGyzaA/VqLa92NW/yqAPD0iauf7r2E4C1B2lrXeyO0BdXzaF8rXZPceyNFAF+8epqBfVq6sNd5q5hrwQWhKrqyt+5sHwfvOXbs5KWTx4+dAJiu702+PLoA9433cN/Y4tNbXDtnc7APQon+W8/LRxwA3/jkRoh5dtbMT26M4nt9Qf/lSG3c2Tr4crDn3zAMNSLWD6JPfnFv7N+CwZ4jKUxtyMsX9+509PjCB/tI4P+6eqct/MWXX2whgRfcuXqlq2uibwERvCV85cq2K1vI4AXFV+4jlgxesKWB7XUkcKSL/uDhEDkcomzEqmH4omyhLUSCBsYfjde9hRxms5OTwLS/1d8T9Ld6LURwgUajKYD1bhKve78G1rA1DouS1z1y3Pa1ovVuja+1VsHBG31+Sitamtf0BIs1ssKs1LT2FKSYNa09GoVUpAjW1Pp9mpTWoGKSU7xgpHG0tgJLBkNWVp9DY04hg/HKfwoxTJRMdrkKoTapkEmv+++/173V9VFW1k7046L9XV1do3r7R/Ag7s+FEt3v5MJXr3LSrbm5uX16q3h4651WyvUKKfyKi/pIDF71Co5Av4r3C/IRtZNQM/A7GXhVvGbuWb7RkpojfMQKKXiVeHUQ28zA0RjyPM2ispMyfMQJtCAD2z/K+khMDJRgBMawTPDzKr4EEWyrkhKqLzcqXbmy0kfFAG/iX3HpohS0CeE4M96UtKZPXQFVVZ2qRlHV3Oo60jeG1fbnVXG/8sdgvOaPJG1exd1wb/1IfJBZxQK/jRlkyIavVczwhQfGnSCCgTFW2IFxcgfoN4PR5mQ9c6MI661WoCry4CZP+Vy03lhZ4QKPkwpXoV7hXLR2Td7OLJgmhinrnYV6hXPR4iN5XFburEKvpkD2XLSAD+tr5fekf0ewV2FrfEHQbmQntLMq1ijA5loIg8r4DOksQY3Cueg/X6Zxcvns7Lw1yueiMCvjygJXpBr9rVHFc9FsQ72+3lloh/zqBOeihqxCCMVar8smOmM0ZukKXQop3nmnlwaC5PWT56LCHaA/iL1LPyzYrUIojwpRt0N/ciHjawc3mIzS/CON0vzwnYvaVXR+/QUrMazXD1wQO3UUg+0XBjLKBi4owxaY7BzIhyg7GflwlkDTFlnY49UP5KdnpGdkWPW0xyuj2UIPjXv12vR82MB/QW+xof2aMnAgoNXb0zMG0jMu6GnbOOxgtEjA4Pvs6ayygssHwPkDWth4OdIpAYPe8aER2wAXTOwCbBe18aeOBZpp2PQZsHPeR/kAwyZST3Rmmj8i2T022O9pL4vAsLV0vNtt541IH0Tl/sjt8fsfHOPM+Lfr9+/fvn+fB6C9/5zcv3+/fcO2AAPnH4PHkKrjb9HXhXv/7yOZt5+hb19PvX/9fqpU9Ib78Or1++XX9zGhD1JT0XuvS8DX0Wv370O0hvx9gXJ46/3U63+bJwmjDwZD5gWul2OTZghooRnwmX+7jt4Ehb0O9/7WnnpfCp73N+aVv11H2uehB9evK4anYGCyWBbX74NuYpj9+4FkDOGfi27YoxBflH9GtWFPhmx8UcG5qBCOjy86I5VUsyAZlqLmpAemedpDrXnPfnLN+1L3EGs2ncRJ5AjgfRBqubs9dc/JPfsVYdO+QxvQbr/2DRtOkphxqB0nqNtPZPM+vMXgJFkBj6dCQIz2/WTwng2HTu5B94hg7sb0wDrSD6E/J6nT/O/kmp+RG77E4ouqGBhVnbiqOiVWdbI9eZ3yrcKvHvnsVVL41fn0kdfJYAiX9zK9Bm5fVYRf/ezIkSNemj7y8stxpsTD0TTDLyvC8199lck0rP3sdRKbP2P0vk5SwFcZ+DMi+PUj9JqX/bSfTPORI69C7R15lbBRXmX+Jvvz9+OKfnJe9GvPXhYRy4OcvcyzEkseNc0gIk2wiTxe0LaCWDEYckoyjEDHviCy3GBsampqNpU4m5xG5bUJUMtIk0EZNhpKTDh2g4Fk1cOgg63kYkmVReEmOC3ZIQqL7EH4yZnsrJISsT0ILldhzI8L76EodMW/oq65VcEBFUIVqZCH5Rh8aGI6qdgu+tSUtDTijagvphHLi9QUcngKNaoGnp4yqgZOWdynAk4hVD6Fc00cVQNjvFpeXuKiu6O/Hpu3SlbwqnSoZbV5tTnlhZ4ahR1GGM7oMHd0mM0Fo2+B34fM3qXpKIAR7KLEAePNy1MO6pYZJZdWp5tDg+iyeZiJF798+abZUlu/MIyDgETi4S9fflCCnobNaEHJgtmA+GBInbRmFPvGNBxq6UD1t9y8qW7ZsvhvCPZrAtfGMMSfwt6om2YjVEK44DPYPcDs8P+3/b+lZSq/BSdgklhWosFnQjNSlb7HOTMWbyAZkaYzFpANX9NJUQSnpITIB8bpE9/HUfQX5PCTuyCaBqkZz5TWdW8nLeA0iP9xYjth1YHDQqlx6/Z2Ihidb5SWbm1vJ4V1xlKSYrIw0HXK9IzIaU9pkmIxozAU88T2dlnhwbpSw65j++U3g/POvoylJdFt77zIWNE96fxTNWNOE/eS6eizcfeeiDmvy3E2MzGYMvq3MilHTKb+MTaWWiysy9EloiF1bKw6bevWZt49MRh0oz3v/ZvTqjdvhcwn+8fQvbF9YrABrMZ5Q6o3bx7DsZuauXtxMJxmY/tMR9O29o9lsPfGxsQKCAazBR+GGhjGnz0MwbqGm+NgY+n6Zi6GHNrjb4q5x4eh5x3aIy/RjlS6q327UsTjabxuRNr5k06Qdn6irs8dsMhcwgO21EB2cAP8TKnzBBmLYjoRD0h4FP2FmlF0cl704YPVuL6ocqr5xp5OA7CkT+gLoUcuC/kDZPno7eBToL+QYSdKMW/NQPnoM4iS12u1GQPglJFBaPMF7IJAmo/ePjBgn/R0mpwX/bFkr/te7ZhLFka/M0g+QJHx8lSIMAwI7R3ih8Yb8tKSYUAsNN3p9rL+W/DA5vYInLmmChKU2yB4fwBC0wNggYj/gSIIi8/zuOLDdCdabYe4kMh/i/bgsPHu9k5awoeqE8WZZ6PuYdrt7pRyuLLQEG+9aIh9mQ7AgxFJJzGLtts9Aq9buHeOpHZrLVKjqBfCBHqG2Af6ANgDlccfRRN40phgg5+ICB4goV6SnK9Ji5/AUTX39YOHVU0bqpqQVBkZjyDWPZKfPkUU657b6vGUIEqzgvwU5r7MOLo78yOUmBdUbn/er0LUBWGb5iSWaXHLOsZSEFisgTnF7PhlHeGwul5Xd/58HezHKaysdGVny47P6+v629raqvthawu4xNY7s6VgSIdaOrutDbrMxhY9rUdetFZnFi9JahSG1KUlJU1piK0Oc16i+pqflJSUcCtHfBie3orYtOpZdMRDNxHBBiGM8rKC9GM4LSEywkEILuYVHmxwNmOBC3kktig8cAa/kIhcVSJwIpLmMQxXJ/Bh/AofZs0ofQubsbElYrPdmRNnBlfLRmx0NWeHXi8I/xXTKLhNQHXYxnxNCSN6xbWg7nx/Wlr/eWeFVWuvKRRG/4rvG+uT6up06yFct8tpjIm1BucbObFSWor/ZWXFvpBEoUYm/aF2qBBqUIVQq1WIukFG1fClamCkaG9oFElCcnICvhOaYyhMGY0TH0p0n1yjxVFU5rz33hwcJ6Wut167RTwoSs+N3kK6dQsHF9/qddr9oxLhVrZsuZWcnOcNLbj83nuXkdoKfc8WmagvozfWVdLBOStWzLmVbLBWjUpHfUmAkBdVeRCOO2/Firy8eppOCMIz4iGFqOReJId7eyG4E0Rp6mUeSmiOxnziiwT8ezmYq+NI0KoaJHBbsWJFRV5NPXqcN4exectxJt/ucfYhCoc12kpXJM9JWLEiwUsXJl9e/H/bOxvnpq5r0Z8KWkA3aUqoHJjrvjZD6Mu7wpziAlbwtQQZGdlhrgaHSZHFwOEZlNS1Rv4Qx0ziAihINoJHI0HGdnxdMFcSgwXGpeA8A44ZxwZbodihzo0ZV8RJDXOHTOa9f+Gtvc+HjqTzsdVCH2m9bMuy9NPS2mvts62zz95r7d69m1eVNzbWPfZoJq9ddF3c77Cc+XI38nN7i915YJnoO4CdxWOPHolwvIuuPXM4IkQwwpYtXSqklsJwt0Sz1+U+g3JFCX0DMk05zyzjn83rfm5sbGasWIADBw5z2XhwuHEXYJsEP+d1dz96NDMmaj54UHjP1L3dQgD7u7sfPOju7ifKCPRx9+jvfj3a3UEEx7dO/e7XU1vjZLmG+qd+/eupfsLERPGRb74ZiZNmMRpau3aIPOVRPD6X0+mx5HTyRuIkKZ3iEW9WxZBS9VX3aVVtrpSqrrpP+zeRDmevul+4klRzWl0PTc2Ln5jmBXOa5zTPaX7cmhfnpvmfyTX/UG34klt1n8PASDFt8c4hnH7NcQ3l3Tw81Ckn8TaUcq9z165dnThznANn67wW3yUvnQwV2UUK74pQneRw5xycBe/stIvwdjV4KA4SY+0gDpwc9bAWnCbikzt5ybBZVg5GYrHYEPohgHfp+bnFEAG8s3NoyEC3xWLwJhqwL9gJRvtofXDXziF9RB3u0h/cFUdwKL5ziIlo2hwzHgzRrRH2IG+HegPDXSE6otd37dRs4M4uOmhn7Ayrp4c04U7G0BYEx/na9AYCP+/aeZChDWQR3BWP74ywnbuGDhLAnXrsvSFjF4nmtjaMdMVIYORqX6e0i0ZUYZ9R0rvbuOFL2e74QenwhQdGAsEDY8bVpcWHVVc6LeYLgXHjtmXxqpMqK534cd1ZoAXjlU44rY7H7jFrwXjhBFxjiTbQDVG42qIBL4BU9JAw3kE7PDBBadWCzR7h8qvLY37Trb6MxGpu4Olai9XiVivJDQ20RjnaCdNXFndacY3MGVeUjggbYkcTmxa36vQsCkgt7YAqcpDSXxu2FJQ1uUs8ZbUQRW3NBWgi1lzgKSDQXMDVNMAzt+rwmxlySM0bH2eKmp9/mymPrfT50wKfJBaATxELFN/sIZYnWvMlF/gn5PBP+BqgRIq/j2uAEgkqjvx3f43+CZa9yGXVkJclFm9ul88WlhNLjhfm5uC/DayrJBYd5ctBnuCuKGcOktsx+K3MjDe30umpX+kku8TpMax0EmRigrTgEbAVa+VSqcrADrjEjJJhTbgIYEhBhdROVFzShE3GS2vQslJY2pm1FjULdjjk78vAsApVXK4Ki1HXOtTXi166JH+fG2Ry2vCbkevw5En5+1wixLkckk/j3iVv9ZHdBHKk2ktR3t3rsNjWacluL1XN3z2iCMWFO9UUB9lW+hXo+FShcPcIxVtxpGu3LNvbPZWyQ4AVbJ7auLFQBpY1YWZj9+g6MrhwdGP3xhkluOtfpcYMd2/s7t44lQGLfvDpbFJzu7uzYFvEv1u2ad1ycKUvG+2c4dhsM2TcMMqzKg3MZrs1XVe4NcV2d8dV4XndUnZjrxpcmMZKW5gNF3ZnyKgyHJ/MhFN2ZMJSP2Q5T4R3/6sCK/GHANuqjdAv5FlRtQjrWnavK5yUY4Gel21zb7eSjGbBwxs3KsG8ISm4dzRbto5OTk5ykYl3Ipjv+YVTU8Oq0ouGAn6QmTfDy6iCTKFBxqt4xIqTnEgK42j4ymlgzK0e/fCeQ5ushJ9FX2qN5e2xbCL7LDqvsLVw5D03ifIFaF1ua+FA6R6rNr4YL+KFrYKn3zu6yUKiGdGwVfG5Ag3lC4Tlwa29PaDcooqLMBjef7r0OVVbUjBuZunaPSq2SGDUTNhADg3dpAE38s2EXYjKtnDw8eNCM4d7UH1iBacjuLEtFAo2Cobjre/ytmA4xtJsTKQH8K7I545aFTTTNB0Uiokf7MWXYE/vya5jim1uSxgTokeGbyDF7x1VamDj8bbY8ZT3FFso9A1JXAB1y/tOGhToHxc5N2/SjCDayHq6VK0zpWBk7mnVriHpooUD0OncqgeAALfOu4i7M0nnRweK9lHI+bmxQ8sC8YAFc1U6cZpmGGT6ScYB7hr98J7vEA9fuea6/+65N+GPN8/9liSn02/PvYk25p7jNqTCThK1nE7p8IcfnKpTyemUBp/cS5+qUvnML4FB50c3b+5trpOzJgMGppn+6Cb9QdXND29WqcN1zSyo/agOcgavamY/rFOHP7R/hPTVwaWrqmb6wyp1m1edYvfyCqv20jfrVOGqU4wIN8PuHXXN2CECvFfDjFWnhPeu+oBmNOC6mx9wHq46BTt3tMyo27u3rqqurgo2JcG2IS34JmR2vnmzmaFpZpVmA2GLEW1HixLYDM/JwUDvRWh255ODoQ/d/OijU1V1q0jgVSgfSJ12F9U+h52D/zL4R+Twj7KHL40zevKB8R9xXtQKU4wWK9nsJVxwdrsLzGYC2FLiqXXQdgdUS9JM72bBV/ddLpq2N2TWps+ErSVwBd5pMbudAZquLbGqwiVOusm8wdPkKAs4aHzRXhm2WF0uS9QpVBl1WNW2yZidtDPq5naNlzWBarMKXBKg3SV4RYKrzOkps9eWqMFNdjO8AFkAxYHcjoAqHLAjf+B1EdFoLa2uuYH2RLlFF4GG2gDdoAZb3HSgxBzgnWG3u1U3DQHojGLaBf6rVd9QZrY46AZztMDjrLXTDos6XGB2l9F2sLcMHO02a/U6s6UWB8VRazFr92cLVGByOj0FJURJBVEhrxKzZa7ukvbVpR8/nyG1SxVH0ezLeOm9WGrGj2lSGBooKG7yiAe1ErxAhD1Qq08DXszDjiZYsVNbZifR7DDjAmXcKKAFBzagZV/mqJsEdnncBVar2x0gayAs+yppIvaGc0OJgxh21AZoYpgggn89HFCEZa76eiyKF+ayL/uan/aLiX/38D9CJeUzRIIKhjJfz9zaQiRnHFTs9c+nx8hwN/X166+//mArEX6G+hzg178elcE3Z9EcDKZsVdS+ORNGpmzVNEaEX/96RhNPwdgUdVwCI1MqVHEMf35cYkqFMs5pTsTgpvBzbEqFMs7BIXtvoT4heEUR5+BeNPYfl5oiiyP48160vj4h9UqFbFMB/jqBdyCw8wR6ukJBN8Cff/3nXoZmGLaXxAyQIPv158eROwga+LohJLVX3XWv9x4nD4qk52mGO/eOlEsXzaHzqx1WmTCYQHJ8aw4FZzZLhgKtQWazdJDRkw9fZbkNjH8nZ/QW2VN0uX9tFihtC6focp9Qss+tLM4ApJIvkzlHzz6VdnMfG+0uV22Bxhl9Cf7AXeZ0F7g9Aaf6iRjsRECf1CwoaQlMLKhqtprL8Kc6TiNkMraqwHDuT9MOoRavxZ1ptRS24HNX/oTYYo46aXfUbFWA4aQcf47GrKfBWYbOMKTnx+kwNM/FPWvmJwwcJDA4BtHp57zpsIvftYBbizzjjCo20NJEixMgZg9dVks3lVgVXYdOU8q4U12zp8Fa4mmwKMKWAhf2nYWbnbEUqOaTwVGB038+3Oq9zsqdLwU80FM9DW6NXmeF6svcfhKHo6FAqwCBFYp4NzmAJen8XPVlxcMq+4C1wiI969/RZ1FNeKmn6fn5IZwASssMs7XBZAqia57zfqDRQDPsnjGxocbjXNIqNddBNe1arJa7QLpC7QTBbHaWmbxtjfxl18Y2Zc2WEnfAZDLwauEVhvmKMKhlTExbY6OglqEZBZhTmyjkLTg+zwBJfBTOgEosDSytb+MbdrwxxMLQapZdeAz+ajIZU2pjQZOpFo5J2blcS4OJ1sckak1lOBeUzKyaNAxIrd5kbCjA40cmDBOztcZUGI4XJoyglj9sMidRzR6G9krV0izM7FrlBpmSgkAquvCKBPhLcuCmDYwoDF4xDMchDKxTOtak4Ozoglp3iWwyJbMZwuAXwgDR9aIwyI51OAymjDBkzTJyMKg1pkfXxHiyR0YEY7VsSKrWWCszeYlgcwFSmx5dp+y0BcxveJj06NJsg6XEKj8iSQ8yHN0mmfFTnJORhsEPas1m5bFONQyZo+gKSXQZp7Ja7ho93zCktqDEonGNHq8VCGmq5ffRvzQvZnh+fu2CpQSj6L/Mr64sz/fkL9Qt9DuuLrurVjD0XzbUmqr/BPA2Xb2rxOOtUStFOr92Q8C0vAVgv8tcYL9eo1bk1EcjWn8ov95uLqDD21TLp1b66IYNAdrisiO9ldvuqsG6d6pNDSW17iY3sO9owOFwi5dGSc7cDjrcEn5B3uYaDoYSOocsbqvVDBtL4e4XNYoswPkgTQE021oWyA/UBuU1J2cxvHz5tnoaNqx6rGXs7W3Lb8vpnR1ce6O5BjWw8jpdYC1zuxo2NLH7jyy/K2fE4Na19zF8nXabXbSlDKZRm4z7s7xRM9tcUwNFeDAchktErvr8Q/mfAg2WZNoMJoDBNagi7veo5xFbGfTk/6kL0fU16QbUzFZUDIreOHTVUa+rzP9OoLwS6Gh+TZoJszX3Bwehbbyf2/r6bv/b7T5f3+3b/9bX11YtQe833xicvX+/5j68CuHfo6BSMtQMhjrJd/FtjTQOgxVQ9hjU3p8dbL6vUrS3ZvY+OKHnxiywNbM3KtZiP8vDoAt8ADaAx+BVyYobqxVhaBZYsBpb1Zxcfb95dva+suaa5ooesADUNfesHbzPtSUbruHdC4KImtm1FckaharE2Ek1yVmsC8IM/oMbeRg7aTaJO1nNffR7dcqbGTB20mwN18ngDSoqZmuUiyNzTmo+n8RwczKpBq9unoVY3a/hyi6DF+6rVVLmGpZ26P2NKilnptHb9vs3FNeLZm1sA1hpMBfTrZTrytXhVE6nct3KavhRhYUUMbryFq/R34WVK8KLhaI2YZq203SXjkCzzodz9dLG/eUEcAvOMGm3+3SPG67mzGBXEphRXt6CT4Z9JA1EtJ/1+yrLSWAUlP2kQSEK9wJqW5b8b2V4WbYol1J6Q0bmrgHNXV16wmf05JtnBdbIBBk82W+0s0Yj/2034mTfrN4o0PDDBIOJIIYZvSGhDxr0BvgO6hMGPX7QAI/gewDbmVCC0esN+GW710Uqd0d2w3dlZN1urCEIWcETbSwHB0N6hmGChiBNs22/SpMIwPpEEJ7WJ/Q0TbHwlgxoTgT1WDMgNsS1w886pBmZBQBYylLGRIgNGpBiBBvWATOEbxCcwDCoNgTZUIKl2DYDA4nMgYc2sBGkNBRZt24osY4zAx4GPUE9A0opeyjEMDjtedBg5MwYchgMLvQyW5AxGoJcVnQm0Wak7AZsP7gKvMqAPjA2omfakOJfgRlIix55wBCiKWQuosEymjcDjF2X5g3MBpkghcyF5oJucA6jjx+USBy8wfAsihOV0LPBhAHZrDew7L3NaXIF24yCAI5jDJQhhO7DH2BJ0HsuHb6Dmw7KDAaGTSQoYyihR10C+Q5is2Tz5kePEIdul0D/wGoBgQYaKdpoCIVQv4EWGBgw49H09PTmzXAD9BW9AbUc3YCHca8zwpvZWUNIH2TAjEdTHYA96piC23NgRcjA2JHhfBflc9cnkPuXwPuDTriB2yUoHgkm1fu5DosuiYEpyAzBZuwN1Iu4Hs9rRp4MsTRSzVzZvnn7ZvF7O5iR4J4xoN+oP0PogkYO1p+7dg99H7537Vz+4XNBDjYaOApgA5/2Sh8KQghx5nxGSJ9vhyODf9YgakYCnkaugfT9rD7IcgULUEOEZ3mb8Yuhb9izD39jkHuWQU6hMGaA4zsUNNq5jo07MLIHHd1sMBREDtQLfoboQ9CNCAsFDSED/AUR04O9ECegUYjpVFDsRnTIM8jVAEO/gv6Ajjz0PnbefGkEjeAnxqjXs1zhAhiR9PAnPGhPiyAvDCMzvtkZNnuwIxsYCbaLXs57triDqwGqsRH12KrzFRUDKB35PK1KyiePXc6rKB4ubOXmRReRqeXmRVXgkyex2sZWYS+ICnxs1QioLWwV93cUK8LHTl4ursgbbuXVNg7nVeQpwCePncpQW1HR/0/y8LGT57FabiaotXG4uOKi7+xrcjBWW9xRKDSsF9Re+fnZ1+Q0c2p7BbWFHcVbkVpUp2aRbBgkavMqKhI/P8sVtVmUFYbiVBhAbUUFpzYbBrXFaWGANwm9dlYsl7MoKwy9af66ffa1n8vAx7jotqapPXtWWohnkVoYJGqlcEYYWlEYUtamwZzaDlGtEIafy8DZ0d2a5zv7WnbxoEVIbZ5cdGUqDS3CYUiLbioMmTD2V0ejJLrFmQ1LwecrMqLbL68Ww6phyIRVw5AJzxPDAAeZiloMv5RSK+uv9LpL83hr83zqKFd3CSqGDBQXX/mnsyT16Oeq183BjwE+m4PklpioNAehnllDLM/Mwd96+CfkMGTGI1b9DM6M9wyR4Mx438J69DnBeTkIBR+gSL+KqbxiYsnLDS7OQaijmWI+2jAxMeH8ztFsoRZkVNuBfTImXKApq0DPpuz9VpYyE5fYqdasvUjMyWd+Mhnd2Uu5DqXL1YCQnMnUcDXjuUNUb7r8OV+ojEQn/pzxXC+14kSaHE/QQim7tuPpT53IqgQnFpWiGWHDvEqva0zgM2QaFGf3uhWtGXLcVw8O8Ud2ZT7RuoIayJSO6YFLly4OTA9kP0M9W5EtY2PFMo9WPPsku2gFsTxL7clBsrqoijxFK51+ulwnvbikqw/Apf2lgfr0Rxf+FCkuceb7+AsN3BUeL9pyUhLwSh4r1/nynUu/T73sib5R27JcuNYgC+uWt9Qeih56mVoebngj6sn3bdMpwTqkNnq1IVxN6bb58kF5Q1hQnglzaj2Brm06uOpRuTxci5R3ccrTYZ3uU07t8kou/SZS7sTK0cWXNLgS1L7BqRVzSEofk8C6bZ9KtIgJJ3W629y73a6sFGHBvk/5xqeyU6baUc/B9ZW+AOfWynIhO6WYe/LIO8vveaIbPPdYDmbvOdFf1e/sFhHqekrWXzeVBWCbIQej3UxNJngwJRSsFhTFgf8oQ0tGYZmBQ3xEeFoum5+FWyAlk83vb5pUUNkMT7agRZcWt8wT0v1WdhONL1aizVloOyqaezPZpZnxqkXZf9sf8LidTSYONukb3J5a/6f7UwSl46Wyshr69VXnvZVCuMtbnFehZ1RDYlFehL5RKXYNsSNVbutCh0VtWOgcfEcSjxw4XFJdtDytN/NwuU76oLTzS5VwMHrEwx85WYdVyjwdgnXph2DmAStVTpWLrVAcCgTlC6mfZgwbMoMMPuauXnW+TH0/Ta3C8FW5rSVwKIoGu5d95QQDY/XLeO+S+0DW0v1XXsl66IDbQVFlMgXYNt+6tVnm4TLKnfnQLe4/ZvHYrcxn3JnF3TaPSf7RZqjfkgHfSvvHV5xOv5IO38r8P7lZRXPWv9sxZfgzHtnK/4DcUjRD5v/4mJLmWym9qTubFTSnmrc1pfqWgubPpNzWbPiVLDhTHqVp/l+CYJhzBPribkCzCGyhlvxBlEcj2ecEI5Lnl1CV7xBLJfUncvhPucBzmv8KzVc6iOUKVUr+KbeUukQOX6Jc5LCLolyXyPLiX3LhlU67bZ02m/DD/frz+5lyAK906vLZbP647YjfZvO1wN2IrdPfmQ2///41WOnU2VndKf5EhvAv25dNMvJDanenrWWo0xa2dQ612Dq7InAX4C65K2JllM0LnHHINmQEzGuzsT7bEWP8N/8lJ5QNamt2RjqH4vCD78JPtU3O5vffp6DxYdwmWyRss7Wg1h6x2XoPywllY8BUFsxgwQzwCFttO8LGu+Qv49mqI3FbF2Qw7LJ1RqqhaUNxW4vN55ATZIafNwP0hn1wF8xQstkPZnjBDC/4EHAvmOE9ogS3+Dohgp0QwU5fF9gNnvbbvpRP6SxvhkIDd1VDhH2d+Aca2Ok7gu72/h85oWy+CLi309YJnSgCXm4ZAv1KDfy/svI/5TXTOUhuCa7fz0Fygx05SG4NPJyD5Gbzf+UgVBm5yWWUp4lYPNQPr5FafA2d0ZccIEEPlPwF2Ujmp8nzfuWyy9/PzFFOe8sVCzr/WEiPbjRxU2SKMJSK5hW7Ji5dcrnU4YUcbLqEK8DgtOea8ASAIEAD7FcuxzAfpVDv4aeYe9bAtBcbVhIMX+oRZ6RdwvIL2QoLALvWiHDPRHa6+LQc7CZHaqq755IGbDRKzHCY0IJUeZnP2VwhaaAGbJwQjO65hPwsORFNFwybXGsqetZAVFDzwM86BeEjCMHuWYPS4RNEEGfCd2l1pIWp9PUmrS4qhcX+rN430sXOdrUoiEyZAPW+QSrzc4NzKgISzkFyq3Ly5IqtPC316HNZog+L/2tWX/fW96W2pNSsrlFY/P/f4Jl6+npfH7c/5u761ev7Vq9X2LsEiq/T6/+d3x1R01e/ur7vbr3CDiPYgsCaVtcQbUJAsNEo/ImV1q9X0VxTT/f9O9c2MLyPu1GE7xqNfavvrr7bRwADXc/W9/Ft8yIzvHcVYNh6w+2+4b+5Gzn5HrUMf5JYtkz4TLFMvMmSZVRDDiJfXkRenuRQ8ERhE+E3wOTemE95DhGLh+rIQaj/yEGo7/6MWL77rYRfJIdfpH5ArPq7aLB78btE8iIaRV37NmaLS35xqWvjRlKYpvblAm/8dsBp63I1YOZK0kgMJwcGGCLYTruY/oGBJGMngF3JZPLKwEAima8nMCN4JahPJvVBwRI12GhIJNEy6/7pfgLNsA7fwCSvJEk0owvfzLkB1mgnc51r4I+/J3OdMdnf33/uC7S/QRue6E/259/Lv4dWsmvCDOgtu9eUnxAWeavBprKkvuncF016hiHsdcmyHLro4docYGfZt+8Y/MsHmZyGr5wGRskH11+GSrPKhJ4/lpbrPvWRGOCsedbzx6TJoiUftjVgSEO9kBxeNAc/RvjyZQ7jfqvD548dO89R+LcqjJ48Bjovo9/nNeDLUviylhmX0dufP4/MuEzUQGwvSQN5gGslASzYSxaUy8cEliSCQmDIwt3zD9qfcxpkchq+choYc1pcmtOy1cwFsa9m/KQtiNVS/KrwLazLfTXtMUXd39KFx28RyzNUm4xEQOQep8p/mS3bunzbZB7+ZfYMVbkONvfTsHakXHs6q7y6unx/S9fKlb79mnD5fi8N+RN05V10eGW5Bqwr93ur0dobH9tSqQHrwAju3v79YJBODdZV2437dXw799vt6fTCjL3/y+v9y+Xuc0L9JgehFqdv+zeb5e8jWTy3j/6p3Efvon0Hi9qL2vO3bMlvR3e+PLw0P17UnikRBtilHns4XlRku7dly732oqKhL854XOEiGWlnqOq2pUub2EhREYKLiiKHz9SafEWyEqHai4aWHXC6WuIIjv/+jNvhj++Uh+PU0FB85T23k/bqt2/X51saaP9QfCguC7dTcCkvX99U21RWu317bVOgrAlyKzVBS2XhLTJrtrb/oegxwEtRQtcDB86cgVdtQb+RXFOA/Xp92O+yNzmatm9vol2BMm9Y7w8r2Bwv2jnkdbmX3svfvj0/TDec+WIIxVEePlhUzQbOHP5NO45ghLvPORpqHxYWniiE2zgPD4VpD2jjIti+Mx52cX/Cc7GHDx5y34U8bG9aurQN3taWv3kzdq/PFLh6GN1pP/Fw+uHDjodwe4KH7y1ZhvUUffmHP3yJbR0K6+8UcfCDhzEmBLcnRJuzW9PeLsIfOwwSWL7hHPzgm4chJvSADH74IPaxK0aoGdoWYmOSBqprfmigE6Q2P3iYoIMPvyGAi+IYZuE2rgnHBjrAdaGPHz74uD+uAcdHuzvaoI0PT7QNdA+0q8I74x0dozMdH8c+HpiZ6eho17K5fRiX7pwZiKX6c5o+yS0yJQbVP2Pt4lAQKSKWCMW0k7IwfFFMpJ1I0MD4F2QjIaTRJB6beWVyYsKYleXAyMETIzeSE5J5Rzo5OjkopY3MpcHJQT4vxCSSQTH3SXJ0ZnKcSZHJG+j5JAezI+gPqNg6ODGBGDY5eWF8AoMTE0COYmUTfL4CFv05Ojo5Po4V0MnxC+PoNwNaxsdH8bNJMbkBehQUXLgwOT5ppFm4Mz4I7zE4Pgkv41h7KhPCBDYEnhmfDBqTFy7A3QnaP3IBvR7Bg7zrUG02O9Y9ijXu1sWglHR8OLZyXWj8AlY8yredMra0MJDGz+8aHEWqJ4PrhMQsUIZ5cPwC1JEd0dP2cAtOIhHu89Pr+1i6OTgyOgNPrkvlcZm6gNhk2E/br/fhLBlMn59df91OV53SD46Ojk+ipWLoH5YuPjQD7EjS/wJw4fUYNq6/7u/zM6dib98Eh4+OHkWp/a7VwlcDqJ0M+vquQ7N4GH63rGftdW+/HWt2gO4BuPb1xbUGgJMzoHd9V5chrBdhfx+8lg6+/XZVCHx8KZmCYX44vH6264UWowiz69f7IS6xt6tiaP5zcAkPL5lBtfF8XV19jGgzain8xcaq3q66aUe96AsMNzyaHDHSfp+vJUiL3uB9CLX4wOqgHrydxPA9aN0g3eJrQQER/CzmOakD1bEp1JWXALxEz4Br9L4uIy2TJcOYiL39u6nxkRE2OTOw5NzUIJscGR/tYGg5mKYNhvNTcISA1ZCZBdxGM4mpGSWYpl3NdQwNvp6ZHIVhKzw76zPYFWEaKjx+yMygqKM+4Vv/aZhWgekPm9HxCvCIkXmh71O/KswdseOjgyyt982+YNSEaWYwyaVPCdPaMG3P+K0K//WD3T9m9bqn5gzImgNstVrJYcueoxZS2FKwZs8mItgKm+6O7nsPbrWTn1vdsJvvvX1r9hzdc9SqCRe8t28fzGXs27fvqGbhPyi69xyG1xzdRNDATW48TZLNyhZ3cyMbCOFNe/Y9d/S5fc+Rad4DVcU37dljtRIFBQr+KhR0XkDYi+bO6J+qXPfS/KJ3Dh86RGrGj1ob7xQcspI18Jl+yCazjEj5AmrN6bWQJaaXxJbFVMfF06d7Ok603lmsiS+gVhR2rD1denGYwHSosg1JcvpLT5cOzMOma9ajhyw1F0sJTBeKfRd29Jw+/R6Y3qtiulhiHtV0l5hulZNUNXOwBZnej0xXHMxTO8chIdF7nOmN8pK2zRzbAkXgBzo6BmS/0vek87iCvJULXCprhpLINvCEvKzIcl1v64mYYoXfzKC0xlTKAaeFu1EF5eFURyqsUy80LHZRFWNFWOz8rRoogrnDqlEbRfAaAmNF+Jl+bWNF+L8TWSBcXSJF+UrKi4gEX13yLofNXH6hpiaIJyonJahIkxfv6OJg944NGzZE3RvkJeqgqonhDR5+l18GHN2Af6Tf6BF+95m2ZsQrwlGZFyjA0Q0bsqwA+B0ZOCpnRFTFDDk7VBsYzXgZ9c6vMuANEjiA9914dgjwSrzq3Y+X1TuhtI+lwCOwlh0WXCBoR0kJD7uztp6XCHDAucPsoJ07SsosPBxVigDAAFqAddBmHi7ZoCgBmnbuQMrtjwWWxEzBjKzApjfQYdE2w7rDnOG6kkyNqbfYEW3KCIqg+UyWFTLhzjLjDP8TzW651IwoR8n1t2iG5mjWr6wXcfCZ9BdIf0clLxQ0R7PeU67zm9OfjUqaKbaAf+Mo5clUmW6ttCUeyqH0plGZ4YtyeEoyx8CMeyXiwEj9c0Sa5/43b6h9FuXWFQjXRQFW+yzKXQDdX64Nw2dRrLfFC1dUUbITVZhLq64L0z4dXHbVgLlc9+X7q8EOuA6s09ZcXo7TrYS9+8s14XLxErC2zXB1G2ethzfQhsv3+9HFai5tPInNqI0t1eWksK6a9ZH5mQviypXksI4Azshzrw5nJrq3qsGEee7nMtLPndH//zqjn5sX/dvAMomJlGRpbpvBn89lA863dDvS07CbUp+DQL02YlnxBHNIfhvhnNJv5pTYM6eUodQP/sfe5+c7ly4lmhddVFfXjOpUlpgJ5kVXraqrOvWBiYaaf2atURQnEq+rurmXpms1avktoBadxJMXdXUf7aVdToWahsIoev7UMQ6vqms20WLRSnnNz5aeX8Wtva2rWvUBqlGriC+ghvNKey6fFHBV02HGtbGjp/TiZd6WuipkOtTLtSrNuKIpvRHR9FXYdPlRFCfwhtmvDNP/U0Yc/BQc5OovvSEx/QNZEfpzK5ovE22pq5IVsfNzpoteV5s25BOw96+9cXkVEQy2HOwoLR1ZdZIEBrvz1o5cJtGMEquDR7DNGg1slfhaw3XIFaW8K5SDMh/DyMlCwCHcdtpfLZeBoBxgbCzf83BH+s+u8kr5bebzBGNPCl20ZWVlucKe9Hlil+OMDe+v1CluYH9W6MxwWCFjFVEE830NH7CsT95YEV5EYKwI84OMqrGpffTc8OWt1kK5ffRoYPQt1JHto89hu2hOG1E1tri+C5La4qqu+N1PBgcHP3mXaKftu5+gxegjpPDgjTVvDZLBYPLgW2/dINzw++7Pbrz11qs/e5cMxkZ/QgqPnD8/QghzjtZuIL/zWvKSd5XhU5eRrKo7efJk3apPsCjD7jeR3EE1I1qH93E7BRThw2/Cv5FDd05wMLcHYQ6eg5XgF8nhnygPX1kwynWvNDAetsBnykN3VsDH0BXD+/hc9+wnXxHJJyywX/2CUL5iqU9+QSyfUF+Rw1/lAv/iMcDQeEL4qylYUTo+OfUVATw1zsmF8SlNmGM3fjb22VgWnQljtvvWrVe2vHKrO5POhJG5n72CZMutsY2TqjBS3L0FsTtuPfosU7UMPPbKjh1Y962N6vAoatwtpBgS2Z651T2qBY/PPPgjsnhsrHt8VMsMgKfHuruxCzVtHp9+MHqBj8yUlusmYZkmz05qBmV0evrB9KSMYrlwz0yPTj94MD06rhluoKenL2wE+o/TUyT9Gboo2P3N4+/8T/QYVBoKchpkchi+9uY2MOb2WbQuh8+iLxXWkadbmQflGogTuaBz2FgOcGHjvLweoooh3IkYKvJFUKpjXqpyFikMJ3kdxWPPFY+pfeWlzjRP3NFansWtR0KVJ4DutRyyqgmCGwshM9Aw0l14WD3ZEII7Tu87fQOVzzhRuEw9O+W8xt4br65569VeXGvjhJpwk3sd+9a8NdxKNlHWOgBwB1fFQ0tzY+FFWPM5wJlReEdFMNx/8eINDJ9AC8pUvSHKiROwmkwzKDzbeufNN9XKXiyWTCwUDmgW1BAXXKFCg+pSLC64Gi6u0C4CwnV+6M6knb+xEJ2IXNb6uowP2MKT//EuieQ2FLxUGMshp1PdE8rp9P8A10HNPon0JEEAAAAASUVORK5CYII=";a.ZP.div`
  display: inline-flex;
  align-items: center;
  justify-content: center;
  background-color: ${({theme:e})=>e.colors.alibabaGrey};
  border-radius: 4px;
  padding: 1px 5px;
  margin-left: ${({theme:e})=>e.padding.default};
  font-size: ${({theme:e})=>e.fontSize.extraSmall};
  font-weight: bold;
`,a.ZP.img`
  height: 12px;
  width: 15px;
  margin-right: 2px;
  background-size: cover;
  background-image: url(${Wt});
  background-position: ${({code:e})=>Vt[e]};
`,Object.defineProperty,Object.defineProperties,Object.getOwnPropertyDescriptors,Object.getOwnPropertySymbols,Object.prototype.hasOwnProperty,Object.prototype.propertyIsEnumerable,a.ZP.div`
  min-width: 92px;
  display: inline-block;
  color: ${({theme:e})=>e.colors.white};
  font-size: 14px;
  font-weight: bold;
  position: relative;
  padding: 6px 8px 6px 12px;
  text-align: center;
  box-sizing: border-box;
  background-color: ${e=>e.background};

  &::before {
    content: "";
    position: absolute;
    left: -1px;
    top: -1px;
    border-right: 12px solid transparent;
    border-top: 34px solid #fff;
  }
`,Object.defineProperty,Object.getOwnPropertySymbols,Object.prototype.hasOwnProperty,Object.prototype.propertyIsEnumerable,a.ZP.div`
  display: flex;
  align-items: center;
  justify-content: center;
`,(0,a.ZP)(D)`
  color: ${({theme:e})=>e.colors.darkGrey};
`,(0,a.ZP)(D)`
  font-weight: 800;
  color: ${({theme:e})=>e.colors.black};
  margin-right: ${({theme:e})=>e.padding.large};
`,Object.defineProperty,Object.getOwnPropertySymbols,Object.prototype.hasOwnProperty,Object.prototype.propertyIsEnumerable,a.ZP.footer`
  background-color: ${({theme:e})=>e.colors.white};
  padding: ${({theme:e})=>e.padding.default} 0;
  border-top: 1px solid ${({theme:e})=>e.colors.lightGrey};
  display: flex;
  align-items: center;
  justify-content: space-between;
`,(0,a.ZP)(_e)`
  padding-left: ${({theme:e})=>e.padding.large};
  height: 40px;
`,a.ZP.div`
  flex: 1;
`,r(5002),a.ZP.ul`
  margin: 0;
  padding: 20px 0;
  display: flex;
  list-style: none;
  justify-content: center;
`,a.ZP.li`
  font-size: 13px;
  font-weight: 600;  
  margin: 0 4px;
  cursor: pointer;
  text-decoration: underline;
  color: ${({active:e})=>e?"#0081ff":"#3a3a3a"};
  list-style: none;

  &:hover {
    color: ${({active:e})=>e?"#0081ff":"#737373"};
    text-decoration: none;
  }
}
`,a.ZP.div`
  display: flex;
  flex-direction: column;
`,(0,a.ZP)(x)`
  font-size: 12px;
  text-align: ${({align:e})=>e};
  color: ${({theme:e})=>e.colors.lightRed};

  line-height: 20px;
`;const qt=(["KeyX","KeyC","KeyA"].concat(["KeyV"]),[".",","]);["Backspace","ArrowLeft","ArrowRight","Delete","Tab","Control"].concat(qt);const Yt={small:{padding:"8px",fontSize:"14px",height:"28px",arrowMargin:"0 5px"},middle:{padding:"8px",fontSize:"14px",height:"34px",arrowMargin:"0 10px"},large:{padding:"12px",fontSize:"18px",height:"40px",arrowMargin:"0 15px"}};a.ZP.div`
  display: flex;
  flex-direction: ${({isColumn:e})=>e?"column":"row"};
  align-items: ${({isColumn:e})=>e?"flex-start":"center"};
`,(0,a.ZP)((function(e){return i.createElement("svg",C({viewBox:"0 0 14 8",fill:"none",xmlns:"http://www.w3.org/2000/svg"},e),I||(I=i.createElement("path",{d:"M9.72.11l-.221.22a.375.375 0 000 .531l2.621 2.61H.375A.375.375 0 000 3.844v.312c0 .207.168.375.375.375h11.746L9.5 7.14a.374.374 0 000 .53l.22.221a.375.375 0 00.531 0l3.64-3.625a.374.374 0 000-.53L10.25.11a.374.374 0 00-.53 0z",fill:"#343a40"})))}))`
  width: 14px;
  height: 8px;
  margin: ${({controlSize:e})=>Yt[e||"small"].arrowMargin};
`,a.ZP.div`
  ${({isColumn:e})=>e?"\n      margin-top: 4px;\n      margin-left: 0px;\n      ":"\n      margin-left: 5px;\n      "};
  display: flex;
  flex-direction: row;
  align-items: center;

  &:-webkit-autofill {
    color: #fff !important;
  }
`,a.ZP.input`
  box-sizing: border-box;
  width: 100%;
  padding: 0 ${({controlSize:e})=>Yt[e||"small"].padding};
  font-size: ${({controlSize:e})=>Yt[e||"small"].fontSize};
  border: ${({theme:e})=>`1px solid ${e.colors.middleBeige}`};
  height: ${({controlSize:e})=>Yt[e||"small"].height};
  border-radius: 4px;
  transition: border-color 0.2s ease;

  &::placeholder {
    color: ${({theme:e})=>e.colors.grey};
  }

  &::-webkit-outer-spin-button,
  &::-webkit-inner-spin-button {
    -webkit-appearance: none;
  }

  &:hover,
  &:focus {
    outline: none;
  }

  &:focus {
    border-color: ${({theme:e})=>e.colors.blue};
  }
`;var Qt=Object.defineProperty,Ht=Object.getOwnPropertySymbols,Xt=Object.prototype.hasOwnProperty,Kt=Object.prototype.propertyIsEnumerable,Jt=(e,t,r)=>t in e?Qt(e,t,{enumerable:!0,configurable:!0,writable:!0,value:r}):e[t]=r;Object.defineProperty,Object.getOwnPropertySymbols,Object.prototype.hasOwnProperty,Object.prototype.propertyIsEnumerable,a.ZP.div`
  cursor: pointer;
  display: flex;
  align-items: center;
`,a.ZP.img`
  width: 100%;
  height: auto;
  max-width: 87px;
  max-height: 19px;
`,(0,a.ZP)(v)`
  color: ${({theme:e})=>e.colors.white};
`,a.ZP.div`
  height: 460px;
  display: flex;
  align-items: center;
  justify-content: center;
`,a.ZP.h3``,a.ZP.h3`
  text-align: center;
  margin-bottom: 30px;
  line-height: 30px;
`,a.ZP.div`
  width: 80px;
  height: 80px;
  display: flex;
  border-radius: 50%;
  margin-bottom: 50px;
`,(0,a.ZP)((function(e){return i.createElement("svg",((e,t)=>{for(var r in t||(t={}))Xt.call(t,r)&&Jt(e,r,t[r]);if(Ht)for(var r of Ht(t))Kt.call(t,r)&&Jt(e,r,t[r]);return e})({viewBox:"0 0 512 512",fill:"none",xmlns:"http://www.w3.org/2000/svg"},e),i.createElement("path",{d:"M256 8C119.043 8 8 119.083 8 256c0 136.997 111.043 248 248 248s248-111.003 248-248C504 119.083 392.957 8 256 8zm0 448c-110.532 0-200-89.431-200-200 0-110.495 89.472-200 200-200 110.491 0 200 89.471 200 200 0 110.53-89.431 200-200 200zm0-338c23.196 0 42 18.804 42 42s-18.804 42-42 42-42-18.804-42-42 18.804-42 42-42zm56 254c0 6.627-5.373 12-12 12h-88c-6.627 0-12-5.373-12-12v-24c0-6.627 5.373-12 12-12h12v-64h-12c-6.627 0-12-5.373-12-12v-24c0-6.627 5.373-12 12-12h64c6.627 0 12 5.373 12 12v100h12c6.627 0 12 5.373 12 12v24z"}))}))`
  margin: auto;
  fill: ${({theme:e})=>e.colors.darkBlue};
`,Object.defineProperty,Object.getOwnPropertySymbols,Object.prototype.hasOwnProperty,Object.prototype.propertyIsEnumerable,a.ZP.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
`,a.ZP.div`
  width: ${({width:e})=>e}px;
  background-color: ${({theme:e})=>e.colors.lightGrey};
  border-radius: 4px;
  overflow: hidden;
`,a.ZP.div`
  background: ${({theme:e})=>e.colors.blue};
  height: 6px;
  transition: width 0.2s ease;
  width: ${({loaded:e,length:t})=>100*e/t+"%"};
`,(0,a.ZP)(j)`
  margin-bottom: 8px;
  line-height: 1;
  color: ${({theme:e})=>e.colors.darkGrey};
`,a.ZP.div`
  display: inline-flex;
  flex-direction: row;
  align-items: center;
  margin-left: ${({theme:e})=>e.padding.button};
  border-radius: 4px;
  padding: 1px ${({theme:e})=>e.padding.small};
  background-color: ${({theme:e})=>e.colors.alibabaOrangeBackground};
  color: ${({theme:e})=>e.colors.alibabaOrange};
  font-size: ${({theme:e})=>e.fontSize.label};
  font-weight: bold;
`,a.ZP.div`
  font-size: 12px;
  margin-left: 2px;
`,It()(vt()),Ot()(vt()),zt()(vt()),jt()(vt()),a.ZP.div`
  animation: appear 0.6s ease;

  @keyframes appear {
    0% {
      opacity: 0;
    }
    100% {
      opacity: 1;
    }
  }
`,a.ZP.div`
  cursor: pointer;
  display: flex;
  align-items: center;
`,a.ZP.div`
  height: ${({height:e})=>e+"px"};
`,(0,a.ZP)(v)`
  color: ${({theme:e})=>e.colors.white};
`,It()(vt()),Ot()(vt()),zt()(vt()),jt()(vt()),It()(vt()),Ot()(vt()),zt()(vt()),jt()(vt()),a.ZP.div`
  ::-webkit-scrollbar {
    width: 8px;
    height: 8px;
  }

  ::-webkit-scrollbar-track {
    background: ${({theme:e})=>e.colors.scroll.track};
  }

  ::-webkit-scrollbar-thumb {
    border-radius: 4px;
    background: ${({theme:e})=>e.colors.scroll.thumb};

    &:hover {
      background: ${({theme:e})=>e.colors.scroll.thumbHover};
    }

    &:active {
      background: ${({theme:e})=>e.colors.scroll.thumbActive};
    }
  }
`,It()(vt()),Ot()(vt()),zt()(vt()),jt()(vt()),window.location.hostname.includes("pinterest.com"),r(4631),Object.defineProperty,Object.defineProperties,Object.getOwnPropertyDescriptors,Object.getOwnPropertySymbols,Object.prototype.hasOwnProperty,Object.prototype.propertyIsEnumerable,a.ZP.div`
  position: relative;
  color: ${({theme:e})=>e.colors.darkGrey};

  & > div {
    max-width: 100%;
    display: block !important;
  }
`,a.ZP.input`
  padding: 15px 132px 15px 72px;
  border: solid 1px #dddddd;
  border-radius: 4px;
  font-size: ${({theme:e})=>e.fontSize.headerLarge};
  color: ${({theme:e})=>e.colors.darkGrey};
  width: 100%;
  box-sizing: border-box;
  font-family: ${({theme:e})=>e.fontFamily.NunitoSans};

  &:focus {
    outline: none;
  }

  ::placeholder {
    color: #6a6c6f;
    opacity: 0.5;
    letter-spacing: -0.1px;
  }
`,a.ZP.div`
  font-size: ${({theme:e})=>e.fontSize.headerSmall};
  background-color: ${({highlighted:e,theme:t})=>e?t.colors.lightGrayBackground:"none"};
  padding: 6px 16px 6px 72px;
  transition: all 0.2s ease-in-out;
`,a.ZP.div`
  border-radius: 3px;
  box-shadow: rgba(0, 0, 0, 0.1) 0 2px 12px;
  background: ${({theme:e})=>e.colors.white};
  padding: 2px 0;
  font-size: 90%;
  //position: fixed;
  overflow: auto;
  max-height: 200px;
  transform: translateY(6px);
  position: absolute;
  left: 0 !important;
  top: 100% !important;
`;var $t,_t=r(8816);function er(){return(er=Object.assign||function(e){for(var t=1;t<arguments.length;t++){var r=arguments[t];for(var i in r)Object.prototype.hasOwnProperty.call(r,i)&&(e[i]=r[i])}return e}).apply(this,arguments)}const tr={color:{border:N.colors.middleBeige,danger:"#dc3545",primary:"#007bff",disabled:"#e9ecef",placeholder:N.colors.grey,dangerLight:"rgba(220, 53, 69, 0.25)",iconSeparator:"#fff"},input:{},select:{backgroundColor:"#f4f"},control:{fontSize:"14px",fontWeight:600,borderWidth:"1px",padding:"0 8px",borderStyle:"solid",borderRadius:"0.25rem",boxShadow:"0 0 0 0.2rem",minHeight:"34px",boxShadowColor:"none",focusedBorderColor:N.colors.blue,transition:"box-shadow 0.15s ease-in-out, border-color 0.15s ease-in-out",cursor:"pointer"},icon:{css:{padding:"0 5px 0 0"}},separator:{display:"none"},menu:{fontSize:"14px",fontWeight:600,padding:"0",width:"100%",margin:"0.5rem 0",borderRadius:"4px",backgroundColor:"#fff",maxHeight:"200px",boxShadow:"0 0 0 1px rgba(0, 0, 0, 0.1), 0 4px 11px rgba(0, 0, 0, 0.1)",option:{textAlign:"left",selectedColor:"#fff",selectedBgColor:"#007bff",padding:"8px 16px",minHeight:0,height:"24px",focusedBgColor:"rgba(0, 123, 255, 0.20)",boxSizing:"border-box"}}};var rr=Object.defineProperty,ir=Object.getOwnPropertySymbols,ar=Object.prototype.hasOwnProperty,nr=Object.prototype.propertyIsEnumerable,or=(e,t,r)=>t in e?rr(e,t,{enumerable:!0,configurable:!0,writable:!0,value:r}):e[t]=r,sr=(e,t)=>{for(var r in t||(t={}))ar.call(t,r)&&or(e,r,t[r]);if(ir)for(var r of ir(t))nr.call(t,r)&&or(e,r,t[r]);return e};const lr=({selected:e})=>{const{t}=(0,i.useContext)(X),r=e.length;if(1===e.length){const[{label:t}]=e;return i.createElement(gr,null,t)}return i.createElement("span",null,r," ",t("common.selected"))},cr=e=>{var t=e,{selectRef:r,options:a,defaultValue:n,onChange:o,isMulti:s=!1,extendedTheme:l,renderMultiOptions:c=lr}=t,d=((e,t)=>{var r={};for(var i in e)ar.call(e,i)&&t.indexOf(i)<0&&(r[i]=e[i]);if(null!=e&&ir)for(var i of ir(e))t.indexOf(i)<0&&nr.call(e,i)&&(r[i]=e[i]);return r})(t,["selectRef","options","defaultValue","onChange","isMulti","extendedTheme","renderMultiOptions"]);const u=(0,i.useCallback)((e=>e.value),[]),g=(0,i.useCallback)((e=>e.label),[]),p=a.find((e=>e.value===n)),m=(0,i.useCallback)((e=>{null==o||o((null==e?void 0:e.value)||null)}),[o]);return i.createElement(dr,null,i.createElement(_t.P,sr({ref:r,isMulti:s,options:a,initialValue:p,getOptionValue:u,getOptionLabel:g,onOptionChange:m,caretIcon:i.createElement(ur,{viewBox:"0 0 16 16"}),isSearchable:!1,themeConfig:sr(sr({},tr),l),renderMultiOptions:c,menuMaxHeight:400},d)))},dr=a.ZP.div`
  font-size: ${({theme:e})=>e.fontSize.small};
  width: 100%;
  * {
    box-sizing: border-box;
  }

  &,
  * {
    &::-webkit-scrollbar {
      width: 7px;
      height: 7px;
    }

    &::-webkit-scrollbar-button {
      width: 0;
      height: 0;
    }

    &::-webkit-scrollbar-track {
      background: #e5e5e5;
      border: 0 none #fff;
    }

    &::-webkit-scrollbar-thumb {
      background: rgba(100, 100, 100, 0.3);
      border: 0 none #fff;
      border-radius: 3px;

      &:hover {
        background: rgba(100, 100, 100, 0.4);
      }

      &:active {
        background: rgba(100, 100, 100, 0.45);
      }
    }

    &::-webkit-scrollbar-corner {
      background: transparent;
    }
  }
`,ur=(0,a.ZP)((function(e){return i.createElement("svg",er({width:16,height:16,fill:"none",xmlns:"http://www.w3.org/2000/svg"},e),$t||($t=i.createElement("path",{d:"M8 11L3 6l.7-.7L8 9.6l4.3-4.3.7.7-5 5z"})))}))`
  fill: #343a40;
`,gr=a.ZP.div`
  max-width: calc(100% - 5px);
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  width: 100%;
`;var pr,mr;function hr(){return(hr=Object.assign||function(e){for(var t=1;t<arguments.length;t++){var r=arguments[t];for(var i in r)Object.prototype.hasOwnProperty.call(r,i)&&(e[i]=r[i])}return e}).apply(this,arguments)}function wr(){return(wr=Object.assign||function(e){for(var t=1;t<arguments.length;t++){var r=arguments[t];for(var i in r)Object.prototype.hasOwnProperty.call(r,i)&&(e[i]=r[i])}return e}).apply(this,arguments)}Object.defineProperty,Object.defineProperties,Object.getOwnPropertyDescriptors,Object.getOwnPropertySymbols,Object.prototype.hasOwnProperty,Object.prototype.propertyIsEnumerable,a.ZP.div`
  width: 23px;
  height: 15.8px;
  margin-right: 8px;
  background-size: cover;
  background-image: url(${Wt});
  background-position: ${({code:e})=>Vt[e]};
`,a.ZP.div`
  display: flex;
  align-items: center;
`,Object.defineProperty,Object.getOwnPropertySymbols,Object.prototype.hasOwnProperty,Object.prototype.propertyIsEnumerable,a.ZP.div`
  text-align: center;
  font-size: 10px;
`,a.ZP.input`
  display: none;
`,(0,a.ZP)((function(e){return i.createElement("svg",wr({"aria-hidden":"true","data-prefix":"fas","data-icon":"star",className:"star-solid_svg__svg-inline--fa star-solid_svg__fa-star star-solid_svg__fa-w-18",xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 576 512"},e),mr||(mr=i.createElement("path",{fill:"currentColor",d:"M259.3 17.8L194 150.2 47.9 171.5c-26.2 3.8-36.7 36.1-17.7 54.6l105.7 103-25 145.5c-4.5 26.3 23.2 46 46.4 33.7L288 439.6l130.7 68.7c23.2 12.2 50.9-7.4 46.4-33.7l-25-145.5 105.7-103c19-18.5 8.5-50.8-17.7-54.6L382 150.2 316.7 17.8c-11.7-23.6-45.6-23.9-57.4 0z"})))}))`
  color: ${({theme:e})=>e.colors.gold};
  width: 34px;
  height: 34px;
`,(0,a.ZP)((function(e){return i.createElement("svg",hr({"aria-hidden":"true","data-prefix":"far","data-icon":"star",className:"star-regular_svg__svg-inline--fa star-regular_svg__fa-star star-regular_svg__fa-w-18",xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 576 512"},e),pr||(pr=i.createElement("path",{fill:"currentColor",d:"M528.1 171.5L382 150.2 316.7 17.8c-11.7-23.6-45.6-23.9-57.4 0L194 150.2 47.9 171.5c-26.2 3.8-36.7 36.1-17.7 54.6l105.7 103-25 145.5c-4.5 26.3 23.2 46 46.4 33.7L288 439.6l130.7 68.7c23.2 12.2 50.9-7.4 46.4-33.7l-25-145.5 105.7-103c19-18.5 8.5-50.8-17.7-54.6zM388.6 312.3l23.7 138.4L288 385.4l-124.3 65.3 23.7-138.4-100.6-98 139-20.2 62.2-126 62.2 126 139 20.2-100.6 98z"})))}))`
  color: ${({theme:e})=>e.colors.gold};
  width: 34px;
  height: 34px;
`,a.ZP.div`
  cursor: pointer;
  display: flex;
  flex-direction: column;
  align-items: center;
  user-select: none;
`,a.ZP.div`
  height: 19px;
  margin: 8px;
  font-size: ${({theme:e})=>e.fontSize.medium};
  font-weight: bold;
  letter-spacing: 0.3px;
  color: ${({theme:e})=>e.colors.blue};
  cursor: pointer;

  .arrow {
    margin-left: 8px;
  }
`;var br=Object.defineProperty,fr=Object.getOwnPropertySymbols,Mr=Object.prototype.hasOwnProperty,yr=Object.prototype.propertyIsEnumerable,vr=(e,t,r)=>t in e?br(e,t,{enumerable:!0,configurable:!0,writable:!0,value:r}):e[t]=r;const xr=a.ZP.div`
  padding: 0 6px;
`,zr=a.ZP.span``,Nr=a.ZP.input`
  display: none;
`,jr=a.ZP.div`
  cursor: pointer;
  display: flex;
  align-items: center;
  user-select: none;

  & ${Nr} {
    position: absolute;
    width: 0;
    height: 0;
  }

  & ${zr} {
    flex: 0 0 auto;
    width: 36px;
    height: 24px;
    background-color: ${({theme:e})=>e.colors.lightGrayBackground};
    display: inline-block;
    position: relative;
    border-radius: 15px;
    transition: 150ms linear;
  }

  & ${zr}::after {
    content: "";
    top: 4px;
    left: 4px;
    border-radius: 8px;
    width: 16px;
    height: 16px;
    position: absolute;
    background-color: ${({theme:e})=>e.colors.white};
    transition: 150ms linear;
  }

  & ${Nr}:checked + ${zr} {
    background-color: ${({theme:e})=>e.colors.blue};
  }

  & ${Nr}:disabled + ${zr} {
    background-color: ${({theme:e})=>e.colors.lightGrayBackground};
    cursor: no-drop;
  }

  & ${Nr}:checked + ${zr}::after {
    left: 16px;
  }
`;a.ZP.div`
  display: inline-flex;
  align-items: center;
  justify-content: center;
  margin-left: ${({theme:e})=>e.padding.default};
  font-weight: 550;
`;const Dr=new Y.Z({en:{common:{xRay:"Xray - Amazon Product Research",xRayWalmart:"Xray — Walmart Product Research",profitabilityCalculator:"Profitability Calculator",inventoryLevels:"Inventory Levels",asinGrabber:"ASIN Grabber",reviewInsights:"Review Insights",switchTitle:"Switch to another account",search:"Search",extensionToggle:"Enable/disable Helium 10 Extension",myDashboard:"My Dashboard",extension:"Extension",beforeStarted:"Before you get started…",enablePermissions:"You’ll need to enable permissions for the Extension to work on Amazon, Alibaba.com, Walmart and other sites",answeredBy:"Answered By",get:"Get",getMoreAnswers:{one:"Get {number} More Answer",other:"Get {number} More Answers"},votes:"Votes",by:"By",selected:"Selected",xRayShortName:"Xray",nowOn:"Now on",reviewGrath:"Review Graph",getConnectedForInsights:"Get Connected for More Insights"},auth:{welcome:"Welcome to the<br/>Helium 10 Chrome Extension",logInText:"Please log in to launch the extension tools.",logIntoAccount:"Log into My Account",or:"OR",signUp:"Sign up for Free"},buttons:{save:"Save",open:"Open",cancel:"Cancel",enable:"Enable",clear:"Clear",apply:"Apply",browseAmazon:"Browse Amazon Marketplace",demandAnalyzeOnAmazon:"Analyze Product Demand on Amazon",extractReviews:"Extract Reviews",reloadPage:"Reload page",browseWalmart:"Browse on Walmart"},options:{title:"Helium 10 extension",version:"Version {version}",options:"Options",extendedInformation:"Display extended information on the search page",showScore:"Show Listing Health Score",showBsrGraph:"Show BSR graph",successScoreSetting:"Success score setting",multiFactorScore:"Multi factor success score",twoFactorScore:"Two factor success score",revenue:"Revenue",reviews:"Reviews",optionsSaved:"Options saved",runDiagnostics:"Run diagnostics",language:"Language",languages:{en:"English – EN",de:"Deutsch – DE",it:"Italiano – IT",es:"Español – ES"},headerTitle:"Helium 10 Extension Options"},filters:{grabberStars:"4 Stars And Above",sponsoredProducts:"Sponsored Products",boughtTogether:"Frequently Bought Together",selectDateRange:"Select the date range",booleanFilters:"Select filters",sort:"Sort",stars:"Select ratings",searchKeywords:"Enter a keyword",isVerified:"Only Verified Purchase",isHelpful:"Only Helpful",isImages:"Only With Images",isVideos:"Only With Videos",reviewsRating:{allStars:"All stars",star5:"5 stars only",star4:"4 stars only",star3:"3 stars only",star2:"2 stars only",star1:"1 star only",allPositive:"All positive",allCritical:"All critical"},sortOptions:{date:"Most recent",helpful:"Top reviews"},mediaOptions:{allFormats:"Text, image, video",mediaOnly:"Image and video reviews only"},reviewFormats:"All variations",allReviews:"All reviews",verifiedOnly:"Verified purchase only"},reviewInsight:{tooltips:{reviews:"This will save all reviews to a CSV file",questions:"This will save all questions to a CSV file",analysis:"This will save all keyword phrases below and the number of times they appear in reviews to a CSV file",phrase:"Use this to export this keyword and reviews where it appears to the CSV",variations:"This will save all variations to a CSV file"},header:{avgRating:"Average Rating",totalReviews:"Total Reviews Found",reviewsFound:"Reviews Found",export:"Export",questions:"Questions",maxReviewsLength:"No more than 5,000 reviews can be downloaded from Amazon",isOnlyVerifiedEnabled:"Only Verified",isOnlyHelpfulEnabled:"Only Helpful",isOnlyWithImagesEnabled:"Only With Images",isOnlyWithVideosEnabled:"Only With Videos",isStar1Enabled:"1 Star",isStar2Enabled:"2 Stars",isStar3Enabled:"3 Stars",isStar4Enabled:"4 Stars",isStar5Enabled:"5 Stars"},categories:{overview:"overview",reviews:"reviews",questions:"questions",analysis:"analysis",variations:"variations"},overview:{topPhrases:"Top Phrases",topReviews:"Top Helpful Reviews",noReviews:"No Reviews",setUpFilters:"Set up filters to run Review Insights",fountHelpful:"people found this review helpful"},reviews:{noResults:"No results",noResultsForFilter:"No results found for this filtering",loadMore:"Load 100 More",reviewsNotFound:"Reviews not found"},questions:{votes:"By votes",answerCount:"By answer count"},ratingTable:{rating:"Rating",count:"Rating Count",asinCount:"ASINs",seeAll:"See All",distribution:"Distribution",asinDistribution:"ASIN Distribution"},analysis:{by:"By",noPhrases:"No Phrases"},variations:{noVariations:"No variations found for this product",asin:"ASIN",variations:"Variations",reviewCount:"Review Count",reviewShare:"Review Share",rating:"Rating",noDescription:"No Descriptions"},navTitles:{overview:"Overview",allReviews:"All Reviews",allQuestions:"All Questions",reviewAnalysis:"Review Analysis",asinVariations:"Product Variations"},exportAccess:{reviews:"Starter Plan or higher is required in order to access reviews beyond 100.",variations:"Starter Plan or higher is required in order to access variations beyond 100.",questions:"Starter Plan or higher is required in order to access questions beyond 100.",analysis:"Starter Plan or higher is required in order to access analysis beyond 100."}},errors:{reloadRageText:"Reload the page to update the extension and activate Demand Analyzer.",request:"Some of your requests have been blocked by Amazon. Please try again later to get all of them.",limit:"Requests limit exceeded"},exports:{titles:{asin:"ASIN",description:"Description",reviewCount:"Review Count",reviewShare:"Review Share",date:"Date",author:"Author",verified:"Verified",helpful:"Helpful",title:"Title",body:"Body",rating:"Rating",images:"Images",videos:"Videos",url:"URL",variation:"Variation",style:"Style",question:"Question",answer:"Answer",votes:"Votes",countAnswers:"Total answers",allAnswersLink:"All answers",phrase:"Keyword Phrase",analysisCount:"Appeared"}},tag:{new:"New",beta:"Beta"},newsFeed:{whatsNew:"What's new"}},de:{common:{xRay:"Xray - Amazon Produktrecherche",xRayWalmart:"Xray — Walmart Produktrecherche",profitabilityCalculator:"Rentabilitätsrechner",inventoryLevels:"Inventory Levels",asinGrabber:"ASIN Grabber",reviewInsights:"Review Insights",switchTitle:"Zu einem anderen Konto wechseln",search:"Suchen",extensionToggle:"Erweiterung aktivieren/deaktivieren",myDashboard:"Mein Dashboard",extension:"Erweiterung",beforeStarted:"Bevor Sie loslegen …",enablePermissions:"Damit die Erweiterung auf einer Amazon-, Alibaba.com- oder Shopify-Website funktioniert, müssen Sie die Zugriffsrechte aktivieren.",answeredBy:"Beantwortet von",get:"Anzeige von",getMoreAnswers:{one:"{number} weitere Antwort anzeigen",other:"{number} weitere Antworten anzeigen"},votes:"Stimmen",by:"Von",selected:"Ausgewählt",xRayShortName:"Xray",nowOn:"Jetzt auf",reviewGrath:"Bewertungsgrafik",getConnectedForInsights:"Vernetzen Sie sich für mehr Einblicke"},auth:{welcome:"Willkommen bei der<br/>Helium 10 Chrome Erweiterung",logInText:"Bitte melden Sie sich an, um die Erweiterungs-Tools zu starten.",logIntoAccount:"Bei meinem Konto einloggen",or:"ODER",signUp:"Kostenlos registrieren"},buttons:{save:"Speichern",open:"Öffnen",cancel:"Abbrechen",enable:"Aktivieren",clear:"Löschen",apply:"Anwenden",browseAmazon:"Amazon Marketplace durchsuchen",demandAnalyzeOnAmazon:"Produktnachfrage analysieren",extractReviews:"Extrahieren",reloadPage:"Seite neu laden",browseWalmart:"Walmart durchsuchen"},options:{title:"Helium 10 Erweiterung",version:"Version {version}",options:"Optionen",extendedInformation:"Erweiterte Informationen auf der Suchseite anzeigen",showScore:"Listing Health Score anzeigen",showBsrGraph:"BSR-Graph anzeigen",successScoreSetting:"Erfolgsscore-Einstellung",multiFactorScore:"Multi-Faktoren-Erfolgsscore",twoFactorScore:"Zwei-Faktoren-Erfolgsscore",revenue:"Umsatz",reviews:"Bewertungen",optionsSaved:"Optionen gespeichert",runDiagnostics:"Diagnose ausführen",language:"Sprache",languages:{en:"English",de:"Deutsch",it:"Italiano",es:"Español"},headerTitle:"Helium 10 Erweiterung Optionen"},filters:{grabberStars:"4 Sterne und mehr",sponsoredProducts:"Gesponserte Produkte",boughtTogether:"Häufig zusammen gekauft",selectDateRange:"Bitte wählen Sie den Datumsbereich",booleanFilters:"Filter auswählen",sort:"Sortieren",stars:"Bewertungen",searchKeywords:"Geben Sie ein Keyword ein.",isVerified:"Nur verifizierter Kauf",isHelpful:"Nur hilfreich",isImages:"Nur mit Bildern",isVideos:"Nur mit Videos",reviewsRating:{allStars:"Alle Sterne",star5:"Nur 5 Sterne",star4:"Nur 4 Sterne",star3:"Nur 3 Sterne",star2:"Nur 2 Sterne",star1:"Nur 1 Stern",allPositive:"Alle positiven",allCritical:"Alle kritischen"},sortOptions:{date:"Neueste",helpful:"Top-Bewertungen"},mediaOptions:{allFormats:"Text, Bild, Video",mediaOnly:"Nur Bild- und Videobewertungen"},reviewFormats:"Alle Varianten",allReviews:"Alle Bewertungen",verifiedOnly:"Nur verifizierter Kauf"},reviewInsight:{tooltips:{reviews:"Dies speichert alle Bewertungen in einer CSV-Datei.",questions:"Dies speichert alle Fragen in einer CSV-Datei.",analysis:"Dies speichert alle unten aufgeführten Keyword-Wortgruppen und die Anzahl, wie oft sie in Bewertungen erscheinen, in einer CSV-Datei.",phrase:"Verwenden Sie diese Option, um dieses Keyword und Rezensionen dorthin zu exportieren, wo sie in der CSV-Datei erscheinen.",variations:"Dies speichert alle Varianten in einer CSV-Datei."},header:{avgRating:"Durchschnittliche Bewertung",totalReviews:"Gesamtzahl der gefundenen Bewertungen",reviewsFound:"Gefundene Bewertungen",export:"Export",questions:"Fragen",maxReviewsLength:"Es können nicht mehr als 5.000 Rezensionen von Amazon heruntergeladen werden.",isOnlyVerifiedEnabled:"Nur verifiziert",isOnlyHelpfulEnabled:"Nur hilfreich",isOnlyWithImagesEnabled:"Nur mit Bildern",isOnlyWithVideosEnabled:"Nur mit Videos",isStar1Enabled:"1 Stern",isStar2Enabled:"2 Sterne",isStar3Enabled:"3 Sterne",isStar4Enabled:"4 Sterne",isStar5Enabled:"5 Sterne"},categories:{overview:"Übersicht",reviews:"bewertungen",questions:"Fragen",analysis:"Analyse",variations:"Varianten"},overview:{topPhrases:"Top Wortgruppen",topReviews:"Top Hilfreiche Bewertungen",noReviews:"Keine Bewertungen",setUpFilters:"Richten Sie Filter ein, um Review Insights auszuführen.",fountHelpful:"Personen fanden diese Bewertung hilfreich"},reviews:{noResults:"Keine Ergebnisse",noResultsForFilter:"Keine Ergebnisse für diese Filterung gefunden",loadMore:"100 weitere laden",reviewsNotFound:"Bewertungen nicht gefunden"},questions:{votes:"Nach Stimmen",answerCount:"Nach Anzahl der Antworten"},ratingTable:{rating:"Bewertung",count:"Gesamtzahl der Verkäuferbewertungen",asinCount:"ASINs",seeAll:"Alle anzeigen",distribution:"Verteilung",asinDistribution:"ASIN-Verteilung"},analysis:{by:"Von",noPhrases:"Keine Wortgruppen"},variations:{noVariations:"Keine Varianten für dieses Produkt gefunden",asin:"ASIN",variations:"Varianten",reviewCount:"Bewertungsanzahl",reviewShare:"Bewertungs-Verteilung",rating:"Bewertung",noDescription:"Keine Beschreibungen"},navTitles:{overview:"Übersicht",allReviews:"Alle Bewertungen",allQuestions:"Alle Fragen",reviewAnalysis:"Bewertungsanalyse",asinVariations:"Produktvarianten"},exportAccess:{reviews:"Für den Zugriff auf mehr als 100 Bewertungen ist Starter Plan oder höher erforderlich.",variations:"Für den Zugriff auf mehr als 100 Varianten ist Starter Plan oder höher erforderlich.",questions:"Für den Zugriff auf mehr als 100 Fragen ist Starter Plan oder höher erforderlich.",analysis:"Für den Zugriff auf mehr als 100 Analysen ist Starter Plan oder höher erforderlich."}},errors:{reloadRageText:"Laden Sie die Seite neu, um die Erweiterung zu aktualisieren und den Demand Analyzer zu aktivieren.",request:"Einige Ihrer Anfragen wurden von Amazon blockiert. Bitte versuchen Sie es später erneut, um alle zu erhalten.",limit:"Anfragelimit überschritten"},exports:{titles:{asin:"ASIN",description:"Beschreibung",reviewCount:"Anzahl der Bewertungen",reviewShare:"Bewertungs-Verteilung",date:"Datum",author:"Autor",verified:"Verifiziert",helpful:"Hilfreich",title:"Titel",body:"Textkörper",rating:"Bewertung",images:"Bilder",videos:"Videos",url:"URL",variation:"Variante",style:"Stil",question:"Frage",answer:"Antwort",votes:"Stimmen",countAnswers:"Antworten insgesamt",allAnswersLink:"Alle Antworten",phrase:"Keyword-Begriff",analysisCount:"Erscheint"}},tag:{new:"Neu",beta:"Beta"},newsFeed:{whatsNew:"Was gibt es Neues?"}},es:{common:{xRay:"Xray – Búsqueda de Amazon",xRayWalmart:"Xray — Búsqueda de productos",profitabilityCalculator:"Calculador de rentabilidad",inventoryLevels:"Inventory Levels",asinGrabber:"ASIN Grabber",reviewInsights:"Review Insights",switchTitle:"Cambiar a otra cuenta",search:"Búsqueda",extensionToggle:"Habilitar/Inhabilitar extensión",myDashboard:"Mi tablero",extension:"Extensión",beforeStarted:"Antes de empezar…",enablePermissions:" Deberás habilitar permisos para que la extensión funcione en el sitio de Amazon, Alibaba.com o Shopify",answeredBy:"Respondido por",get:"Obtener",getMoreAnswers:{one:"Obtener {number} Respuesta Más",other:"Obtener {number} Respuestas Más"},votes:"Votos",by:"Por",selected:"Seleccionado",xRayShortName:"Xray",nowOn:"Ahora en",reviewGrath:"Gráfico de reseñas",getConnectedForInsights:"Conéctese para obtener más información"},auth:{welcome:"Bienvenido a la <br/> Extensión Helium 10 de Chrome",logInText:"Por favor, inicia sesión para usar las herramientas de la extensión.",logIntoAccount:"Iniciar sesión en Mi Cuenta",or:"O",signUp:"Suscríbete gratis"},buttons:{save:"Guardar",open:"Abrir",cancel:"Cancelar",enable:"Habilitar",clear:"Limpiar",apply:"Aplicar",browseAmazon:"Navegar por Amazon Marketplace",demandAnalyzeOnAmazon:"Analizar la demanda en Amazon",extractReviews:"Obtener reseñas",reloadPage:"Recargar página",browseWalmart:"Navegar en Walmart"},options:{title:"Extensión Helium 10",version:"Versión {version}",options:"Opciones",extendedInformation:"Mostrar información extendida en la página de búsqueda",showScore:"Mostrar puntuación de estado del listing",showBsrGraph:"Motrar gráfico BSR",successScoreSetting:"Configuración de la puntuación de éxito",multiFactorScore:"Puntuación de éxito multifactor",twoFactorScore:"Puntuación de éxito de dos factores",revenue:"Ingreso",reviews:"Reseñas",optionsSaved:"Opciones guardadas",runDiagnostics:"Ejecutar diagnósticos",language:"Idioma",languages:{en:"English",de:"Deutsch",it:"Italiano",es:"Español"},headerTitle:"Opciones de Extensión Helium 10"},filters:{grabberStars:"4 estrellas y más",sponsoredProducts:"Productos auspiciados",boughtTogether:"Frecuentemente comprados juntos",selectDateRange:"Por favor, selecciona rango de fecha",booleanFilters:"Seleccionar filtros",sort:"Ordenar",stars:"Selecciona calificaciones",searchKeywords:"Ingresa una palabra clave",isVerified:"Solo compra verificada",isHelpful:"Solo útil",isImages:"Solo con imágenes ",isVideos:"Solo con videos",reviewsRating:{allStars:"Todas las estrellas",star5:"Solo 5 estrellas",star4:"Solo 4 estrellas",star3:"Solo 3 estrellas",star2:"Solo 2 estrellas",star1:"Solo 1 estrella",allPositive:"Todos los comentarios positivos",allCritical:"Todas las críticas"},sortOptions:{date:"Más reciente",helpful:"Reseñas principales"},mediaOptions:{allFormats:"Texto, imagen, video",mediaOnly:"Solo reseñas de imagen y vídeo"},reviewFormats:"Todas las variaciones",allReviews:"Todas las reseñas",verifiedOnly:"Solo compra verificada"},reviewInsight:{tooltips:{reviews:"Esto guardará todas las reseñas en un archivo CSV",questions:"Esto guardará todas las preguntas en un archivo CSV",analysis:"Esto guardará en un archivo CSV todas las frases claves de abajo y la cantidad de veces que aparecen en las reseñas",phrase:"Usa esto para exportar estas palabras claves y reseñas donde aparezcan en el archivo CSV",variations:"Esto guardará todas las variaciones en un archivo CSV"},header:{avgRating:"Calificación promedio",totalReviews:"Total de reseñas encontradas",reviewsFound:"Reseñas encontradas",export:"Exportar",questions:"Preguntas",maxReviewsLength:"No se pueden descargar más de 5000 reseñas de Amazon",isOnlyVerifiedEnabled:"Verificados solamente",isOnlyHelpfulEnabled:"Solo útil",isOnlyWithImagesEnabled:"Solo con imágenes ",isOnlyWithVideosEnabled:"Solo con videos",isStar1Enabled:"1 estrella",isStar2Enabled:"2 estrellas",isStar3Enabled:"3 estrellas",isStar4Enabled:"4 estrellas",isStar5Enabled:"5 estrellas"},categories:{overview:"vista general",reviews:"reseñas",questions:"preguntas",analysis:"análisis",variations:"variaciones"},overview:{topPhrases:"Frases principales",topReviews:"Principales reseñas útiles",noReviews:"Sin reseñas",setUpFilters:"Configurar filtros para ejecutar la revisión de reseñas",fountHelpful:"otras personas encontraron esta reseña muy útil"},reviews:{noResults:"No hay resultados",noResultsForFilter:"No se encontraron resultados para este filtro",loadMore:"Cargar 100 más",reviewsNotFound:"Reseñas no encontradas"},questions:{votes:"Por votos",answerCount:"Por número de respuestas"},ratingTable:{rating:"Clasificación",count:"Cuenta de clasificación",asinCount:"ASINs",seeAll:"Ver todo",distribution:"Distribución",asinDistribution:"Distribución de ASINs"},analysis:{by:"Por",noPhrases:"Sin frases"},variations:{noVariations:"No se encontraron variaciones para este producto",asin:"ASIN",variations:"Variaciones",reviewCount:"Cuenta de reseñas",reviewShare:"Cuota de reseñas",rating:"Clasificación",noDescription:"No hay descripciones"},navTitles:{overview:"Vista general",allReviews:"Todas las reseñas",allQuestions:"Todas las preguntas",reviewAnalysis:"Análisis de reseñas",asinVariations:"Variaciones de producto"},exportAccess:{reviews:"Se necesita el Plan Iniciante o superior para acceder a más de 100 reseñas.",variations:"Se necesita el Plan Iniciante o superior para acceder a más de 100 variaciones.",questions:"Se necesita el Plan Iniciante o superior para acceder a más de 100 preguntas.",analysis:"Se necesita el Plan Iniciante para acceder a más de 100 análisis."}},errors:{reloadRageText:"Recargar la página para actualizar la extensión y activar Demand Analyzer.",request:"Amazon ha bloqueado algunas de tus solicitudes. Vuelve a intentarlo más tarde para obtenerlas todas.",limit:"Se superó el límite de solicitudes"},exports:{titles:{asin:"ASIN",description:"Descripción",reviewCount:"Recuento de reseñas",reviewShare:"Cuota de reseñas",date:"Fecha",author:"Autor",verified:"Verificado",helpful:"Útil",title:"Título",body:"Cuerpo",rating:"Clasificación",images:"Imágenes",videos:"Vídeos",url:"URL",variation:"Variación",style:"Estilo",question:"Pregunta",answer:"Respuesta",votes:"Votos",countAnswers:"Total de respuestas",allAnswersLink:"Todas las respuestas",phrase:"Frase clave",analysisCount:"Apareció"}},tag:{new:"Nuevo",beta:"Beta"},newsFeed:{whatsNew:"Qué hay de nuevo"}},it:{common:{xRay:"Xray - Ricerca prodotti Amazon",xRayWalmart:"Xray — Ricerca dei prodotti",profitabilityCalculator:"Calcolatore di redditività",inventoryLevels:"Inventory Levels",asinGrabber:"ASIN Grabber",reviewInsights:"Review Insights",switchTitle:"Passa ad un altro account",search:"Cerca",extensionToggle:"Abilita / disabilita l'estensione",myDashboard:"Dashboard",extension:"Estensione",beforeStarted:"Prima di iniziare...",enablePermissions:"Dovrai concedere le autorizzazioni per poter utilizzare l'estensione su Amazon, Alibaba.com o Shopify",answeredBy:"Risposta da",get:"Ottieni",getMoreAnswers:{one:"Ottieni {number} altra risposta",other:"Ottieni altre {number} risposte"},votes:"Voti",by:"Da",selected:"Selezionato",xRayShortName:"Xray",nowOn:"Ora su",reviewGrath:"Grafico di recensioni",getConnectedForInsights:"Connettiti per ulteriori informazioni"},auth:{welcome:"Benvenuto nell'estensione Chrome di <br/>Helium 10",logInText:"Accedi per avviare gli strumenti dell'estensione.",logIntoAccount:"Accedi al mio account",or:"O",signUp:"Iscriviti gratuitamente"},buttons:{save:"Salva",open:"Apri",cancel:"Cancella",enable:"Abilita",clear:"Elimina",apply:"Applica",browseAmazon:"Sfoglia il marketplace di Amazon",demandAnalyzeOnAmazon:"Analizza la domanda su Amazon",extractReviews:"Estrai recensioni",reloadPage:"Ricarica la pagina",browseWalmart:"Sfoglia su Walmart"},options:{title:"Estensione Helium 10",version:"Versione {version}",options:"Opzioni",extendedInformation:"Visualizza informazioni estese nella pagina di ricerca",showScore:"Mostra l'Healt Score del listing",showBsrGraph:"Mostra grafico BSR",successScoreSetting:"Impostazione del success score",multiFactorScore:"Success score multifattoriale",twoFactorScore:"Success score a due fattori",revenue:"Fatturato",reviews:"Recensioni",optionsSaved:"Impostazioni salvate",runDiagnostics:"Esegui diagnostica",language:"Lingua",languages:{en:"English",de:"Deutsch",it:"Italiano",es:"Español"},headerTitle:"Opzioni di Estensione Helium 10"},filters:{grabberStars:"4 stelle e oltre",sponsoredProducts:"Prodotti sponsorizzati",boughtTogether:"Spesso acquistati insieme",selectDateRange:"Seleziona l'intervallo di date",booleanFilters:"Seleziona filtri",sort:"Ordina",stars:"Seleziona la valutazione",searchKeywords:"Inserisci una parola chiave",isVerified:"Solo acquisto verificato",isHelpful:"Solo utile",isImages:"Solo con immagini",isVideos:"Solo con video",reviewsRating:{allStars:"Tutte",star5:"Solo 5 stelle",star4:"Solo 4 stelle",star3:"Solo 3 stelle",star2:"Solo 2 stelle",star1:"Solo 1 stella",allPositive:"Solo positive",allCritical:"Solo critiche"},sortOptions:{date:"Più recenti",helpful:"Recensioni migliori"},mediaOptions:{allFormats:"Testo, immagine, video",mediaOnly:"Solo recensioni con immagini e video"},reviewFormats:"Tutte le varianti",allReviews:"Tutte le recensioni",verifiedOnly:"Solo acquisto verificato"},reviewInsight:{tooltips:{reviews:"Salva tutte le recensioni in un file CSV",questions:"Salva tutte le domande in un file CSV",analysis:"Salva tutte le keyword e il numero di occorrenze nelle recensioni in un file CSV",phrase:"Esporta nel file CSV la keyword e le recensioni in cui è usata",variations:"Salva tutte le varianti in un file CSV"},header:{avgRating:"Valutazione media",totalReviews:"Tutte le recensioni trovate",reviewsFound:"Recensioni trovate",export:"Esporta",questions:"Domande",maxReviewsLength:"Non è possibile scaricare più di 5.000 recensioni da Amazon",isOnlyVerifiedEnabled:"Solo verificate",isOnlyHelpfulEnabled:"Solo utile",isOnlyWithImagesEnabled:"Solo con immagini",isOnlyWithVideosEnabled:"Solo con video",isStar1Enabled:"1 stella",isStar2Enabled:"2 stelle",isStar3Enabled:"3 stelle",isStar4Enabled:"4 stelle",isStar5Enabled:"5 stelle"},categories:{overview:"panoramica",reviews:"recensioni",questions:"domande",analysis:"analisi",variations:"varianti"},overview:{topPhrases:"Keyword principali",topReviews:"Recensioni utili migliori",noReviews:"Nessuna recensione",setUpFilters:"Imposta i filtri per eseguire Review Insights",fountHelpful:"persone hanno trovato questa recensione utile"},reviews:{noResults:"Nessun risultato",noResultsForFilter:"Nessun risultato trovato con questi filtri",loadMore:"Carica altre 100",reviewsNotFound:"Recensioni non trovate"},questions:{votes:"Per voti",answerCount:"Per numero di risposte"},ratingTable:{rating:"Valutazioni",count:"Numero di valutazioni",asinCount:"ASIN",seeAll:"Visualizza",distribution:"Distribuzione",asinDistribution:"Distribuzione dell'ASIN"},analysis:{by:"Da",noPhrases:"Nessun risultato"},variations:{noVariations:"Nessuna variante trovata per questo prodotto",asin:"ASIN",variations:"Varianti",reviewCount:"Numero di recensioni",reviewShare:"Condivisioni",rating:"Valutazioni",noDescription:"Nessuna descrizione"},navTitles:{overview:"Panoramica",allReviews:"Tutte le recensioni",allQuestions:"Tutte le domande",reviewAnalysis:"Analisi delle recensioni",asinVariations:"Varianti del prodotto"},exportAccess:{reviews:"Per visualizzare più di 100 recensioni è necessario uno Starter Plan o superiore.",variations:"Per visualizzare più di 100 varianti è necessario uno Starter Plan o superiore.",questions:"Per visualizzare più di 100 domande è necessario uno Starter Plan o superiore.",analysis:"Per visualizzare più di 100 analisi è necessario uno Starter Plan o superiore."}},errors:{reloadRageText:"Ricarica la pagina per aggiornare l'estensione e attivare Demand Analyzer.",request:"Alcune delle tue richieste sono state bloccate da Amazon. Riprova più tardi per ottenerle tutte.",limit:"Limite di richieste superato"},exports:{titles:{asin:"ASIN",description:"Descrizione",reviewCount:"Numero di recensioni",reviewShare:"Condivisioni",date:"Data",author:"Autore",verified:"Verificato",helpful:"Utile",title:"Titolo",body:"Corpo",rating:"Valutazioni",images:"Immagini",videos:"Video",url:"URL",variation:"Variante",style:"Stile",question:"Domanda",answer:"Risposta",votes:"Voti",countAnswers:"Risposte totali",allAnswersLink:"Tutte le risposte",phrase:"Keyword",analysisCount:"Occorrenze"}},tag:{new:"Nuovo",beta:"Beta"},newsFeed:{whatsNew:"Cosa c'è di nuovo"}}},{logsEnabled:!1}),Or=({children:e})=>i.createElement(q.DO,{strings:Dr,TranslateContext:Ar},e),Ar=(0,i.createContext)(null),Ir=()=>i.createElement(Cr,null,i.createElement(_e,{type:"logoModalDark"})),Cr=a.ZP.div`
  padding: 48px 0;
`;var Sr=Object.defineProperty,Pr=Object.getOwnPropertySymbols,Lr=Object.prototype.hasOwnProperty,Tr=Object.prototype.propertyIsEnumerable,kr=(e,t,r)=>t in e?Sr(e,t,{enumerable:!0,configurable:!0,writable:!0,value:r}):e[t]=r,Er=(e,t)=>{for(var r in t||(t={}))Lr.call(t,r)&&kr(e,r,t[r]);if(Pr)for(var r of Pr(t))Tr.call(t,r)&&kr(e,r,t[r]);return e};const Zr=(e,t,r=!1)=>"GET"!==e&&t?{body:r?t:JSON.stringify(t)}:{},Br=(e,t,r)=>"GET"===e&&r?rt.stringifyUrl({url:t,query:r}):t,Gr=e=>{return t=void 0,r=[e],i=function*({url:e,params:t,method:r="GET",headers:i={},type:a="background-request",form:n,rawParams:o}){return new Promise(((s,l)=>{const c={url:Br(r,e,t),params:o||Er({method:r,headers:i,form:n,credentials:"same-origin"},Zr(r,t,n))};chrome.runtime.sendMessage(Er({type:a},c),(e=>{((e,t,r)=>{var i,a;200===(null==e?void 0:e.status)?(a=e.data,s(a)):(i={data:null==e?void 0:e.data,status:null==e?void 0:e.status},l(i))})(e)}))}))},new Promise(((e,a)=>{var n=e=>{try{s(i.next(e))}catch(e){a(e)}},o=e=>{try{s(i.throw(e))}catch(e){a(e)}},s=t=>t.done?e(t.value):Promise.resolve(t.value).then(n,o);s((i=i.apply(t,r)).next())}));var t,r,i};r(8377);var Rr=Object.defineProperty,Fr=Object.getOwnPropertySymbols,Ur=Object.prototype.hasOwnProperty,Vr=Object.prototype.propertyIsEnumerable,Wr=(e,t,r)=>t in e?Rr(e,t,{enumerable:!0,configurable:!0,writable:!0,value:r}):e[t]=r,qr=(e,t)=>{for(var r in t||(t={}))Ur.call(t,r)&&Wr(e,r,t[r]);if(Fr)for(var r of Fr(t))Vr.call(t,r)&&Wr(e,r,t[r]);return e};const Yr={feedback:"Extension Feedback",connectMWSToken:"Extension MWS Button Clicked",widgetButtonClicked:"Extension Widget Button Clicked",languageSwitched:"Extension Language Switched"},Qr=()=>{const[e,t]=(0,i.useState)(null);return(0,i.useEffect)((()=>{var e,r;null==(r=null==(e=null==window?void 0:window.chrome)?void 0:e.storage)||r.sync.get("settings",(({settings:e})=>{t((null==e?void 0:e.language)||"en")}))}),[]),{sendSegmentEvent:(0,i.useCallback)((t=>{return void 0,r=[t],i=function*({name:t,properties:r}){yield Gr({method:"POST",headers:{"Content-Type":"application/json"},url:"https://helium10.groupbuyamz.com/api/v1/customers/segment-track",params:{name:t,properties:qr({language:e},r)}})},new Promise(((e,t)=>{var a=e=>{try{o(i.next(e))}catch(e){t(e)}},n=e=>{try{o(i.throw(e))}catch(e){t(e)}},o=t=>t.done?e(t.value):Promise.resolve(t.value).then(a,n);o((i=i.apply(undefined,r)).next())}));var r,i}),[e]),segmentEventType:Yr}},Hr=e=>{const t=new Blob([e],{type:"text/plain;charset=utf-8"}),r=document.createElement("a");r.href=URL.createObjectURL(t),r.style.visibility="hidden",r.download=`helium10-report${(new Date).toISOString().split(".")[0].replace("T","_")}.txt`,document.body.appendChild(r),r.click(),document.body.removeChild(r)},Xr=()=>{var e,t;const r="-";let i="";(null==window?void 0:window.screen)&&(i+=window.screen.width+" x "+window.screen.height);const a=navigator.userAgent;let n,o,s,l=navigator.appName,c=""+parseFloat(navigator.appVersion),d=parseInt(navigator.appVersion,10);-1!==(o=a.indexOf("Chrome"))?(l="Chrome",c=a.substring(o+7)):(n=a.lastIndexOf(" ")+1)<(o=a.lastIndexOf("/"))&&(l=a.substring(n,o),c=a.substring(o+1),l.toLowerCase()===l.toUpperCase()&&(l=navigator.appName)),-1!==(s=c.indexOf(";"))&&(c=c.substring(0,s)),-1!==(s=c.indexOf(" "))&&(c=c.substring(0,s)),-1!==(s=c.indexOf(")"))&&(c=c.substring(0,s)),d=parseInt(""+c,10),isNaN(d)&&(c=""+parseFloat(navigator.appVersion),d=parseInt(navigator.appVersion,10));let u=navigator.cookieEnabled;void 0!==navigator.cookieEnabled||u||(document.cookie="testcookie",u=-1!==document.cookie.indexOf("testcookie"));let g=r;const p=[{s:"Windows 10",r:/(Windows 10.0|Windows NT 10.0)/},{s:"Windows 8.1",r:/(Windows 8.1|Windows NT 6.3)/},{s:"Windows 8",r:/(Windows 8|Windows NT 6.2)/},{s:"Windows 7",r:/(Windows 7|Windows NT 6.1)/},{s:"Windows Vista",r:/Windows NT 6.0/},{s:"Windows Server 2003",r:/Windows NT 5.2/},{s:"Windows XP",r:/(Windows NT 5.1|Windows XP)/},{s:"Windows 2000",r:/(Windows NT 5.0|Windows 2000)/},{s:"Android",r:/Android/},{s:"Open BSD",r:/OpenBSD/},{s:"Sun OS",r:/SunOS/},{s:"Linux",r:/(Linux|X11)/},{s:"iOS",r:/(iPhone|iPad|iPod)/},{s:"Mac OS X",r:/Mac OS X/},{s:"Mac OS",r:/(MacPPC|MacIntel|Mac_PowerPC|Macintosh)/},{s:"QNX",r:/QNX/},{s:"UNIX",r:/UNIX/},{s:"BeOS",r:/BeOS/},{s:"OS/2",r:/OS\/2/}];for(const e in p){const t=p[e];if(t.r.test(a)){g=t.s;break}}let m=r;return/Windows/.test(g)&&(m=(null==(e=/Windows (.*)/.exec(g))?void 0:e[1])||r,g="Windows"),"Mac OS X"===g&&(m=(null==(t=/Mac OS X (10[._\d]+)/.exec(a))?void 0:t[1])||r),{screen:i,browser:l,browserVersion:c,browserMajorVersion:d,os:g,osVersion:m,cookies:u,extensionVersion:chrome.runtime.getManifest().version_name}},Kr={extendedInformation:!0,listingHealthScore:!0,bsrGraph:!0,factor:"two",score:{revenue:5e3,reviews:75},language:"en"};var Jr=Object.defineProperty,$r=Object.defineProperties,_r=Object.getOwnPropertyDescriptors,ei=Object.getOwnPropertySymbols,ti=Object.prototype.hasOwnProperty,ri=Object.prototype.propertyIsEnumerable,ii=(e,t,r)=>t in e?Jr(e,t,{enumerable:!0,configurable:!0,writable:!0,value:r}):e[t]=r,ai=(e,t)=>{for(var r in t||(t={}))ti.call(t,r)&&ii(e,r,t[r]);if(ei)for(var r of ei(t))ri.call(t,r)&&ii(e,r,t[r]);return e},ni=(e,t)=>$r(e,_r(t));const oi=()=>{var e;const{t,changeLanguage:r}=(0,i.useContext)(Ar),{sendSegmentEvent:a,segmentEventType:n}=Qr(),[o,s]=(0,i.useState)({content:Kr,status:"init"}),[l,c]=(0,i.useState)(!1),d=(0,i.useMemo)((()=>Dr.getAvailableLanguages().map((e=>({value:e,label:t(`options.languages.${e}`)})))),[t]);(0,i.useEffect)((()=>{chrome.storage.sync.get("settings",(e=>{e.settings?s({content:e.settings,status:"loaded"}):s((e=>ni(ai({},e),{status:"loaded"}))),document.title=t("options.headerTitle")}))}),[]);const u=(0,i.useCallback)((e=>{s((t=>ni(ai({},t),{content:ai(ai({},t.content),e)})))}),[]),g=(0,i.useCallback)((()=>{return void 0,null,e=function*(){yield(()=>{return e=function*(){const e=Xr();let t=`Extension version: ${e.extensionVersion}\n\nOS: ${e.os} ${e.osVersion}\nScreen Size: ${e.screen}\nBrowser: ${e.browser} ${e.browserMajorVersion} (${e.browserVersion})\nCookies: ${e.cookies}\nFull User Agent: ${navigator.userAgent}\n\n`;const r=yield Gr({url:"https://helium10.groupbuyamz.com/extension/diagnostic"});t+="Response data:\n",void 0===r.error?(t+=`Authorized: ${r.authorized}\n`,t+=`Headers: ${JSON.stringify(r.headers)}`):t+=`Error: ${JSON.stringify(r.error)}`,Hr(t)},new Promise(((t,r)=>{var i=t=>{try{n(e.next(t))}catch(e){r(e)}},a=t=>{try{n(e.throw(t))}catch(e){r(e)}},n=e=>e.done?t(e.value):Promise.resolve(e.value).then(i,a);n((e=e.apply(void 0,null)).next())}));var e})()},new Promise(((t,r)=>{var i=t=>{try{n(e.next(t))}catch(e){r(e)}},a=t=>{try{n(e.throw(t))}catch(e){r(e)}},n=e=>e.done?t(e.value):Promise.resolve(e.value).then(i,a);n((e=e.apply(undefined,null)).next())}));var e}),[]),p=(0,i.useCallback)((()=>{c(!0),setTimeout((()=>c(!1)),3e3),chrome.storage.sync.set({settings:o.content}),chrome.runtime.sendMessage({type:"reload-tabs"}),r(o.content.language),a({name:n.languageSwitched,properties:{language:o.content.language}}).then(),document.title=t("options.headerTitle")}),[r,n.languageSwitched,a,o.content,t]),m=(0,i.useCallback)((e=>{s((t=>ni(ai({},t),{content:ni(ai({},t.content),{factor:e})})))}),[]),h=(0,i.useCallback)((e=>t=>{(""===t.target.value||/^[0-9\b]+$/.test(t.target.value))&&s((r=>ni(ai({},r),{content:ni(ai({},r.content),{score:ni(ai({},r.content.score),{[e]:t.target.value})})})))}),[]);return"loaded"===o.status?i.createElement(si,null,i.createElement(li,null,t("options.title")),i.createElement(ui,null,t("options.version",{version:(null==(e=chrome.runtime.getManifest().version_name)?void 0:e.toString())||""})),i.createElement(ci,null,t("options.options")),i.createElement(gi,null,i.createElement(pi,{checked:o.content.extendedInformation,onChange:e=>{u({extendedInformation:e})}},i.createElement(mi,null,t("options.extendedInformation"))),i.createElement(pi,{checked:o.content.listingHealthScore,onChange:e=>{u({listingHealthScore:e})}},i.createElement(mi,null,t("options.showScore"))),i.createElement(pi,{checked:o.content.bsrGraph,onChange:e=>{u({bsrGraph:e})}},i.createElement(mi,null,t("options.showBsrGraph")))),i.createElement(ci,null,t("options.successScoreSetting")),i.createElement(gi,null,i.createElement(Zt,{onChange:m},i.createElement(yi,{name:"factor",value:"multi",checked:"multi"===o.content.factor},i.createElement(mi,null,t("options.multiFactorScore"))),i.createElement(yi,{name:"factor",value:"two",checked:"two"===o.content.factor},i.createElement(mi,null,t("options.twoFactorScore")))),i.createElement(bi,null,i.createElement(fi,null,i.createElement(di,null,t("options.revenue")),i.createElement(Mi,{onChange:h("revenue"),disabled:"multi"===o.content.factor,value:o.content.score.revenue,type:"text"})),i.createElement(fi,null,i.createElement(di,null,t("options.reviews")),i.createElement(Mi,{onChange:h("reviews"),disabled:"multi"===o.content.factor,value:o.content.score.reviews,type:"text"})))),i.createElement(ci,null,t("options.language")),i.createElement(gi,null,i.createElement(vi,null,i.createElement(cr,{options:d,defaultValue:o.content.language||"en",onOptionChange:e=>{e&&e.value!==o.content.language&&u({language:e.value})}}))),i.createElement(hi,null,i.createElement(xi,null,i.createElement(wi,{onClick:p},t("buttons.save")),i.createElement(zi,{visible:l},t("options.optionsSaved"))),i.createElement(wi,{colorType:"light-blue",onClick:g},t("options.runDiagnostics")))):i.createElement(i.Fragment,null)},si=a.ZP.div`
  padding: 48px;
  border-radius: 8px;
  box-shadow: 0 1px 20px 4px rgb(56 56 56 / 10%);
`,li=(0,a.ZP)(M)`
  font-weight: normal;
  color: ${({theme:e})=>e.colors.darkGrey};
`,ci=(0,a.ZP)(y)`
  font-weight: normal;
  color: ${({theme:e})=>e.colors.darkGrey};
`,di=(0,a.ZP)(z)`
  color: ${({theme:e})=>e.colors.lightOpacityGrey};
  font-weight: normal;
`,ui=(0,a.ZP)(di)`
  margin-bottom: 24px;
  display: block;
`,gi=a.ZP.div`
  margin: 12px 0 24px 0;
`,pi=(0,a.ZP)((e=>{var t=e,{disabled:r,checked:a,onChange:n,children:o,text:s}=t,l=((e,t)=>{var r={};for(var i in e)Mr.call(e,i)&&t.indexOf(i)<0&&(r[i]=e[i]);if(null!=e&&fr)for(var i of fr(e))t.indexOf(i)<0&&yr.call(e,i)&&(r[i]=e[i]);return r})(t,["disabled","checked","onChange","children","text"]);const c=(0,i.useCallback)((()=>{n(!a)}),[a,n]);return i.createElement(jr,((e,t)=>{for(var r in t||(t={}))Mr.call(t,r)&&vr(e,r,t[r]);if(fr)for(var r of fr(t))yr.call(t,r)&&vr(e,r,t[r]);return e})({onClick:c},l),i.createElement(Nr,{type:"checkbox",disabled:r,checked:a,onChange:()=>{}}),i.createElement(zr,null),o||(s?i.createElement(xr,null,s):null))}))`
  margin-bottom: 8px;
`,mi=(0,a.ZP)(x)`
  padding-left: 4px;
`,hi=a.ZP.div`
  display: flex;
  margin-top: 48px;
  justify-content: space-between;
`,wi=(0,a.ZP)((e=>{var t,r=e,{colorType:a="blue",type:n,size:o="middle",disabled:s,onClick:l,children:c,form:d}=r,u=((e,t)=>{var r={};for(var i in e)xe.call(e,i)&&t.indexOf(i)<0&&(r[i]=e[i]);if(null!=e&&ve)for(var i of ve(e))t.indexOf(i)<0&&ze.call(e,i)&&(r[i]=e[i]);return r})(r,["colorType","type","size","disabled","onClick","children","form"]);return i.createElement(Oe,(t=((e,t)=>{for(var r in t||(t={}))xe.call(t,r)&&Ne(e,r,t[r]);if(ve)for(var r of ve(t))ze.call(t,r)&&Ne(e,r,t[r]);return e})({},u),Me(t,ye({form:d,type:n,colorSchema:je[a],sizeSchema:De[o],disabled:s,onClick:l}))),c)}))`
  min-width: 140px;
  text-align: center;
  display: flex;
  justify-content: center;
`,bi=a.ZP.div`
  padding-left: 24px;
  display: flex;
`,fi=a.ZP.div`
  padding-right: 8px;
  display: flex;
  flex-direction: column;
  width: 100px;
`,Mi=(0,a.ZP)((e=>{var t,r,a=e,{type:n="text",expanded:o,label:s,textAlign:l="left",onChange:c,controlSize:d="small",register:u}=a,g=((e,t)=>{var r={};for(var i in e)k.call(e,i)&&t.indexOf(i)<0&&(r[i]=e[i]);if(null!=e&&T)for(var i of T(e))t.indexOf(i)<0&&E.call(e,i)&&(r[i]=e[i]);return r})(a,["type","expanded","label","textAlign","onChange","controlSize","register"]);return i.createElement(F,{expanded:o},s&&i.createElement(R,null,s),i.createElement(G,(t=((e,t)=>{for(var r in t||(t={}))k.call(t,r)&&Z(e,r,t[r]);if(T)for(var r of T(t))E.call(t,r)&&Z(e,r,t[r]);return e})({name:g.name,type:n},u?{ref:u}:{onChange:e=>{!g.disabled&&(null==c||c(e))}}),r={sizeSchema:d,textAlign:l,value:g.value,placeholder:g.placeholder,disabled:g.disabled,min:g.min,max:g.max,step:g.step},P(t,L(r)))))}))``,yi=(0,a.ZP)((e=>{var t,r=e,{children:a,className:n,innerRef:o}=r,s=((e,t)=>{var r={};for(var i in e)Tt.call(e,i)&&t.indexOf(i)<0&&(r[i]=e[i]);if(null!=e&&Lt)for(var i of Lt(e))t.indexOf(i)<0&&kt.call(e,i)&&(r[i]=e[i]);return r})(r,["children","className","innerRef"]);return i.createElement(Gt,{className:n},i.createElement(Ft,(t=((e,t)=>{for(var r in t||(t={}))Tt.call(t,r)&&Et(e,r,t[r]);if(Lt)for(var r of Lt(t))kt.call(t,r)&&Et(e,r,t[r]);return e})({},s),St(t,Pt({type:"radio",ref:o})))),i.createElement(Rt,null),a&&i.createElement(Ut,null,a))}))`
  margin-bottom: 8px;
`,vi=(0,a.ZP)(gi)`
  width: 232px;
`,xi=a.ZP.div`
  display: flex;
  align-items: center;
`,zi=(0,a.ZP)(x)`
  margin-left: 16px;
  color: ${({theme:e})=>e.colors.green};
  opacity: ${({visible:e})=>e?1:0};
  transition: opacity 0.2s ease-in-out;
`,Ni=()=>i.createElement(ji,null,i.createElement(Ir,null),i.createElement(oi,null)),ji=a.ZP.div`
  width: 100%;
  padding: 0 16px;
  margin: 0 auto;

  @media (min-width: 576px) {
    max-width: 576px;
    padding: 0 24px;
  }
  @media (min-width: 768px) {
    max-width: 768px
  };
}

@media (min-width: 992px) {
  max-width: 992px;
}

@media (min-width: 1320px) {
  max-width: 1320px;
}
`;function Di(){return i.createElement(i.Suspense,{fallback:i.createElement(i.Fragment,null)},i.createElement(a.f6,{theme:N},i.createElement(H,null,i.createElement(Or,null,i.createElement(Ni,null))),i.createElement(it,null)))}U.render(i.createElement(i.Fragment,null,i.createElement(Di,null)),document.getElementById("options-root"))},8377:()=>{}},r={};function i(e){var a=r[e];if(void 0!==a)return a.exports;var n=r[e]={exports:{}};return t[e].call(n.exports,n,n.exports,i),n.exports}i.m=t,e=[],i.O=(t,r,a,n)=>{if(!r){var o=1/0;for(d=0;d<e.length;d++){for(var[r,a,n]=e[d],s=!0,l=0;l<r.length;l++)(!1&n||o>=n)&&Object.keys(i.O).every((e=>i.O[e](r[l])))?r.splice(l--,1):(s=!1,n<o&&(o=n));if(s){e.splice(d--,1);var c=a();void 0!==c&&(t=c)}}return t}n=n||0;for(var d=e.length;d>0&&e[d-1][2]>n;d--)e[d]=e[d-1];e[d]=[r,a,n]},i.n=e=>{var t=e&&e.__esModule?()=>e.default:()=>e;return i.d(t,{a:t}),t},i.d=(e,t)=>{for(var r in t)i.o(t,r)&&!i.o(e,r)&&Object.defineProperty(e,r,{enumerable:!0,get:t[r]})},i.g=function(){if("object"==typeof globalThis)return globalThis;try{return this||new Function("return this")()}catch(e){if("object"==typeof window)return window}}(),i.o=(e,t)=>Object.prototype.hasOwnProperty.call(e,t),i.r=e=>{"undefined"!=typeof Symbol&&Symbol.toStringTag&&Object.defineProperty(e,Symbol.toStringTag,{value:"Module"}),Object.defineProperty(e,"__esModule",{value:!0})},i.j=798,(()=>{var e={798:0};i.O.j=t=>0===e[t];var t=(t,r)=>{var a,n,[o,s,l]=r,c=0;if(o.some((t=>0!==e[t]))){for(a in s)i.o(s,a)&&(i.m[a]=s[a]);if(l)var d=l(i)}for(t&&t(r);c<o.length;c++)n=o[c],i.o(e,n)&&e[n]&&e[n][0](),e[o[c]]=0;return i.O(d)},r=globalThis.webpackChunkhelium10_main_tool=globalThis.webpackChunkhelium10_main_tool||[];r.forEach(t.bind(null,0)),r.push=t.bind(null,r.push.bind(r))})();var a=i.O(void 0,[216],(()=>i(4911)));a=i.O(a)})();