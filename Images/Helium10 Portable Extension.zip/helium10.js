(() => {
  "use strict";
  var e,
    r = {
      2400: (e, r, t) => {
        var o = t(7563),
          n = Object.defineProperty,
          a = Object.getOwnPropertySymbols,
          i = Object.prototype.hasOwnProperty,
          l = Object.prototype.propertyIsEnumerable,
          s = (e, r, t) =>
            r in e
              ? n(e, r, {
                  enumerable: !0,
                  configurable: !0,
                  writable: !0,
                  value: t,
                })
              : (e[r] = t),
          u = (e, r) => {
            for (var t in r || (r = {})) i.call(r, t) && s(e, t, r[t]);
            if (a) for (var t of a(r)) l.call(r, t) && s(e, t, r[t]);
            return e;
          };
        const c = (e, r, t = !1) =>
            "GET" !== e && r ? { body: t ? r : JSON.stringify(r) } : {},
          m = (e, r, t) =>
            "GET" === e && t ? o.stringifyUrl({ url: r, query: t }) : r,
          d = (e) => {
            return (
              (r = void 0),
              (t = [e]),
              (o = function* ({
                url: e,
                params: r,
                method: t = "GET",
                headers: o = {},
                type: n = "background-request",
                form: a,
                rawParams: i,
              }) {
                return new Promise((l, s) => {
                  const d = {
                    url: m(t, e, r),
                    params:
                      i ||
                      u(
                        {
                          method: t,
                          headers: o,
                          form: a,
                          credentials: "same-origin",
                        },
                        c(t, r, a)
                      ),
                  };
                  chrome.runtime.sendMessage(u({ type: n }, d), (e) => {
                    ((e, r, t) => {
                      var o, n;
                      200 === (null == e ? void 0 : e.status)
                        ? ((n = e.data), l(n))
                        : ((o = {
                            data: null == e ? void 0 : e.data,
                            status: null == e ? void 0 : e.status,
                          }),
                          s(o));
                    })(e);
                  });
                });
              }),
              new Promise((e, n) => {
                var a = (e) => {
                    try {
                      l(o.next(e));
                    } catch (e) {
                      n(e);
                    }
                  },
                  i = (e) => {
                    try {
                      l(o.throw(e));
                    } catch (e) {
                      n(e);
                    }
                  },
                  l = (r) =>
                    r.done ? e(r.value) : Promise.resolve(r.value).then(a, i);
                l((o = o.apply(r, t)).next());
              })
            );
            var r, t, o;
          };
        t(7294),
          Object.defineProperty,
          Object.getOwnPropertySymbols,
          Object.prototype.hasOwnProperty,
          Object.prototype.propertyIsEnumerable,
          chrome.runtime.id,
          ["1", "2", "3", "4", "5"].map((e) => `isStar${e}Enabled`),
          document.body.setAttribute(
            "data-helium10-main-tool-id",
            chrome.runtime.id
          ),
          document.body.setAttribute(
            "data-helium10-main-tool-version",
            chrome.runtime.getManifest().version
          ),
          chrome.storage.local.get({ isMember: -1 }, (e) => {
            if (!chrome.runtime.lastError)
              switch (e.isMember) {
                case -1:
                case !1:
                  b();
              }
          });
        const b = () => {
          d({ url: "https://helium10.groupbuyamz.com/user/check-login" }).then(
            (e) => {
              chrome.storage.local.set({
                isMember: !!(null == e ? void 0 : e.loggedIn),
              });
            }
          );
        };
      },
    },
    t = {};
  function o(e) {
    var n = t[e];
    if (void 0 !== n) return n.exports;
    var a = (t[e] = { exports: {} });
    return r[e].call(a.exports, a, a.exports, o), a.exports;
  }
  (o.m = r),
    (e = []),
    (o.O = (r, t, n, a) => {
      if (!t) {
        var i = 1 / 0;
        for (c = 0; c < e.length; c++) {
          for (var [t, n, a] = e[c], l = !0, s = 0; s < t.length; s++)
            (!1 & a || i >= a) && Object.keys(o.O).every((e) => o.O[e](t[s]))
              ? t.splice(s--, 1)
              : ((l = !1), a < i && (i = a));
          if (l) {
            e.splice(c--, 1);
            var u = n();
            void 0 !== u && (r = u);
          }
        }
        return r;
      }
      a = a || 0;
      for (var c = e.length; c > 0 && e[c - 1][2] > a; c--) e[c] = e[c - 1];
      e[c] = [t, n, a];
    }),
    (o.n = (e) => {
      var r = e && e.__esModule ? () => e.default : () => e;
      return o.d(r, { a: r }), r;
    }),
    (o.d = (e, r) => {
      for (var t in r)
        o.o(r, t) &&
          !o.o(e, t) &&
          Object.defineProperty(e, t, { enumerable: !0, get: r[t] });
    }),
    (o.g = (function () {
      if ("object" == typeof globalThis) return globalThis;
      try {
        return this || new Function("return this")();
      } catch (e) {
        if ("object" == typeof window) return window;
      }
    })()),
    (o.o = (e, r) => Object.prototype.hasOwnProperty.call(e, r)),
    (o.r = (e) => {
      "undefined" != typeof Symbol &&
        Symbol.toStringTag &&
        Object.defineProperty(e, Symbol.toStringTag, { value: "Module" }),
        Object.defineProperty(e, "__esModule", { value: !0 });
    }),
    (o.j = 187),
    (() => {
      var e = { 187: 0 };
      o.O.j = (r) => 0 === e[r];
      var r = (r, t) => {
          var n,
            a,
            [i, l, s] = t,
            u = 0;
          if (i.some((r) => 0 !== e[r])) {
            for (n in l) o.o(l, n) && (o.m[n] = l[n]);
            if (s) var c = s(o);
          }
          for (r && r(t); u < i.length; u++)
            (a = i[u]), o.o(e, a) && e[a] && e[a][0](), (e[i[u]] = 0);
          return o.O(c);
        },
        t = (globalThis.webpackChunkhelium10_main_tool =
          globalThis.webpackChunkhelium10_main_tool || []);
      t.forEach(r.bind(null, 0)), (t.push = r.bind(null, t.push.bind(t)));
    })();
  var n = o.O(void 0, [216], () => o(2400));
  n = o.O(n);
})();
