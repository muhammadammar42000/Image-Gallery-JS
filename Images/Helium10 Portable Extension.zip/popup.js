(()=>{"use strict";var e,t={2035:(e,t,r)=>{var n=r(4367),a=r(7294),o=r(1565);const i=()=>a.createElement(s,null,a.createElement(l,null,a.createElement("div",{className:"item-logo-block1"}),a.createElement("div",{className:"item-logo-block2"}),a.createElement("div",{className:"item-logo-block3"}),a.createElement("div",{className:"item-logo-block4"}),a.createElement("div",{className:"item-logo-block5"}),a.createElement("div",{className:"item-logo-block6"}))),l=o.ZP.div`
  position: inherit;
  margin: 0;
  top: auto;
  left: auto;
  flex-wrap: wrap;
  width: 4.2em;
  height: 4.2em;
  display: grid;
  grid-template: "a a a" 52% "c c c" 34% / 1fr 1fr 1fr; /* 30px */
  grid-gap: 14%;
`,s=o.ZP.div`
  font-size: 16px;
  width: 100px;
  height: 100px;
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 1;
  margin-bottom: 1rem;

  .item-logo-block1 {
    margin-top: auto;
    height: 61%;
    background-color: ${({theme:e})=>e.colors.blue};
    clip-path: polygon(0 0, 100% 40%, 100% 100%, 0% 100%);
    animation: component-loader 1s 0.15s ease-in-out infinite;
  }

  .item-logo-block2 {
    height: 61%;
    margin-top: auto;
    background-color: ${({theme:e})=>e.colors.blue};
    clip-path: polygon(0 40%, 100% 0%, 100% 100%, 0% 100%);
    animation: component-loader 1s 0.3s ease-in-out infinite;
  }

  .item-logo-block3 {
    clip-path: polygon(0 25%, 100% 0%, 100% 100%, 0% 100%);
    background-color: ${({theme:e})=>e.colors.blue};
    animation: component-loader 1s 0.45s ease-in-out infinite;
  }

  .item-logo-block4,
  .item-logo-block5,
  .item-logo-block6 {
    background-color: ${({theme:e})=>e.colors.darkBlue};
  }

  .item-logo-block4 {
    animation: component-loader 1s ease-in-out infinite;
  }

  .item-logo-block5 {
    animation: component-loader 1s 0.15s ease-in-out infinite;
  }

  .item-logo-block6 {
    animation: component-loader 1s 0.3s ease-in-out infinite;
  }

  @keyframes component-loader {
    0% {
      transform: scale(1);
    }
    30% {
      transform: scale(0.2);
    }
    60% {
      transform: scale(1);
    }
  }
`,c=(Object.entries({"www.amazon.com":"com","www.amazon.com.au":"au","www.amazon.ca":"ca","www.amazon.com.mx":"mx","www.amazon.de":"de","www.amazon.es":"es","www.amazon.fr":"fr","www.amazon.it":"it","www.amazon.co.uk":"uk","www.amazon.in":"in","www.amazon.nl":"nl","www.amazon.co.jp":"jp"}).map((([e,t])=>({value:t,label:e}))),{store:"ATVPDKIKX0DER",currency:"USD",locale:"en-US"});var u,d,g,p;function m(){return(m=Object.assign||function(e){for(var t=1;t<arguments.length;t++){var r=arguments[t];for(var n in r)Object.prototype.hasOwnProperty.call(r,n)&&(e[n]=r[n])}return e}).apply(this,arguments)}function h(){return(h=Object.assign||function(e){for(var t=1;t<arguments.length;t++){var r=arguments[t];for(var n in r)Object.prototype.hasOwnProperty.call(r,n)&&(e[n]=r[n])}return e}).apply(this,arguments)}function w(){return(w=Object.assign||function(e){for(var t=1;t<arguments.length;t++){var r=arguments[t];for(var n in r)Object.prototype.hasOwnProperty.call(r,n)&&(e[n]=r[n])}return e}).apply(this,arguments)}Object.defineProperty,Object.getOwnPropertySymbols,Object.prototype.hasOwnProperty,Object.prototype.propertyIsEnumerable,Object.defineProperty,Object.defineProperties,Object.getOwnPropertyDescriptors,Object.getOwnPropertySymbols,Object.prototype.hasOwnProperty,Object.prototype.propertyIsEnumerable;const f=o.F4`
  from {
    opacity: 0;
  }
  to {
    opacity: 1;
  }
`,b=o.ZP.div`
  width: 16px !important;
  height: 16px !important;
  text-align: initial;
`,v=(0,o.ZP)((function(e){return a.createElement("svg",h({width:16,height:16,fill:"none",xmlns:"http://www.w3.org/2000/svg"},e),d||(d=a.createElement("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M8 8L0 0h16L8 8z",fill:"#222"})))}))`
  width: 16px !important;
  height: 16px !important;
  position: absolute;
`,y=(0,o.ZP)((function(e){return a.createElement("svg",w({width:16,height:16,fill:"none",xmlns:"http://www.w3.org/2000/svg"},e),g||(g=a.createElement("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M8 7L1 0h14L8 7z",fill:"#fff"})),p||(p=a.createElement("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M0 0l8 8 8-8h-1.414L8 6.586 1.414 0H0z",fill:"#DEE2E6"})))}))`
  width: 16px !important;
  height: 16px !important;
  position: absolute;
`,M={dark:{background:"#222",color:"#fff",boxShadow:"none"},light:{background:"#fff",color:"#343a40",boxShadow:"0px 0px 0px 1px rgba(222, 226, 230, 1)"}};o.ZP.div`
  max-width: ${({maxWidth:e})=>e?e+"px":"auto"};
  padding: 8px 12px;
  border-radius: 4px;
  color: #fff;
  animation: ${f} 0.2s ease;
  transition-property: transform, visibility, opacity;
  text-align: center;
  ${({colorType:e})=>`\n    background: ${M[e||"dark"].background};\n    color: ${M[e||"dark"].color};\n    box-shadow: ${M[e||"dark"].boxShadow};\n  `};

  &[data-placement^="top"] {
    ${b} {
      bottom: 0;
    }
    ${v}, ${y} {
      top: 16px;
    }
  }

  &[data-placement^="bottom"] {
    ${b} {
      top: 0;
    }
    ${v}, ${y} {
      bottom: 16px;
      transform: rotate(180deg);
    }
  }

  &[data-placement^="left"] {
    ${b} {
      right: 0;
    }
    ${v}, ${y} {
      transform: rotate(-90deg);
      left: 16px;
    }
  }

  &[data-placement^="right"] {
    ${b} {
      left: 0;
    }
    ${v}, ${y} {
      transform: rotate(90deg);
      right: 16px;
    }
  }
`,Object.defineProperty,Object.getOwnPropertySymbols,Object.prototype.hasOwnProperty,Object.prototype.propertyIsEnumerable,o.ZP.div``,o.ZP.div`
  margin-right: 4px;
`,o.ZP.div`
  display: flex;
  align-items: center;
`,o.ZP.div`
  width: 18px;
  height: 18px;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
`,(0,o.ZP)((function(e){return a.createElement("svg",m({width:11,height:11,fill:"none",xmlns:"http://www.w3.org/2000/svg"},e),u||(u=a.createElement("path",{clipRule:"evenodd",d:"M5.5 7.319a1.02 1.02 0 100 2.04 1.02 1.02 0 000-2.04zm.148-5.5c-1.209 0-1.98.509-2.585 1.414a.266.266 0 00.06.36l.77.584c.115.087.28.066.37-.047.395-.503.667-.794 1.27-.794.453 0 1.013.291 1.013.73 0 .333-.274.503-.721.754-.522.293-1.212.657-1.212 1.567v.089c0 .147.12.266.266.266h1.242c.147 0 .266-.12.266-.266v-.03c0-.631 1.845-.657 1.845-2.365 0-1.287-1.334-2.262-2.584-2.262zM11 5.5a5.5 5.5 0 11-11 0 5.5 5.5 0 0111 0z"})))}))`
  fill: ${({theme:e,color:t})=>e.colors[t]};
`;const x=o.iv`
  font-stretch: normal;
  font-style: normal;
  line-height: normal;
  font-weight: normal;
  letter-spacing: normal;
  margin: 0;
  padding: 0;
  text-transform: initial;
`,z=(o.ZP.h1`
  ${x};
  font-weight: bold;
  color: ${({theme:e})=>e.colors.darkBlue};
  font-size: ${({theme:e})=>e.fontSize.headerBig};
`,o.ZP.h2`
  ${x};
  font-size: ${({theme:e})=>e.fontSize.headerLarge};
  font-weight: bold;
`),j=(o.ZP.h3`
  ${x};
  font-size: ${({theme:e})=>e.fontSize.headerMedium};
  font-weight: bold;
`,o.ZP.h4`
  ${x};
  font-size: ${({theme:e})=>e.fontSize.headerSmall};
  font-weight: 600;
`),N=o.ZP.span`
  ${x};
  font-size: ${({theme:e})=>e.fontSize.medium};
  font-weight: normal;
`,O=o.ZP.span`
  font-size: ${({theme:e})=>e.fontSize.extraSmall};
  font-weight: 600;
`;Object.defineProperty,Object.defineProperties,Object.getOwnPropertyDescriptors,Object.getOwnPropertySymbols,Object.prototype.hasOwnProperty,Object.prototype.propertyIsEnumerable,o.ZP.div`
  line-height: 1 !important;
  background-color: ${({theme:e})=>e.colors.white};
  border-radius: ${({theme:e})=>e.borderRadius.small};
  border: ${({theme:e,haveBorder:t})=>t?`1px solid ${e.colors.middleBeige}`:"1px solid rgba(255, 255, 255, 0)"};
  padding: ${({theme:e})=>e.padding.default};
`,(0,o.ZP)(O)`
  text-transform: uppercase;
  color: ${({theme:e})=>e.colors.grey};
`,(0,o.ZP)(z)`
  line-height: 1 !important;
  padding-top: 3px;
  color: ${({theme:e})=>e.colors.darkBlue};
  text-transform: uppercase;
`;const D={colors:{white:"#ffffff",blue:"#0081ff",lightGrayBackground:"#e4e5e7",darkBlue:"#003873",middleBlue:"#0150a4",darkGrey:"#343a40",black:"#000",grey:"#646464",lightGrey:"#ebf0f2",lightBeige:"#ede8e4",beige:"#ede8e4",middleBeige:"#cbcbcb",lightBlue:"#f7f9fa",middleGrey:"#a8aab7",mediumGrey:"#d1d4d8",lightOpacityGrey:"#8c8c8c",lightRed:"#e74c3c",green:"#35a854",yellow:"#eba646",gold:"#f4c005",asphalt:"#313a47",alibabaGrey:"#eef2f7",alibabaOrange:"#ff6700",alibabaOrangeBackground:"#ffece0",scroll:{track:"#ede8e4",thumb:"#cbcbcb",thumbHover:"#c1c1c1",thumbActive:"#b9b9b9"}},fontFamily:{Neuton:"Neuton",NunitoSans:"Nunito Sans"},fontSize:{smallLabel:"8.3px",label:"11px",extraSmall:"12px",small:"13px",medium:"14px",large:"18px",headerSmall:"16px",headerMedium:"20px",headerLarge:"24px",headerBig:"27px"},fontWeight:{small:"normal",middle:"500",large:"600"},lineHeight:{small:"120%",middle:"140%",large:"160%"},padding:{modal:{default:"11px 16px"},small:"4px",default:"16px",middle:"20px",large:"24px",section:"36px",button:"10px",footerBottom:"40px"},borderRadius:{small:"4px",middle:"8px",large:"35px"}};Object.defineProperty,Object.defineProperties,Object.getOwnPropertyDescriptors,Object.getOwnPropertySymbols,Object.prototype.hasOwnProperty,Object.prototype.propertyIsEnumerable,D.colors.white,D.colors.blue,o.ZP.a`
  display: flex;
  align-items: center;
  flex-wrap: nowrap;
  border: none;
  transition: all 0.2s ease-in-out;
  cursor: pointer;
  font-weight: bold;
  color: ${e=>e.colorSchema.fontColor} !important;
  font-size: 14px;
  outline: none;
  text-decoration: none;

  &:hover {
    text-decoration: none !important;
    color: ${e=>e.colorSchema.fontColor} !important;
  }

  svg {
    margin-left: 8px;
  }
`,Object.defineProperty,Object.getOwnPropertySymbols,Object.prototype.hasOwnProperty,Object.prototype.propertyIsEnumerable,o.ZP.div``,o.ZP.div`
  background-color: ${({theme:e})=>e.colors.white};
  border-radius: ${({theme:e})=>e.borderRadius.small};
  border: 1px solid ${({theme:e})=>e.colors.lightGrey};
`,o.ZP.div`
  padding: ${({theme:e,noPadding:t})=>t?0:e.padding.default};
`,o.ZP.div`
  padding-bottom: 8px;
`,o.ZP.div`
  border-top: 1px solid ${({theme:e})=>e.colors.lightGrey};
  padding: 10px;
  display: flex;
  justify-content: center;
`,o.ZP.span`
  ${x};
  font-family: ${({theme:e})=>e.fontFamily.Neuton}, serif;
  font-size: ${({theme:e})=>e.fontSize.headerMedium};
  letter-spacing: 0.5px;
`;const A=o.ZP.span`
  font-size: ${({theme:e})=>e.fontSize.headerSmall};
  font-weight: 600;
  letter-spacing: 0.5px;
`,P=o.ZP.span`
  font-size: ${({theme:e})=>e.fontSize.large};
  font-weight: bold;
  line-height: 1.39;
  letter-spacing: 0.82px;
  color: ${({theme:e})=>e.colors.darkBlue};
`,I=o.ZP.span`
  font-size: ${({theme:e})=>e.fontSize.headerSmall};
  font-weight: 600;
  line-height: 1.56;
  letter-spacing: 0.73px;
`,C=(o.ZP.span`
  font-size: ${({theme:e})=>e.fontSize.large};
  font-weight: bold;
  line-height: 1.39;
  letter-spacing: 0.82px;
`,o.ZP.span`
  font-size: ${({theme:e})=>e.fontSize.small};
  line-height: 1.15;
`,o.ZP.span`
  ${x};
  font-size: ${({theme:e})=>e.fontSize.smallLabel};
  font-weight: bold;
`);Object.defineProperty,Object.getOwnPropertySymbols,Object.prototype.hasOwnProperty,Object.prototype.propertyIsEnumerable,o.ZP.div`
  display: flex;
  align-items: center;
  padding-top: 3px;
`,(0,o.ZP)(z)`
  line-height: 1 !important;
  color: ${e=>e.theme.colors.darkBlue};
`,(0,o.ZP)(O)`
  line-height: 1 !important;
  text-transform: uppercase;
  color: ${e=>e.theme.colors.grey};
`,o.ZP.div`
  display: flex;
  align-items: center;
`,(0,o.ZP)(C)`
  color: ${e=>e.theme.colors.white};
  background-color: ${e=>e.theme.colors.asphalt};
  padding: 0 8px;
  border-radius: 3px;
  height: 11px;
  line-height: 11px;
  margin-left: 5px;
`,o.ZP.div`
  display: inline-block;
  padding: 16px;
  border: 1px solid ${({theme:e})=>e.colors.middleBeige};
  border-radius: 4px;
`,o.ZP.div`
  position: absolute;
  top: 0;
  left: 0;
  height: 100%;
  display: block;
  overflow: hidden;
  width: ${({rating:e})=>e>5?100:20*e}%;
`,o.ZP.div`
  position: relative;
  margin-right: 4px;
`;var E=r(660),S=Object.defineProperty,L=Object.defineProperties,T=Object.getOwnPropertyDescriptors,k=Object.getOwnPropertySymbols,Z=Object.prototype.hasOwnProperty,B=Object.prototype.propertyIsEnumerable,G=(e,t,r)=>t in e?S(e,t,{enumerable:!0,configurable:!0,writable:!0,value:r}):e[t]=r;const R=o.ZP.div`
  transition: 0.2s;
  opacity: ${({state:e})=>"entered"===e?1:0};
  display: ${({state:e})=>"exited"===e?"none":"flex"};
`,F=o.F4`
  0% {
    background-position: 100% 50%;
  }
  100% {
    background-position: 0 50%;
  }
`,U=o.ZP.div`
  border-radius: 4px;
  background: linear-gradient(
    90deg,
    ${e=>e.colorOne||"#e6e6e6"} 25%,
    ${e=>e.colorTwo||"#f3f3f3"} 50%,
    ${e=>e.colorOne||"#e6e6e6"} 75%
  );
  background-size: 400% 100%;
  animation: ${F} 1.5s infinite;
  height: calc(100% - ${e=>e.heightShrinkAmount||18}px);
  width: 100%;
`;var V;function q(){return(q=Object.assign||function(e){for(var t=1;t<arguments.length;t++){var r=arguments[t];for(var n in r)Object.prototype.hasOwnProperty.call(r,n)&&(e[n]=r[n])}return e}).apply(this,arguments)}Object.defineProperty,Object.defineProperties,Object.getOwnPropertyDescriptors,Object.getOwnPropertySymbols,Object.prototype.hasOwnProperty,Object.prototype.propertyIsEnumerable;const Y={small:{height:"28px"},middle:{height:"34px"},large:{height:"40px"}},W=o.ZP.input`
  font-size: 14px;
  box-sizing: border-box;
  height: ${({sizeSchema:e})=>Y[e||"small"].height};
  padding: 0 8px;
  background: #fff;
  display: block;
  width: 100%;
  border: none;
  text-align: ${({textAlign:e})=>e};

  &:focus {
    outline: none;
  }

  &::placeholder {
    color: ${({theme:e})=>e.colors.grey};
  }

  &[type="number"]::-webkit-inner-spin-button,
  &[type="number"]::-webkit-outer-spin-button {
    -webkit-appearance: none;
    margin: 0;
  }

  &:disabled {
    cursor: not-allowed;
    background: #fbfbfb;
  }
`,H=o.ZP.div`
  box-sizing: border-box;
  padding: 0 8px;
  display: flex;
  align-items: center;
  justify-content: center;
  position: absolute;
  left: 0;
  top: 0;
  bottom: 0;
  width: 26px;
  border-right: 1px solid #e2e2e2;
  color: #929292;
  font-size: 13px;
  overflow: hidden;
`;o.ZP.div`
  position: relative;
  display: ${({expanded:e})=>e?"flex":"inline-flex"};
  border: ${({theme:e})=>`1px solid ${e.colors.middleBeige}`};
  border-radius: 4px;
  transition: border-color 0.2s ease;
  overflow: hidden;

  ${H} + ${W} {
    padding-left: 34px;
  }

  &:focus-within {
    border-color: ${({theme:e})=>e.colors.blue};
  }
`,Object.defineProperty,Object.defineProperties,Object.getOwnPropertyDescriptors,Object.getOwnPropertySymbols,Object.prototype.hasOwnProperty,Object.prototype.propertyIsEnumerable,o.ZP.div`
  justify-content: space-between;
  display: flex;
  align-items: center;

  & > div {
    width: 100%;
  }
`,r(9119),r(1193),r(9429),(0,a.createContext)({current:null});var Q=r(3935);const X=o.ZP.div`
  font-family: ${({theme:e})=>e.fontFamily.NunitoSans}, -apple-system, "Neuton", sans-serif;
`,K=o.ZP.button`
  width: 24px;
  height: 24px;
  background-color: ${({theme:e})=>e.colors.middleBlue};
  border-radius: 50%;
  border: none;
  cursor: pointer;
  background-repeat: no-repeat;
  background-position: center;
  outline: none;
  box-sizing: border-box !important;
  padding: 0;
  transition: none;

  &:hover {
    background-color: ${({theme:e})=>e.colors.middleBlue};
  }
`;Object.defineProperty,Object.getOwnPropertySymbols,Object.prototype.hasOwnProperty,Object.prototype.propertyIsEnumerable,(0,o.ZP)(K)`
  background-image: url(${"data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPHN2ZyB3aWR0aD0iMTBweCIgaGVpZ2h0PSIxMHB4IiB2aWV3Qm94PSIwIDAgMTAgMTAiIHZlcnNpb249IjEuMSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB4bWxuczp4bGluaz0iaHR0cDovL3d3dy53My5vcmcvMTk5OS94bGluayI+CiAgICA8dGl0bGU+MTc1NUIyRjctRUQyMy00NzE2LUI0NkYtNDM3NTFBNTI2QUNCPC90aXRsZT4KICAgIDxnIGlkPSJBbGliYWJhLURlbWFuZC1GaW5kZXIiIHN0cm9rZT0ibm9uZSIgc3Ryb2tlLXdpZHRoPSIxIiBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPgogICAgICAgIDxnIGlkPSJBbGliYWJhLURlbWFuZC1GaW5kZXItLS1kZW1hbmQtZmluZGVyLShuby1yZXN1bHRzKSIgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTExNDkuMDAwMDAwLCAtMTc5LjAwMDAwMCkiIGZpbGw9IiNGRkZGRkYiPgogICAgICAgICAgICA8ZyBpZD0iR3JvdXAtNSIgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoMTE0Mi4wMDAwMDAsIDE3Mi4wMDAwMDApIj4KICAgICAgICAgICAgICAgIDxnIGlkPSJpY29uLXN5bmMiIHRyYW5zZm9ybT0idHJhbnNsYXRlKDcuMDAwMDAwLCA3LjAwMDAwMCkiPgogICAgICAgICAgICAgICAgICAgIDxwYXRoIGQ9Ik0wLjQ4Mzg3MDk2OCw1LjgwNjQ1MTYxIEwzLjE4NjY3MzM5LDUuODA2NDUxNjEgQzMuNjE3NzYyMSw1LjgwNjQ1MTYxIDMuODMzNjQ5MTksNi4zMjc2NDExMyAzLjUyODgzMDY1LDYuNjMyNDc5ODQgTDIuNjg3MDk2NzcsNy40NzQyMTM3MSBDMy4zMTczNzkwMyw4LjA2NDM5NTE2IDQuMTM1MzgzMDYsOC4zODc5MDMyMyA1LjAwMzE0NTE2LDguMzg3MTE2OTQgQzYuNTYzOTkxOTQsOC4zODU3MDU2NSA3LjkxMjcyMTc3LDcuMzE1NjY1MzIgOC4yODUxNDExMyw1LjgyOTY3NzQyIEM4LjMxMjIzNzksNS43MjE1NTI0MiA4LjQwODU2ODU1LDUuNjQ1MjAxNjEgOC41MjAwNDAzMiw1LjY0NTIwMTYxIEw5LjY3NTM2MjksNS42NDUyMDE2MSBDOS44MjY1MzIyNiw1LjY0NTIwMTYxIDkuOTQxMzcwOTcsNS43ODI0Mzk1MiA5LjkxMzQwNzI2LDUuOTMxMDA4MDYgQzkuNDc3MTU3MjYsOC4yNDc1IDcuNDQzMjg2MjksMTAgNSwxMCBDMy42NjAzMjI1OCwxMCAyLjQ0MzcyOTg0LDkuNDczMDY0NTIgMS41NDYwNjg1NSw4LjYxNTIyMTc3IEwwLjgyNjAwODA2NSw5LjMzNTI4MjI2IEMwLjUyMTE4OTUxNiw5LjY0MDEwMDgxIDAsOS40MjQyMTM3MSAwLDguOTkzMTI1IEwwLDYuMjkwMzIyNTggQzAsNi4wMjMwODQ2OCAwLjIxNjYzMzA2NSw1LjgwNjQ1MTYxIDAuNDgzODcwOTY4LDUuODA2NDUxNjEgTDAuNDgzODcwOTY4LDUuODA2NDUxNjEgWiBNNy4zMTI5MDMyMywyLjUyNTgwNjQ1IEM2LjY4MjYyMDk3LDEuOTM1NjQ1MTYgNS44NjQ2Nzc0MiwxLjYxMjEzNzEgNC45OTY5MzU0OCwxLjYxMjkwMzIzIEMzLjQzNTI4MjI2LDEuNjE0Mjc0MTkgMi4wODcwOTY3NywyLjY4NTA0MDMyIDEuNzE0ODU4ODcsNC4xNzAzNjI5IEMxLjY4Nzc2MjEsNC4yNzg0ODc5IDEuNTkxNDMxNDUsNC4zNTQ4Mzg3MSAxLjQ3OTk1OTY4LDQuMzU0ODM4NzEgTDAuMzI0NjU3MjU4LDQuMzU0ODM4NzEgQzAuMTczNDg3OTAzLDQuMzU0ODM4NzEgMC4wNTg2NDkxOTM1LDQuMjE3NjAwODEgMC4wODY2MTI5MDMyLDQuMDY5MDMyMjYgQzAuNTIyODQyNzQyLDEuNzUyNSAyLjU1NjcxMzcxLDAgNSwwIEM2LjMzOTY3NzQyLDAgNy41NTYyNzAxNiwwLjUyNjkzNTQ4NCA4LjQ1MzkzMTQ1LDEuMzg0Nzc4MjMgTDkuMTczOTkxOTQsMC42NjQ3MTc3NDIgQzkuNDc4ODEwNDgsMC4zNTk4OTkxOTQgMTAsMC41NzU3ODYyOSAxMCwxLjAwNjg3NSBMMTAsMy43MDk2Nzc0MiBDMTAsMy45NzY5MTUzMiA5Ljc4MzM2Njk0LDQuMTkzNTQ4MzkgOS41MTYxMjkwMyw0LjE5MzU0ODM5IEw2LjgxMzMyNjYxLDQuMTkzNTQ4MzkgQzYuMzgyMjM3OSw0LjE5MzU0ODM5IDYuMTY2MzUwODEsMy42NzIzNTg4NyA2LjQ3MTE2OTM1LDMuMzY3NTIwMTYgTDcuMzEyOTAzMjMsMi41MjU4MDY0NSBaIiBpZD0iRmlsbC0xIj48L3BhdGg+CiAgICAgICAgICAgICAgICA8L2c+CiAgICAgICAgICAgIDwvZz4KICAgICAgICA8L2c+CiAgICA8L2c+Cjwvc3ZnPg=="});
  transition: 200ms linear;
  transition-duration: 0.2s;
  margin-right: 8px;

  &:active {
    transform: rotate(-180deg);
    transition: 0s;
  }
`,(0,o.ZP)(K)`
  background-image: url(${"data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPHN2ZyB3aWR0aD0iMTBweCIgaGVpZ2h0PSIxMHB4IiB2aWV3Qm94PSIwIDAgMTAgMTAiIHZlcnNpb249IjEuMSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB4bWxuczp4bGluaz0iaHR0cDovL3d3dy53My5vcmcvMTk5OS94bGluayI+CiAgICA8dGl0bGU+NUM4NjIyMUMtOTg0MC00RjE1LTk0OEItMzU0QzJFRTU5MDlCPC90aXRsZT4KICAgIDxkZWZzPgogICAgICAgIDxmaWx0ZXIgaWQ9ImZpbHRlci0xIj4KICAgICAgICAgICAgPGZlQ29sb3JNYXRyaXggaW49IlNvdXJjZUdyYXBoaWMiIHR5cGU9Im1hdHJpeCIgdmFsdWVzPSIwIDAgMCAwIDEuMDAwMDAwIDAgMCAwIDAgMS4wMDAwMDAgMCAwIDAgMCAxLjAwMDAwMCAwIDAgMCAxLjAwMDAwMCAwIj48L2ZlQ29sb3JNYXRyaXg+CiAgICAgICAgPC9maWx0ZXI+CiAgICAgICAgPHBvbHlnb24gaWQ9InBhdGgtMiIgcG9pbnRzPSIwIC0xLjQ3MjYyNzQzZS0xNSA5Ljk1MzM2Nzg4IC0xLjQ3MjYyNzQzZS0xNSA5Ljk1MzM2Nzg4IDkuOTUzMzU3NTEgMCA5Ljk1MzM1NzUxIj48L3BvbHlnb24+CiAgICA8L2RlZnM+CiAgICA8ZyBpZD0iQWxpYmFiYS1EZW1hbmQtRmluZGVyIiBzdHJva2U9Im5vbmUiIHN0cm9rZS13aWR0aD0iMSIgZmlsbD0ibm9uZSIgZmlsbC1ydWxlPSJldmVub2RkIj4KICAgICAgICA8ZyBpZD0iQWxpYmFiYS1EZW1hbmQtRmluZGVyLS0tbG9nZ2VkLWluLShhZnRlci1zZWFyY2gtb24tYWxpYmFiYS1saW1pdC1yZWFjaGVkLW1vZGFsKSIgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTEwNDMuMDAwMDAwLCAtMTEzLjAwMDAwMCkiPgogICAgICAgICAgICA8ZyBpZD0iR3JvdXAtNyIgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoMzU3LjAwMDAwMCwgODIuMDAwMDAwKSI+CiAgICAgICAgICAgICAgICA8ZyBpZD0iR3JvdXAtNCIgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoNjc5LjAwMDAwMCwgMjQuMDAwMDAwKSI+CiAgICAgICAgICAgICAgICAgICAgPGcgaWQ9Ikdyb3VwLTMiIHRyYW5zZm9ybT0idHJhbnNsYXRlKDcuMDAwMDAwLCA3LjAwMDAwMCkiIGZpbHRlcj0idXJsKCNmaWx0ZXItMSkiPgogICAgICAgICAgICAgICAgICAgICAgICA8Zz4KICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxtYXNrIGlkPSJtYXNrLTMiIGZpbGw9IndoaXRlIj4KICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dXNlIHhsaW5rOmhyZWY9IiNwYXRoLTIiPjwvdXNlPgogICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9tYXNrPgogICAgICAgICAgICAgICAgICAgICAgICAgICAgPGcgaWQ9IkNsaXAtMiI+PC9nPgogICAgICAgICAgICAgICAgICAgICAgICAgICAgPHBhdGggZD0iTTkuNzc0NTkwNjcsMS40Njg5MDE1NSBMNi4yNjY4NzA0Nyw0Ljk3NjY3MzU4IEw5Ljc3NDU5MDY3LDguNDg0NDQ1NiBDMTAuMDEyOTg0NSw4LjcyMjc4NzU2IDEwLjAxMjk4NDUsOS4xMDYyMDcyNSA5Ljc3NDU5MDY3LDkuMzQ0NTQ5MjIgTDkuMzQ0NTM4ODYsOS43NzQ2MDEwNCBDOS4xMDYyNDg3LDEwLjAxMjk0MyA4LjcyMjc3NzIsMTAuMDEyOTQzIDguNDg0NDg3MDUsOS43NzQ2MDEwNCBMNC45NzY2NjMyMSw2LjI2Njg4MDgzIEwxLjQ2ODg5MTE5LDkuNzc0NjAxMDQgQzEuMjMwNjAxMDQsMTAuMDEyOTQzIDAuODQ3MTI5NTM0LDEwLjAxMjk0MyAwLjYwODgzOTM3OCw5Ljc3NDYwMTA0IEwwLjE3ODczNTc1MSw5LjM0NDU0OTIyIEMtMC4wNTk2MDYyMTc2LDkuMTA2MjA3MjUgLTAuMDU5NjA2MjE3Niw4LjcyMjc4NzU2IDAuMTc4NzM1NzUxLDguNDg0NDQ1NiBMMy42ODY1MDc3Nyw0Ljk3NjY3MzU4IEwwLjE3ODczNTc1MSwxLjQ2ODkwMTU1IEMtMC4wNTk2MDYyMTc2LDEuMjMwNTU5NTkgLTAuMDU5NjA2MjE3NiwwLjg0NzEzOTg5NiAwLjE3ODczNTc1MSwwLjYwODc5NzkyNyBMMC42MDg4MzkzNzgsMC4xNzg3NDYxMTQgQzAuODQ3MTI5NTM0LC0wLjA1OTU5NTg1NDkgMS4yMzA2MDEwNCwtMC4wNTk1OTU4NTQ5IDEuNDY4ODkxMTksMC4xNzg3NDYxMTQgTDQuOTc2NjYzMjEsMy42ODY1MTgxMyBMOC40ODQ0ODcwNSwwLjE3ODc0NjExNCBDOC43MjI3NzcyLC0wLjA1OTU5NTg1NDkgOS4xMDYyNDg3LC0wLjA1OTU5NTg1NDkgOS4zNDQ1Mzg4NiwwLjE3ODc0NjExNCBMOS43NzQ1OTA2NywwLjYwODc5NzkyNyBDMTAuMDA3NzUxMywwLjg0NzEzOTg5NiAxMC4wMDc3NTEzLDEuMjMwNTU5NTkgOS43NzQ1OTA2NywxLjQ2ODkwMTU1IiBpZD0iRmlsbC0xIiBmaWxsPSIjMDAwMDAwIiBtYXNrPSJ1cmwoI21hc2stMykiPjwvcGF0aD4KICAgICAgICAgICAgICAgICAgICAgICAgPC9nPgogICAgICAgICAgICAgICAgICAgIDwvZz4KICAgICAgICAgICAgICAgIDwvZz4KICAgICAgICAgICAgPC9nPgogICAgICAgIDwvZz4KICAgIDwvZz4KPC9zdmc+"});
`,(0,o.ZP)(K)`
  transition: 300ms linear;
  background-image: url(${({active:e})=>e?"data:image/svg+xml;base64,PHN2ZyB2ZXJzaW9uPSIxLjEiIGlkPSJDYXBhXzEiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgeG1sbnM6eGxpbms9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkveGxpbmsiIHg9IjBweCIKICAgICB5PSIwcHgiCiAgICAgd2lkdGg9IjQzOC41MjlweCIgaGVpZ2h0PSI0MzguNTI5cHgiIHZpZXdCb3g9IjAgMCA0MzguNTI5IDQzOC41MjkiCiAgICAgc3R5bGU9ImVuYWJsZS1iYWNrZ3JvdW5kOm5ldyAwIDAgNDM4LjUyOSA0MzguNTI5OyIKICAgICB4bWw6c3BhY2U9InByZXNlcnZlIj4KPGc+Cgk8Zz4KCQk8cGF0aCBmaWxsPSIjZmZmIiBkPSJNMTgwLjE1NiwyMjUuODI4Yy0xLjkwMy0xLjkwMi00LjA5My0yLjg1NC02LjU2Ny0yLjg1NGMtMi40NzUsMC00LjY2NSwwLjk1MS02LjU2NywyLjg1NGwtOTQuNzg3LDk0Ljc4N2wtNDEuMTEyLTQxLjExNwoJCQljLTMuNjE3LTMuNjEtNy44OTUtNS40MjEtMTIuODQ3LTUuNDIxYy00Ljk1MiwwLTkuMjM1LDEuODExLTEyLjg1MSw1LjQyMWMtMy42MTcsMy42MjEtNS40MjQsNy45MDUtNS40MjQsMTIuODU0djEyNy45MDcKCQkJYzAsNC45NDgsMS44MDcsOS4yMjksNS40MjQsMTIuODQ3YzMuNjE5LDMuNjEzLDcuOTAyLDUuNDI0LDEyLjg1MSw1LjQyNGgxMjcuOTA2YzQuOTQ5LDAsOS4yMy0xLjgxMSwxMi44NDctNS40MjQKCQkJYzMuNjE1LTMuNjE3LDUuNDI0LTcuODk4LDUuNDI0LTEyLjg0N3MtMS44MDktOS4yMzMtNS40MjQtMTIuODU0bC00MS4xMTItNDEuMTA0bDk0Ljc4Ny05NC43OTMKCQkJYzEuOTAyLTEuOTAzLDIuODUzLTQuMDg2LDIuODUzLTYuNTY0YzAtMi40NzgtMC45NTMtNC42Ni0yLjg1My02LjU3TDE4MC4xNTYsMjI1LjgyOHoiLz4KICAgICAgICA8cGF0aCBmaWxsPSIjZmZmIiBkPSJNNDMzLjExLDUuNDI0QzQyOS40OTYsMS44MDcsNDI1LjIxMiwwLDQyMC4yNjMsMEgyOTIuMzU2Yy00Ljk0OCwwLTkuMjI3LDEuODA3LTEyLjg0Nyw1LjQyNAoJCQljLTMuNjE0LDMuNjE1LTUuNDIxLDcuODk4LTUuNDIxLDEyLjg0N3MxLjgwNyw5LjIzMyw1LjQyMSwxMi44NDdsNDEuMTA2LDQxLjExMmwtOTQuNzg2LDk0Ljc4NwoJCQljLTEuOTAxLDEuOTA2LTIuODU0LDQuMDkzLTIuODU0LDYuNTY3czAuOTUzLDQuNjY1LDIuODU0LDYuNTY3bDMyLjU1MiwzMi41NDhjMS45MDIsMS45MDMsNC4wODYsMi44NTMsNi41NjMsMi44NTMKCQkJczQuNjYxLTAuOTUsNi41NjMtMi44NTNsOTQuNzk0LTk0Ljc4N2w0MS4xMDQsNDEuMTA5YzMuNjIsMy42MTYsNy45MDUsNS40MjgsMTIuODU0LDUuNDI4czkuMjI5LTEuODEyLDEyLjg0Ny01LjQyOAoJCQljMy42MTQtMy42MTQsNS40MjEtNy44OTgsNS40MjEtMTIuODQ3VjE4LjI2OEM0MzguNTMsMTMuMzE1LDQzNi43MzQsOS4wNCw0MzMuMTEsNS40MjR6Ii8+Cgk8L2c+CjwvZz4KPC9zdmc+Cg==":"data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPHN2ZyB3aWR0aD0iMTBweCIgaGVpZ2h0PSIxMHB4IiB2aWV3Qm94PSIwIDAgMTAgMTAiIHZlcnNpb249IjEuMSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB4bWxuczp4bGluaz0iaHR0cDovL3d3dy53My5vcmcvMTk5OS94bGluayI+CiAgICA8dGl0bGU+REM0Mzk0Q0MtQ0JCRS00NDM3LTg3N0ItRkVGQzZCN0IzQzE5PC90aXRsZT4KICAgIDxnIGlkPSJBbGliYWJhLURlbWFuZC1GaW5kZXIiIHN0cm9rZT0ibm9uZSIgc3Ryb2tlLXdpZHRoPSIxIiBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPgogICAgICAgIDxnIGlkPSJBbGliYWJhLURlbWFuZC1GaW5kZXItLS1kZW1hbmQtZmluZGVyLShuby1yZXN1bHRzKSIgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTExODEuMDAwMDAwLCAtMTc5LjAwMDAwMCkiIGZpbGw9IiNGRkZGRkYiPgogICAgICAgICAgICA8ZyBpZD0iR3JvdXAtNSIgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoMTE0Mi4wMDAwMDAsIDE3Mi4wMDAwMDApIj4KICAgICAgICAgICAgICAgIDxnIGlkPSJHcm91cC0zIiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgzMi4wMDAwMDAsIDAuMDAwMDAwKSI+CiAgICAgICAgICAgICAgICAgICAgPGcgaWQ9Imljb24tc2hyaW5rIiB0cmFuc2Zvcm09InRyYW5zbGF0ZSg3LjAwMDAwMCwgNy4wMDAwMDApIj4KICAgICAgICAgICAgICAgICAgICAgICAgPHBhdGggZD0iTTkuODk1NDAxNzksMS4xNzYwMjY3OSBMNy42Nzg1NzE0MywzLjM5Mjg1NzE0IEw4LjQxMzQxNTE4LDQuMDg1NDY4NzUgQzguNzUwOTM3NSw0LjQyMjk2ODc1IDguNTExOTE5NjQsNSA4LjAzNDY0Mjg2LDUgTDUuNTM0NjQyODYsNSBDNS4yMzg3NzIzMiw1IDUsNC43NjAxNTYyNSA1LDQuNDY0Mjg1NzEgTDUsMS45NjQyODU3MSBDNSwxLjQ4NzAwODkzIDUuNTc1OTM3NSwxLjI0Nzk5MTA3IDUuOTEzNDE1MTgsMS41ODU0Njg3NSBMNi42MDcxNDI4NiwyLjMyMTQyODU3IEw4LjgyMzk3MzIxLDAuMTA0NTk4MjE0IEM4Ljk2MzQxNTE4LC0wLjAzNDg2NjA3MTQgOS4xODk1NzU4OSwtMC4wMzQ4NjYwNzE0IDkuMzI5MDQwMTgsMC4xMDQ1OTgyMTQgTDkuODk1NDAxNzksMC42NzA5NTk4MjEgQzEwLjAzNDg0MzgsMC44MTA0MjQxMDcgMTAuMDM0ODQzOCwxLjAzNjU2MjUgOS44OTU0MDE3OSwxLjE3NjAyNjc5IE0wLjEwNDU5ODIxNCw4LjgyMzk3MzIxIEwyLjMyMTQyODU3LDYuNjA3MTQyODYgTDEuNTg2NTYyNSw1LjkxNDUzMTI1IEMxLjI0OTA2MjUsNS41NzcwMzEyNSAxLjQ4ODA4MDM2LDUgMS45NjUzMzQ4Miw1IEw0LjQ2NTMzNDgyLDUgQzQuNzYxMjI3NjgsNSA1LDUuMjM5ODQzNzUgNSw1LjUzNTcxNDI5IEw1LDguMDM1NzE0MjkgQzUsOC41MTI5OTEwNyA0LjQyNDAxNzg2LDguNzUyMDA4OTMgNC4wODY1NjI1LDguNDE0NTMxMjUgTDMuMzkyODU3MTQsNy42Nzg1NzE0MyBMMS4xNzYwMjY3OSw5Ljg5NTQwMTc5IEMxLjAzNjU2MjUsMTAuMDM0ODQzNyAwLjgxMDQyNDEwNywxMC4wMzQ4NDM3IDAuNjcwOTU5ODIxLDkuODk1NDAxNzkgTDAuMTA0NTk4MjE0LDkuMzI5MDQwMTggQy0wLjAzNDg2NjA3MTQsOS4xODk1NzU4OSAtMC4wMzQ4NjYwNzE0LDguOTYzNDM3NSAwLjEwNDU5ODIxNCw4LjgyMzk3MzIxIiBpZD0iRmlsbC0xIj48L3BhdGg+CiAgICAgICAgICAgICAgICAgICAgPC9nPgogICAgICAgICAgICAgICAgPC9nPgogICAgICAgICAgICA8L2c+CiAgICAgICAgPC9nPgogICAgPC9nPgo8L3N2Zz4="});
  background-size: 10px;
  transform: rotate(${e=>e.active?"360deg":"90deg"});
  margin-right: 8px;
`,o.ZP.div`
  display: flex;
`;var J=r(9101),$=r(2694);const _=new $.Z({en:{plans:{Helium10_ALaCarte:"A La Carte",Helium10_ALaCarteAnnual:"A La Carte",Helium10_Diamond:"Diamond",Helium10_DiamondAnnual:"Diamond",Helium10_Elite:"Elite",Helium10_Free:"Free",Helium10_Gold:"Gold",Helium10_GoldAnnual:"Gold",Helium10_Platinum:"Platinum",Helium10_PlatinumAnnual:"Platinum",Helium10_Platinum_FastAction:"Platinum",Helium10_Starter:"Starter",Helium10_StarterAnnual:"Starter",Helium10_Enterprise:"Enterprise"},common:{month:"mo",freeLaunchesLeft:"Free launches left:",pleaseWait:"Loading Product Data",verified:"Verified",selected:"Selected"},placeholders:{min:"Min",max:"Max",anyKeyword:"Enter any keyword..."},errors:{default:{required:"This field is required",min:"This field requires min value",minLength:"This field requires min length",noData:"Data is not available. Please try again later.",limit:"You’ve run into your backend limit to access Historical Sales data. Please contact Support for more information."},minMax:{validate:"Min should be less than Max",required:"This field is required",min:"This field requires min value",minLength:"This field requires min length"}},buttons:{upgrade:"Upgrade",noThanks:"No, thanks",upgradeForUnlimited:"Upgrade for unlimited",seeAnalysis:"See analysis",show:"Show",hide:"Hide",cancel:"Cancel",rateUs:"Rate Us",notNow:"Not Now",switchLanguage:"Switch Language",no:"No",yes:"Yes",understand:"I understand"},upgrade:{discount:{title:"You've used up your 50 free launches",subTitle:"Unlock access to Xray and other great tools for <b>{discount}% off</b> your first month",subTitleWalmart:"Use code for <b>{discount}%  off</b> your 1st month of Diamond"},title:"Upgrade now for full access to the Chrome Extension",titleWalmart:"Need more Walmart insights?",subTitle:"Get unlimited launches for Xray, Demand Analyzer, and much more",essentialFeatures:"Full access to these essential features:",essentialFeaturesWalmart:"For a very limited time unlock:",proposals:{chromeExtension:"Unlimited Access to the Chrome Extension",freedomTicket:"Freedom Ticket Amazon Training Course",blackBox:"Black Box Product Research",trendster:"Trendster Amazon Trends Finder",magnet:"Magnet<sup>2</sup> &nbsp; Keyword Research",scribbles:"Scribbles Listing Optimizer",indexChecker:"Index Checker"},proposalsWalmart:{chromeExtension:"Unlimited Xray for Walmart launches",magnet:"Unlimited Magnet<sup>2</sup> &nbsp; for Walmart launches",cerebro:"Unlimited Cerebro for Walmart launches",profits:"Unlimited access to Profits for Walmart",sorting:"Unlimited access to advanced sorting & filtering",more:"More future Walmart tools and features"}},subscriptionRequired:{title:"Subscription required",text:"Historical Search Volume is only available to subscribed Helium 10 members. Please upgrade to the one of our plans for unlimited access"},notFoundResult:{title:"No results found",text:"Please go back and try searching with another keyword",buttonText:"Back to Alibaba"},modals:{rateUsHeader:"Like using Helium 10 Extension?",rateUsLike:"I like to use the extension. I really use all the functionality of the extension.",rateUsDislike:"I don't like working with the extension, I don't like how it develops and its functionality",rateUsNegativeHeader:"Thanks for your feedback!",rateUsPositiveHeader:"Thanks You",rateUsMessage:"We are trying to improve and refine our application, your feedback will help us with this. If you have any suggestions on how to make our extension better, you can contact support.",rateUsPositiveMessage:"We are so happy to hear that you like our extension! It would be super helpful if you rate us. Thanks",localizationHeader:"New languages for extension",localizationMessage:"The extension is now available in the language of your browser. All available languages can be viewed in the settings. Change the language to yours? Page will be reloaded.",notShowAgain:"Don't show again"},hour:{one:"Hour",other:"Hours"},day:{one:"Day",other:"Days"},year:{one:"Year",other:"Years"},allTime:"All Time",localizationModal:{header:"New languages available now",message:"We are happy to announce Chrome Extension language support in German, Italian, and Spanish. Switch your language preference at any time in Settings.",notShowAgain:"Don't show again"},charts:{time:"Time",price:"Price",rank:"Rank",rating:"Rating",salesRank:"Sales Rank",newPrice:"New Price",listPrice:"List Price",values:"Values",sales:"Sales",trendLine:"Trend Line",movingAverage:"7-Day Moving Average",reviews:"Reviews",numberOfReviews:"Number of Reviews",searchVolume:"Search Volume",reviewCount:"Review Count",downloads:{csv:"Download CSV",xls:"Download XLS",png:"Download PNG image",jpeg:"Download JPEG image"},resetZoom:"Reset Zoom"}},de:{plans:{Helium10_ALaCarte:"A La Carte",Helium10_ALaCarteAnnual:"A La Carte",Helium10_Diamond:"Diamond",Helium10_DiamondAnnual:"Diamond",Helium10_Elite:"Elite",Helium10_Free:"Free",Helium10_Gold:"Gold",Helium10_GoldAnnual:"Gold",Helium10_Platinum:"Platinum",Helium10_PlatinumAnnual:"Platinum",Helium10_Platinum_FastAction:"Platinum",Helium10_Starter:"Starter",Helium10_StarterAnnual:"Starter",Helium10_Enterprise:"Enterprise"},common:{month:"Mon",freeLaunchesLeft:"Verbleibende kostenlose Suchanfragen:",pleaseWait:"Produktdaten werden geladen",verified:"Verifiziert",selected:"Ausgewählt"},placeholders:{min:"Min",max:"Max",anyKeyword:"Geben Sie ein beliebiges Keyword ein …"},errors:{default:{required:"Dieses Feld erfordert eine Angabe",min:"Dieses Feld erfordert einen Mindestwert",minLength:"Dieses Feld erfordert eine Mindestlänge",noData:"Daten sind nicht verfügbar. Bitte versuchen Sie es später erneut.",limit:"Sie haben Ihr Back-End-Limit für den Zugriff auf historische Verkaufsdaten überschritten. Bitte kontaktieren Sie den Support für weitere Informationen."},minMax:{validate:"Min sollte kleiner als Max sein",required:"Dieses Feld erfordert eine Angabe",min:"Dieses Feld erfordert einen Mindestwert",minLength:"Dieses Feld erfordert eine Mindestlänge"}},buttons:{upgrade:"Upgrade",noThanks:"Nein, danke",upgradeForUnlimited:"Upgrade auf Unbegrenzt",seeAnalysis:"Analyse ansehen",show:"Anzeigen",hide:"Ausblenden",cancel:"Abbrechen",rateUs:"Bewerten Sie uns.",notNow:"Nicht jetzt",switchLanguage:"Sprache wechseln",no:"Nein",yes:"Ja",understand:"Ich verstehe"},upgrade:{discount:{title:"Sie haben Ihre 50 kostenlosen Suchanfragen aufgebraucht",subTitle:"Schalten Sie den Zugang zu Xray und anderen tollen Tools frei, mit <b>{discount}% Rabatt</b> im ersten Monat",subTitleWalmart:"Verwenden Sie den Code für <b> {discount} % </b> Ihren ersten Monat Diamond"},title:"Erwerben Sie jetzt ein Upgrade für vollen Zugriff auf die Chrome-Erweiterung",subTitle:"Erhalten Sie unbegrenzten Zugriff auf Xray, Demand Analyzer und vieles mehr",essentialFeatures:"Voller Zugriff auf diese wesentlichen Funktionen:",proposals:{chromeExtension:"Unbegrenzter Zugriff auf die Chrome-Erweiterung",freedomTicket:"Freedom Ticket Amazon-Trainingskurs",blackBox:"Black Box Produktrecherche",trendster:"Trendster Amazon Trend-Recherche",magnet:"Magnet<sup>2</sup> &nbsp; Keyword-Recherche",scribbles:"Scribbles Listing-Optimierer",indexChecker:"Index-Prüfer"},titleWalmart:"Benötigen Sie weitere Walmart-Einblicke?",essentialFeaturesWalmart:"Für eine sehr begrenzte Zeit freischalten:",proposalsWalmart:{chromeExtension:"Unbegrenzte Markteinführungen von Xray für Walmart",magnet:"Unbegrenzter Magnet <sup>2</sup> &nbsp; für Walmart-Starts",cerebro:"Unbegrenzter Cerebro für Walmart-Starts",profits:"Unbegrenzter Zugang zu Profits für Walmart",sorting:"Unbegrenzter Zugriff auf erweiterte Sortier- und Filterfunktionen",more:"Weitere zukünftige Walmart-Tools und -Funktionen"}},subscriptionRequired:{title:"Abonnement erforderlich",text:"Suchvolumen-Verlauf ist nur für Helium 10 Mitglieder im Abonnement verfügbar. Bitte upgraden Sie auf einen unserer Tarife für unbegrenzten Zugriff"},notFoundResult:{title:"Keine Ergebnisse gefunden",text:"Bitte gehen Sie zurück und versuchen Sie es mit einem anderen Keyword",buttonText:"Zurück zu Alibaba"},hour:{one:"Stunde",other:"Stunden"},day:{one:"Tag",other:"Tage"},year:{one:"Jahr",other:"Jahre"},allTime:"Alle Zeit",localizationModal:{header:"Neue Sprachen sind jetzt verfügbar",message:"Wir freuen uns, die Sprachunterstützung der Chrome-Erweiterung in Deutsch, Italienisch und Spanisch ankündigen zu können. Ändern Sie Ihre Spracheinstellung jederzeit in den Einstellungen.",notShowAgain:"Nicht mehr anzeigen"},charts:{time:"Zeit",price:"Preis",rank:"Rang",rating:"Bewertung",salesRank:"Verkaufsrang",newPrice:"Neuer Preis",listPrice:"List-Preis",values:"Werte",sales:"Absatz",trendLine:"Trendlinie",movingAverage:"Gleitender 7-Tage-Durchschnitt",reviews:"Bewertungen",numberOfReviews:"Anzahl der Bewertungen",searchVolume:"Suchvolumen",reviewCount:"Bewertungsanzahl",downloads:{csv:"CSV-Bericht herunterladen",xls:"XLS herunterladen",png:"PNG-Bild herunterladen",jpeg:"JPEG-Bild herunterladen"},resetZoom:"Zoom zurücksetzen"},modals:{rateUsHeader:"Like using Helium 10 Extension?",rateUsLike:"I like to use the extension. I really use all the functionality of the extension.",rateUsDislike:"I don't like working with the extension, I don't like how it develops and its functionality",rateUsNegativeHeader:"Thanks for your feedback!",rateUsPositiveHeader:"Thanks You",rateUsMessage:"We are trying to improve and refine our application, your feedback will help us with this. If you have any suggestions on how to make our extension better, you can contact support.",rateUsPositiveMessage:"We are so happy to hear that you like our extension! It would be super helpful if you rate us. Thanks",localizationHeader:"New languages for extension",localizationMessage:"The extension is now available in the language of your browser. All available languages can be viewed in the settings. Change the language to yours? Page will be reloaded.",notShowAgain:"Don't show again"}},es:{plans:{Helium10_ALaCarte:"A La Carte",Helium10_ALaCarteAnnual:"A La Carte",Helium10_Diamond:"Diamond",Helium10_DiamondAnnual:"Diamond",Helium10_Elite:"Elite",Helium10_Free:"Free",Helium10_Gold:"Gold",Helium10_GoldAnnual:"Gold",Helium10_Platinum:"Platinum",Helium10_PlatinumAnnual:"Platinum",Helium10_Platinum_FastAction:"Platinum",Helium10_Starter:"Starter",Helium10_StarterAnnual:"Starter",Helium10_Enterprise:"Entreprise"},common:{month:"me",freeLaunchesLeft:"Usos libres restantes:",pleaseWait:"Cargando datos del producto",verified:"Verificado",selected:"Seleccionado"},placeholders:{min:"Mín",max:"Máx",anyKeyword:"Ingresa cualquier palabra clave..."},errors:{default:{required:"Este campo es obligatorio",min:"Este campo requiere un valor Mín",minLength:"Este campo requiere una longitud Mín",noData:"Los datos no están disponibles, por favor, intenta de nuevo después.",limit:"Se ha topado con su límite de backend para acceder a los datos de ventas históricas. Comuníquese con Soporte para obtener más información."},minMax:{validate:"Mín debe ser menor a Máx",required:"Este campo es obligatorio",min:"Este campo requiere un valor Mín",minLength:"Este campo requiere una longitud Mín"}},buttons:{upgrade:"Ampliar",noThanks:"No, gracias",upgradeForUnlimited:"Ampliar al plan ilimitado",seeAnalysis:"Ver análisis",show:"Mostrar",hide:"Ocultar",cancel:"Cancelar",rateUs:"Califícanos",notNow:"Ahora no",switchLanguage:"Cambiar idioma",no:"No",yes:"Sí",understand:"Entiendo"},upgrade:{discount:{title:"Has agotado tus 50 usos libres",subTitle:"Desbloquea el acceso a Xray y otras herramientas buenísimas para un <b>{discount}%</b> de descuento el primer mes",subTitleWalmart:"Use el código para obtener un <b> {discount} % de descuento </b> su primer mes de Diamond"},title:"Ampliar ahora para tener acceso total a la extensión de Chrome",subTitle:"Obtén usos ilimitados a Xray, Demand Analyzer y mucho más",essentialFeatures:"Acceso total a estas funciones esenciales:",proposals:{chromeExtension:"Acceso ilimitado a la extensión de Chrome",freedomTicket:"Acceso libre al curso de capacitación de Amazon",blackBox:"Búsqueda de productos con Black Box",trendster:"Búsqueda de tendencias con Amazon Trendster",magnet:"Magnet<sup>2</sup> &nbsp; Búsqueda de palabras clave",scribbles:"Optimizador de listings con Scribbles",indexChecker:"Verificación con Index Checker"},titleWalmart:"¿Necesita más información sobre Walmart?",essentialFeaturesWalmart:"Desbloquear por un tiempo muy limitado:",proposalsWalmart:{chromeExtension:"Lanzamientos ilimitados de Xray para Walmart",magnet:"Magnet<sup>2</sup> &nbsp; ilimitado para los lanzamientos de Walmart",cerebro:"Lanzamientos ilimitados de Cerebro para Walmart",profits:"Acceso ilimitado a Profits para Walmart",sorting:"Acceso ilimitado a la clasificación y el filtrado avanzados",more:"Más herramientas y funciones futuras de Walmart"}},subscriptionRequired:{title:"Se necesita suscripción",text:"El historial de volumen de búsqueda está disponible solo para miembros suscritos de Helium 10. Por favor, amplia a uno de nuestros planes para tener acceso ilimitado"},notFoundResult:{title:"No se hallaron resultados",text:"Por favor, regresa e intenta buscar con otra palabra clave",buttonText:"Volver a Alibaba"},hour:{one:"hora",other:"horas"},day:{one:"día",other:"dias"},year:{one:"año",other:"años"},allTime:"Todo el tiempo",localizationModal:{header:"Nuevos idiomas disponibles ahora",message:"Nos complace anunciar que la extensión de Chrome es compatible con los idiomas alemán, italiano y español. Cambie su preferencia de idioma en cualquier momento en la Configuración.",notShowAgain:"No volver a mostrar"},charts:{time:"Tiempo",price:"Precio",rank:"Rango",rating:"Calificación",salesRank:"Rango de ventas",newPrice:"Nuevo precio",listPrice:"Precio de lista",values:"Valores",sales:"Ventas",trendLine:"Línea de tendencia",movingAverage:"Media móvil de 7 días",reviews:"Reseñas",numberOfReviews:"Número de reseñas",searchVolume:"Volumen de búsqueda",reviewCount:"Cuenta de reseñas",downloads:{csv:"Descargar informe CSV",xls:"Descarga XLS",png:"Descargar imagen PNG",jpeg:"Descargar imagen JPEG"},resetZoom:"Restablecer zoom"},modals:{rateUsHeader:"Like using Helium 10 Extension?",rateUsLike:"I like to use the extension. I really use all the functionality of the extension.",rateUsDislike:"I don't like working with the extension, I don't like how it develops and its functionality",rateUsNegativeHeader:"Thanks for your feedback!",rateUsPositiveHeader:"Thanks You",rateUsMessage:"We are trying to improve and refine our application, your feedback will help us with this. If you have any suggestions on how to make our extension better, you can contact support.",rateUsPositiveMessage:"We are so happy to hear that you like our extension! It would be super helpful if you rate us. Thanks",localizationHeader:"New languages for extension",localizationMessage:"The extension is now available in the language of your browser. All available languages can be viewed in the settings. Change the language to yours? Page will be reloaded.",notShowAgain:"Don't show again"}},it:{plans:{Helium10_ALaCarte:"A La Carte",Helium10_ALaCarteAnnual:"A La Carte",Helium10_Diamond:"Diamond",Helium10_DiamondAnnual:"Diamond",Helium10_Elite:"Elite",Helium10_Free:"Free",Helium10_Gold:"Gold",Helium10_GoldAnnual:"Gold",Helium10_Platinum:"Platinum",Helium10_PlatinumAnnual:"Platinum",Helium10_Platinum_FastAction:"Platinum",Helium10_Starter:"Starter",Helium10_StarterAnnual:"Starter",Helium10_Enterprise:"Enterprise"},common:{month:"m",freeLaunchesLeft:"Lanci gratuiti rimasti:",pleaseWait:"Caricamento dei dati del prodotto",verified:"Verificato",selected:"Selezionato"},placeholders:{min:"Min",max:"Max",anyKeyword:"Inserisci una parola chiave..."},errors:{default:{required:"Campo necessario",min:"Questo campo richiede un valore minimo",minLength:"Questo campo richiede una lunghezza minima",noData:"I dati non sono disponibili, riprova più tardi.",limit:"Hai raggiunto il limite del tuo backend per accedere ai dati storici delle vendite. Si prega di contattare il supporto per ulteriori informazioni."},minMax:{validate:"Min dovrebbe essere inferiore a Max",required:"Campo necessario",min:"Questo campo richiede un valore minimo",minLength:"Questo campo richiede una lunghezza minima"}},buttons:{upgrade:"Esegui l'upgrade",noThanks:"No, grazie",upgradeForUnlimited:"Esegui l'upgrade per avere accesso illimitato",seeAnalysis:"Visualizza analisi",show:"Mostra",hide:"Nascondi",cancel:"Annulla",rateUs:"Dai un voto",notNow:"Non adesso",switchLanguage:"Cambia lingua",no:"No",yes:"Sì",understand:"Capisco"},upgrade:{discount:{title:"Hai esaurito i tuoi 50 lanci gratuiti",subTitle:"Ottieni l'accesso a Xray e altri fantastici strumenti con uno <b> sconto del {discount}% </b> il primo mese",subTitleWalmart:"Usa il codice per <b> {discount} % di sconto </b> tuo primo mese di Diamond"},title:"Esegui l'upgrade ora per l'accesso completo all'estensione di Chrome",subTitle:"Ottieni lanci illimitati per Xray, Demand Analyzer e tanto altro",essentialFeatures:"Accesso completo a questi strumenti indispensabili:",proposals:{chromeExtension:"Accesso illimitato all'estensione di Chrome",freedomTicket:"Corso di formazione Amazon Freedom Ticket",blackBox:"Ricerca dei prodotti con Black Box",trendster:"Ricerca degli Amazon Trends con Trendster",magnet:"Ricerca di parole chiave via Magnet<sup>2</sup> &nbsp;",scribbles:"Ottimizzazione dei listing con Scribbles",indexChecker:"Index Checker"},titleWalmart:"Hai bisogno di ulteriori informazioni su Walmart?",essentialFeaturesWalmart:"Sblocca Per un tempo molto limitato:",proposalsWalmart:{chromeExtension:"Lanci illimitati per Xray per Walmart",magnet:"Magnet<sup>2</sup> &nbsp; illimitato per i lanci Walmart",cerebro:"Lanci illimitati di Cerebro per Walmart",profits:"Accesso illimitato ai Profits per Walmart",sorting:"Accesso illimitato all'ordinamento e al filtraggio avanzati",more:"Altri futuri strumenti e funzionalità Walmart"}},subscriptionRequired:{title:"Accesso richiesto",text:"La cronologia del volume di ricerca è disponibile solo per gli abbonati ad Helium 10. Passa ad uno dei nostri piani per un accesso senza restrizioni"},notFoundResult:{title:"Nessun risultato trovato",text:"Torna indietro e prova a cercare con un'altra parola chiave",buttonText:"Torna ad Alibaba"},hour:{one:"ora",other:"ore"},day:{one:"giorno",other:"giorni"},year:{one:"anno",other:"anni"},allTime:"Tutto il tempo",localizationModal:{header:"Nuove lingue sono ora disponibili",message:"Siamo lieti di annunciare il supporto linguistico dell'estensione Chrome in tedesco, italiano e spagnolo. Cambia la tua preferenza di lingua in qualsiasi momento in Impostazioni.",notShowAgain:"Non mostrare più"},charts:{time:"Tempo",price:"Prezzo",rank:"Classifica",rating:"Valutazioni",salesRank:"Classifica delle vendite",newPrice:"Nuovo prezzo",listPrice:"Prezzo di listino",values:"Valori",sales:"Vendite",trendLine:"Linea di tendenza",movingAverage:"Media mobile di 7 giorni",reviews:"Recensioni",numberOfReviews:"Numero di recensioni",searchVolume:"Volume di ricerca",reviewCount:"Numero di recensioni",downloads:{csv:"Scarica il rapporto in CSV",xls:"Scarica XLS",png:"Scarica l'immagine PNG",jpeg:"Scarica l'immagine JPEG"},resetZoom:"Ripristina zoom"},modals:{rateUsHeader:"Like using Helium 10 Extension?",rateUsLike:"I like to use the extension. I really use all the functionality of the extension.",rateUsDislike:"I don't like working with the extension, I don't like how it develops and its functionality",rateUsNegativeHeader:"Thanks for your feedback!",rateUsPositiveHeader:"Thanks You",rateUsMessage:"We are trying to improve and refine our application, your feedback will help us with this. If you have any suggestions on how to make our extension better, you can contact support.",rateUsPositiveMessage:"We are so happy to hear that you like our extension! It would be super helpful if you rate us. Thanks",localizationHeader:"New languages for extension",localizationMessage:"The extension is now available in the language of your browser. All available languages can be viewed in the settings. Change the language to yours? Page will be reloaded.",notShowAgain:"Don't show again"}}},{logsEnabled:!1}),ee=({children:e})=>a.createElement(J.DO,{strings:_,TranslateContext:te},e),te=(0,a.createContext)(null);var re,ne,ae,oe,ie;function le(){return(le=Object.assign||function(e){for(var t=1;t<arguments.length;t++){var r=arguments[t];for(var n in r)Object.prototype.hasOwnProperty.call(r,n)&&(e[n]=r[n])}return e}).apply(this,arguments)}function se(){return(se=Object.assign||function(e){for(var t=1;t<arguments.length;t++){var r=arguments[t];for(var n in r)Object.prototype.hasOwnProperty.call(r,n)&&(e[n]=r[n])}return e}).apply(this,arguments)}function ce(){return(ce=Object.assign||function(e){for(var t=1;t<arguments.length;t++){var r=arguments[t];for(var n in r)Object.prototype.hasOwnProperty.call(r,n)&&(e[n]=r[n])}return e}).apply(this,arguments)}var ue=Object.defineProperty,de=Object.defineProperties,ge=Object.getOwnPropertyDescriptors,pe=Object.getOwnPropertySymbols,me=Object.prototype.hasOwnProperty,he=Object.prototype.propertyIsEnumerable,we=(e,t,r)=>t in e?ue(e,t,{enumerable:!0,configurable:!0,writable:!0,value:r}):e[t]=r;const fe=o.ZP.span`
  padding-left: 5px;
  padding-right: 5px;
`,be=o.ZP.label`
  cursor: pointer;
`,ve=Object.assign((e=>{var t,r=e,{label:n,children:o,innerRef:i,almost:l}=r,s=((e,t)=>{var r={};for(var n in e)me.call(e,n)&&t.indexOf(n)<0&&(r[n]=e[n]);if(null!=e&&pe)for(var n of pe(e))t.indexOf(n)<0&&he.call(e,n)&&(r[n]=e[n]);return r})(r,["label","children","innerRef","almost"]);return a.createElement(be,null,a.createElement(ze,(t=((e,t)=>{for(var r in t||(t={}))me.call(t,r)&&we(e,r,t[r]);if(pe)for(var r of pe(t))he.call(t,r)&&we(e,r,t[r]);return e})({type:"checkbox"},s),de(t,ge({ref:i})))),l?a.createElement(xe,null):a.createElement(Me,null),n&&!o&&a.createElement(fe,null,n),o&&a.createElement(fe,null,o))}),{Text:fe,Label:be}),ye=o.iv`
  width: 11px;
  height: 11px;
  border-radius: 2px;
  fill: transparent;
  border: 1px solid ${({theme:e})=>e.colors.lightGrayBackground};
`,Me=(0,o.ZP)((function(e){return a.createElement("svg",ce({width:12,height:12,fill:"none",xmlns:"http://www.w3.org/2000/svg"},e),ie||(ie=a.createElement("path",{d:"M5.68 8.805l4.242-4.242a.476.476 0 00.14-.352.486.486 0 00-.14-.36l-.711-.703A.48.48 0 008.859 3a.48.48 0 00-.351.148L5.32 6.328 3.555 4.563a.48.48 0 00-.352-.149.48.48 0 00-.351.149l-.711.703A.487.487 0 002 5.625c0 .14.047.258.14.352L4.97 8.805a.48.48 0 00.351.148c.141 0 .26-.05.36-.148z"})))}))`
  ${ye}
`,xe=(0,o.ZP)((function(e){return a.createElement("svg",se({width:12,height:12,fill:"none",xmlns:"http://www.w3.org/2000/svg"},e),oe||(oe=a.createElement("rect",{x:2,y:5,width:8,height:2,rx:1})))}))`
  ${ye}
`,ze=o.ZP.input`
  display: none;

  &:checked + ${xe} {
    fill: white;
    border: 1px solid ${({theme:e})=>e.colors.middleBlue};
    background: ${({theme:e})=>e.colors.middleBlue};
  }

  &:checked:disabled + ${xe} {
    fill: white;
    border: 1px solid ${({theme:e})=>e.colors.lightGrayBackground};
    background: ${({theme:e})=>e.colors.lightGrayBackground};
  }

  &:checked + ${Me} {
    fill: white;
    border: 1px solid ${({theme:e})=>e.colors.middleBlue};
    background: ${({theme:e})=>e.colors.middleBlue};
  }

  &:checked:disabled + ${Me} {
    fill: white;
    border: 1px solid ${({theme:e})=>e.colors.lightGrayBackground};
    background: ${({theme:e})=>e.colors.lightGrayBackground};
  }
`;o.ZP.div`
  ${ve.Label} {
    display: flex;
    align-items: center;
    justify-content: center;
  }

  ${ve.Text} {
    line-height: 14px;
  }

  ${O} {
    line-height: 12px;
  }
`;var je=Object.defineProperty,Ne=Object.defineProperties,Oe=Object.getOwnPropertyDescriptors,De=Object.getOwnPropertySymbols,Ae=Object.prototype.hasOwnProperty,Pe=Object.prototype.propertyIsEnumerable,Ie=(e,t,r)=>t in e?je(e,t,{enumerable:!0,configurable:!0,writable:!0,value:r}):e[t]=r;const Ce={white:{fontColor:D.colors.blue,standard:D.colors.white,hover:D.colors.white},blue:{fontColor:D.colors.white,standard:D.colors.blue,hover:D.colors.darkBlue},"light-blue":{fontColor:D.colors.blue,standard:"#e5f2ff",hover:"#cde1f5"}},Ee={small:{fontSize:D.fontSize.medium,padding:"6px 16px 7px 16px"},middle:{fontSize:D.fontSize.headerSmall,padding:`${D.padding.button} ${D.padding.default}`},large:{fontSize:D.fontSize.headerLarge,padding:`${D.padding.large} ${D.padding.section}`}},Se=e=>{var t,r=e,{colorType:n="blue",type:o,size:i="middle",disabled:l,onClick:s,children:c,form:u}=r,d=((e,t)=>{var r={};for(var n in e)Ae.call(e,n)&&t.indexOf(n)<0&&(r[n]=e[n]);if(null!=e&&De)for(var n of De(e))t.indexOf(n)<0&&Pe.call(e,n)&&(r[n]=e[n]);return r})(r,["colorType","type","size","disabled","onClick","children","form"]);return a.createElement(Le,(t=((e,t)=>{for(var r in t||(t={}))Ae.call(t,r)&&Ie(e,r,t[r]);if(De)for(var r of De(t))Pe.call(t,r)&&Ie(e,r,t[r]);return e})({},d),Ne(t,Oe({form:u,type:o,colorSchema:Ce[n],sizeSchema:Ee[i],disabled:l,onClick:s}))),c)},Le=o.ZP.button`
  display: flex;
  align-items: center;
  flex-wrap: nowrap;
  border: none;
  transition: all 0.2s ease-in-out;
  border-radius: ${({theme:e})=>e.borderRadius.middle};
  cursor: pointer;
  background-color: ${e=>e.colorSchema.standard};
  font-weight: bold;
  padding: ${e=>e.sizeSchema.padding};
  color: ${e=>e.colorSchema.fontColor};
  font-size: ${e=>e.sizeSchema.fontSize};
  outline: none;
  line-height: 1.5;

  &:hover {
    background-color: ${e=>e.colorSchema.hover};
  }

  &:active,
  &:focus {
    color: ${({theme:e})=>e.colors.btnPrimaryText};
    background-color: ${({theme:e})=>e.colors.btnPrimaryHover};
  }

  :disabled {
    cursor: auto;
    opacity: 0.5;
    background-color: ${e=>e.colorSchema.standard};
  }
`;var Te,ke,Ze,Be,Ge,Re,Fe;function Ue(){return(Ue=Object.assign||function(e){for(var t=1;t<arguments.length;t++){var r=arguments[t];for(var n in r)Object.prototype.hasOwnProperty.call(r,n)&&(e[n]=r[n])}return e}).apply(this,arguments)}function Ve(e){return a.createElement("svg",Ue({width:110,height:18,xmlns:"http://www.w3.org/2000/svg"},e),Te||(Te=a.createElement("g",{fill:"none"},a.createElement("path",{d:"M34.533 17.756V12h-6.377v5.754h-2.543V3.892h2.543v5.754h6.377V3.898h2.525V17.76l-2.525-.004zm13.15-.737c-.812.561-1.979.894-3.541.894-1.96 0-3.586-.58-4.505-1.947-.547-.755-.866-1.79-.866-3.087 0-1.229.319-2.245.919-3.018.902-1.242 2.437-1.982 4.433-1.982 2.102 0 3.542.755 4.364 1.913.723 1.016.988 2.483.865 3.965h-8.25c.024.559.265 1.086.673 1.473.458.473 1.325.807 2.367.807a4.164 4.164 0 002.012-.456c.513-.281.76-.668.796-.912h2.331c-.21.958-.781 1.8-1.598 2.35zm-1.237-6.403c-.477-.439-1.183-.807-2.315-.807-1.058 0-1.835.317-2.348.772a2.17 2.17 0 00-.708 1.421h5.919a1.88 1.88 0 00-.548-1.386zm4.733 7.14c-.052-.035-.07-.157-.07-.72V4.846c0-.474-.017-.896-.036-1.054h2.369c.054.295.078.595.07.894v12.176c0 .507 0 .807.053.894h-2.386zm4.367-10.771v-2.35h2.5v2.35h-2.5zm2.544 10.77h-2.367c-.09-.034-.125-.245-.125-.947v-8.7H58v8.65c0 .7.019.946.09.998zm9.12 0l-.052-1.367c-.69 1.122-2.156 1.525-3.568 1.525-2.225 0-3.621-.859-3.621-3.068 0-5.86-.019-6.685-.09-6.737h2.413c.035 0 .054.35.054 6.087 0 1.333.917 1.806 2.17 1.806 1.574 0 2.563-.755 2.563-1.947V8.108h2.367v8.086c-.01.521.007 1.043.052 1.562H67.21zm17.26-5.858c0-.965-.37-1.825-1.995-1.825-1.183 0-2.137.65-2.137 1.876v5.808h-2.26v-6c0-1.035-.726-1.684-1.945-1.684-1.36 0-2.208.93-2.208 1.93v5.754H71.54V8.108h2.333v1.544c.417-1.089 1.731-1.738 3.18-1.738 1.447 0 2.595.58 3.02 1.754.387-1.175 1.625-1.754 3.231-1.754 2.473 0 3.334 1.316 3.334 3.14 0 4.054.016 6.621.087 6.702h-2.142c-.112 0-.112-2.446-.112-5.86zm9.76 5.859V6.722l-3.428.474V5.214c2.898-.414 3.71-.86 3.958-1.386h1.96v13.928h-2.49zm15.443-10.368c.208.964.231 2.104.231 3.439 0 1.088-.125 2.702-.337 3.49-.625 2.483-2.402 3.615-5.298 3.615-2.986 0-4.63-1.035-5.3-3.631-.265-.948-.336-2.386-.336-3.493 0-1.316-.016-2.21.248-3.403.477-2.262 2.244-3.68 5.404-3.68 3.127 0 4.894 1.576 5.388 3.663zm-2.56.561c-.23-1.262-1.184-2.034-2.828-2.034-1.677 0-2.666.772-2.879 2.034-.087.62-.158 2.123-.158 2.878-.003.993.073 1.984.23 2.965.264 1.35 1.237 1.998 2.807 1.998 1.571 0 2.5-.718 2.773-1.998.125-.544.209-2.123.209-2.984.008-.955-.043-1.91-.154-2.859z",fill:"#003873"}),a.createElement("path",{d:"M.125 3.896v5.756H4.54v-3.36L.125 3.896zm6.958 2.396v3.36H11.5V3.896L7.083 6.292zm6.96-3.774v7.134h4.415V.124l-4.414 2.394z",fill:"#0081FF"}),a.createElement("path",{d:"M.125 12.002H4.54v5.754H.125v-5.754zm6.958 0h4.415v5.754H7.083v-5.754zm6.96 0h4.415v5.754h-4.414v-5.754z",fill:"#003873"}))))}function qe(){return(qe=Object.assign||function(e){for(var t=1;t<arguments.length;t++){var r=arguments[t];for(var n in r)Object.prototype.hasOwnProperty.call(r,n)&&(e[n]=r[n])}return e}).apply(this,arguments)}function Ye(e){return a.createElement("svg",qe({width:145,height:24,xmlns:"http://www.w3.org/2000/svg",xmlnsXlink:"http://www.w3.org/1999/xlink"},e),ke||(ke=a.createElement("defs",null,a.createElement("path",{id:"logo-h10-light-window_svg__a",d:"M.094.091h111.322v18.943H.094z"}),a.createElement("path",{id:"logo-h10-light-window_svg__c",d:"M0 23.743h144.983V0H0z"}))),Ze||(Ze=a.createElement("g",{fill:"none",fillRule:"evenodd"},a.createElement("g",{transform:"translate(33.567 4.709)"},a.createElement("mask",{id:"logo-h10-light-window_svg__b",fill:"#fff"},a.createElement("use",{xlinkHref:"#logo-h10-light-window_svg__a"})),a.createElement("path",{d:"M107.73 5.724c-.304-1.683-1.564-2.712-3.734-2.712-2.215 0-3.522 1.03-3.803 2.712-.116.828-.209 2.83-.209 3.837a24.925 24.925 0 00.302 3.954c.35 1.8 1.635 2.664 3.71 2.664 2.074 0 3.301-.957 3.661-2.664.166-.726.276-2.831.276-3.978a30.695 30.695 0 00-.204-3.813zm3.38-.747c.276 1.285.306 2.805.306 4.584 0 1.451-.165 3.603-.446 4.654-.825 3.31-3.172 4.82-6.996 4.82-3.943 0-6.114-1.38-7-4.842-.35-1.263-.443-3.18-.443-4.656 0-1.755-.022-2.947.327-4.538.63-3.016 2.964-4.908 7.138-4.908 4.13 0 6.463 2.102 7.115 4.886zM90.716 18.8V4.088l-4.527.632V2.077c3.828-.551 4.9-1.147 5.228-1.848h2.59v18.57h-3.291zm-12.888-7.812c0-1.286-.49-2.433-2.636-2.433-1.563 0-2.823.865-2.823 2.502V18.8h-2.985v-8c0-1.38-.958-2.245-2.567-2.245-1.797 0-2.917 1.24-2.917 2.573V18.8h-3.15V5.937h3.081v2.057c.55-1.45 2.287-2.317 4.199-2.317s3.428.773 3.99 2.34c.511-1.567 2.146-2.34 4.267-2.34 3.266 0 4.402 1.755 4.402 4.188 0 5.404.022 8.827.116 8.935h-2.829c-.148 0-.148-3.26-.148-7.812zM55.03 18.8l-.068-1.823c-.911 1.495-2.848 2.033-4.714 2.033-2.938 0-4.782-1.145-4.782-4.091 0-7.813-.024-8.913-.118-8.982h3.186c.047 0 .072.466.072 8.115 0 1.777 1.21 2.409 2.867 2.409 2.077 0 3.384-1.007 3.384-2.596V5.937h3.125v10.78c-.013.695.01 1.39.07 2.083H55.03zm-12.046 0H39.86c-.119-.047-.165-.328-.165-1.263v-11.6h3.172V17.47c0 .933.025 1.26.118 1.33zM39.626 4.438h3.302V1.305h-3.302v3.133zM33.86 18.8c-.069-.047-.093-.21-.093-.96V1.586c0-.631-.022-1.194-.047-1.404h3.128c.073.393.104.792.094 1.192v16.234c0 .676 0 1.076.068 1.192h-3.15zm-6.251-9.52c-.63-.585-1.563-1.076-3.057-1.076-1.398 0-2.424.422-3.1 1.03a2.902 2.902 0 00-.936 1.894h7.816a2.52 2.52 0 00-.723-1.848zm1.634 8.538c-1.073.748-2.614 1.192-4.677 1.192-2.59 0-4.735-.773-5.949-2.596-.723-1.007-1.145-2.386-1.145-4.116 0-1.639.422-2.993 1.214-4.025 1.191-1.655 3.22-2.643 5.855-2.643 2.776 0 4.677 1.007 5.764 2.552.955 1.355 1.304 3.31 1.142 5.286H20.55c.032.745.35 1.449.89 1.964.604.631 1.75 1.076 3.125 1.076a5.457 5.457 0 002.658-.607c.677-.375 1.004-.891 1.05-1.217h3.08a5.1 5.1 0 01-2.11 3.134zm-17.367.982v-7.674H3.453v7.671H.093V.315h3.36v7.671h8.422V.323h3.335v18.483l-3.335-.006z",fill:"#EDE8E3",mask:"url(#logo-h10-light-window_svg__b)"})),a.createElement("mask",{id:"logo-h10-light-window_svg__d",fill:"#fff"},a.createElement("use",{xlinkHref:"#logo-h10-light-window_svg__c"})),a.createElement("path",{d:"M18.382 23.509h5.83v-7.672h-5.83v7.672zm-9.192 0h5.83v-7.672H9.19v7.672zm-9.19 0h5.83v-7.672H0v7.672zM18.382 3.192v9.511h5.83V0l-5.83 3.192zM9.19 8.223v4.48h5.833V5.03L9.19 8.223zM0 5.03v7.674h5.83v-4.48L0 5.03z",fill:"#0081FF",mask:"url(#logo-h10-light-window_svg__d)"}))))}function We(){return(We=Object.assign||function(e){for(var t=1;t<arguments.length;t++){var r=arguments[t];for(var n in r)Object.prototype.hasOwnProperty.call(r,n)&&(e[n]=r[n])}return e}).apply(this,arguments)}function He(e){return a.createElement("svg",We({width:168,height:28,xmlns:"http://www.w3.org/2000/svg",xmlnsXlink:"http://www.w3.org/1999/xlink"},e),Be||(Be=a.createElement("defs",null,a.createElement("path",{id:"logo-h10-window_svg__a",d:"M.108.105h128.98v21.85H.109z"}),a.createElement("path",{id:"logo-h10-window_svg__c",d:"M0 .296h28.053v14.652H0z"}),a.createElement("path",{id:"logo-h10-window_svg__e",d:"M0 27.704h167.98V.318H0z"}))),Ge||(Ge=a.createElement("g",{fill:"none",fillRule:"evenodd"},a.createElement("g",{transform:"translate(38.892 5.75)"},a.createElement("mask",{id:"logo-h10-window_svg__b",fill:"#fff"},a.createElement("use",{xlinkHref:"#logo-h10-window_svg__a"})),a.createElement("path",{d:"M124.817 6.602c-.35-1.94-1.81-3.127-4.326-3.127-2.566 0-4.08 1.186-4.405 3.127-.134.955-.242 3.265-.242 4.426a28.622 28.622 0 00.35 4.56c.405 2.078 1.894 3.073 4.297 3.073 2.404 0 3.826-1.104 4.243-3.073.192-.837.319-3.265.319-4.588a35.247 35.247 0 00-.236-4.398zm3.918-.862c.32 1.483.354 3.236.354 5.288 0 1.674-.191 4.156-.517 5.368-.956 3.818-3.675 5.559-8.106 5.559-4.568 0-7.083-1.591-8.11-5.584-.405-1.458-.513-3.67-.513-5.371 0-2.024-.026-3.399.379-5.234.73-3.478 3.434-5.66 8.27-5.66 4.784 0 7.488 2.424 8.243 5.634zm-23.631 15.944V4.716l-5.244.728V2.396c4.434-.636 5.677-1.324 6.057-2.132h3v21.42h-3.813zm-14.933-9.01c0-1.483-.567-2.807-3.054-2.807-1.81 0-3.27.999-3.27 2.886v8.93h-3.459v-9.226c0-1.591-1.11-2.59-2.974-2.59-2.082 0-3.38 1.432-3.38 2.969v8.848h-3.65V6.847h3.57v2.374c.638-1.674 2.65-2.673 4.866-2.673 2.215 0 3.972.891 4.622 2.698.593-1.807 2.487-2.698 4.945-2.698 3.784 0 5.1 2.024 5.1 4.83 0 6.233.026 10.182.134 10.306h-3.277c-.173 0-.173-3.76-.173-9.01zm-26.41 9.01l-.08-2.103c-1.055 1.725-3.3 2.345-5.461 2.345-3.405 0-5.54-1.32-5.54-4.719 0-9.01-.03-10.28-.138-10.36h3.692c.054 0 .083.538.083 9.36 0 2.05 1.402 2.779 3.322 2.779 2.406 0 3.92-1.161 3.92-2.994V6.847h3.622v12.435c-.016.802.011 1.604.08 2.402h-3.5zm-13.957 0h-3.621c-.138-.054-.192-.378-.192-1.457V6.847h3.676v13.304c0 1.075.029 1.453.137 1.533zM45.912 5.12h3.825V1.505h-3.825V5.12zM39.23 21.684c-.08-.054-.109-.242-.109-1.107V1.83c0-.729-.025-1.378-.054-1.62h3.625c.084.453.12.914.108 1.375V20.31c0 .78 0 1.24.08 1.374h-3.65zm-7.243-10.98c-.73-.675-1.81-1.241-3.542-1.241-1.62 0-2.808.487-3.592 1.187a3.341 3.341 0 00-1.084 2.186h9.056a2.899 2.899 0 00-.838-2.132zm1.894 9.847c-1.244.863-3.029 1.375-5.42 1.375-3 0-5.486-.891-6.892-2.994-.838-1.161-1.326-2.752-1.326-4.747 0-1.89.488-3.453 1.406-4.643 1.38-1.909 3.73-3.048 6.784-3.048 3.216 0 5.419 1.162 6.678 2.943 1.106 1.563 1.511 3.819 1.323 6.097H23.81c.037.86.406 1.671 1.03 2.265.701.728 2.027 1.241 3.621 1.241a6.346 6.346 0 003.08-.7c.784-.433 1.163-1.028 1.218-1.403h3.567a5.88 5.88 0 01-2.445 3.614zm-20.122 1.133v-8.852H4v8.849H.108V.363h3.893V9.21h9.758V.372h3.864v21.319l-3.864-.007z",fill:"#003873",mask:"url(#logo-h10-window_svg__b)"})),a.createElement("g",{transform:"translate(0 .022)"},a.createElement("mask",{id:"logo-h10-window_svg__d",fill:"#fff"},a.createElement("use",{xlinkHref:"#logo-h10-window_svg__c"})),a.createElement("path",{d:"M21.298 3.977v10.971h6.755V.296l-6.755 3.681zm-10.65 5.804v5.167h6.758V6.096l-6.759 3.685zM0 6.096v8.852h6.755V9.781L0 6.096z",fill:"#0081FF",mask:"url(#logo-h10-window_svg__d)"})),a.createElement("mask",{id:"logo-h10-window_svg__f",fill:"#fff"},a.createElement("use",{xlinkHref:"#logo-h10-window_svg__e"})),a.createElement("path",{d:"M21.298 27.434h6.755v-8.849h-6.755v8.849zm-10.65 0h6.755v-8.849h-6.756v8.849zM0 27.434h6.755v-8.849H0v8.849z",fill:"#003873",mask:"url(#logo-h10-window_svg__f)"}))))}function Qe(){return(Qe=Object.assign||function(e){for(var t=1;t<arguments.length;t++){var r=arguments[t];for(var n in r)Object.prototype.hasOwnProperty.call(r,n)&&(e[n]=r[n])}return e}).apply(this,arguments)}function Xe(e){return a.createElement("svg",Qe({width:110,height:18,xmlns:"http://www.w3.org/2000/svg"},e),Re||(Re=a.createElement("g",{fill:"none"},a.createElement("path",{d:"M34.533 17.756V12h-6.377v5.754h-2.543V3.892h2.543v5.754h6.377V3.898h2.525V17.76l-2.525-.004zm13.15-.737c-.812.561-1.979.894-3.541.894-1.96 0-3.586-.58-4.505-1.947-.547-.755-.866-1.79-.866-3.087 0-1.229.319-2.245.919-3.018.902-1.242 2.437-1.982 4.433-1.982 2.102 0 3.542.755 4.364 1.913.723 1.016.988 2.483.865 3.965h-8.25c.024.559.265 1.086.673 1.473.458.473 1.325.807 2.367.807a4.164 4.164 0 002.012-.456c.513-.281.76-.668.796-.912h2.331c-.21.958-.781 1.8-1.598 2.35zm-1.237-6.403c-.477-.439-1.183-.807-2.315-.807-1.058 0-1.835.317-2.348.772a2.17 2.17 0 00-.708 1.421h5.919a1.88 1.88 0 00-.548-1.386zm4.733 7.14c-.052-.035-.07-.157-.07-.72V4.846c0-.474-.017-.896-.036-1.054h2.369c.054.295.078.595.07.894v12.176c0 .507 0 .807.053.894h-2.386zm4.367-10.771v-2.35h2.5v2.35h-2.5zm2.544 10.77h-2.367c-.09-.034-.125-.245-.125-.947v-8.7H58v8.65c0 .7.019.946.09.998zm9.12 0l-.052-1.367c-.69 1.122-2.156 1.525-3.568 1.525-2.225 0-3.621-.859-3.621-3.068 0-5.86-.019-6.685-.09-6.737h2.413c.035 0 .054.35.054 6.087 0 1.333.917 1.806 2.17 1.806 1.574 0 2.563-.755 2.563-1.947V8.108h2.367v8.086c-.01.521.007 1.043.052 1.562H67.21zm17.26-5.858c0-.965-.37-1.825-1.995-1.825-1.183 0-2.137.65-2.137 1.876v5.808h-2.26v-6c0-1.035-.726-1.684-1.945-1.684-1.36 0-2.208.93-2.208 1.93v5.754H71.54V8.108h2.333v1.544c.417-1.089 1.731-1.738 3.18-1.738 1.447 0 2.595.58 3.02 1.754.387-1.175 1.625-1.754 3.231-1.754 2.473 0 3.334 1.316 3.334 3.14 0 4.054.016 6.621.087 6.702h-2.142c-.112 0-.112-2.446-.112-5.86zm9.76 5.859V6.722l-3.428.474V5.214c2.898-.414 3.71-.86 3.958-1.386h1.96v13.928h-2.49zm15.443-10.368c.208.964.231 2.104.231 3.439 0 1.088-.125 2.702-.337 3.49-.625 2.483-2.402 3.615-5.298 3.615-2.986 0-4.63-1.035-5.3-3.631-.265-.948-.336-2.386-.336-3.493 0-1.316-.016-2.21.248-3.403.477-2.262 2.244-3.68 5.404-3.68 3.127 0 4.894 1.576 5.388 3.663zm-2.56.561c-.23-1.262-1.184-2.034-2.828-2.034-1.677 0-2.666.772-2.879 2.034-.087.62-.158 2.123-.158 2.878-.003.993.073 1.984.23 2.965.264 1.35 1.237 1.998 2.807 1.998 1.571 0 2.5-.718 2.773-1.998.125-.544.209-2.123.209-2.984.008-.955-.043-1.91-.154-2.859z",fill:"#ede8e3"}),a.createElement("path",{d:"M.125 3.896v5.756H4.54v-3.36L.125 3.896zm6.958 2.396v3.36H11.5V3.896L7.083 6.292zm6.96-3.774v7.134h4.415V.124l-4.414 2.394zM.125 12.002H4.54v5.754H.125v-5.754zm6.958 0h4.415v5.754H7.083v-5.754zm6.96 0h4.415v5.754h-4.414v-5.754z",fill:"#0081FF"}))))}function Ke(){return(Ke=Object.assign||function(e){for(var t=1;t<arguments.length;t++){var r=arguments[t];for(var n in r)Object.prototype.hasOwnProperty.call(r,n)&&(e[n]=r[n])}return e}).apply(this,arguments)}function Je(e){return a.createElement("svg",Ke({width:128,height:128,xmlns:"http://www.w3.org/2000/svg"},e),Fe||(Fe=a.createElement("g",{fill:"none"},a.createElement("path",{d:"M0 28.259v40.847h30.545V45.253L0 28.259zm49.455 16.994v23.853H80V28.259L49.455 45.253zm48-26.393v50.246H128V2L97.455 18.86z",fill:"#0081FF"}),a.createElement("path",{d:"M0 85.153h30.545V126H0V85.153zm49.455 0H80V126H49.455V85.153zm48 0H128V126H97.455V85.153z",fill:"#003873"}))))}var $e=Object.defineProperty,_e=Object.defineProperties,et=Object.getOwnPropertyDescriptors,tt=Object.getOwnPropertySymbols,rt=Object.prototype.hasOwnProperty,nt=Object.prototype.propertyIsEnumerable,at=(e,t,r)=>t in e?$e(e,t,{enumerable:!0,configurable:!0,writable:!0,value:r}):e[t]=r;const ot={small:a.createElement(Je,null),largeDark:a.createElement(Ve,null),largeLight:a.createElement(Xe,null),logoModalLight:a.createElement(Ye,null),logoModalDark:a.createElement(He,null)},it=e=>{var t,r=e,{type:n="small"}=r,o=((e,t)=>{var r={};for(var n in e)rt.call(e,n)&&t.indexOf(n)<0&&(r[n]=e[n]);if(null!=e&&tt)for(var n of tt(e))t.indexOf(n)<0&&nt.call(e,n)&&(r[n]=e[n]);return r})(r,["type"]);return a.createElement(lt,(t=((e,t)=>{for(var r in t||(t={}))rt.call(t,r)&&at(e,r,t[r]);if(tt)for(var r of tt(t))nt.call(t,r)&&at(e,r,t[r]);return e})({},o),_e(t,et({href:"https://www.helium10.com/",target:"_blank",rel:"noreferrer"}))),ot[n])},lt=o.ZP.a`
  line-height: 0;
`;Object.defineProperty,Object.getOwnPropertySymbols,Object.prototype.hasOwnProperty,Object.prototype.propertyIsEnumerable,(0,o.ZP)(X)`
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: ${({dark:e})=>e?"rgba(0, 0, 0, 0.5)":"rgba(0, 0, 0, 0.2)"};
  overflow: hidden;
  display: flex;
  overflow-y: auto;
  padding: 24px 0;
`;const st={small:"477px",large:"727px"};o.ZP.div`
  flex: 0 0 auto;
  margin: auto;
  border-radius: ${({theme:e})=>e.borderRadius.small};
  width: ${e=>e.width?`${e.width}px`:st[e.size||"small"]};
  overflow: hidden;
`,o.ZP.div`
  background-color: ${({theme:e})=>e.colors.white};
`,o.ZP.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: ${({theme:e,small:t})=>t?e.padding.modal.default:e.padding.large};
  background-color: ${({theme:e})=>e.colors.darkBlue};
`,o.ZP.div`
  display: flex;
  align-items: center;
  justify-content: center;
  padding-top: ${({theme:e})=>e.padding.large};
  padding-bottom: ${({theme:e})=>e.padding.footerBottom};
`,o.ZP.div`
  text-align: center;
  padding: 30px;
`,o.ZP.p``,o.ZP.div`
  display: flex;
  justify-content: center;
  margin-bottom: 8px;

  button {
    margin: 4px;
  }
`,Object.defineProperty,Object.defineProperties,Object.getOwnPropertyDescriptors,Object.getOwnPropertySymbols,Object.prototype.hasOwnProperty,Object.prototype.propertyIsEnumerable,(0,o.ZP)((function(e){return a.createElement("svg",le({height:"512pt",viewBox:"0 0 512 512",width:"512pt",xmlns:"http://www.w3.org/2000/svg"},e),re||(re=a.createElement("path",{d:"M373.852 308.297c-1.446-4.82-7.391-7.074-13.497-7.074-5.945 0-11.89 2.254-13.335 7.074l-31.012 101.062c-.16.645-.32 1.286-.32 1.606 0 5.144 7.55 8.676 13.175 8.676 3.535 0 6.266-1.121 7.07-4.176l6.102-21.371h36.797l6.11 21.37c.8 3.056 3.53 4.177 7.066 4.177 5.625 0 13.176-3.692 13.176-8.676 0-.48-.16-.965-.32-1.606zm-27.477 69.406l13.977-49.324 13.984 49.324zm0 0"})),ne||(ne=a.createElement("path",{d:"M456.836 208.867H303.129V143.22l49.953-35.68a14.998 14.998 0 000-24.41l-50.555-36.11C298.578 20.45 275.613 0 247.965 0H55.168C24.746 0 0 24.746 0 55.168v192.8c0 30.419 24.746 55.165 55.168 55.165h153.703v65.648l-49.953 35.68c-3.941 2.816-6.281 7.363-6.281 12.207s2.34 9.39 6.281 12.203l50.555 36.11C213.422 491.55 236.387 512 264.035 512h192.8C487.255 512 512 487.25 512 456.832V264.035c0-30.422-24.746-55.168-55.164-55.168zM55.168 273.133c-13.879 0-25.168-11.29-25.168-25.168v-192.8C30 41.288 41.29 30 55.168 30h192.797c13.875 0 25.164 11.29 25.164 25.164 0 4.848 2.34 9.395 6.281 12.207l39.145 27.961-39.145 27.961a15.005 15.005 0 00-6.281 12.207v73.367h-9.094c-30.418 0-55.164 24.746-55.164 55.164v9.102zM482 456.832C482 470.711 470.71 482 456.836 482h-192.8c-13.876 0-25.165-11.29-25.165-25.168 0-4.844-2.34-9.39-6.281-12.203l-39.145-27.961 39.145-27.961a15.005 15.005 0 006.281-12.207V264.035c0-13.879 11.29-25.168 25.164-25.168H456.836c13.875 0 25.164 11.29 25.164 25.168zm0 0"})),ae||(ae=a.createElement("path",{d:"M197.652 138.277c4.668 0 8.457-3.789 8.457-8.46s-3.789-8.462-8.457-8.462h-37.629v-20.539c0-4.671-3.789-8.46-8.46-8.46-4.668 0-8.458 3.789-8.458 8.46v20.54h-37.628c-4.668 0-8.457 3.789-8.457 8.46s3.789 8.461 8.457 8.461h11.66c1.863 17.864 9.566 34.008 21.152 46.512a63.681 63.681 0 01-32.812 9.07c-4.668 0-8.457 3.786-8.457 8.457s3.789 8.461 8.457 8.461c17.117 0 32.996-5.351 46.085-14.453 13.094 9.102 28.973 14.453 46.09 14.453a8.459 8.459 0 000-16.918 63.606 63.606 0 01-32.812-9.07c11.586-12.504 19.289-28.648 21.152-46.512zm-46.09 35.942c-9.253-9.606-15.539-22.078-17.378-35.942h34.761c-1.84 13.864-8.125 26.336-17.382 35.942zm0 0"})))}))`
  width: 100px;
  height: 100px;

  path {
    fill: ${({theme:e})=>e.colors.darkBlue};
  }
`,Object.defineProperty,Object.defineProperties,Object.getOwnPropertyDescriptors,Object.getOwnPropertySymbols,Object.prototype.hasOwnProperty,Object.prototype.propertyIsEnumerable,D.borderRadius.small,o.ZP.div`
  display: flex;
  cursor: move;
  justify-content: space-between;
  align-items: center;
  padding: 11px ${({theme:e})=>e.padding.default};
  background-color: ${({theme:e})=>e.colors.darkBlue};
  flex: 0 0 auto;
  opacity: 1 !important;

  * {
    user-select: none;
  }
`,o.ZP.div``,o.ZP.div`
  display: flex;
  flex-direction: column;
  overflow: hidden;
  flex-grow: 1;
  background-color: ${({theme:e})=>e.colors.white};
  opacity: ${({transparent:e})=>e?"0":"1"};
  transition: opacity 0.1s ease-in-out;
`,o.ZP.div`
  text-align: center;
  display: flex;
  flex-direction: column;
  padding: 40px 40px 0 40px;
`,o.ZP.div`
  width: 80px;
  height: 80px;
  display: flex;
  background-color: rgba(0, 129, 255, 0.15);
  border-radius: 50%;
  margin: auto;
`,(0,o.ZP)(I)`
  color: ${({theme:e})=>e.colors.darkGrey};
`,o.ZP.img`
  margin: auto;
`;var ct=r(7563);Object.defineProperty,Object.defineProperties,Object.getOwnPropertyDescriptors,Object.getOwnPropertySymbols,Object.prototype.hasOwnProperty,Object.prototype.propertyIsEnumerable;const ut=o.vJ`
  @font-face {
    font-family: "Neuton";
    src: local("Neuton"),
    url("https://fonts.gstatic.com/s/neuton/v13/UMBTrPtMoH62xUZCz4g6.woff2") format("woff2");
  }

  @font-face {
    font-family: "Nunito Sans";
    src: local("Nunito Sans"),
    url("https://fonts.gstatic.com/s/nunitosans/v6/pe0qMImSLYBIv1o4X1M8cce9I9s.woff2") format("woff2");
  }

  body, button, h1, h2, h3, h4, h5, h6, a, span, p, div {
    font-family: 'Nunito Sans', -apple-system, 'Neuton', sans-serif;
    line-height: normal;
  }

  p {
    margin: 0;
  }

  * {
    
    &::-webkit-scrollbar {
      width: 7px;
      height: 7px;
    }

    &::-webkit-scrollbar-button {
      width: 0;
      height: 0;
    }

    &::-webkit-scrollbar-track {
      background: #e5e5e5;
      border: 0 none #fff;
    }

    &::-webkit-scrollbar-thumb {
      background: rgba(100, 100, 100, 0.3);
      border: 0 none #fff;
      border-radius: 3px;

      &:hover {
        background: rgba(100, 100, 100, 0.4);
      }

      &:active {
        background: rgba(100, 100, 100, 0.45);
      }
    }

    &::-webkit-scrollbar-corner {
      background: transparent;
    }
  }
`;var dt,gt,pt;function mt(){return(mt=Object.assign||function(e){for(var t=1;t<arguments.length;t++){var r=arguments[t];for(var n in r)Object.prototype.hasOwnProperty.call(r,n)&&(e[n]=r[n])}return e}).apply(this,arguments)}function ht(){return(ht=Object.assign||function(e){for(var t=1;t<arguments.length;t++){var r=arguments[t];for(var n in r)Object.prototype.hasOwnProperty.call(r,n)&&(e[n]=r[n])}return e}).apply(this,arguments)}o.vJ`
  @font-face {
    font-family: "Neuton";
    src: local("Neuton"),
    url("https://fonts.gstatic.com/s/neuton/v13/UMBTrPtMoH62xUZCz4g6.woff2") format("woff2");
  }

  @font-face {
    font-family: "Nunito Sans";
    src: local("Nunito Sans"),
    url("https://fonts.gstatic.com/s/nunitosans/v6/pe0qMImSLYBIv1o4X1M8cce9I9s.woff2") format("woff2");
  }
  
  #h10-style-container {
    button, h1, h2, h3, h4, h5, h6, a, span, p, div {
      font-family: 'Nunito Sans', -apple-system, 'Neuton', sans-serif;
      line-height: normal;
      letter-spacing: 0;
    }

    p {
      margin: 0;
    }

    * {

      &::-webkit-scrollbar {
        width: 7px;
        height: 7px;
      }

      &::-webkit-scrollbar-button {
        width: 0;
        height: 0;
      }

      &::-webkit-scrollbar-track {
        background: #e5e5e5;
        border: 0 none #fff;
      }

      &::-webkit-scrollbar-thumb {
        background: rgba(100, 100, 100, 0.3);
        border: 0 none #fff;
        border-radius: 3px;

        &:hover {
          background: rgba(100, 100, 100, 0.4);
        }

        &:active {
          background: rgba(100, 100, 100, 0.45);
        }
      }

      &::-webkit-scrollbar-corner {
        background: transparent;
      }
    }
  }
`,o.ZP.span`
  text-decoration: ${({discount:e})=>e?"line-through":"unset"};
`,o.ZP.div`
  color: ${({theme:e})=>e.colors.darkGrey};
  padding: 40px 40px 0 40px;
`,o.ZP.div`
  text-align: center;
  margin-bottom: 40px;
`,o.ZP.div`
  display: grid;
  grid-template-columns: 1fr repeat(2, 131px);
`;const wt=(0,o.ZP)(I)`
  padding: ${({theme:e})=>e.padding.default} 24px;
  border-bottom: 1px solid ${({theme:e})=>e.colors.lightGrey};
  position: relative;

  sup {
    position: absolute;
    font-size: 10px;
    font-weight: bold;
    top: unset;
    line-height: initial;
  }
`,ft=((0,o.ZP)(wt)`
  color: ${({theme:e})=>e.colors.darkBlue};
`,(0,o.ZP)(wt)`
  text-align: center;
`);var bt,vt,yt,Mt;(0,o.ZP)(ft)`
  color: ${({theme:e})=>e.colors.darkBlue};
`,(0,o.ZP)(ft)`
  color: ${({theme:e})=>e.colors.white};
  background-color: ${({theme:e})=>e.colors.darkBlue};
  border-bottom: 1px solid #ebf0f261;
`,(0,o.ZP)((function(e){return a.createElement("svg",mt({xmlns:"http://www.w3.org/2000/svg",width:13,height:10},e),dt||(dt=a.createElement("path",{fill:"#fff",d:"M11.613.1L4.135 7.57 1.387 4.827a.34.34 0 00-.483 0L.1 5.629a.341.341 0 000 .482L3.893 9.9c.134.132.35.132.483 0L12.9 1.384a.341.341 0 000-.482L12.096.1a.342.342 0 00-.483 0",fillRule:"evenodd"})))}))`
  fill: ${({theme:e})=>e.colors.white};
  display: inline-block;
  width: 15px;
  height: 15px;
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
`,(0,o.ZP)((function(e){return a.createElement("svg",ht({width:10,height:10,fill:"none",xmlns:"http://www.w3.org/2000/svg"},e),gt||(gt=a.createElement("g",{clipPath:"url(#icon-close-alt-blue_svg__clip0)"},a.createElement("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M9.775 1.469L6.267 4.977l3.508 3.507a.607.607 0 010 .86l-.43.43a.607.607 0 01-.86 0L4.977 6.268 1.469 9.775a.607.607 0 01-.86 0l-.43-.43a.607.607 0 010-.86l3.508-3.508L.179 1.469a.607.607 0 010-.86l.43-.43a.607.607 0 01.86 0l3.508 3.508L8.485.179a.607.607 0 01.86 0l.43.43a.616.616 0 010 .86z",fill:"#003873"}))),pt||(pt=a.createElement("defs",null,a.createElement("clipPath",{id:"icon-close-alt-blue_svg__clip0"},a.createElement("path",{fill:"#fff",d:"M0 0h10v10H0z"})))))}))`
  fill: ${({theme:e})=>e.colors.darkBlue};
  display: inline-block;
  width: 10px;
  height: 10px;
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
`,(vt=bt||(bt={})).AlaCarte="Helium10_ALaCarte",vt.AlaCarteAnnual="Helium10_ALaCarteAnnual",vt.Diamond="Helium10_Diamond",vt.DiamondAnnual="Helium10_DiamondAnnual",vt.Elite="Helium10_Elite",vt.Free="Helium10_Free",vt.Gold="Helium10_Gold",vt.GoldAnnual="Helium10_GoldAnnual",vt.Platinum="Helium10_Platinum",vt.PlatinumAnnual="Helium10_PlatinumAnnual",vt.PlatinumFastAction="Helium10_Platinum_FastAction",vt.Enterprise="Helium10_Enterprise",vt.Starter="Helium10_Starter",vt.StarterAnnual="Helium10_StarterAnnual",(Mt=yt||(yt={}))[Mt.Diamond=199]="Diamond",Mt[Mt.Free=0]="Free",Mt[Mt.Platinum=99]="Platinum",Mt[Mt.Starter=39]="Starter",bt.Free,yt.Free,bt.Starter,yt.Starter,bt.Platinum,yt.Platinum,Object.defineProperty,Object.getOwnPropertySymbols,Object.prototype.hasOwnProperty,Object.prototype.propertyIsEnumerable,o.ZP.div`
  padding-bottom: 30px;
`,o.ZP.div`
  display: flex;
  align-items: center;
  justify-content: center;
  padding-top: ${({theme:e})=>e.padding.large};
  padding-bottom: ${({theme:e})=>e.padding.footerBottom};
`,o.ZP.div`
  display: flex;
  justify-content: space-around;
  align-items: center;
  margin: auto;
`,o.ZP.div`
  display: flex;
  align-items: center;
  flex-direction: column;
`,o.ZP.div`
  padding: 24px 0;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  text-align: center;
`,(0,o.ZP)(I)`
  padding-bottom: ${({theme:e})=>e.padding.large};
`;var xt=r(9446);const zt=[{point:49,color:"#e74c3c"},{point:87,color:"#ffbc00"},{point:100,color:"#157846"}];(0,a.memo)((({value:e,maxValue:t=100,title:r,backgroundColor:n="#f1f3f6",color:o,labelStyle:i,lineWidth:l=16,customColors:s=zt,className:u})=>{const d=r||(({value:e,locale:t=c.locale,options:r})=>{try{return null==e?"n/a":new Intl.NumberFormat(t,r).format(e)}catch(e){return"n/a"}})({value:e,options:{minimumFractionDigits:0}}),g=e/t*100,p=o||((e,t)=>{let r=null;for(let n=0;n<t.length;n++)if(e<=t[n].point){r=t[n].color;break}return r||t[t.length-1].color})(e,s),m=(0,a.useMemo)((()=>({fontSize:36,fill:p,fontWeight:500})),[p]);return a.createElement(xt.PieChart,{data:[{value:e,title:d,key:1,color:p}],reveal:g,lineWidth:l,animate:!0,rounded:!0,startAngle:165,lengthAngle:210,label:({dataEntry:e})=>e.title,labelStyle:i||m,labelPosition:15,viewBoxSize:[100,70],background:n,className:u})})),Math.PI,o.ZP.circle`
  stroke-dashoffset: ${e=>e.range};
  stroke-dasharray: ${e=>e.circumference};
  stroke-width: 9px;
  stroke: ${({progress:e,theme:{colors:t}})=>e>=75&&t.green||e>=50&&t.yellow||t.lightRed};
  stroke-linecap: round;
  fill: none;
  transition: 0.9s ease;
`,o.ZP.circle`
  stroke: #cbcbcb;
`,o.ZP.span`
  position: absolute;
  top: 50%;
  left: 50%;
  font-weight: bold;
  font-size: 14px;
  transform: translate(-50%, -50%);
`,o.ZP.svg`
  transform: rotate(-90deg);
  width: 100%;
  height: 100%;
`,o.ZP.div`
  position: relative;
  flex-direction: column;
  display: flex;
  width: 55px;
  height: 55px;
  flex-shrink: 0;
`,Object.defineProperty,Object.getOwnPropertySymbols,Object.prototype.hasOwnProperty,Object.prototype.propertyIsEnumerable,o.ZP.div`
  position: absolute;
  top: 0;
  left: 0;
  height: 100%;
  display: block;
  overflow: hidden;
  width: ${({rating:e,maxRating:t})=>{return null!=(r=e)&&"number"==typeof r&&-1!==r?5*Math.ceil(100*e/t/5):0;var r}}%;
`,o.ZP.div`
  position: relative;
`,o.ZP.div`
  transition: 0.4s;
  opacity: ${({state:e})=>"entered"===e?1:0};
  display: ${({state:e})=>"exited"===e?"none":"block"};
`,o.ZP.div`
  display: flex;
  align-items: center;
  justify-content: center;
  height: ${({withHeight:e})=>e?"auto":0};
  margin: auto;
`;const jt={small:"24px",large:"32px"};var Nt;function Ot(){return(Ot=Object.assign||function(e){for(var t=1;t<arguments.length;t++){var r=arguments[t];for(var n in r)Object.prototype.hasOwnProperty.call(r,n)&&(e[n]=r[n])}return e}).apply(this,arguments)}o.ZP.div`
  width: ${({size:e})=>jt[e]};
  height: ${({size:e})=>jt[e]};
  animation: spin 1.2s infinite linear;
  background: url(${"data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iaXNvLTg4NTktMSI/Pgo8IS0tIEdlbmVyYXRvcjogQWRvYmUgSWxsdXN0cmF0b3IgMTYuMC4wLCBTVkcgRXhwb3J0IFBsdWctSW4gLiBTVkcgVmVyc2lvbjogNi4wMCBCdWlsZCAwKSAgLS0+CjwhRE9DVFlQRSBzdmcgUFVCTElDICItLy9XM0MvL0RURCBTVkcgMS4xLy9FTiIgImh0dHA6Ly93d3cudzMub3JnL0dyYXBoaWNzL1NWRy8xLjEvRFREL3N2ZzExLmR0ZCI+CjxzdmcgdmVyc2lvbj0iMS4xIiBpZD0iQ2FwYV8xIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiB4PSIwcHgiIHk9IjBweCIKCSB3aWR0aD0iNDU2LjgxN3B4IiBoZWlnaHQ9IjQ1Ni44MTdweCIgdmlld0JveD0iMCAwIDQ1Ni44MTcgNDU2LjgxNyIgc3R5bGU9ImVuYWJsZS1iYWNrZ3JvdW5kOm5ldyAwIDAgNDU2LjgxNyA0NTYuODE3OyIKCSB4bWw6c3BhY2U9InByZXNlcnZlIj4KPGc+Cgk8Zz4KCQk8cGF0aCBmaWxsPSIjMDE1MGE0IiBkPSJNMTA5LjY0MSwzMjQuMzMyYy0xMS40MjMsMC0yMS4xMywzLjk5Ny0yOS4xMjUsMTEuOTkxYy03Ljk5Miw4LjAwMS0xMS45OTEsMTcuNzA2LTExLjk5MSwyOS4xMjkKCQkJYzAsMTEuNDI0LDMuOTk2LDIxLjEyOSwxMS45OTEsMjkuMTNjNy45OTgsNy45OTQsMTcuNzA1LDExLjk5MSwyOS4xMjUsMTEuOTkxYzExLjIzMSwwLDIwLjg4OS0zLjk5NywyOC45OC0xMS45OTEKCQkJYzguMDg4LTcuOTkxLDEyLjEzMi0xNy43MDYsMTIuMTMyLTI5LjEzYzAtMTEuNDIzLTQuMDQzLTIxLjEyMS0xMi4xMzItMjkuMTI5QzEzMC41MjksMzI4LjMzNiwxMjAuODcyLDMyNC4zMzIsMTA5LjY0MSwzMjQuMzMyeiIKCQkJLz4KCQk8cGF0aCBmaWxsPSIjMDE1MGE0IiBkPSJNMTAwLjUwNSwyMzcuNTQyYzAtMTIuNTYyLTQuNDcxLTIzLjMxMy0xMy40MTgtMzIuMjY3Yy04Ljk0Ni04Ljk0Ni0xOS43MDItMTMuNDE4LTMyLjI2NC0xMy40MTgKCQkJYy0xMi41NjMsMC0yMy4zMTcsNC40NzMtMzIuMjY0LDEzLjQxOGMtOC45NDUsOC45NDctMTMuNDE3LDE5LjcwMS0xMy40MTcsMzIuMjY3YzAsMTIuNTYsNC40NzEsMjMuMzA5LDEzLjQxNywzMi4yNTgKCQkJYzguOTQ3LDguOTQ5LDE5LjcwMSwxMy40MjIsMzIuMjY0LDEzLjQyMmMxMi41NjIsMCwyMy4zMTgtNC40NzMsMzIuMjY0LTEzLjQyMkM5Ni4wMzQsMjYwLjg1NywxMDAuNTA1LDI1MC4xMDIsMTAwLjUwNSwyMzcuNTQyeiIKCQkJLz4KCQk8cGF0aCBmaWxsPSIjMDE1MGE0IiBkPSJNMzY1LjQ1NCwxMzIuNDhjNi4yNzYsMCwxMS42NjItMi4yNCwxNi4xMjktNi43MTFjNC40NzMtNC40NzUsNi43MTQtOS44NTQsNi43MTQtMTYuMTM0CgkJCWMwLTYuMjgzLTIuMjQxLTExLjY1OC02LjcxNC0xNi4xM2MtNC40Ny00LjQ3NS05Ljg1My02LjcxMS0xNi4xMjktNi43MTFjLTYuMjgzLDAtMTEuNjYzLDIuMjQtMTYuMTM2LDYuNzExCgkJCWMtNC40Nyw0LjQ3My02LjcwNyw5Ljg0Ny02LjcwNywxNi4xM3MyLjIzNywxMS42NTksNi43MDcsMTYuMTM0QzM1My43OTEsMTMwLjI0NCwzNTkuMTcxLDEzMi40OCwzNjUuNDU0LDEzMi40OHoiLz4KCQk8cGF0aCBmaWxsPSIjMDE1MGE0IiBkPSJNMTA5LjY0NCw1OS4zODhjLTEzLjg5NywwLTI1Ljc0NSw0LjkwMi0zNS41NDgsMTQuNzAzYy05LjgwNCw5LjgwMS0xNC43MDMsMjEuNjUtMTQuNzAzLDM1LjU0NAoJCQljMCwxMy44OTksNC44OTksMjUuNzQzLDE0LjcwMywzNS41NDhjOS44MDYsOS44MDQsMjEuNjU0LDE0LjcwNSwzNS41NDgsMTQuNzA1czI1Ljc0My00LjkwNCwzNS41NDQtMTQuNzA1CgkJCWM5LjgwMS05LjgwNSwxNC43MDMtMjEuNjUyLDE0LjcwMy0zNS41NDhjMC0xMy44OTQtNC45MDItMjUuNzQzLTE0LjcwMy0zNS41NDRDMTM1LjM4Nyw2NC4yOSwxMjMuNTM4LDU5LjM4OCwxMDkuNjQ0LDU5LjM4OHoiLz4KCQk8cGF0aCBmaWxsPSIjMDE1MGE0IiBkPSJNNDM5LjY4NCwyMTguMTI1Yy01LjMyOC01LjMzLTExLjc5OS03Ljk5Mi0xOS40MS03Ljk5MmMtNy42MTgsMC0xNC4wODksMi42NjItMTkuNDE3LDcuOTkyCgkJCWMtNS4zMjUsNS4zMy03Ljk4NywxMS44MDMtNy45ODcsMTkuNDIxYzAsNy42MSwyLjY2MiwxNC4wOTIsNy45ODcsMTkuNDFjNS4zMzEsNS4zMzIsMTEuNzk5LDcuOTk0LDE5LjQxNyw3Ljk5NAoJCQljNy42MTEsMCwxNC4wODYtMi42NjIsMTkuNDEtNy45OTRjNS4zMzItNS4zMjQsNy45OTEtMTEuOCw3Ljk5MS0xOS40MUM0NDcuNjc1LDIyOS45MzIsNDQ1LjAyLDIyMy40NTgsNDM5LjY4NCwyMTguMTI1eiIvPgoJCTxwYXRoIGZpbGw9IiMwMTUwYTQiIGQ9Ik0zNjUuNDU0LDMzMy40NzNjLTguNzYxLDAtMTYuMjc5LDMuMTM4LTIyLjU2Miw5LjQyMWMtNi4yNzYsNi4yNzYtOS40MTgsMTMuNzk4LTkuNDE4LDIyLjU1OQoJCQljMCw4Ljc1NCwzLjE0MiwxNi4yNzYsOS40MTgsMjIuNTZjNi4yODMsNi4yODIsMTMuODAyLDkuNDE3LDIyLjU2Miw5LjQxN2M4Ljc1NCwwLDE2LjI3Mi0zLjE0MSwyMi41NTUtOS40MTcKCQkJYzYuMjgzLTYuMjgzLDkuNDIyLTEzLjgwMiw5LjQyMi0yMi41NmMwLTguNzYxLTMuMTM5LTE2LjI3NS05LjQyMi0yMi41NTlDMzgxLjcyNywzMzYuNjEsMzc0LjIwOCwzMzMuNDczLDM2NS40NTQsMzMzLjQ3M3oiLz4KCQk8cGF0aCBmaWxsPSIjMDE1MGE0IiBkPSJNMjM3LjU0NywzODMuNzE3Yy0xMC4wODgsMC0xOC43MDIsMy41NzYtMjUuODQ0LDEwLjcxNWMtNy4xMzUsNy4xMzktMTAuNzA1LDE1Ljc0OC0xMC43MDUsMjUuODM3CgkJCXMzLjU2NiwxOC42OTksMTAuNzA1LDI1LjgzN2M3LjE0Miw3LjEzOSwxNS43NTIsMTAuNzEyLDI1Ljg0NCwxMC43MTJjMTAuMDg5LDAsMTguNjk5LTMuNTczLDI1LjgzOC0xMC43MTIKCQkJYzcuMTM5LTcuMTM4LDEwLjcwOC0xNS43NDgsMTAuNzA4LTI1LjgzN3MtMy41NjktMTguNjk4LTEwLjcwOC0yNS44MzdTMjQ3LjYzNiwzODMuNzE3LDIzNy41NDcsMzgzLjcxN3oiLz4KCQk8cGF0aCBmaWxsPSIjMDE1MGE0IiBkPSJNMjM3LjU0NywwYy0xNS4yMjUsMC0yOC4xNzQsNS4zMjctMzguODM0LDE1Ljk4NmMtMTAuNjU3LDEwLjY2LTE1Ljk4NiwyMy42MDYtMTUuOTg2LDM4LjgzMgoJCQljMCwxNS4yMjcsNS4zMjcsMjguMTY3LDE1Ljk4NiwzOC44MjhjMTAuNjYsMTAuNjU3LDIzLjYwNiwxNS45ODcsMzguODM0LDE1Ljk4N2MxNS4yMzIsMCwyOC4xNzItNS4zMjcsMzguODI4LTE1Ljk4NwoJCQljMTAuNjU2LTEwLjY1NiwxNS45ODUtMjMuNjAxLDE1Ljk4NS0zOC44MjhjMC0xNS4yMjUtNS4zMjktMjguMTY4LTE1Ljk4NS0zOC44MzJDMjY1LjcxOSw1LjMzLDI1Mi43NzksMCwyMzcuNTQ3LDB6Ii8+Cgk8L2c+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPC9zdmc+Cg=="}) no-repeat center center;
  background-size: cover;

  @keyframes spin {
    0% {
      -moz-transform: rotateZ(0deg);
      -webkit-transform: rotateZ(0deg);
      -o-transform: rotateZ(0deg);
      -ms-transform: rotateZ(0deg);
    }
    100% {
      -moz-transform: rotateZ(360deg);
      -webkit-transform: rotateZ(360deg);
      -o-transform: rotateZ(360deg);
      -ms-transform: rotateZ(360deg);
    }
  }
`,o.ZP.div`
  overflow: hidden;
`,o.ZP.div`
  padding: 24px 16px;
  cursor: pointer;
  border-top: 1px solid #e4e5e7;
  display: flex;
  align-items: center;
  justify-content: space-between;
`,o.ZP.div`
  font-size: 14px;
  font-weight: bold;
  color: #343a40;
`,o.ZP.div`
  height: ${({open:e,itemHeight:t})=>e?t+"px":0};
  overflow: hidden;
  transition: all 0.3s;
  padding: 0 16px ${({open:e})=>e?"24px":0};
`,(0,o.ZP)((function(e){return a.createElement("svg",Ot({xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 448 512"},e),Nt||(Nt=a.createElement("path",{d:"M6.101 359.293L25.9 379.092c4.686 4.686 12.284 4.686 16.971 0L224 198.393l181.13 180.698c4.686 4.686 12.284 4.686 16.971 0l19.799-19.799c4.686-4.686 4.686-12.284 0-16.971L232.485 132.908c-4.686-4.686-12.284-4.686-16.971 0L6.101 342.322c-4.687 4.687-4.687 12.285 0 16.971z"})))}))`
  width: 20px;
  height: 10px;
  transform: rotate(${({open:e})=>e?0:180}deg);
  transition: transform 0.3s;

  path {
    fill: #0081ff;
  }
`,o.ZP.div``,Object.defineProperty,Object.getOwnPropertySymbols,Object.prototype.hasOwnProperty,Object.prototype.propertyIsEnumerable,o.ZP.div``,o.ZP.div`
  display: inline-block;
`,o.ZP.div`
  display: flex;
  justify-content: center;
  align-items: center;
  width: 100%;
  height: 150px;
`,o.ZP.img`
  max-width: 130px;
  max-height: 130px;
  margin-top: 10px;
`,o.ZP.div`
  display: flex;
  padding: 10px 0;
  font-size: ${({theme:e})=>e.fontSize.extraSmall};
  font-weight: bold;
  margin: 0 16px;
  word-break: break-word;
`,o.ZP.div`
  margin: 0 16px 8px;
  display: flex;
  align-items: center;
  justify-content: space-between;
`,o.ZP.div`
  display: flex;
  justify-content: center;
  align-items: center;
  height: 48px;
  border-top: 1px solid ${e=>e.theme.colors.lightGrey};
  color: ${e=>e.theme.colors.darkBlue};
  font-size: ${({theme:e})=>e.fontSize.headerLarge};
  font-weight: bold;
`,o.ZP.div`
  display: inline-block;
  margin-left: 8px;
  margin-top: 4.5px;
  font-size: ${({theme:e})=>e.fontSize.extraSmall};
  font-weight: 600;
`,o.ZP.div`
  width: 200px;
  box-shadow: 0 2px 4px 0 rgba(0, 0, 0, 0.25);
  background: ${({theme:e})=>e.colors.white};
  color: ${({theme:e})=>e.colors.darkGrey};
`,r(184);var Dt=r(8840),At=r.n(Dt),Pt=r(2929),It=r.n(Pt),Ct=r(195),Et=r.n(Ct),St=r(9662),Lt=r.n(St),Tt=r(8393),kt=r.n(Tt);r(5708),kt()(At()),Lt()(At()),It()(At()),Et()(At()),Object.defineProperty,Object.defineProperties,Object.getOwnPropertyDescriptors,Object.getOwnPropertySymbols,Object.prototype.hasOwnProperty,Object.prototype.propertyIsEnumerable,o.ZP.div``,o.ZP.label`
  display: flex;
  cursor: pointer;
`;const Zt=o.ZP.div`
  width: 16px;
  height: 16px;
  border-radius: 8px;
  border: 1px solid ${({theme:e})=>e.colors.middleGrey};
  position: relative;
  top: 2px;
  box-sizing: border-box;
  transition: all 0.15s ease-in-out;
`,Bt=(o.ZP.input`
  display: none;

  &:checked + ${Zt} {
    border: 5px solid ${({theme:e})=>e.colors.blue};
  }

  &:checked:disabled + ${Zt} {
    border: 5px solid ${({theme:e})=>e.colors.middleGrey};
  }
`,o.ZP.span`
  padding-left: 10px;
`,()=>{const[e,t]=(0,a.useState)(bt.Free);return(0,a.useEffect)((()=>{var e,r,n;(null==(e=null==chrome?void 0:chrome.runtime)?void 0:e.id)?null==(n=null==(r=null==chrome?void 0:chrome.storage)?void 0:r.local)||n.get(["subscription"],(e=>{t(e.subscription||bt.Free)})):t((null==localStorage?void 0:localStorage.getItem("subscription"))||bt.Free)}),[]),{plan:e}});o.ZP.iframe`
  width: 100%;
  height: 440px;
  border: none;
`,(0,o.ZP)(j)`
  color: ${({theme:e})=>e.colors.white};
`,Object.defineProperty,Object.getOwnPropertySymbols,Object.prototype.hasOwnProperty,Object.prototype.propertyIsEnumerable,o.ZP.div`
  cursor: pointer;
  display: flex;
  align-items: center;
`,o.ZP.img`
  width: 100%;
  height: auto;
  max-width: 87px;
  max-height: 19px;
`,Object.defineProperty,Object.getOwnPropertySymbols,Object.prototype.hasOwnProperty,Object.prototype.propertyIsEnumerable,o.ZP.div`
  padding: 24px;
`,o.ZP.div``,o.ZP.div`
  overflow: hidden;
  transition: height 0.2s ease;
  height: ${({height:e,open:t,auto:r})=>t?r?"auto":e+"px":0};
`,o.ZP.div`
  padding-top: 16px;
`,r(9852);const Gt={com:"0 93.38843%",ad:"0 .413223%",ae:"0 .826446%",af:"0 1.239669%",ag:"0 1.652893%",ai:"0 2.066116%",al:"0 2.479339%",am:"0 2.892562%",an:"0 3.305785%",ao:"0 3.719008%",aq:"0 4.132231%",ar:"0 4.545455%",as:"0 4.958678%",at:"0 5.371901%",au:"0 5.785124%",aw:"0 6.198347%",az:"0 6.61157%",ba:"0 7.024793%",bb:"0 7.438017%",bd:"0 7.85124%",be:"0 8.264463%",bf:"0 8.677686%",bg:"0 9.090909%",bh:"0 9.504132%",bi:"0 9.917355%",bj:"0 10.330579%",bm:"0 10.743802%",bn:"0 11.157025%",bo:"0 11.570248%",br:"0 11.983471%",bs:"0 12.396694%",bt:"0 12.809917%",bv:"0 13.22314%",bw:"0 13.636364%",by:"0 14.049587%",bz:"0 14.46281%",ca:"0 14.876033%",cc:"0 15.289256%",cd:"0 15.702479%",cf:"0 16.115702%",cg:"0 16.528926%",ch:"0 16.942149%",ci:"0 17.355372%",ck:"0 17.768595%",cl:"0 18.181818%",cm:"0 18.595041%",cn:"0 19.008264%",zh:"0 19.008264%",co:"0 19.421488%",cr:"0 19.834711%",cu:"0 20.247934%",cv:"0 20.661157%",cx:"0 21.07438%",cy:"0 21.487603%",cz:"0 21.900826%",de:"0 22.31405%",dj:"0 22.727273%",dk:"0 23.140496%",dm:"0 23.553719%",do:"0 23.966942%",dz:"0 24.380165%",ec:"0 24.793388%",ee:"0 25.206612%",eg:"0 25.619835%",eh:"0 26.033058%",er:"0 26.446281%",es:"0 26.859504%",et:"0 27.272727%",fi:"0 27.68595%",fj:"0 28.099174%",fk:"0 28.512397%",fm:"0 28.92562%",fo:"0 29.338843%",fr:"0 29.752066%",ga:"0 30.165289%",gd:"0 30.578512%",ge:"0 30.991736%",gf:"0 31.404959%",gh:"0 31.818182%",gi:"0 32.231405%",gl:"0 32.644628%",gm:"0 33.057851%",gn:"0 33.471074%",gp:"0 33.884298%",gq:"0 34.297521%",gr:"0 34.710744%",gs:"0 35.123967%",gt:"0 35.53719%",gu:"0 35.950413%",gw:"0 36.363636%",gy:"0 36.77686%",hk:"0 37.190083%",hm:"0 37.603306%",hn:"0 38.016529%",hr:"0 38.429752%",ht:"0 38.842975%",hu:"0 39.256198%",id:"0 39.669421%",ie:"0 40.082645%",il:"0 40.495868%",in:"0 40.909091%",io:"0 41.322314%",iq:"0 41.735537%",ir:"0 42.14876%",is:"0 42.561983%",it:"0 42.975207%",jm:"0 43.38843%",jo:"0 43.801653%",jp:"0 44.214876%",ke:"0 44.628099%",kg:"0 45.041322%",kh:"0 45.454545%",ki:"0 45.867769%",km:"0 46.280992%",kn:"0 46.694215%",kp:"0 47.107438%",kr:"0 47.520661%",kw:"0 47.933884%",ky:"0 48.347107%",kz:"0 48.760331%",la:"0 49.173554%",lb:"0 49.586777%",lc:"0 50%",li:"0 50.413223%",lk:"0 50.826446%",lr:"0 51.239669%",ls:"0 51.652893%",lt:"0 52.066116%",lu:"0 52.479339%",lv:"0 52.892562%",ly:"0 53.305785%",ma:"0 53.719008%",mc:"0 54.132231%",md:"0 54.545455%",me:"0 54.958678%",mg:"0 55.371901%",mh:"0 55.785124%",mk:"0 56.198347%",ml:"0 56.61157%",mm:"0 57.024793%",mn:"0 57.438017%",mo:"0 57.85124%",mp:"0 58.264463%",mq:"0 58.677686%",mr:"0 59.090909%",ms:"0 59.504132%",mt:"0 59.917355%",mu:"0 60.330579%",mv:"0 60.743802%",mw:"0 61.157025%",mx:"0 61.570248%",my:"0 61.983471%",mz:"0 62.396694%",na:"0 62.809917%",nc:"0 63.22314%",ne:"0 63.636364%",nf:"0 64.049587%",ng:"0 64.46281%",ni:"0 64.876033%",nl:"0 65.289256%",no:"0 65.702479%",np:"0 66.115702%",nr:"0 66.528926%",nu:"0 66.942149%",nz:"0 67.355372%",om:"0 67.768595%",pa:"0 68.181818%",pe:"0 68.595041%",pf:"0 69.008264%",pg:"0 69.421488%",ph:"0 69.834711%",pk:"0 70.247934%",pl:"0 70.661157%",pm:"0 71.07438%",pn:"0 71.487603%",pr:"0 71.900826%",pt:"0 72.31405%",pw:"0 72.727273%",py:"0 73.140496%",qa:"0 73.553719%",re:"0 73.966942%",ro:"0 74.380165%",rs:"0 74.793388%",ru:"0 75.206612%",rw:"0 75.619835%",sa:"0 76.033058%",sb:"0 76.446281%",sc:"0 76.859504%",sd:"0 77.272727%",se:"0 77.68595%",sg:"0 78.099174%",sh:"0 78.512397%",si:"0 78.92562%",sj:"0 79.338843%",sk:"0 79.752066%",sl:"0 80.165289%",sm:"0 80.578512%",sn:"0 80.991736%",so:"0 81.404959%",sr:"0 81.818182%",ss:"0 82.231405%",st:"0 82.644628%",sv:"0 83.057851%",sy:"0 83.471074%",sz:"0 83.884298%",tc:"0 84.297521%",td:"0 84.710744%",tf:"0 85.123967%",tg:"0 85.53719%",th:"0 85.950413%",tj:"0 86.363636%",tk:"0 86.77686%",tl:"0 87.190083%",tm:"0 87.603306%",tn:"0 88.016529%",to:"0 88.429752%",tp:"0 88.842975%",tr:"0 89.256198%",tt:"0 89.669421%",tv:"0 90.082645%",tw:"0 90.495868%",ty:"0 90.909091%",tz:"0 91.322314%",ua:"0 91.735537%",ug:"0 92.14876%",gb:"0 92.561983%",uk:"0 92.561983%",en:"0 92.561983%",um:"0 92.975207%",us:"0 93.38843%",uy:"0 93.801653%",uz:"0 94.214876%",va:"0 94.628099%",vc:"0 95.041322%",ve:"0 95.454545%",vg:"0 95.867769%",vi:"0 96.280992%",vn:"0 96.694215%",vu:"0 97.107438%",wf:"0 97.520661%",ws:"0 97.933884%",ye:"0 98.347107%",za:"0 98.760331%",zm:"0 99.173554%",zr:"0 99.586777%",zw:"0 100%"},Rt="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACwAABx6CAMAAABT87djAAAC0FBMVEVHcEz8blE2SqFDSlT1+PtSwWI7r9rtVWVHWKlXqGPS0dRKidz212D/z1Pwh3/8q1dOi5LtVGX+//+zKjjuVWSwsrTot0SMuuLmR1K6V3hHvlZFV6nSs8NXqGNCntz3+fv6z1dRwWGlRHdObb9CSVQwPk6RuOGpRGPTxcyXv3Xpqa/19/pHWKntVWVXqGP///9SwWI7r9pDSlRKidz31mD/z1MBJH4BAWX2///PECmMu+T3vEE7WqLsPlDtSFntT2LvKTT+3wfy1mABfwDuUmT/3VHsRGcCInD11to/Uqk/ht3dKA8CeF42e9H7+vv3AwPbIB7+zjgBAAD80RgRhwD9VF1Gty0xWLL54+UtQZ3wh5HLAwYCesDtGSIBDlXi4+MBJFWlRHY/m0wYN4j0klz88O3+SWX/218wSLRpebkFGaopq9/tYWsyZv7wc370qrFNoljM4fTym6Pc5fHR6Nbq8fM4P03552D/JzcbjEEBMJn0x80GiTBUaK7TJTcgIWH+WGl+kL9AwGPOVmTL1Oj2ur+Txp+irdIjQo69vb7wc2BBo2XbAQopMj5tV5n4vlyQkpO2vtsvSlJNqWO/CjAx8BEqOlR3epIXGXKz27yajFsIlsoZO3FDs2NmrGb/7VKQnMjeNjo90GJfapzvOERTaWcyhu4DUPG2dWL90QEyO3aovF/+/gL10FHfwl9qUVkljRj54ZecV4aDsV6rnX50ueGk064FYbPGrWr5SVLPO0ulyOu2lkt/wYvTz2joz2A7uk1HT4t+k2R9c07Fx09sunzxXDDTxQv4pS6lp6GIx2BPkMezCRmSS1z57AT368FsnuE/uOSAKB7f3RD7gRP76/0UExCVria+nrIpeq+cgw4aOa3Kx5VKsM/GeorAphGVdqROujNNNkVotr5nYxUsZiE3gYHbdYqs8qi4UxAvJxNLp5ZknBNq8VbXZX1QP3CehJUSAAAAK3RSTlMA/f7v7u7u7u7u/u7u7iX+JfXv/aH99+/3/v6h/qGhoaGh7v6h76GhoaBmgP35vAAA39tJREFUeNrsvY97U1W28H+MIFoRKFAtiOp80Xnve9NwsC0lBZoApm3CXDJU7Usa1N6hDW0kTwJJQ7+am9KQhLS9YFt9XgqMQEraeRi8UOpFplAAC4IIhWJ1pAK3+DDoc+Uy/8O79jknyfl99nFkRrALmpzkfLKy9tr7rJxz9t5rE8Q/Z+HJP00iiH9uxpZJRBY8ZiX/s7ezmnl7mv+J4H44S+oVpZPISm2iv6wsDpXF/QiRxX6VlQEvWOZkJPfRnyJYr7KyMkhtVuqjWVmVZGUW6wtSMPWykiTTdBb10s8uBZHVnPoHihFNW5CV5UevMugX9D+CW/o0nWZZmjPY0kzptqJNiq1s5uzmwiAMraVY3j4WXJemtX4xlobrUiQSK0lLJUtJnbgZGYwJVpEdLLgyqYADVzJ/abhSoBi5jSN1omYgk61ahq6Td52VxqxC3Wk46RBKb2UGz9HMFxCVHKF9Rok1vZkUQoplaL8krOUqo02S1OznfrGV1MqYUemXfcmD5UUd/Bw++0/EJHwYgt2kf8rAEhQYiSlPP5qS2sP1E9lSnTkhJdMBnvJoTlpqD+/JZ0l9dYkuLZmTiKdzcGHddOJRfHiCGjjznmkeg8fgMfgffcCqCjKqwpeqwEhMms68WnN673gZ+dUUYDOTXwPwXDkZP4WYrsOF5/6KmIAPjycy1cAT7nd4prywYMOsOgVhwUVmUl6msuGAXisr48ZgKViNn8tH2xSEBTfe2qogbLjnvVxZefgewpn3TPN0fPgFVvhSgh+ewgqMjT0vPiwjL0xB56IvpN948VLjBJas2bfrsZQ8A/CUh1nf9N6lRnaoB3hOWh6bQryQiwvPeYZ4GB9+7IGATQYTTZoMyrDRrTMZDQajSec2KsFH7VaPQWe36wweq/2oArzGTNoNXofDa7CTZiXYTZq7dJ5AwKPrMpONCrCd9Ba5vDqd11XkJe2KsMdj9xoMXrtXGXaTDo/bo9N57B4b6VaAywFxebxej8tN2pRdR9rcBqPR4LaRiq5rNHhI0mO3o0eDcg2Cl1HIBE8blRuSsUgHnrDrioxYrc5YBGJ8UI8UWVhVkFEVvlQFRg6sFHInKcX7lIk9k4jp4Vws+r3c8HRiQuMlPrxhG4gAhuIQmSbeb8mGbT1ndu48k7uNZ0SjKRN+2hqNbEM25B5fWFZWtvB4zzaOEcZGuECA38HGMFvH8bKFSMoWcuhwo46GdSyzt+2kWaCf5FcWA6fM3pD7ZBJeWHZmW9rgNIwM2XCLUtyTYheWHafhWxsoI1KwrnzG7y/S8heWMG/9fka5jg2bykNf0LKWJcxboXITB9aVGy+ufUlU1l40luu4sO5o+CVReu1L4aM6Pqw7OioOjx7VCWHT0ZAIvTZ01CQC68p1/yWg1/6XrlwnBouY/UXaYD6sO/otD1777VGdFGwsD63lSKjcKAnrjmb2cyTzqE4a1kHgZ4mdwwpgU5EndRKt9xSZZGGd0WhmaL3ZaNTJwzqDy0HReofLoOPDmbx3dEV2PdB6vb2IvydToBl+JKIIjhYZdQLN0/lv6QxgNhhsEOyYzjoXTdNuvd4tZNEVfepcNC3ZXm+24E3qit6qTWyvApnV2TkLPVc5Rzs9TVV8aXL6CMKR7SHj20sLCmY1FM4qKCit+taYbfMViEiVjwiNZGc6fAPzabg0ONppJ9urxOACJ1FVgL4WlI80FI5UhTKzzdrE/FJRuIloqtq+aKTTTUZmFRZmjGTbyUgTFEEUriKovgdb1OYIFBYGzAGrg7olXCUOdzYkpbAwtdkgoRkYEdlO7f2gtLR0//75pRs/wNDcfePw50NDn7fd6GBg6u68w2q2mcFmq8Ps8FVW2ippm7tJcqgXndd0M3BTVUFThLQXjWSAN2Cjc2RRQdIbALd+1drqSMFV8xN+c7bx2yrk54I46ekcdRYwfh4gyfOtQ0MszTHS2zkaZKp7/oDPkZk90sTAQ0Otvb3nh8iBpM227Oxvq1DbWLECtY3tlPIqBm7tBeXnh5KwpwGpBaHMAJmf48sI067bb+0FGTrfu5+Bt2+v4rWE0lQBP/D3fvUV4JWlyQIWSEtpBtgx1Eo2Y8Ft6NRxiGzDgQv2R1DEi+wvwIFLTyP4dCkWXLBxc3//5o0FeHDBtiM7thXgwgX79xfgw5zGf+/gJny4iXDiw07Ch20HhC/C5xRGQRGhAqNYyBUVFHJFgrmEQDCfrsOW6cIfIGkR+WmTsYOnGX5UjYYi+PGBB6OO9xPL+4U1ul0Gtydq1+nsUY/b4HIbZWCD1+xyRUlSpyPJqMtl9hpkNXs8gajdFo3a7NGAxyOv2e3x2kivnSTtXtLm9dgNsnAgaiZtZpI020hzNOBWMAM0MwKaZc0wur1s2Ktksyd1P9AMBZQ3I8qGo/JmuLyeaJTCoXger0sBjsKtAqvDYfXaPVF52GT02LvspAduWZCw4TGaZDWjexBRt8PhjoJqj4IZHqB1AZIM6ICVh8EdOoPBHrBaA3aDQec2yp8Eolbs8tpsqGz8E7AJYoeV0RQI6Ixih5XYMWhwi5ypScFg909+wCqEAlVBRlX4UhUYf2FRVEHzzwTOLMeWTOJdFUI8uhJbHuX2lsrLLwCuVSFEhwohnijGlXlPEE/Mw5ZfAPw8Pvw8MQlb9RMo2D3/BJY8j6Ior8fQvCIl/M5FASsHk6LwFuo/FrzlR2jeci80M7pxYUzNtjdSIoSDPMnZv3Hjxv3UQw5/HyG8HqkINRW8owm9I9xDoPfYfwUFQe0iuNrxVzAEaycBD+8U0P/fofdVaeCiiHoo4O58h2CItOZ3Cjjfk9oJDwT70/Dtsao0XhVzFnC+FplB769CD6FI+tsLqiKhlOYqRnP6G98p4Nzngcuv1NfSBXwn+ZopIDw2MQ9sm99Jak4Xj3ozGAHXaSLBlIaqpGEilaJpBxdXtC8SqRR+xF60PyWL+PvEGtIK1IpWbHnjJ26iP+IYxD5S1B6DdODAgreo1SweNwh8myGK2lwNfCmk/vPEZQNW/FagiDTYCHchtriJY/jwMaIBH274+8Mrzq3Ahs9d/o+vsOEV584vefUcHnzuHFJ+Hgde8dX5V79aUXhuyVc4ms9dvoxMOL9kBQ58/jyCv3oVQ/O5aYOF8PbguctfDXLhO6/w5esvb9Mbty/f5uy4Q3wtgF+5yUC3P+NpEYPvLKF131xyRxl+5c7NJde+fuX2kmvKmu9QFty88+XNVxThO0tu3r7z9e2bn127rQy/cu0/lixZcvnanZvXvlaGv7595+bNO7df+fraZzgFTMptLi0Pv3L7tgqYb/MdfPgO0Y0PdxMZ2HZ8nUEQGT1fY0kPsIT/yrLlGLLsip8gfHmC96/k5YnheT7iCv+9fp9Vq/VHRPgrBN+GBUyY90f6BTzBe32R9bOwvv+KPLyA+zOyvl8Ip9/q5/3oaPMEcCSS/EK/MnyFJBfkiVgBskBo8xU/qb2StyCiFcARIXxRm5x1gwEvv+KTGLzYL+a6K1pxWMuqmxScpyUVdafg9eRPAi8QFlDSCtKfJ7Q5IgX7RBqSlG7rArFWJ+HpiGgT7dcq1Qq7PedB04BDSqtY3Qx+BQ7WvAXr+9Mt9YrMkcI/BvqXK8PrBW6ThpPHwHruEUuIhqMr/RG/v79/AT8UXJEIVyJR6QrhW44tKNjhBkbUuzTl109hya/REKqnFmDKU1OIXy/All8TT+HDT/1s4I+x5SlivQ9b1hNTSWyZSowTGfat19r0erHR4ONE0N7WhflDeixY23t+4cLzC4W0CKwfOo/GZp1vxdGs72WGcglU/82wGjNUFVCl66QrRVV1q2pIqpro/XgMqgoyqsKXqsBIVCbQ/TYZuQWXWsfsAXT5XymP3hoeXNXgjjromwUJeXKwMOxBpLW5krQS0opvDaKvR7ci9BmfXxrOAFjm64+5o2iCsHZk3zBIpQSMSPh6qsvZP3IJocOXSFF4mPp6Gz0nXEujw8PNIjAoLTzmDiRnj5OVDNvj58OUn5ivZ2SEYdHMaDZMfb3XxjmSMoaHf0DwYRjElYb5X8/IrEttw8PTEJ3R7Kdh5usdImdTlRmohNOG22iY9pNXdPaNtrlSv5My+vPmZq2VmAb3Wrxmq/jBX9lcWdmMVO/T+lGlINhjk4gUfTdgzjfy3k6S9ganXfHkxg30CKoPIzZVwMJjowGBxTcOUvQl1DDYfkal5DvZeuP8zeMw7/34tREyrZlVfVEOf6Ovr+/mjZs3mG8SVDeYw3LNjeaMvmvXoJxWUqQhUebYk063Hr/Zd/jatePHr90QaN4oqM4bN4/37Tx840ZfJUnKNP4GdwDxlX03b9487hexmXP8r6KPfzLjxvHDfr43xM1Bcwz8zDmvDJw2h/GOVS4UsMIR3dCsskGGdaijyrUqhS+W+QEU7BIb31QU4MO2sT76n2UffbYBW7IJswohpuqxRfyESnLO4wMPq3DdVHWVoqq678sxJw/8SKd/HuessMxyz3pU82jEVj5j5aMS8jScuP7zYo/eeR3glZr1jiJ3hkZ6YMgUYpxncVQ/OwZwxGHQkf0V6b0WHv00ESIRndE4a70VsRo2YeGPOakIkd7FUdLoANbKZjXOmIYPa95x6r1FHlfABew7Fan9llCEbHeilxZLCm5vj/lINNTTZSPbY+1xTUoxSfqQIRXOoCYJu93uRqPLZDK4XCa3u8W9MgkHIxGww5ITjMSCSXgWSCAKw1S95uisqGckqdkSDGqCqIwRkozRljxKzJ69cj3pdrncJrP/4srZs1OOsGgob2hiJOnUJAtY0U/qTGaXw7s44A9WWPhO04Ti8TTcT7oMDtJoJu2LA9ogXScWSyyY4jWatDdIV5Fj/azGWVeANvupkmuc7WQkZBEOBJqK2Ipm96zrcUSvr6AK5yetTo0QdpU71lsqMloCKyuALveupKxoj7TTdls0bPijb+M5mhznu054PxR6913qbeS2IF1Q1hc8SqxciTygWYneq6hYydSJhtGb0+5P264w0smiiZDxCiFsEaU1zlDQgj2GSsNqtAxsqchpt1RYsEZnWYLOOBl3Bi14MLo168vBgqmWTgY1OZiwtt3nxIQtTqfG6bRgDj+DJqCxKA8/exp/rNrT3Gwk8oqncLORyAkKjIR/QR6WLPAThD9vGUjqQeYvz08sQNiyfoqWxZctW0BcoSD7FSUUHq4QaOsPV7rif1DWnIfgvCujhaNX5A2BhzyA8xbYu6BjeLGdZTf/md5GZuRdic8oDMevpN2C1LCe85itPNrm+GK2zfwPsDWjF+4rnLfFjEhqXpbXztaSx3tOfgujmVuD4pqTruPjye087rcJNC8TRdOa8zieF7g6/W1SmvN4n8tL2Sz8cu577IaUx1XM2WR/lKUZQ1BDwhei7FVsKSM+VSHEH1QI8aEKIV5dgi2vEqGL2BJS5+cF+PACJnxhKfarC4yqQq6qYK7qZ2JsgDcHtghkpQXOX0TkUWJGWPgvPDo6Gha+P4MQDts/2hggA163yIB+4bUVTJYm7QajzmDCuMQzeEhvl8HltZtMGLAZzpGNUdIqMgtbAjaTpNuAawZMjzLi2KyDAhqNoF0IrxEIcp3Z4xbuWEOExYSqFKEQj70vIuvWrRN59zHisTnY8guAn8GHIRsJtmoqG8kzj2EJnY0ERVGNpY2bQI+R+rZafhRFly61fZzcfIzsaavlRVENXNE5K3IO7pGH6ShqCUb8Tk1tIr9GHqYjElzPwQVubVtNDQYM1wfBSHuQl1JQCoaLfdIa1FgEhRSFc3JioRxNbfBUMRZsqQiC/zp4ZkvBlhjZrqlt24MD51ji2phFw6sbSTgHXQ/W5hwsxoDBf5ZYxFmbYJstCYNuHxkHs4trMGDwdsyp0bDrRgYGSyqccGmfLqQcjC45Sef1xNJiHBgufeGuRbpuZOEc6oZCum7kYbiEd0ZilmTdKMA5mjjptyTrRgm2BKkGSNeNEpxsgG3FeLClnYzRdYMDx+AWiMYCh7syjO7E5ISCKxNLazBgsDoENyWgbniw+KmaJuSPQHA4zAsyEieBFie6pWY5eLgW+4rekuiwcK7oufBBTgw9XCtzLmrJOcgOBXtYRgjPRWVh/rmoPPzoAwTXYMJwhNQc7AO6vkYZ7jtVX78zFx4OHlSEAeyr6dm2E54x4JrcM/U7Hz64dMPOemUz6o/31Pf11PT1nMKwuebUwwcB3nmmHssbZ4739eSfOY4D59fvPHO8p6/nIB58fANKmQVbGDBUyc6evr6leNUNDsnNr8dtG+C9UzXYDenUQRWtrqbmwTmsVAUZVeFLVWBUdeKq6pRY1cn23/cCAV0bYcLv70o/KsG75uzcF84M7zst0C6Ed53OhCs/I/zt271LAd61c80aJmPGmvCc92XhXaeTLEqaGJaH39+3hpWNY83OXTLw+6c5OSxA9fvSMFjMvow3Ze6Wg9lWAGw6vQsfNsrCasxQVUBVrlNXKaqqm9OQ5uz6SZuousav7rB64K7o2clId3Kv6/kd+pw0p3ACw86436ozcYcKcBKoysIwCOFhfHiCHJzPgzN/Ms1/kxkTxswYM2PMjJ/+gFUVZFSFL1WBcWy86D9wfJ3RhA+bXPiaja7WFiMuXNLCW6BGEjaWlJRU17eiJ+XOl4eqq6vRQQJPws6XfTzpq69HbRoe+/i79hF7ebJp7in6WuzCJv6uvcR4/vormy4guObDTSIrswjhszVIMOELNUs/PFlzci4WfPLU3E1zP0QPyvDcC4Bt2jQXS/PcTdJLz4yfiy33J/wrfPhXxBRs1ePRueivxmMJWkqJmPTcOCx5DkVR7GHK4yYRz+EPaX5ubID3j58SeEKFEDM/wZaZD/4xeO/gvSpE8JsiJyJDBaRlbNT93y2/aCqKerIVz0XTsUAfFU/JmjaDFUX1+qhYYlhWAdlBRjSHP9t149hzk+0G+UphmWxzF5l0mJr1Adny8c1QoCdwC2h2GfFhrQpvONzYZoARRTp8bxjVeMPsUuMNG34BVcFqzFBVQFWuU1Up6qpbVUNS00RVNX5Vh5WqAxYjFKgKMqrCl6rACCE3O1sx3mZP8FDnolP1AVeRUdbBhiK3Wa+fClGU1OsdXoOMsaYik0evt5L+/02crSNJvT7gllROqyXJHXNnEjPnHtECrfUaU40ZEtgXFTHDGE1FOlrt5pkz4RRi5icp5QZ6GRej2253uygc1NpotZ8w5xufzNxMKffoQLnB5DVD9ehtkDTeUKSLUmpPfDIzdXKSVG52F1EG6rXUFECPgaWWdSYzc+ZmP2nV671ubSoxBWjXgtpKWi3ntOeTuTuQcq2ewjzMs9WaVMs9R5r5CSinGK05qvMG0IY1rZZ/QgXKrfQKPDCz0Is+R9Z9Inn29clmkmnWi03Ud5DaszOl4Jk7aNgBqeapxXus5OZPJOE6GkbKaa+QR+RhvdZMoWbKaBkYmQFVY0P63VG9Vs4MKCC0KIi7Hn3UZTDZHaRfqoCo0q2g2LDYaIMY2QXrAoHrxOFPZh6xQhUC5rajhYbc0Eqs/iPpCkzDMz85UUdXt82st4HRZr3DhlpcXboOk/Ancym1Drs76TXKIajRWVPKk030RCVqc1FXsokiT0MYoZtzsoHQjR/aBKUWHbYGHd34HSjpPqTfp5TTTY86rE74GbVGwWFlZB8r4wmmHdvs6WjAPmB1jHJ0uIwnGLU6yVDAOr6pIGO2FxkUAxJJ/hMKX3BUm+RPQ6mYNJU6F83OVD4TzXbT69FzuqIOTpQSlNKZ18l1qiZfSiZO4nefycD5z/M75uTgiWPw/QDXS4sAPjhZRvhweE2JpEwQwnJnMmPwzw7OVKf5GXx4Oj98ycBU7xInMIYzZc9FrVpnAW/1umxPtiBJ8zG3jSAcRV4yVkCtXtdAr16XnW3zN4hnaQ59W+Ry+BaVMnAOtXpd06B4luamgkS402MNwXJmDSNIbcCfKC1ldKWUMlmaNVVVOdSidRn06nVWyDle1SSRSxnWgYPV6wL06nU2swNWr4N3GsTh7M7OTu4ac+gNeu8gEupROVn04CVYOvwj9NAxqKh5sJkkyX2DGSRZOciy2eEw25DNDjC+MmXzYBaVLWqUJOsYGDLPL4pY7dnJ1euyR3KqGG8geNbg4L40XFCa8AfQMnPIzwVxq6cznCgoZWCrDeBRrSOluZ20d47mMNVdusjncBV9qxmkba4c3nfmzJnhrKTNflsms3od3TYKYpC+IEzb3OzvOP0/f/nL95Ek7GmAr92+fTtV3WijNFFpzma8kXH6ePc3H19MaYaU4YPJ+mc8hvKI0/DID2fObO3o2ZcxqJhnezDr2PDV28M9l1ZlTVOGRy6d2Xl7+Mzp4VEM+POMrOa2MxlZbc1sMxpSJqefAO4+cfpMc2Vb97p1yjYXfncIkmZlDQ8e+i4Np/kG7hEy/N3wd93d8DDMyYbdwAeppxXD3x0CYVjFFOWDdw4dujMolmebZwRjyjA/rbqYFQ0ixyAnYbuo7tQ7x1ip4EXIBl6QkUwyL3QoSknvPtaAIVRgVLW8iKqFS56fV1aGvSTKuKHe/HllmIutjIOrEoovw4GpCxitrbdGkX+CuSeDrnocSgY9QfUBJS/KKR7pnzy5WBTuaK5M4dQXAF/c2jJZFH5xw8MdWVT2NhbfYpxcXCYCP5y7YevW3O7PM7RJXq//M1w4DqESCzRT6zhv3bChu63ZT/Nmr93ugStTvkdB87ZtG3KZD3Qjg6Kuo11FRV1Frii60GPzTxAHj59Bi1/T+KWe9zpG3V6P1+v1ugEOeKEGhnrn0QbB2jrF8w4cP9OzYduGDbnvhXUbtk7r6chCS7ub7Xqt0aVneZRaiActOQQj3HO3betpDPdk9mzdeiyzLSPD5bAX0cv9InuAT63aA/zBnWfeu2TqMcHq1ZnhrbCi9QhaQZ7tUdYSP/AFB1uMPeHwe+/B34Zw9q3s0c8rqczXyS4/TtvfU13yZPWa8CWd7lK48VJP46VUDViFcHFLybx5RrRKdmNjY25u44z3oMaSNWDlwfNaJ0+GARZw3WnSNf7uVg9dAckamMqDi4urXXAObkTjJh6qRjWQqrHcjizBGkbF8yZXt7hcLdWT4ZMHaI8yX/CiyIJHxcWcxz60WDn1BQ8rr46EaoBqEhsexlpKCfhWaBIvYq+7hAqgYt2l4nu67tLYSKefXyaxCUYRQUPMhTKBaBWVyaLvEhNFLrDhuKpuFbvunpifv5T7P7+lpMRUYpxcz99DwVypn1yCbkGVuEQu/4UwPdjKZGyt/6lhNWawC6gM1+dXt+hahCyCa4RSX9MKfwKZSFxQIcQmFTI20unvNdJJDSxixqYLS5de2CRmhqCAmzZdQLPPLggHwv1K4LpNcz9FE9Vqaj4VDIcT+HnT3JN76Klte07yaT686UJxfV9bRyLR0dZXX8wznAtv2vThnoMdFnpRR0vHwT0fcgznwGDunr6c2mRWutqcvj0cw9nwpgun9hy0XK8AoXN/1cLM41MsU9Iw5bFTA7XOeAyy2wWpfGq1MPOY5cMUDObW1BR/nlxzQgtZ/yBlWe3hejT8cRMXBo/V1Byo8UdiIafTGYr5SLIdsuRBDgPweNKHDAzmgnOLbzgtFRqQigqLM0L6IZtiDpqRWsMYTsFgLj2Z+/B1S2rauyZkJUMV9DT5mhrKcFrzSXomImfqnaXCqSWD1+k59TXUUExpGFLfBa0+Gl7KgilPwHvFfRZObjWYih0/XEwp/jBtBmrBVEG4eeYsFe1+at7mUlYBGdeB6o5a7sTt2c2gmO86phkXH+TaYbH0FbMaNq+6oYgsGiaDF4tWN1MzNW1pmsoqId6QGMOLD+fUIh4adQ7oPSnVRGkf7jnYlgA+J9F2cE+NTOOnTMmv37P0YF/fwaV76vNlD6tk8yves6e4pkbxgFUIBaqCjGj4ys8XD18qo+izj2DJs0hx90tfvIQlj0whXrjV/V+Y9LNwWXor9yIe/Qia3XAr95svvsCFAf8eh2bg3Fs4xUzCWHQKxilmGqaLuVZOWDBclp0+KS+ciSG3dpbBLQLJf0/wZpGcOVAsd3+DA+duyz1YjA0DfRwfzt3Ygw1v2HbmFC68YdvOYlybweDieZje2HBmYXGZjLDhW99vVpAUvAHa9FoFSTVRjKMl1fhxjsPkYYUVDyh4A94hSMG4BzfAL2CHDQgyqsKXqsAIl/8TsYS6LzoxH0fq6ye74L4oHptfbSyZTkzEUtvqgquzCZLwgfwDB9hqqSt6Sc29QzUHgD/Q29vaQl30SWvuHbKS5FBv74H8IbuhJHndPVGaRTI0RJrtzHg+Cbh3KL0KhsetAOfXpFiHPTXeTAI+MERx0QBJOmwetwyMfECZDIMgzQ6b2eXSScIHKB/3Ugv4etEKHgEZM3odjqGh/IlMCW0k6UkObBHCQ/RyEWagzB7Sa7LbjUYJMw7ks5beCBipQThGnZTNoHio1R6lFpiwF3FHxAhgB+modnd1Gd02KFiXy84efsiDDyA44IDxOLqA1RHw2jiDQjkwOJguHumFsXNuaqEUs9EoCveiFmELkJ4AjAoyGQ2GrijJyRaYhg9QTrO5oqS7izHU4A7YoiZRzWCtA4bPugMOb3KIKYw6Ymc4TMH1DqvH7Ybd4AaH15BKWGAScV19rxeGNqFciV6oX8k7VBOpo7faxQx0MupspLtI6hbcRDQfs6XEmJ6I5zZKan4eYo2uhGWa9MhKGC/KVvvTjrq3wcGLxOXoX37xoj9qMIqKy466rRYzS6gvdvT/6U9/0nvekJLFNsL9Bi78hp3owoeNamCDOLxY5E8SVqX57w8v5sO/lYSLiGhKSARrbVFJCRDpJTC0AL/uk1skg7j4TVpA8zcycpFABKZ8ow6+mF6dEX1ObvXGi6wCIm+87qc3xYWIehhJus4jKdF0pbyhWCld92WrkzqseP/vtRmqgoyq8IUCIxVRXY7IRRQYJeIvFRjVXdE/8tJL2KfEz76ELc8Sj+DDj/wC4LXY8gjx8RcfY/7/4mN1c0szVAiMK8CWFwUX6TLysDr4Rej9xvz3ItGtQlSu1KlC1FX32JHChlUFGVXhS+UV/fTKqVG7Nxurj97tipo9Bsw+ekfU7XHbAkVYffQunQMmg7hMWH30HnvU4bF7DTh99NmQjdzrDkSL8DrHDTZ9oMiI1ZOebYsG9FFzAE8zzF3xwswVI1YB7e4oXIfbDZhmmPUB7AIavR67AbuA3oDdjKc5E02jMWPaDN7wRnG9AWbYo3ZcPxsMMJulC7OAZg8UENN1mWhEGNQhXgFdOi12e852RD02L24BTSbKCBPOPPrsqNesh5Po7NPKQmRCbeujXm940y5FQWNOwAwjP82feP46KGDUAQU8hgMzoaARS/N0D1SKG2x+HyMz3iSobrM3EFU2A2XGQ4Ex0GUIY2XGUzXSqRxbJhH/6yNs+V+w6Bi+iGTDplcDs2g0ykt1QNbxWOTPf/ZF4jkVFgVYE2wn/Ts2n9hcR/45zltMS5BWPejXnli3++zZs3Pm7IAM9RYZWBO01q07W4e60/1H1p0lIxyalwpe4/OvPkENdLSSZOWcs6wl1QSwJk7OOUGNiaRmUvrXHbGyu555mn071mlJrQNGZmodDi25Y501ViEBQ9L4szAHVN+Lbt7l2/SkdveOiMUiDlfE/XPqEFyG7lQ79FZy8wl/UAqO+ddVIpi6pe3Qa8nNu61BDQZ8QAlmzBiibuc6tLJmMAWEBenRfUxQLFfApOtgQXpqOXpZ17EqxaFXrhRU3ZtRdeuVq1tVQ1LXRFmNf4dy41d3WMkfsKpCgaogoyp8qcxGwoKzPZw0TmbZ8aJFHj0nTQQnFQB/vKgszB8vKg/zxovKw5nqNP/tsF4FrFehGSawB/SYMJpZ7I6imdWKMIi3y1TkQhvKmmEylcEIc+4DDq0CHNW7dS6vzmiEfiJXQKsEQ2eZgZldrQhrYYI3OsUzwWztqFbJ5qjOQPdRFHm1DkVvQAcM1S/gwfEGJCBwuaDHBst1WofZETWj2fFYNQgTFRzU7Hi8hhS16fGbqONeted/wAGrKsioCl+qAiNRufsQluyuJIi6117GlNfqiN3UxqGrn3129ZACvY6giLtfXgZZclVa613gXqPgu0uWfLnks0OfXZak717+DMxF8GufXf7y7tW7L3+2ZMkhRfguGHD3ZSiwtGrKDAq+evkzavvlQ19+JltCGr56FfBDr9398su0Iw/dPfSaGLxkyeUldw/dBDNSmg99tuTyl3xnMjYv+fLqzc++/DJl893LYNprr4nAh9C6jJdvfnZ5yeW7THm+pEqPtg6xjKH8fBVUL/kBvjhpBbyR/NhnXx7iwuDoy5/98MfLqffTxh/6MvltSfjl16gypsrzWtr4l+/e5ZlBef1u+uvYMMuVrxGiFczyYbrGvzwkDqcLyK7yl8XhtOsEfhZtZVKVIkqDN0WrW1wkGhK2YMLpxo8h6cPqp4aZULAbv3zr1IUvog43MNbhrAFqsbRNhDFGVK57hZUsLbUJWJ+rBYZxQDB/mhliLIXmHK7fQ41SMMFIJ3qNuY6EKF1b23FyDz1KwVjiaqWWuqutPXj4eq1F1IIaGOWE1Oqqa+oRnMjpqDmVSPCUW2phyb49k9HgKV1JScu8Pac6ALa0LaVWpuEOq+ZaMHlPPQxfRnBOHxps3WbhqA0e3lNcbaIsMFbX7OlL1FqoixoY1L5nD2cENliwFFlgpCxoBQvALfQVEIyg7uvLT5tMWTCvBeVHZiwIUqVn4Lba2raO9KD/w3vqKQt0lAUnE4yjmGurWoulNm3BqT2tLrpgYMHSttQuweJuyLW0BeDayXv2HE7USqzATldutS5tQUet1AplULBTrMrdU9+WI7UQD21BdQlTuVwLuDBY0JZqXqhyuRZwYLHKtUis7c5tXsVU5Uos+cptXqhyBRYk4aQFJXIWMHCyeelYzUtyMdlU86Iq91S6csXg+nktRmULGJhVuX0dtRb5NW0zRZqXJDwhWbnBWuXF66eXGMUrV2yh4UktUDBFC5LrLk16HlyLux69IIomqPPU8hmSKymz4sDKd6nb5+UzVkqspGzp6LAowszqdZa2mqUpWhqm23Ntx56aRC0mbEm0pQO0HKxBM4oqrlMTi+jNAQZOv8WIhggJ5Ftq0eDysHCPSA+vgxqBV2QX6eEVwrb7EP6zNFwnkAwKNriFewhhAul1lJ/X7BPuEc4f3LubhsN7MSYb3gewYJrn3jmMN/YKZ4AKVqg/2UfBJS0ii9cLZq3WtzJwvXDWqnCmbQqWmDy7lPWnCLNkqRycHJS+VNmM54XD3SXhiZNEBtK30lfwLSID6XEmOl04lcyMpzARdRM1P24pCJihMMUVlk9YSrNLlz4vP3l2EzULcSkjE+XgTdR8sSS6tF4OZluA2FMtkjBYcJKtdmk13MAZL6WWYwE1gniCOLxp7gWOBUtbjNS0gvE4FlBnOaIwFIyFLk2PYRbCXNcitaaS1Nh43iy/TWc5FtTT51miMFiQz1ZLn2eJwjIW8GGqefEsMPK6sMdLVC7XAg6sZAEL5jev+smi47gpmF+5p4QWJGGR5lVikuij51Zufb3MSPIJBLdgp6iTaOmx8WwL2JUrCos0L0VY3LX8UfcizUt61L1U5YqOup+IY0HqvujzBydk/pjepbFsJGI5YUFMeLBJZwfRmbBgyDLIzGfBgaMIjmLCHmoylDKMyraYhhcLSimAURJe2gy0JQvTZUsLt5SCDiMuHP3HwAY3dP7YqKlWDtgwuw1y3jAaTaakn00mo1G+UqDDqouGu4w89m+rQdVtA2YkORxiCwZILOAFYsTNrmM0GIx/5wP2Z7NiyPPphLjnezldUVOPfMKddD+Jkz63l93JBaM9PuFO53+ezZ6XgyFRwGRszXBRMxlf8/gxzWOaxzQ/sJqfx9f8K274Oq8QvjiBcbJCYCRsHm1s45tvvunMXuUegOf9Mxrc1sSbAhmAPnp/B8rKDDudLgT/a0e4M6DveFNENkaI0JsDo51eMvZmAsH7Rztd1sj+N0VlgAAlH3x7LOyobAczYuHOqD70ppQQkXYQf9RMkgA7ojbS3wxvJMRheyeSY/C3atUK6hmk6xbryzem4fAqEdkyzOwODezXZm3sSODAA9r4m6HERm0zrZ0ww5zKWdFAwBM4tiociHqigVnwzrtoXyK+cQA5Bh4H4miDCA0M7A/pHS63L7zK7SOj2V7n/gHazix/yoffkqi+CDAnpIdsywNUpXT4o53hd5lK2DiQrhDq48TA/ojD1Tm6n6nB/REr9QqqneO/jbH4xjeJdj3oQtULsB2pCpHwPUDv97MrfWNGFmh2uGlFKRiU21qGkRUbOS0DXhEdd/aX0q9u3dm/kTEQWTgQ4sDoJZGQaghxcoDzUjsgA28c4Jox8KYM/OZAx0beCxmYY0ec3C8L709sTNbgxv3wQhZ+880OP617Y7yS+pgsnGjfn8jamGje2JG1URFGOv37k/oVYbD2zZTlijD3GFQFd6iB4/jsAFGJD0Owq+wY2I8hAx2Vwt6l4Lip0muAThGM4iWl1wB9OtmzyjxJw7AGKK/zXw4ex3ToV+S0W6gBvsqwJRiMk5BazoIH+0iS9OVgwTBaG2CnJgcT1rb7cWGL06lxOvEKiAYw59Ajo3FgTD/zhjjXztaTUtPopxL/H2+Q8wyvtBCCUc5FkpJ9f2aIHYN/UVf06d6lvTvXCJBqTkpnVu8SwPyvLqkuZieLZvUuKcDzOL1LSvATv1DYdI80m0zVyYmKijCMhFkIfQkmLBiSP5edb2lpwYCNroW0tBgxNBtb0qyyGSXVZQvLzpeYcOHzCxe6sGCT7nxLiasa0wxAUnmRMCqFqpixxq8EqwoyqsKXqsD4N/YumfB7l9DSgPi9Sy3VLuWfNvrb4aAqq5awJPXTZnRVm+iPnIc4IE6nfmFLWhYyBCyvAI3ZJN27ZDLBgQeZ9RCCOhlaIP25VO8S9EK44IBO7gdTyha6xGGTq7q6Go7nheerz9NlK6leWC1hhklXXVZGBZaysha6lC0ul1QBweBkyKJDi8nYIl1AU8l5iqXTy6OvWljtkuw+oyIWUky7BhVQxhvny85XowBHVaSppOV8taQZUCPndSVQd6ivg2obJdI1aGppgfxwJaYWVDTUNoxyJ1R0ny1KKMe0DbyzLxPVNnBP1Uwmk2nsXPRB7l16Ekuo/KILsQXyi+LDzxNP4sNPEgtViDrN9wr+mZhxL21eWIYtC4m+4/j/iFoVQjyagy2P3pewqmnmM1QIUa5CxqIo74r+6UexJD3qHqu2p6Tui2LI0w9+49dUYIuGiKsQdRnbPCqEyC7Clvv07qUJWyQWwxKXCQQaNIUpZrQaI66MI4IqhIB0H7j/78/DSlWQURW+VAVGVfCkGTkrsc2YXh5OrMQt4ARdue7dlRYceRT9tJWbPlqJ52d0WJUftftwhLnEK/diRaQJzJhLt0OvVZBxqaO7yGXWY8M6gzGg1+PCkOfbI09TMFxZ0pk/iuxaxQKaigz0vQGgI3ICsNHu9UaZW39HwwO1GkkB2OBy6B3JzHjluo8scjVosEMAiSYvzMvDORYZ2Gj3aD0Majz6O42sGTpDl51Ju24oH5092ykptJ+Z7PCQ4V6vt0oKu1JMqMZlWDYMTnbgVrfB4FVoGmnYYIrqMVud6ajbhtv4gY34lY+qCHXAln+Ug3vAAosbCiDIvIsdZFSFr3sXRcfORX8a2GLBhy3yNHuaOWQMONwWlOHT08wtMEkZ5mNDtoBgreL5c0dfx/XEwb6Kira+hOT5cwwNP2uPZdSU9VJbqQ2hxFLnz0P1zGIavb0OyQPWzojbrizJ82dDS5GB2SoyPiR7/mxsac2vTt1iz8+vFr2DOSEJJ1cgRdv1qW1BylD6Kx56yJj8NsNDDxkkzPAwqwt4khswEM4jvgCBJ+26pMeGeq2SrktOQD64p8/pjIecbQf2HA5JSKq6D59su57o2zmg6TvZcV2qupOtDsa9QEPaAzO3LUHFJgqBr7aj7zB6tmA1/qBFxbmoRf6wuqfnopVn/321vLyNHv79RCVB+K7/y9sKso55riScb71VpQBfvUo/nyBq33rrrXfkla8uo3X/O3H9LSTyyp98kv4QA8srv1p2lQO/9dYHEjYgE578lAdLKF9d9uTdtz99kgPPvi6lfHVZ2dUnOXAtGWcrX3eXTT8JtxfZ8PVIKG052vvkarY3yijnpcxImV71L2hf2cJPuZYsXHiXU8CknEZ3P1evu8qBkfNoOKm9ltro+/Tqk1ffXs1S/WnZ1dU81701WzsbPT159d9QRSxM18mnq1M1mMJn+xF8/dOr69A3L+S3IwRfbw8lLamlPnMc+eJqGZixDuTq1ZRfAK61tvMKCMVZd7Vs579AVV+9y3IhMmM2rTBey8DXwXVXP114/S1+9bMKGEvCbw2gShkQNlyBn6mX17u7r4u0rVR1vyUhH0hqFvsISzkLFmxc5ytPwbXXhabzlads9sVELbnOVr6aqOXCEkIp/3cUZFJm8MzmOOpfUJDx8V0g5cWqt1Gwc9Zex5Da2b6fzwxQNTedVN2sVnWHaqqaO1Tj+BdFqVWKRC6XxglYswfOrqJavTKs13qNXUVwKua16ZVgvd7eVWSHa0i9GQP2FMFlPZXHUtEMvc1VpKPTWOoDggtEPhw1FNn1dDJLyIHvkIe9RQY6h6oHdZV79HiwFgrKv5kiYoaXNtluMnoVbLbB7RZUHXqHx2GOKrnOWwSqadcJnCeAtW6oFBuqFAdGdTvshi4DVLdHq8dpSAGv3W0P6DEaUqqJil7Rq2j8U9UdVup6l9SEgp9NH/1z47CEGnUfJ61aLEGj7jVxksSjYdS9pQKXRkPHsWlqnDkuzYy6rwiRJC6MSaeGu1eErCQ2jEOzBtJXOJVo9qj7ipCWxIYVdXPH81c4/SQ2TNFyByz3ZkjFR7JX9JybISs/Msj2iD3KZmeUm2S7otLwSos8y4YRq9TJlYRX5iixaXhlTrhchwnjsEl4ZQKDZeCV7+rKdZgwJgtR9FGUda0cs3/w6ZXvlpfjRtEpH+Gy6vvoX3gYS15AtwqwFxJ7GNajx1907IV7uJzZfQm/hy0PE2EVQjSqkLEJOH/DCMkSbMkkqlWIuhFlP5PxdfduaKKq4ZSqBmqqGgJKTPn1U1jya9RHH1mAKU9NIZ4j13+MSf+aGGfFpp+C6xSg8WEtrm4KxtX9FHO5hEUnYS3pUwEj+ilsGEM3A1NXdEB/rAzD9aIZ4Uo0rVlvt+sdypYgWO9x63SuKL08VL8cjWCbu4jpvraSR87KCGWzHfVfI8XkkZkyMh5p1nrM1NU7SW7+RC4743i6gNTVMGmVZxmYrhTrCXmWBZN+JTYNk9qzSmwKJv3KbBImKzFYBibr5mKwNIzJIthK1s2cORcPfo7cgcmibCTYLMpGgpEyNJ2NJHXiapsK4s7GuS9q1FH9g24Dzn1RZZg1dwkDTt8XxYAz1Wl+4OHUEFADBeu65C54053jFCzbSa5u2OrPBE7fu6NzUMtJanCpIelnnMGlDOwyyN3ce+Bb3b07YFUFGVXhS1Vg5IfcTRcWPnH8xRe7p04dJwy5/CzNAJcd37ahmyStc2fygzk/S7M0DD8T40XhrWLweBG4jIH1yvDeC+erW+Di1hvQ7lWC987dV15iamwsNxjcO/fKw3t3h9ckb5YZ1uyThffuzmRN4zVBmnIezMlYvo8z5de05jQ7qfl4bj5z/sgbo46bz5xz2fJQiWAqcRn72uoJ9tWhYCZnSQtr9xPEGZbsa+TDpkz2fuLFbSn5155GfhtuNG5I73+R2MoSIawzsvcTbSwZFdy9NLnY+zkh16rjH1ScLP28+GznZfM0FQWkk/nP4mk2uLjJ/DlnyILq3rmXvVtlQ/rRTVRd41d3WKk7YGVDgaogoyp8qQqMwmFRFTEUez3ZIiFXOOCqIiaeTjZzksh4USlYN11k7KUkPEENnHnPNN+fsHAK1TuxVJZm/rmocOh5sJ2sqyMDbrxzUesRED3mGeOOI3ABvgMTPlJHknVHMOG6zX4/rIUtey6aEuuOzZt3aEVnZAhOOSGXMlyqspdQTg8dF5xy0lmaYxUiQ8elsjSLa74P4cx7pnk6Pvy0SB+9FEytu8TvXcr2oMAYqxAddf+MyEr146YKhOqjf2yOQNbtFpsBM3US8cwcXJh8jngMH576U8B6TPj9Xe9jw7vmnN4XDts9Ngx41+nwmjVrMt1ut8eqBO86bVqzJnwazHAEHArwrtNGYOfswvHG+++H1xgz5+yiXOdQ0Lzr9Bo4LdpF+9njUdC8D855Tr8PsMNqdbkcDqs8DBYDfNbsdkE+F5cZB94No5jggjmqYIYxczcFk+6iLjdmAWHIk8fjsslqnhOm3AzesIG5Zpt8pewE1fve34XXRFERobrn6NEtBkV4105oHMaw12O3K8JAQwuFnDlujwOn8e96f87u0zbsw+r9dXP09+yAlYBVBRlV4UtVYBQu0iQhVDaS9GorCgLrLj2/FFueJybiwxMl4AN48IH004ED8vCB3l7EDDl6D6AnJVjvGBqCHhD90NCQVqsEa3sB7V06pAdcGV6atJbZlofpcoHNvXiaBdv3MZzPWWWtuNeaahcHeq3Fxeyd+UQHRxId/t4UPBRJcPfyk6JcjwylmpI1dF0+KYrGSdYfYBT7LBaFSXCamDWfrmw9lYxWFrZoIo56VNdkvEI5dUlt7QL9UL1j/ePXhalL3v1I8G9gxEYGvh0Q7hFNXXLU5TYcFUtdIjpO02AwPUDZSJ59BEueRbcKHnkJUx6ZQjz7ErY8SzyCDz/yC4C/wJZHiG4VQrx4a8OtDXj/Xxwbfvbj4a0qhMhSIfdlL969g5/Dh58jJmGrRueik56biiXPja1e93cbQKgqP5J4hniPRzRvvHjTsKpookNlQ/hwb5kDE7b29uaX1fQO4WmuKZs3r6wMEx4CeF4Nrs2guqwXF+6FvjIHLuzo7R3620NBmwpRF58f+F8rVYPSVQ13VzWQnjB3b/366zuK/7Z2VxKEecvg169gydeVhGvVllV38OhuYgW1ZBEWfIeCV+GZ8jUN45mShLFMScMYprBgZVPY8KotW4Zv5d7iSC779cNsGPBs7l1FMhBgx1MuDAtRsW9wmrO5tyT58KpV7pQuW2E2aQvIwquOJW+puVcFrG6X1SEHrypkTOlsiB5btarTIwuv8iZh0rNqld0qB3cGUmbYvHDfWs5ml4NVQHBGQFpzITvxl/mYnOu2dAoqRRLeMrx6HTeNxTr26zmchnT7ZVk5xG6i372MC28ZfvllTFjRBBasbEIaxjCBhl14JiDZjcLXd3jsa3UEUbn7EJbsrkPnos+M34s7uBTORfft3L1pL9aw1ek66OjQ7Ts9d+/eTYoDYunk52vWuCheYahtZnJgB9yF3/efsvx49hkjug2/c7c0P557egn6TdI8G4YuWLhnb6KKu1usuGnYaHTBGhotkLLdZEzy0ppb8lurq/NbXVSaIdQdJXBPEja6YKXClsktLa2tTIIipJ/nHgaGhPX5kNO9Gpa0n5xfbUwXl+MeBja68ifrIPM+pC8Ca1j5jlBxw6g1bOLAsIgGGA0LhE/O5w6OoopL8UkYrDBCRqXJ4IzJrYIk8yZU3J27Z6aSKYEB1ZPRAh2T81uE2euPHl3jGv1LCp5cUr0HvFFiyufDpqNHj7pGR9B4fsYb4ARd9WQoIPxxEjoZkySaKZD0c359S0n1ZB2oTy/DDjoNSZIFw8gqqI7q6smtqfUBTLTOGHsOQhKGtlENa6vrGL0Ckg1To9igGZlEdQphSOlvpA0VI/kwrVMnTgo0y5EUnJn2pyyZ1mxSJil4OiZJTe2ZlGly45DUpCFi0q+fWoA7HemBv6JXMRevhKiePLka9x9RrEKIJ+ZhyxM0XDwPPjevGAue3DqvtRr+JmPAxS1GOFB18FiMAVeXwIIaphLOCjYysHC5m585PK+VWnukRNeK4+fiyeAO+IEoxqvBya4S12S8GgQaaq8Ys21QzQOjIalqolTjp/9SGxJ/1WoOq1/W6nXK56L8Yauy56K/mostwlH3sueiYjA1JBkPBgzmCs4V4kJ45twTf6F+nP5ydqbS8OCZZ/+S+i37C38ULw+eeZbmbojRvFH3M+fSbGwp/TP6l5mbOKPuD7Ll0ywazmpmNm58yt7NDeb5C5JW3KBVN4sfsJQgU2NZsRvNH2fdyMqKwQdOScPw5TdOxbKQDcCeOgkvy+Tg2MlmeoIpKI8t+FgGpgw9Sfut+ST6hLxmRMfSjzLwjWSNPJWsF5kCnqJqpBlKeYMpplz42gGFyzp5A1DgkS288MWRlqco51HG3Fjw8chD3Hn03PB11M0+hYqZeDP0eRHpqCvGTOT9eMGI8ajCff6jplHKitjI6FGjYqeA6ajRNTo66jp61IRz2oOuCI4aH5x1l+icTlPHBdEQUt9UuZxOk5hJvFZtUANJgX2kXE6n57S4MOR0GocPjxuDfzyc7vWgYK1sr0c6kz3KxZvTLpvrPp1Cnh6tIyf3cmUWNWakpxPQOYGdMgLzu2khk36WS1+vDh5roj8WVhVkVIUvVYGR+OdxzgrLLPesRzWPRmzlM1bKpXT+58UevfM6wCs16x1F7gyNXLLocZ7FUf3sGMARh0FH9lfIpaEOkYjOaJy13opYjUXuSIFkdN7FUdLoANbKZ/mD8TTvOCEXpMcVcAH7ToUmnbIMpQyj/ltSMORh95FemLDnspHtsfY4TVve/QgSab8bnoEeP0rBMGS+0Qi3LA0ul8ntbnHTqxGsfPdo9owZxvLy8IwZR7MtSXgWSCCqg3yX5uisqGeE0ZxwoexJJhN6HE3Bs2evXE+6XS63yey/uHL2bGYYYRBVsL2oyAMNIWJJZ6TvJ3Ums8vhXRzwByssyRGKKHMGwJAKlFyfhvtJl8FBGs2kfXFAG6wQgX0puJ10FTnWz2qcdQVosz/IBKagGcSNSmI2z0rBUxFb0eyedT2O6PW06pUJAwiccxgNhqPhFOwqd6y3VGS0BFZC0kJ7uTfpOgSb+PBH38ZzNDnOd50wNjIUevddpp6DLhC4mQ6PjTMs6RGSyAOalcjWioqVK5ONImJNuo6MaRTiM9jEeIMknUowqCYZuF2jGPmhDkkEk5EcZRhyBvrsRV3R9SlW9jdFMxvOGb+drcH7AdJY3k2wDx2FX6uVK8fWXZLJdW/VOqtAmmZ1ds5qQlvO0WxPRRVfmpw+gnBke8lYVWlBwayGhlkFBaVV32Zn23wFIlLlI0LfZrscvpxSBs4Z7bKT7VVicIGTqCpIhDs91njBSEPDCFIb8CdKS0XhJkJTVZUzkm0nIxmFhRmwYY0MgIXM7lJGGDuIysrKjEpbwOYIFBYGbGaHIyMD3qHpqpxFiyivMS+J7M7OzgZKCgvpZ/TGdmqvZtmV5a+/vvz1ZRoGBkYogzRccaUy9joSDYbmiisZlRkZGaEUTNnscJhtyGYHGF+Ztlnzehz1fbenYPDGQMRqzx5B3oiQsJGT8obm9RDoAlOScFVpwh/Izv62ivJz3OrpDCcKSpPw8uZYrPlKCq5oJ+1dozlMdZfm+Byu7G+bknBV4vsPvv8gBfttSC1qGytWUG0jRnq7ZtB2VOR13OnuvnP6YgUDexpmJKhNZAZVawmfOUx5o3SR3nr4xo3DpH5RKQ3v386Upmo7s1VawBSwNGfBxYPH+w5eXJDDwOINjGk5y785feb06eXLmwqU4YKsQFvWrLYbzQUYcGko1BeP9+0MlWLAVZ8vP3OmZ9/Fz6uU4dJEX1uoujre3jegDFdlNe+LabXtzWcuVSnDhw8f7sjK6hgePqwMF3Tvazt8GGVI6MYp4EDVQCIBD1U4fi4oYB/nVURTAbY0EU582En4qnBZCF+Ez9lUhSFUYHxwRt2vVQN/oQL+wvfxWly43w953jDhtV9oSf/H2PD69euxbf7ii5c+xi/gWtp3a+Xhtf/FMUdB83q2z9b3r5WB2T5bu8Bn1fZ/IQmvfclPatOq15PkAmnNyGc+lhXr/V+slTbjiy/Wfpz+4o/ZL8S8wXbXWp7vxP28dm3/S9gNaUE/pHPEhkmSxG514EEfrhlrP17wcb+KhrT27z0/RVWQURW+VAVGIn0jzL/8m+yuruxvlvvFb5SxWdL/+p86Fy/u/NPrEjA5Bv/9YW0SlrrfSVxMy7IkfFFCiNf/xBYKlpLXifAxtiwGOSYlYaJrMbZ0qYNVmaGqgCzPLE+6brmU61RVylh7/hnCqgIj5/JfE+PcQzXL5nSCzEHcVWuMMjmdZGF+Tid5eIIaOPOeaR6Dx+Ax+B99wKoKMqrCl6rA+KCMdHqw4E3YMp44qUKIiTXYMvGnSBHzAMH1e/YUY/6rIfpUCCw6hi2P/sLWHL9fepd+9Kj7kpZWmHQCY5tbdekn3qh7mDBBS4mrGqZkwFML9dTSYkruMCZH3Rsbq1uTMlnsCaaBNBrp4WdG039+WK8gpz6EiR1o+Bnkrt104STk8MlfKvY/H9IAfTp3LyTHhVFwJuPuvXM3zf0wvyZfVGpqTl7YtGnvbiPKZ24yATx306a5lHIhm/8hqILcuKY0jPALpwQ4qEV6BDDgcz9laCgSjZ66MHcTk3WXByPlyJb6+tbW/Hq6YJtSKXr5MFL+4dL6/BaYkFNNF2yuDIzwky1QXzAE/8O5m9jJf8XguXt3rjG2VBvXGOfsnasMh9fAsvCTWyAFNR5cv6fVhAfvXOOCuUNrjLuVYXCfq0RXYlrTxy6fOAy+q0dzr3TVUCFpz4nBoHZpqlI4jhZWN9NSWdWd8jUfBgt4DWlpTcoWLrxpLlhQI9Ga0zDV+FMWiODIFqbxU4dVqnGK0ksvbKIPK3TAnr6gdMCe3MkcsEBLhYJWXijgBBmYzEU/udhPKMiYhONFYSYeE75couGLFxhb2E+uFuF4UX6SEpSgmc5Iyk9dkkyKwkpGiXIBF6UmPZvt9OISKCkKk27FrEsngeTC9sWLo8l0K4ziaFeXXQx2mGHhHa/Nykr1YPbaDQa3NyCAHS5qsAydqZyGra4uGL0EqxHb+LC5i4aNVj5cJIStbnrAsJdlRsDuNhhddo9IAR1oZI2Dm54i2lVkF/eGd/HiAC+XhdmQ3s2Fbd5kWtJ04gubWaJSFLJkRBEcFYPNQvEi2Cuyg8g2CIRqlkbh+9n3MuuLGjPcQkGHlNElskPMdar8rAhbPV4bdnUHFi/24jYkB1ow20FiNVEvPWaeSU3Abvx2QeO3wnED7xi6zBiHFQzwomAmVYH8AUtabbBStdvsUAoFTJCJLl5sVw4yTPhy2O1m5fClKjASlWffxpKzlQThWHL33/Dk7UqifsmSzw7h0WeJsiVLlnyJp3w1sYSSq2/j2EG8StM4yt9mNCPl+JqR8v+Dr1lZOVvzEiUnUppfFSj/7jtZza9ylA8PK9uccuLgoJLNzNYfv/pheMWK4eHh7xRtBvnqjS0rVryx4raCzfT25T+u2LKl8Dssm8EQgFfclbKZa8flr1acP7/iq6symll2fHX+8uU/fnX5s/+j7A3p6hd6Q6b6xbzBkbtK3lgioZzRnHYJs8XyUfoYUtbMOkApzVyHvCosLaP8bSoUUO/+kcO8KuLE1SjISDma/T3oAD0L4WuJpJt5lqNgV78ES+odY5nxfp6L9hqxZQLRqkKIiaKXUkvF3oXbhsK7H/U1Zw7W1wjvi1AwT07l9207s/TgUsEOEbhmZ27uhtzcM0trcOClZ7blbus5WIOjeWn9QVjFaWd9Pg6cX78z9/iZM/misPDW8UHwxUHRW8oi96RPnYI/0ZvVqm6Dj/UgyK27JNv5oqpbR90aoPiJENWw3HEFqSuTykp/ZaVNEbYC5h8dHpw2ODyqhW2rHOyYBjI6bdXgKngE8cuaMTI4OJgxOjg8OFoJW6PyNmes+m2hPgynU2F94W9XBeThwKrBQm148M4gwIOK8PArw3o3PLhIeJCFzZVeQPxheAj74cFbaZaGR6YNQtmOrYKHLcfgYXDaiDSs3TdIyyrmeZ9WxuZZkKUPnIxkEDa3zJIr4AgiVm357W9/u4XaGsGAh+8M48Bbhr8e3jIIGQQHqS1ZeNaWr1+5w8B3Xvl6i1feDEgBuQplORyktuQ0Z4CfkXvBZup5cFoGB3awZdY+mGA+bVrDtNvwNw22981i7yY6uVJEPQLMepUSYouI/HBt+NqgyPui8KoffvhhFS4MtOjb4vAKNbAazWCyOGwULd81MdZImFeIwNfE4BVmgjC7Vgik4Qfhey7z3zmK3hOYv6qPNBx1Zx9rOGb02pThQHZyMlKD26EAe9lzl46ZZWE7d6ZTg1kGjvLnRR2zSsLWY4JZVHZJ2COcctXgkIKN1G7mj5GoBOzgTOdiXrglYJvIzK9VYRHYji9egvpiMadGVwnKTMNircFeKA6LlZwMC+BjNOwSOY8olNJcKGwK7kIpzYVGPhso5FYRWzO/CmwN7Cpq4GoGmt3MAsfEZuilNBcWZqdOARz2QlFJa0a4N2C2maPuhkKhwZQ1vCmBDQ2F0nKMcAlLzVeYKhZhltPF/aANRVEsvIGKomNX9D+/K3qRLhIpyeae9igI8VQ/tjxFVKiQ+3RQjQVNhFf6h/4/qm480rg/Y8s44r9VCPGJChm7ov97XdGzV6+rr85kB05YCpuXpZl9I6meu/b5Gs6a1WDG8/m4MBRwIj48fgweg8fgMRjBqoKMqvClKjAS/r/+Xyz5q58g6v4vttQRf8WH/0r8XxWiDlb1Q6/qvO6oCiH+fxXCwIvVwF91qYAvn8OEu86d++o/zp976BwWfP4/kLx6Ds+Mr4A9vxjT5nMIxi3g+VfPnX8VU/PirxbjOe/H1OA/HFZxM8Su7q7aX1XIPTy6VQUZVeFLVWBUN3fpoopT4mfzLs6diXuy/XheXt7ZmZin8QjO+5+ZKuC8/1ED511UA+MUMw1jFJMNg+Ez5YUNL/tLnbyw4bxl/QqrqrHhvOVX/LKZHjlw3vI8ueyNPBjofqsVFwZLtLjwsuUf+62YZixD/sC0eVke5EHRSwrHdX94fJbNLCdpeNkfnJnlCjdwHk+x35aXK90aYuA/5I0qsSn4DxdnHDXp8GAw9yjOHarHscxlbsE9nveHZR9hsaD5WSxzkzNAna5y7BuSaldSfvzxx6/A6NHI8sflhMrphHy37AocYuuX58nK4yiK8uDlkvIsXSls+Iq08OFleVrJJLjQnpeBLM+jYGrLqhg3KM3LqC2/1i8hqXSyqG+H2vBfkXaHYBi2NQ9ZIypCmFwm7TvCRwkamaClN2VdR3njStob0q5j4sZylp8VQy67BuWWy3kcv20sF8IyzY5f3XLyOBFZTwmqu/UKEklWCsry+xMvB/zUAmx5iliuQgQ/QMquw5OU63Akcg9XUv41vut+TUzB99wUJjBiyLNMftECQX5RjUx+0YJ0ftGmH59fdP/+3A+E+UVD4vlFt53pkcsvSkY0BVXp3IHD29jpCjn5Rc3c/KIgW4eHS9MwygLayc4C2pnOAgqyfXh4exqWyy86EFq0cevWjYmOKgzNA5XxjbdufdAcKsDIL1paFRxIDLyTkzJDU1WgodKKiuQXLSh4q6qn5623UnABO79oATe/aMHAdUtPT+1bd5I5JDUx6fyi+3v2d/T0JPbf2srOL9qUbhsFVH5RRnHHB9tgPKim+xXl/KIF+7u7u2/fPu1re4WfX7Rg+/ZkQsom5q3urbnf372bCG145V+VU1l25G5NAFz1Cga8v3tDT+j0VefAhq3KcC64ovv7bk1VR7dymtN/hSVcezo6YgOfb1CGt9+5dev2e/9S5+g7o2xG6a0NW2+992/fhxIJjMSe26/lfnDr9obt125hwLdgRNC1M/A3jKP5zM1ceLp27QMM+INr5xB884dcnPyiG4eRzlu3fnb5RX/NWs8uwkldMjXCW+puCvtX8+P1nOsfSIfIXUSP8zMhC8PPxFP48FNjsDLMXCDjwFbS76fOpjFgq3bHhQs70AU1Bkwe+bCs7MMjJA5M+i6gBYsu+EgtBlz3IYI/rMOBrf4LC+fNW3gBruxxbK678OmnF+pIPNeRdUeO1JG4lcKcyY410Z8QVhVkVIUvVYGRMJe/8VsMeaMcDUT93SJM+Z2ZMPT8/nUs+f0lA/FGz+uYcukNYgs+vEUc/kYF3NMwbQAXnpYda86+hAdPG11won+BkBaDe8Kb//Pq6RP9RQPK8DcNsf+8e/Xq1QXt05ThntG/nL577erdeH94QBGeNtK/4PTt07G2/tFLynB7f//m03EYMjUyTRE+1g9j0XeOjoRH2qdhaM5qGzn9edZI+4iyGZdG+tv7T7ft2HEk3KMId//u97GM7tvff//vKxYpV8q0Rd93d+f+6ZszGH5+fWDaY99/c+baZ4sX4bSNS+dOf7/7j4sH8FpdTwPMWh3Abc+Lpl1aiX+kqDqsfhL4Dfy48QZhvPQNplwyEuY3sAWCnW30GMzhGZymJGEbb7xoZvVESXlekNOpuj5fUibyxovKwvnPc4dTysMTueNFleAJvxC40YQPN4aNuDCsCNXzu8ZGPDhTF87tyQxnmjDgxhm5SHrCjbAMvGyCvgnIikvv5b6XG27UrTn+1wsyQpnRaMx9770ecAgkfZKbTknDM3IvXerJbOQPjBF0+VFwONzYGM7UYcE65LZGHSYsMT7ngYAz75nm6fjwr7jhSxamRjpNlxjaJDZedMr/Hj8Tu4/+4c93bJ77yUysPvrpt7Z1ZNQdwcF/RTTqLm3d9jlJ7jg7U4mHSoGW3LO1O4Mk68CaT+YqVUpj4+82bO0YIkn/EVn145m4kXlp64bDQ1ZSX3dC2vpkdYMtuVt7DvaCet+Rs5+I86m2YYKCbtt2ZmH9kENSPashoYJuyz1eXMOoF1rPaXWNjZc2bDvzZNm8fLBeu0OgnttEGxuNPdveOz6vuGwerX4uRz2vPVMFhcnrxcUp9SycDzMF3XmgeF4ZqLdRVTXzEwmYKWjP8QNwoQ7qex2kH6yXhf/14YPosh5pJ0myjh75IIAR+t623J0HaBK1gaRiYQF1l3Khbg4WMybo61htne86sADsTSr1cdstG05ZUDavhmpT/AMoDZsYC56E+naI13cKTlpQ3Cte1Zxgjiy4tTNdpplSTZSyYOvWMzcYR0m1fgRTFmztbhYrk+CADV/asDX3c6vSEUhpBgs2dPyZlDv4UvALWyHI+P9bOWpQo+6723b8N274UhUYCVvLb7CkBU2K+g22mIkWfLiFEH+/M1vsXVE4O+pw48JuK2n7DSacjfrTcc0IkNEA6cGDOx2k205GleDszi3IQaTNbCVbftNit7fIwN5odkvLb7KtwNqzqRmF5hZJmMoHFu2EDjdXpw31ZMGBa5eC7SRptpF2t9WzJWoDOhtNhcyWspkk3W7S/BuvvdPr9oKzraTH7pbyRpSE7jOr+zeo/+03MJ/Qav/NFknXdUKpYAqhNxsq3OxFn5D1s9cByu0rWjohyZqtc4tCpXRmt2SvaLG1dFoDpFmxBlvADofNDVXjIFsUYDQF0xp1tERJb1TQQPhwFPwMvaCdAdLtFTQQQtCKolCR9i3UfF95zS02OsMd8ouVJOVt7rRHzWYPVcNbWoSHCyFz5GergDt/owIWOVJUBRlV4Ysw4wZGNAPU6gsFQXLa7YXhSJCSb0c97UGeOON+gvDPsAfaQ4s0mph78Fg73P4MfjTqMbc7hfdFc6CPflFihjsaCTFw4iN7NCOeU6FJQ8E488k4EXLOvhgatTvWrwfYN+Ixr4/PDs52BtNwnIzk0J8iAoFAFJYljgYC4cFjAXiaNQseAiNpOOSLJeGGQTFZdYlla5D5Ghw4aXkoSERB4JujniiYEUXPs9BbIzxWEyL9TlTA2aGIwzNCFXC91TMSujjbyS4gLc5Iu5OAArQHvKOJRZTrNM5IwP5RYlHSczksO4JBor0yivYuovwcAcoJn53RQVMhTuUECc/oR9RXpmpQowHc/hGlN0LGkmAMwYnkN+XkDOTQlmo0wdl8zcEQgoOYd8w1PDikwKfhoHMRNFAnHpzTHtFGIkE8GKqIJNs1opAAjvu0pNXXLqLaGUm1upQZiyI+fzAnRwjHSV+QB4PRi2JOMTOgvS0SwEHNoiCm63gHpxpY9CP41S0F56i0WfQjQSKu9OXpD8UJXw6uyRC+CH/cGcQQKjA+OGuAPkjwWmx5hOCNzvPJvFrPH4xnlXk1NTkglu70h5U511MbVL++Fvo4rZxB6RzY+vHv+6kufR/1+MXvOR2iXBi6R/uhAx1UfoFUWqlXkrCW6uhOfoE2OVZXAvb1+7UplfCklYatWlCJhjZQKq1+BZv7X2LttoLpXPhvGC/a3y/9Cnql16qQB/9I+bmsAfoAZCMx0cnM09sy2UiMBqPJBNnpqSeDfM4Qg92jAybqgKz6JrfHZZKDIf82nB7bPFG9OeoJaPnLbGUXsWWx3evyRO2GInvU4/Jqi7rYO7MJL0fsAW+XAdkKD11ePXenl5jKmzhjLzJRhppMRXbeLn6Q0QKcst+u12rlItL9CXvTsFcRjhqYKjYZooqw1s00H0jfLoAFUdRcRNHGooAwisZ5EuqPUtVd5NHH+PsIDT8PjCYSKC8qMkTJuGCPMDeLxtJvg4Tu+lAFTiIXiybkIyPBCsysLxVBp0aDnSLGonmA1l1SA6syQ1UBf1FrcmmEKZE0UrDFSR08MUaoF06NBFwRI6lzSj89l4p6EauQguPUydzZt1evm7N69ds70BjJuBxsJckdJzafXX1i84lKktTKwtbKzZuPHDlydjU8whYfXpmW63FQ+29vr169et1ueFj9b6sBvs4CiBlp+d2I3urfUbdjxw7QDI876rT6kd+xAKI8LUe9euSAzet2z5mze/e6OtjWe4+yAPbvYJGXbG8nyRNzzgJ8ds4O0hrzeYokfjQBjldAgAHlbyO17c6K9fJwRU7cT8ERp6bCoqAZGkiwffPq5rhFAymlZGAP+RTyVG3t9zO/oVxW649KwUa3fZTx1D7GWXa3UeqswFDEOGrNGsZZRYYfn6Ps3iVhU3WqpuokUN0M0LHMePd5ZjyzChGcuMqI4OxLTsZg7Y+/ot+sQojVKoR4bA62PHZfws/gw88QU7BVP4ZOGZ95DEuemTIWRX+eK4bcj5G/CFuy1eUaUhH5p44F818W/Bw+DKvXYaseR61eNw5LqNXr2CF39RHORKdxnnMPJaUFRVFOMF+9gzOFSs+CQSZxfybk4encHyB5+KExeAweg8dgBKsKMqrCl6rAeA/vi2qw5WnCqULUXS6NQ92/gn9Wsfd+ih9N8eRq4jDpi5G4sJUMVURIHBgVO2KpcJIkrwNbBLa2wx3XoAZ6EeCWq88qD0MumQpNRU7QUqGpsvDS5Ak1kyGNxenzt8OdvXZS0WZfDpSOJENNIUWbVcGUGUGfP2bJ0SiaQcbUFFCN61RVSrK6feS9aEjqmqh047dii8r7G6pCgaogcw97lyZNb3kIQ6iQO+khbIErenx4OvGQCvkFwOcgMTL/3znRdx8SvS9qAxG9LzpOeBVM+vv7/STefVGy3aLRCKKi+DFI+mCgK3SmCGO/GBzP8ZOkPyeOBTuD6IBzOrHgGAq5kYoYFuwPVsTjFUE/Dgx0KCcn5Cdx74tarfj3RaFr7sjYfdH75r6oLwEJoJrMnYVeJ5XoKW5PrtcWiccjJLMVatei1ev8odL5pQUZhavswfnzS3NGjjV4YGfE154ohdeauA+2qmCryqkl7FEykpjPwE1xF6yKpQ9tn19ailD4q2obKO2Av/nz5yeI0cKwmYwNINiZGF0BU1hiTRQFn4xEQgPB3d3OdWcrfbFEVRXhzHAdi5LaSoD97k4PqQ81NTUlwMgY6pY+Mse3e92JdVSfsr8dsszZAgGUY26VG+bIUMHFZralCrh69+a34W93Wzvg6WR37KXOpsWggE6wpWPzd3O+e3n16tD20qZQO1G4ipHUBloes7SgChUw8fZ3b3e//N2cxHZUCMiMR2XDg7x4qwrpDWqdR2pfPFK5o333dy+//HmoPRJLFGwnIj4H6YA0flBAEiXG00cqIW9oewhG+CK7K797+7vVLx9Bm74Y4fTBEmPZs5A3fKTD3TAabyqoWkTSe9szVq9b/d2RI6ubYxFUQNIG9dDRRFXKQISMNnSO5Mwvjfn8EWfB/NK2tvYjO0+0xyAp4UAoQnhXhD/XJGuwIKQl7YXhz5vm0wUsXdRUFfyoDeqIKeBoMN02Suc3xUhbeMUMal+ovd1ZNb/0cNN2Z3t7fKB0OxFHKfQK6FYHW6WlTj/pCceggD4q81F7vC+LbnuRGOGjE7pGspoddLbX9lg7s1ipr70dfeDDIajpdvQBYlE84tdGnNDKmkKw5QtVlUJrbPf7YWt+aVPGjYxPb+y4AYWA0fMEtMamJlSY+ajN8rcGbnw02tf30edt86kCoiZOFSaeKKC3YnHU2AF1xuKxvlWrjheu2pcRC6ECQttKJOja8sEW1Z8P1eFMhKhi9f2AZB8qaiSeTDLva48wYdYPUwbSW0PXrt28dq2PLiqRiEesVqgtqKJ4RGulCghFhR+tONpqu/nhhx/e3AlZJRMxVMACqoCUlU1NBaktyu75iYysrKzmEP1eqoCx+CJqqwCKRb9XmoCtpoHEzkTCGYs5m6gChpLFgq1FdLGgqDD1gNoKOfd1xOi6DCUL6I/40ltMUWFqBCrqPhtpjUSQvwgnOopRsQoGUGvwo2LBlpX0Q6uhirrPHBuAWk20+4nE/CqNhilWwcBAFVNA1ta+AWbLSfgK6GLFQwNMsdhbi+AA6N4+f1EcarXURxDaWLJYkdCiASezlRhwttOxIzGQaKfTdI31Lj1gffS2P1M/FPD4Z+qM9M826T56cscRSHWk96FHnx497iAlz0XJ3TAY6W3/EfR4xI8ed0sPSifPrpszZ51/x2p0+8mPts/eB/BqLrxaCV6dhFcLYc65qF6r16Pr6NSjnnsu2saWz5HQT6kXLCG2qhDi4Vxsefi+hF/Ah1+ANCDYitG56AsPY8kLUwh1J66qTolVnWz/XK4m0NjJOdTDOsmH1dQDwJtP7N48Z/OJOf+Pvbdxa+pKF773RFuVflBq7cGOZ6bztL3mmieErQgYq5COkwDptJlhRl8DatMCAXNIQ4QE3x4ePKaEBLDK11wiiggTM1VUEaWUqmgRUR1r7Yw9ozp+XVU5l7XX+/4Lz73W3jvZO9kfa7e1Y1tuIOTjlzv3+tgre691r/sOpI5I3gDQPRKYQbkhDgPt9nR206nsTSrceOCmE2662Rs3PT7kdVNuFUKJZQapqpLIGCJ2pZlXb5WYUo69UgVP86zsOO918Qte5JUOW913itAicB64ucOGAadWTwDXZ+XBSFRhsJLA1my098Dp0hPA4KS/s7DCmVVDYjMMhxVOg6tGtDZE/Qq0En4FlZACujDmpgJttxB5gUp2ObNdWS5nFnvjjLlxsTfZTlcylWyvcOkN1nqn3pgHN7q8GripqdHpnTV5cFOfZ4Qbq0HvqrAnU9OcOp1T53Qq3uiccFZgMOiydUQ3PwZ/0cgk6tTK5GnTkvOOaJRXl8wpeE9IVp6/QNnrXhnmed0TwNMnYQEcdd1nYOuRTOl8x9FEySzsfVkylTJljWTqy0P7dLIqrJKp/Kz882fsyy17/vydnMYrm+GKihNog9MlLfwvILR7Kn4TkvgSCduCa2qll0i49Y8CDdeCxZJrJJOdX3TvEtEgo2r4UjUwyi/oJwuHXHlXgSzhYC7vhJAl/JqYQQ5PUwMnPTDNk/AkPAn/qw9YVYOMquFL1cBIPfmrR94lCaP3K3SS+0TG8b+++65CcL53/7o/44knqedNKKvDXFn63bko94PpeWrKURPgcsrfRWozTKajU6iXcBDIjIyTUspZtfvHql+CaRYUoFNSeUQtYHhOphrF0BRXHlG7uToygQORIzNElIPa45xa3myPqPJ3556MqhVMDbHK90WUx6gVziOB8mFUUFZ5rNrYSafN1Sj6JygHrYzajKjauBmqqPJ4tSLTWZzyfUjtVr5a0bkvaKIMLMP9ArXi8OYxBt66ebPCrBq2moFN+2NVx8CsyRl//Ssy2hRjtADm1fS7YtXBh0FttA2houOUR2HcO0y83iHocEJYoFbQOaKtyMLV4odLjHIGRg0heqzwjxMGrpY7Clnl+8Y248NKUm2c8peolxQObp7yl6hfKQ0bc9kmMpl+hYYvpQEJK9+Hhi/IR/9XgoHx3Ueex1f0KiZRn5wNAcdJp2efgai+baQTvxD0VdffRjilnIQiu59vI4OnMdGL29pIYRyOuI0URvHPlekIrFufpFjMKbwozcb+tmpZeYkfENhww+9PkBMMZzNboo3rKxQ896ahSBuFLjaMhsuul3MgnKbLdsFEZSWjO8uZp5eDjdkwn6jXOpnN2RDxRRbGM6B6LvrHTpdWL2dGBUw25jHRYAxZhdJWI9hgrLDWMIqz0RtlCwihbIxM0JssXY1eoTagEgwotomx1PXfyvXMBkEp3RUYUtgBysGlpbvaFT2dWLjUeGJ7u+KiwDTGhKQT2wlWEHABS+tSt5MsNyQx5m4nWpuYpis1bFU0l4WfKXWeIGNh8eXJuu7tKjydfqFmB6iKjU6qtlCp2pz1Q9mqxqwikMF6PcQ71hMuZNQUOnWuSqL1FJj0yTIYsrMMcQsfInBFFhORItuYpxjFyGrMJg+mVMHFR4KRKsZsuTBNutilnW8IqzJDTQFVVZ26RlHV3Oo6ksouOrkDlHQHqIpzUTFXgTbRszw4FxVxQmhLOy96JvaiiHtDG+TCWS92winqC1G3zLhsmYhuERgy8hS6CtfXkcF162sqawqz41XDxEKsY8kXumXWyrzCj87HuZy8RPlj5ezhZfYKa+HOg3Gv+FEYaoHktfRjeGa4Jk7iN7D3pxmtAJ+vPvxR3Ab22Lweuv7qujywuR8KqrSssz4prW12fWGF64u22UTw+fXZ6ET9LWUYEiWdX+ZC8Hky2OWtP0wEYzMqXMkkZhiTEJW1DD5AuYBQdW11sG7uEq26JEOM4HquQfW8LOaV+FXp9efTDLgF00SWz6b+t1Asjedx3zjcYol55b+nxvvzjySX4l43SOLP764rRWZknyDx599+ohQK6KprJ/GTaW/HVSdy1ivmVLO921launU7odd9e/fWE+3EXvft27f/wKORGI3k/qJGo9FA4jiBdBqNJc1NBuXlYKMBrskMuowdiTlwKpNjlIONupJEuDFgzcamJp1cMNKcph07SkBnTk4OcBn4viRscCY2Ow05BmcT8LpmeRh9rCGnKTEjo7lElwNvkR8KDMacJpgygt9mUC5bwBwDWJLBTDKaEqGMOQZJGMpvyClhJyQzMpw5uqYmowSc02QCIDECN+WU7GjmRWf9+rAqM+IKaJQrIKq6HOKq0xlR23GN0lQi2zeMRtTEbHM3meSbm4GZjgTGQ30omcF1UdBvVOgbOfzOT+A4IX1YfZMDVn4o+F5GxltGLE9SvzxILL/kB5xUlO86ZKjZrEZzrZkYhr1eKWYCGDOwDdynibcmDq5FLGxhhA3sKeZaoTUxMGwwh1ClGoeF9pshKmhra4EMXOCjgxrYCa4FGOJeer0pkjFRIShqFdpLWeunLZagGd5paeUbEhNtFSitvxXdwkaXVtiSLh25NAXvJ2XzuqPdL3jDuSQcu+uT1kqGZk2J2yJKWxxSmjW1sXvcLVA54rC5IH7DrMBoPowis4psNK3ViMAah/g8a1Wkh/BgCFPrExUJm8XlO4nEq2ooUDXIqBq+JuOLKny1GZEQuiYaDNFbBdiY4yw5s+jMmRJnjlHxetDQtCh/EUj+ohKDUQHOKcEoxksUzgpymiIs0MJzk/jz5zOLeHJG9hwJDBZIU2ww/2wDL8bvT/7IZ//4E16MXwM4aha6jNykIriIF6Y3R9nm9ELwJmdwQ5bRhSLj5VXitATZugormtO7wOLNF9AknxUSEuDFoco8FBkPnqk3wN4AVx6e/YObAcQOaNmHeWjjgKEeb84CF1D0hLNQq2c2JFr0+oHm5gF95KG20IkUoTWgINqBiVa59GhfajDo19J65qEWP6SZh2gnZxBcQGt7LDSOUuBDUbnNaN8gGv9bHWYUk9uHIxfQlp5a5AJq1hQ40OZIf0qBGUeB1/Sgj++BmAV4TEtB2w+rHAUa83SIdQ8RUGphqzB8laFw3xoUEAU2ScM//BCeDvpbUZgUiHXfGnQgDDEpsA+3tacWP0IaeuAhmMa8aHYEW6E24MuuAH2eg9mp6e1BoevBGCbeNxiAvmxrYa80CvKDnyhAluKYI1C0FBhnWyMPe8AcpIiLRqIN+lp5g310fzmWVl9Qy7ra+rj9vbBl1udwRDF/j8PhC3K7SGFrKY5G4sDfv/DpjEOtT0ujr0sf8wjZA19aEM6BiUbCGNjDhuRnSsqUKwWXlClG1F/UByHRI56hmuk9PdN5D+GbKeIv+otjj5MIWtB/6hHkTVGWvkRRIB/9L8Bt4OO5e9IJ8OepR+bOfW587sd/PVZWpqga4OfGtVpQrmwLhj20dui5595VtAXg58Zp79zxuePPgX/EsTLw1JGUJ6hHPh6iOz9+bsg7hH01BuQENHfSgY8/9sA7sDtFp9yi7SNzPfTIx8+NB5j8wM99PO6Rg2FD4nNQJVyG2I+fC3ilYCifdu5zczstQ5xnB6Q37rRIwl54vZMeimarlrCFhUH1yFx+ptqPnxvxSsJz5wYETiZ//nP3HJGJX8YMqLHOqOZ3/9y9q/QjkcilAFsgry40SsTmP8/dCqvUYl+aj8z10uN8cwGFKTjx726mUeaOD42zxh6qE0cx/ByqNeh5yGZsbKn0WQHqSJ6PPw54QD021iBzCvHIcyO0dnyEMXZZqewZFdP5LZ2QOnlD6ODBTbKC4BGanvtc+0SKWfEkkDlgt0+kmAlOLx9BPWEDAcrC7YvNZrIT11+0T5ChjNe9mfSMWHXGEMVJ1EPPPrFoK7O6pLCdckPqnvz8o5BBHa0uye8Abd9w6Nn8RWOMa9uL8vs0o2qRvCQHt7djtdWbWQe8MRl4Q+pJUMs514FL2yJJeEP7oUX5z46x/onV1ZDz/YwE3L6hO0Ztfn7JNHF4Q/serLaadQEcW5R/pskgCmO1izg/Q/AsRGp1OUYxGKs9yrlHgtMpqMXnx/Ew0wxbw2msZ2E/PAK1Is7SuBmQ2o0d3sZqrDYfrGVPu2NgULuIaYZG2jsFpVjPX9RkzBF1w2aa4YuNoLOjsaOtGgp2hnc2z4c3MK0bBkHmbsRqc3LEHLy5ZtjYYfGGq9lm0AkuEiIw1wyb087S2o6Nm5lmMOhEXMcZtWwznO2ININOBI5pXUZtjiF+YJyB1D4r1roio+gM3AzPCltXRC2GcX1tjRwN/YJmiIX5BxnTus4co9RgDs2wOXKQIbWGHOmRP+ZokFSLLx6nROoLt65B9rL0RZ5anYxaxut+SsRaWbWs1z0sux99YlGJuh2g/9K8S5oCYtFQQRWiMhipnVimUk4VQiXBjkRuZ6LCD3spbeA2MRJskMyGXdOu2GR8EnA27JyusNQ4swngbJ2VtmZbabsSjeFK2gL70CH5fLZR2YxClwsWqJ26QqcibNTlFcIEAGTjszoNijCYC7kJs5203WBQtrkQtnPC5T9dSVBAg6HSWZkH6QZ1BoJ6Bp/ZGtg6m2UgakEjam+dkWA6izxSTZK6Lqqq86s6rFQdsKqGgocle9134C9qEQ0LS0v4i3q1FpGgtRYxjzK6MRwX3ZGmGzsslnjYQofD2o5Gmu8xR89qTNjYSMfD9KyN2lkbbSgAj15rt+M5Nbqlmm5Ji5gdgWlLWgtdfRaxNZUup7OwAhy9LVr2yVj4LFICM2bWQsjbCJLlhGyT9Kxq7dlqrigcTNs2ztJunAWsM4s9vLIhaAdtmdJBg/YYOKFDGw7TtNbFelMasj7aCVE76MaN3llpbG5iXgG94QQaPB4ZvdmuyooKFziz0+EObUJ81Wm9lkjKy+zCVt+5c8HCGj2d0EjTIm5+MJ1oZeadDa7W5TA5tdqXp+fHBhb6BEIkEgx/VImXfswxAUljYKZ8hmVzXjBHU/CJwjA/VzVnPVTyR5U9msgCkqgZtNYGkeV8l8EDriJoZpcU/TRta/HSdBzsTZtF08HlEKTZx15NFsACHd2R5m20CesZ+qcWd5na/9Rw2TE1GqR4Y6ON63gcbLFV4y4DeerZeTpgg7SF7ghD17XEtCB0GQvqMszkJNqEDzN+FlCckLAxIdZmmma7DJp/hCzrKIQkzCWGkWLuyOIVELpMI1KCQkt6vRY8odu40RZVLH5YWbgI1JaEs97qjsghyz9gE8K2+APW1mGjxVoQsjDqFYYCpUHG8i/IGKIY02lKmDym04tp1WmE+L9jR01CfAa3mzLNTQ6DhN0qYGVbZgi2BAI+lxRW0j4j1m21OiwX0ynWx7W6utEjJfEOsXBkSJ5CxMHVCbSk//MkLAtv9NOSuaKmxHpg9xdWSokQBnS27iPp/FZTBOhbsC1P5ix3ShRNOy+H8mBlNAIjNEkBxVf0jGN5nSLKXNEToswVfT8ZylzRP+MkX6O3eDu2dIFcnjlzFvrf1bFr5uWGrljpC1VRlDW5kg5CMNPMOb///RyIE9twKznZWgV34qS4ivLd6nXaqxYvyJyzcOGc3NzQjd5CyDmRKyYhqi83VLeuwtJTfHnhwsvFoLbGG0KhgDl14VDknQ3UaHFx7WXQtiZh4cKEy8mFljWLM4sjrxefffbZa33sgy4qwWZLsOXV59nrVyyEtQq7FTZC2hI4mwv2nTm9L8S9kzq8DstCCKaMoikvRBGV182MGDF2587W4ojmT1aIhGn+hIPT/vGPf2wcjdUMgsM0M8Jpzu27e3fj3VGhzRBJyVoDNkOYZrsNPcPZ7PCB10pDJqd5tDhzcZXFlXwZ1YafLuy9XFvM1UZm/+G6urpdM/s5zVsWOLw1vcm3cD1n9lgq1tVBIF4WnolCB5/6bX9Ecyvt6oXgy9CCv5+Tu2Bxld3Ze6shAt+8efPUqf5MVrM3LxnU5nJ9Y0FmkK7snc28mnn+3tF792beO89pvjFzNq70zMuffDILM6E1CVxttNbkVdTn5fVEbM7lSoN/GRVcM9SeDR/5t/DZxZzmrlwZcdz98kroy3Atp1kWDg6GExLCZ30EmovP//3KlXD4yvKZ5xU193UcPRW0fTm25uypo6FMec2Z/bv2LGkMnmg5cu34nro+Jc0lSy51LH799cUtR027MhXgzJbBwZODZ89uPTk42BFbwEzhDX55cM/RkydbioVVlymlfTQc7ou8Vb6ehdJFNZDDKLI0qWSGqKpiUhiGLwhf39dFIHhgpJ762aNE8jN0LvroPEJ59CnqZ/OI5WfUo+Two+rhchBCuPw62sdxnY+LvxfDt00gt8ujZPnt22KfxcDHQCKay28HrpnKrgVul0vYzPvc8uvpJlN6GfxdLxe1+RoI+1L57eOmdCym47G6Y21GetNZMS2J0R2rufx2Gceml5WJwMjmeezT5YGIYlAdKJevjWN8+JiCzYqaeS3Itzm97Ha5bEcqv14WrQ2TWG3cXnL8+BJOS8BUxlVGQLxvlJVxfaMcrEY4NGGgXKRR5l2/DXI90o0Cx46bTMePxbGszddB+M9Cia9Ld1FhycvLxY8GBgYPmfTb5WSHFbb5QRyDKo5uVYOMquFL1cA4Gev+IYx1n0TuHpxEbVIh1HQxt5V//pN4d4PZ7HCYzWSe1Wbkm9cq4t8iBiN/c4vA3V4ORh7ykFCJCGa80/nu9nLe4BpfVZVPQ+oNvhr/ilSdqkZR1dzfy/78g4/S/JCMogZiUdkoOJMbmeSpSX3+beQA7ewkTt1IeyGdBWFSSIt2pKhoRGSRTjQFWydKpdFJk8EeFO/fRgRb6ADSHIjfjSOWNq4Tz1qL2BEPW7zjDDzutRBoHlKh2cJptihrpoeK3KiARUVDtBIMLdI9Pp6aOj7eHdcuIjZ74R3d3RZ8R7me4dtnaAj5un/DHKAqOv/T6g4rdaOomqHgoYl1//Be0ZerOee/Tg6Xz6v6oJwYfpleQwqXz4M+/UE5IXzE0mFdQwaX/w0WSc/SH5QTwWvo8MY0+xoSGCtOE1UtAq+xgOtl9RQR1XFw+Qfg54BWVURUx8NYMVpGi1cdd939AX12I7NgE686Dl5jR+6H6HeKZY08zCquRnS86ljYa4dlPIiwuXVzdbzVQhh6UMvG6s1bYVLiaPXmONUxmr22tI1pOCiqaRjuaaukYaT4TSZgLY6fCv4cAtV8uHye3gZxWbmgAhCcM81bJaW5/AjdMWaKBCCAWAFjQqt5MFJ8NIoyUWIFqvnwEfu+jBjJT7fzVEfh8g8G8kXEdOFv5fFX9DA/JiYjvLk53hV9uYR8/Sv6B+svauZ2fpvlXbmms9eAZhCFPQ74QswcGk5ZbR4cNq9OGQ6ZleCURcPLW/LzB1cPLiKAh/OfRXsGn81/NkUJTjGDuy/ea5k/TAAPsrsz84fNivDqrWy3+ePgasVNylAdzzLSsVx5R7M5Iv+q7c+qLniXqZDv5QXvDx7+EVzRP/8EkTzPxLonFBTrPoNYnqdA8aHuQ4cOdR/9/MyZM5+fKcsocTbFi7MJVCO4ewOSo59jKTM5c8TEGYFReC0GPlNmahLbZZHTNAlPwpPwQwGnkhzdOgTDIHNyD5JnzyTCz6KMjMQSMUlEg0xk+CpjBJ1kiwob6558YIRz0a5c5InA/jH/vvhTrKzDeZd84Pfh78tt8Ofm+oJwN5Tb5e+Kh//0p8NPUj/t6nJ0Rf5Co/hf7q0aEXmGgleCo125rbldo8Hcrp4Q3IWnesT8GK1UbhVw2tHcUS1gVbm5Xl9ug7Zv0/+ICQW5qUe7Ql2jffCH78KfI1fM5j/9iUJ+NrhMuaFW8HVBpQXHi/46MaFybWCqF8zwghlQI15HboO3T9Rmmsp1hPpye8Axoie3K+SAoo325QZzfaITScgMP2sG6G31wV0wQ8pmP5hRBWZUQR0CXgVmVDVIwUFfF7RgF7Rgl68H7Iaa9ufeyhMTCTMkCvimA1rY14X/oIBdvgZ0t///ExMq1wcuKkHoeNCJQlDLKL94q1QB/39ReUtcM61CqDwVQv1JhaiDrSpEXQHrVIg6m/9HhVBWcpOtlLWGWKzUz/+H1OL/QV73FXUkaF2Feq/7h2IH6Hcc7O5hhzXEMj0+/rOMqNwPK7rjLH4VQ3JFTBueRbp8RsPcYZqNbPnMgiYwN4a9RItcMD27sXoj0ASLLxZbeArepN8oshQlWXUWkarzqBB1ibMflpzjDwesKl27qkTwKqM0P/8skeAr+kXEAlf05PDz1LPk8LPUIhWiTvODghc9wAIeUiFU+wZymTxgBTBERSeVduqECqGSSoll0tNp0tNp0l+UDE4mjziRrO6y9Ju7cn0Pk2F9O7Cq0/g1KoR6tJxYHn3A+1O+b/BD43X/y5lE8ks0is4kFoh1Tw7/kpqpQtTB6gYZHDuX6O/pyUFmEv7xfk2oOqwe3NGtapBRNXypGhgnz0Ufxiug9fECIeKzRZ5Oovrj5Yv+gy1jIs/3Uy+1xcrGcKu+tSW8Oe6Fl0Tib6R56Y5q7FGpnPgPHCPBTTLc0kECQ2SP8MZqmI4MV5PCCTRNArNmNJ6tJjEDpmZbqquniBYQF5z/szHcSCecDcc9Xw3wlLSw4HfKlLa0cAeERYXPjHlFfGLBXeT+cc6cfD/nRSdH0W9zYJRKsyWuWQVcunVXKSlsNKaeIIZL67an6koJYCOamNu6ffsu9F8hy4nRuWvXrq0Q1Th1K0idQRYuTUrd3o6zim/f/m53kjysQxnIubSTxlKlApbqmISQ7ScMpcq1AUnTMVxXqiOCYa60vX0XEXzi3fatW1PfPUEAG5NSUyGOft2J1CSjMlwH4flROXcRwKgNmX+T86KT86I/8HPR7+VcbhaxQN4lFaJuZ+LkRfqPCn5o8tH/7LGI/OWsSZBrqSRJOIo+9dj8qACczpO1grxqMIr+bD4pDKPoY+TwNDVw0gPT/B3DjJ8wGbx2uL9/rH8MklIpw2uPQ24GkP1rSTSPvYk3ag4TwGX7x8b6EbyVRPOSsrVbIavE5jEiM8rKxhDcX0YEL+lHO0D7j5eRwPvxdtG0/WVE9VyN4M3Da0la8Ph+LMfJmnstlrLvUxf9VxywqgYZVcOXqoFR5d4lE6HgvUvi2whE9hXA3iVTSQ6RlJiewDDJCZI4jLPM4xtlGF+fM2HbFWGjETZIlKD9FzFZucVglMscMn2X7DBlJAqu60U164Bu1iWaTCVGRTMMSHWGE+DEHEHKDDG4yYnStZc0g3rYGSYLGw2J/O1mibz6E9GMEsdHt2Hzd6qIwAZdc4Q28dPLi1ddNMN83AvxtdEUNaNJqTagiKxqU6JBqVGiRYzZiCMKc0UUFk+qi7JFFHlaDG5iDrkmEhi6EhadkQCGrLZYSI4UdcegEkw8FKgaZFQNX+r2LglPXF3Jslf0MckbsuWu6AUn27IwfE1MJYenqYGTHpjmSVgWXv+RjNdjLHxjl4wIYYt2XM5TMw52y61NTMLfd/jn5PC/C4cvWRitLgkHxnH51aUHsndp9fQnSfcumVd37H+ecGvP6pTBMtPjEdicUisZUGM1qN1Rlv54JM5Jba1D0oKUQRM6vX+C01zr6Olx+GpF4ouA2uOgNn3fkgssXOsI+qv8QUdtvNraQRSZd9++AfvTLOwIenGa7VhTVptbloBahCI3EgzX+lCibQtkMK8Vqg0NmxD6+AXG52Q6Y3AVTn0DKbtrBWrTdwC65IKFjsKMZgttafXVxqhFqDbizcIWsAfZ4e+pjVW7BBnLZgr3sXFOaiGbuD/Y4+Cr3VHGlIvZ6AMJ2TWRFoT84o6IwRBdJn0HoBdY1Bt0QDah6LYvUM61COo0O0yRctFVPSkFKHc7f49YrTnSumWmaLn8PkAlNpQxarly4c83S+w+YzrNvgErmzi9lskdLwqbUaeBcumFny8G405jWoJRbasjkq1JDEZ90ZSOy4U+Xy7aKqiF1h3Q4qTuTFVJwqtXtxw3oSpATVVglg1rgzoNqgKvsPyi0XXMLfvWXkBNVavRyO/yQ2oRiqpKIWDOT1enbF1ygakqs2L2uo7hAQtuKpLsdU/+fA0/+7xC9jo4cU0UnHUyJ6qCpxJ50Ujg4i9yjm/UoWsgU/Si1JjThC9dItFITHCRa+BfqERP7plrz0g0EvZSSpfDu2CKXKbkGEvYSF1wGl/SzN3nTGEu3NhLthwne2FmMjWXwFJUUyLzMZwpRri6gisrI98EuLBuwrENc3KaGPUm1hQDujY2YLYkAz+fUQJpYw3M4gsERSjB6k3NKD8sXKLvQOXLYeoFPt+JE/1yKzXwvqYSFAMhownNFuArKyPUmAl9PrxoFC7rwBWVE9TvyHAa4EX00JC4A5QCaoyuAUXdApD6REgtDCXOaIbMsk2JcBO9NoW0yyh4I1wMGZipCrjkRxVgQpYCyDSUkSGggIlwtQQRYJw6fAGFMnay7YUueDEFZkDQGLheSqTw1RJ8LHoTvIt/4e00sFAzE//hiWhz4/dkJOYkRuAmHUuxz0Rh5g07mgWwycSPysbAXEyJ5ubEEr4ZuogF+E0MjKASFOgG1R6/gNGyNWO4BF8IR+ovx8ivOqPRwNQR8yYqCTNMy6BWRAcG2yg6J9t66HV4F38BFF4BrAQ9b8DNU4L6JS/tb6RvGNmet6OZ60gwowTzQ+gTuM7BJZPFSlGhS3SRLmrUlZgi3Y6DjdHuzBwrXOfn+j62BtQDjHoycxwyXZ93WHGDANv/YTkYf35G9KASHLDMwYKPrMSmJCpycEdGDmYoYMcNdCXPAYlcyCPemCQcZKJjTCQaSXSIiR++cpzMxEvkir5EfmAsiUQj4blFbdjzuPzqkiCP+J4y2elZgSuXLAxX9DPI4Wlq4KQHpnkSnoQn4X/1AatqkFE1fKkaGGHIfZxI8Lno4+mE8jici8Y+t4T3K5TnKVnFwjc+juElcvp4dohr3qcGHiCH9w3QA/tUwBck4LI4ybhA29Pjny57XGQfffchLU2PdIvtoxfulC8CeSdA03RnERbZffQQrL07gC+LPSNIZJyl3Z2QBFcQpKPbLQ2PxGyMCbhl3LCLxr08FIL6y/psF3V7Jdl4B++iqCWBIuV99DZukmL8Y+V99BxMDyruo//IFam6yiylffTZlYDVF1baabrGYFDwVcuqp+2QwTtLV0HTzmwFj99sq9WFMm1nZxXmubKVvOBcrD5jdraya2KUMfwA/UWX3frLYzz5y61lMv6iH936i8DN4NZHMv6isnCsv6g8HNMo8nCSOs3qYSN7/UQCG51nSvDFAwFs1J3Jzy8xkMIQJvoMGQwGNy1a1ITMVoSNziadwenMgX9GRTinJB8vrpbkN+WQwE05TU3kcFN+fhMxfGZR/hliuESNZmOJGpsTzzjJa+NMCZlmnc6JJwPgH1FzG9ElvzHnQXT+f/0Bq2qQUTV8qRoYqar7rxHJ/SqKsr1GLDbqPjl8n3pNhYjDRUXkcNHp00VEMFZ6+rSo+jj49E24eecduLl5mkyzhOHiBezsJCjgpUsYDdB0oDP6WALeil6c8Hho2uOZUIKZhkrw0rQ34T5RPU94UIofrFkenhgK3J/oRHDnxP3A0IQcPDLU2dkZCCAzAgG4OzQiDU/gU1CvB8EeLz6NnpDRHLtZPCBrBnOSa2POMb1yZrw2ERjyeC1eMLvTC5ZAaWVr434gMMQkvIB/92Vrg82LAczECHNfTvP9+xNImNuJ+/flW/B+YGTk9ggjgftKzX1/CCQIP0ND9wn6xv1AZ4KnM3Cf9OiemBDv/KoGmSpyGA12pAOjDY2ivpTFBFLrQymaiVAkKZCPXlRNSu1ijSb2WR8Vo1izuLZl1uWDB2+dbXEsjsFTqBjW0TK4a9fRXbvGdh0dntUSo1oAa1J6Lu+6NzxgS2gcShi+d/TCrBSNJJwSvAVEgs8RCoV8rReG7x1rlYQ1wTn3hj2+xaMdIKOLHbOu3ZsT1IjDGseFXcMJsKYYajl7tiUEtRE8em+OQyMOB6/dGapFr7U0JoBmeKbnzuyguOaQbdcJrEcTttk78B3HiXuXHaKwY/jeLFTrmoYWiNfZgJ/r2VXj04jBvhtHoTg+vz/BhkZRv79nsabl6HCjqGbf7KM98C/IjUZgraZDAtb4buGKKnDg4cjmKEDPJdwKisOzbLPQnQYf1tuAq8PbcUu8gO5GbwhUaxJQwlAbfi4h4O4RhWvHT9ih6JqQ1nu2xUY7NFB1FneLQ7Q2ND2NCbYQ/EtoAWlE9rcmzGqU6kgJ12wJoLkDwR2hxQ2t1msWieaGT004Zm0NNTBww+JW+3CCTyOlucBxbb/V1sjAPTb78ECPdH+GQl4bHmDhhIHhaz7NYhlY42gc2MrAR/fPcmgWy8GobVoY6Yg7YONhGAI6cGXEDwWLKeIxBg0FPnLYp274osCZgEh6UD76KsfigoIGRuAO3E2x0LSltqEA/7DPFyx2IMUa5nFPa2twcTG6V7wYwcz9hgZf5HkNjKL4KXCU6fH5W+Ng/Hyrn3mjj1rMWlC8uMfvE9FcrOnx9zD3F3MwEEFNpgjc4G1dnBkDNxT4/a09KSJwq781WBsDFxcjbyCExJgBz7fStcUCM2qDfvDuidOMn29t1fA0F2c6aC/3cXw4s1ar9ftZMzQMXOuoAi8nh6+qVWhGrcMPPiAOGNL4NsOzVWCGNxhjc4rDD5/or2pl4IJiLJlQjh5fCr7Pwrzna/H9Airi28T0LHTHgWDH4tjnU2rVxWB/SGDuQMBDDHOPLWD0+RSW4aqueLHDwdZWsYZXdej5WvZuAdsoi2uhUdh+y2+UxbWt8HxQ2EXRbW1rMA7WoEMy2Brb+aHf+hqKRftzT4PIkVKb0hDfRQvARaiWoTX8YxDMKxA7BuH5xcLO3wAdxu+NO1KY57WCI6V4sR91ckzw4WKNX1vFPs/BixdDJw8Gg60+oWb4vmKe72FgPMgshmMSHRFafwzsC1qq4PkqLzPI4OELmqe21c9+nsAMdMCyz2uq2IERD40FuBUKIgNjAf95PDCqCl2iKiiKqnAr3zjqS3u7CnhP9wYxXhRuP34stfsQGbwh9XjZ8fST7QRwe/fJJWh3Yrci3I5htCvwWDvzUA7e093evqH7OKw77dnQfuhQuwy84a/H8FuWHD+0Zw98xjGhLUK4/fgelDkn9SRkvAJswzHmoSjcfqjs0AZeo2w4eVxgtgDewMHRtdNuaXjPWsHnbjgmfHMMXMb/3A3dS8q6N8iYUcZTDe9dIm1GO6hKP7SBeb19wyFoGukCprafhK27eyA+NvrdUyb4nHi4G60hHtsDS4F7jsG943KNgswsAx7WV/F/QV3E9zpMp5cxN0Ij4mEo1nF2BfN4jF6x/rwh9dDJY8ePnTyUuoHgSGnHdde+oZ3wgI3r9g9bTCdw6x7tg4REjvrDh+eEUGqi0GVnnTU4GiPoit6a7LK3jr7xxhsNlSvem1P8xhu5m2b3uvL8o28siBUb5eio661EeEPFihVztiwYnZ3clOf1bVkQLw5qyxt9Bw8frrD31FYCHDqYnFxf5dvyxhsi8CjV4/P5/BWFVloPmmvslRXINd3n6xmNh/uoQhcjTtfhFSvqmHsghf1i8Apxee/vcewbfdTvZeEtfX19zN8WpLm+vn7OnPqamooa14oVlTX1FRU18Li+ZhNmz23bVr5torx827ZzWwAebWgI+el6p8uPCuinrU7nZXSeiutuy5Vt2yZe2/jaxLZtVxD8xgJHVY2zd/ZoA6q6vlG/3dVbt2kLU3UIfm2i7XwbCzuqrK7e2fAqbpS+N7Z0VOXBE6GI5m23N3bfZ2F7ZW9dB3pltOK99+obEOHz5jX9pD8CX994gIPPz+xowB/ZcOOTT25tYeoo2Hrjiwi8rW2Qg7eI9QLAFkQ1nzjAFVCc5d6C4BNf/uY1EngBqrqJO2Twlv6xsatf3DlwF+IBKGvuv3fv3t+//D937t3rX6AI9wF8787/uXvvXp8yvCCM4Dtb74UXEMALwrsA3xXeQgQvKA4fDG9hO78izD9SHgp4lAqRww7KTw7bKMoW6iOSkI0SD11SmEywA5Tbv1eYRbADVBbm7QBF58wKcHSzoc1m8yrA3A5QS1VCQmsCoWbalgBCBFssdBWCLbTFogjb/EgxzC2ydsvAFm8CRpHVrTYLAexn8AQ/AdzK0oqaozb7/Tavhbg22NxMJPXsJ2wUVS1I1DeisF5NryPoz5Pw14aT1GlWNcioGr5UDYyTkfH4mlWlPp+tQtSla//Bp+dbrUKoYRVCrd1B/LOWInZ/lvQl/hfAZcTyOHWcXB6nZnQTC1x3txPLZJTm73QUNSrK1xtFlx1MCSlIysFlrBfcsk0wjpmFvzHPLN8UgQ8uVxoylh+UhmHKWrj7VxrWmB3BoK/WTAJrav00XQWLWGZlWFPrpf0Ojbm2lkCz2U9XpcB+bTOBGRoHTfsKCGujoIfW1moeBKzKDFRAP9plTdQoGoeW9tcSVh3Q0Ch+skZBze0jbm4wF3Uk4l4n10U3KX/H8zo/HFabBD+xj9nDKok8RHmSuqHgYfG6f+rFKUTyIhqe41IspKXh7BLxCRaeol6MR9P6z58/3x+Pvxifu6Gtv84ICTF0dWltioke2s4jUqeDtBr9bQowsFzrrdfF6I6F29J06yMVu75OAT4vyOQhNCTOjNlJvEzghvOxsDB3h1iNczJFXc7x9SpEcBpv/NGHoS5VIeoa5SE5r5vMGPL1z0X5cNHQ04JpgIpkmX30RZ2CpN36iiyZffSycOw+enl4mho46YFp/o5hvZ75I4H19gEQu54E1l+AmE/79qVf0CvDeus+RtKtemXNAyg804UL6fkDyprtsB0WxaqH7bN2Ajj9gh3KRgRr0RZegC/kpxMU8ALYrEfwAEEBtVA0vfZCejpRPdsH8KZfrZ6sb1wYGLig1RN2JFR137P+/C0dsKoGGVXDl6qBMT4y3ibpE9e4yHjLNxklT4l/ygXlWr2ag7Mk0gE/wwXaSgl1hJjLRXPIJSUYNptb9psyhgdDZuayTTKFxHTEDu4wDYaQbga2SCUgAHh1i8nUsXq1GcwwK2k2p+zfMbgaXQC2DHbAdVVtjYTUA7y6IwMUA9wCUWY6zFAbkgk1EGzC8OphiBo0uFqynqEjARzKMLUgGDTvD4HmnTKazebhHcNQ0+ZQx2AHlLG2QkpwbXRkIJqpD5namMpEP0MR4AYHiRoF6FDL8H6oN2ZiQarqarjYhmiO1Mx1JJkCknZRqDpNQYz8c1RaczBepGquUiyfpnSWE1UpUWpUiLo0Lg8uQUylCqGmqkn2/dBkDPkF+Ynrk7tStxOfEj9TWte9nfRkexpKM7ad8DQepjdKjVu3txPBqG9A0rX2dlIYUnuRFJOFga5TpmdEumhp0ontRQoS7c+lhsEhBeHHVVtf2CEv/CPFkHV+o5y8JLyiXx8/tyKYhRAeg+uT+tuIYZg3OU8Ow9wKuRnrZxPbvH79+TZSm9fr+ttIayP78Bek9WzMLpx1dpasRGAIVrd2QEE4OMeYuDZ9n7w8wcWFcDavJVjkmsaEwUxfS7IiloTN5bFLIvGEeP/wH9IM8R/XEq61PRNv7hLBP37IoyeJzGWDKakK06QcpRmmxadWVYqfi8aulqT06PU1rmwj71xUCgW1em+lIZs52Z4uOGuNkYKUoFZf48xiwl/i8w189mcWV0t7C9mgMdnZhfjsa3DHjvQ42lyQ0qrX17NqDRDoZio+r4MQyHD6FavWV0XbeGptek8E3m8Wqq0FtRXOLCbwaZazXq/vnMGeBO4oE5ihMfd49XmuLE5tpVfvGXG7xQoIBWultRU6Tq2rRq8dSi1KnSFSdaAW6iui1lDppT3jbncqCwvXt9hmMDIWgFpvILWIGflj4hJraoNepJZphixDpVbvGWfz/cbAYG0VbgZObR6odbsj3ynTBc0QFDaDVt85Hk0jzIdFmqEqqlYAI2v5anEzdBcJv9qmc2p74lp3xO1OFYFBLdO6PLXQDO5UERjUemlB67LNEA/jZtBWGpjWzUat6x1KLRL7Op4OB5mwGVCnkUi7jI+GyphmKJL4og9qI2qZZkgYL3JLnRU8Lawvb8Dtlj6FmBOtL9S63UVuufMNnlrbiNste3LyDK91U4sUTtXQ6hKJWjbW/TPTXHOmTh2a4SaYF6164T8i0jDa8B9S8gLaFBV5NHby4t69n148vVXqDVUUp3cMyL0Xr95B/y7B4y0xf0g3xd4/uRfJnT98if9fHBVVTTH/TmNm78077J1PG6ThSywCmi8ydy/2icG/AznFAKdP/+EPf7h6k8HP/C5eMLybga+eBs2nr37KPJKAV+1l4S/vfHnnzlX20efi8Ofsy5/eBJhTvHe3OHxmb5S+ejHyQBzezb1+58t//IOrDiUYau4PUEJ5OGrG1Ttcq0jCXAH3niYo4CmOhYoDXL7qIo3yJSrgnYuyjcKpvvkPKOAf7sg09wGQpZc4m//w5c1PsdGffrX0QJxQS7GwH336H1xjf7VURFh4Ka6xm1/+4R93PmX0ysFgCW4T3CqnDyyVh8FEXL4//OHu/7N0qRIM8hskS6WFWqpCHiD8HDn7HOVhikUgSz0U5e0cIpJOL/Z0avoJgTRhT6efEAt4OpHDz1A/USE/AvjUqZ+Q/lB5KkTdpJOYk7I+L49ZyVBOgAsnV6dOVWr1ZHD9qZ/85FQ9IVyJ4EpCOA9VUx4ZDKdjJSU1ogV8mnyD/tOUR4VQbhUyuUb/UK7Re1LZL7LfuLlOYImEttUe4L6QDqTC8OyJfOdFYW9nFI4O/Ac8VPfSeNjTbRGBl6ZSB+JhS6dbFD7A+7aKwLbuooBFBF4qBnemHkj1CuC7fPguH/Z2Fx1wewg1DxUVHTjQSQZb4HLpQFGADNbCRRD82GLguyx8VwB7DoAZqUUMraR5qGh8/MCB36Ty4Lsx8F0O9o4cKEo9ULSUsVpBs+3Abw5AbSxdiptcyYxuZPOBpUUjHuUCerphhfUAVB5uRAXNnnHohwju9ijDQ91FuOqYEor1DfwIw5ZAN3BQxKLuEYuSZrACnckuXVrk7rYpwN5A0dLfgMUHwOzuIYXa8IBaZAbAqakBJTM63UUHlv5mKXS7EaFmcZvHOztHDthkjhRe38DH1QEtTXoM0kMHvOLwATH4Nx7xoUB8kLGJDzJiwxcv4veB3/CHL8rTfYAEPtDtkfV0etomG41E6CpA22SjkcjCsdFI5OEZ3ybsfmCav4/wZG1M1sb3qzZUDTKqhi9VA6Mgeb2c/Awpfmw+oTz2FPWz+cTyM+oxcvixHwH8KrE8RvnXEItf3WWpmGPIQEbGgJbwin4gf2AAuVQSwHp7xgW9/kKGXU8CW4GDd1j1RBfpGeD8OZBBaPMFlLzsgp7wih4cc+2iVaeqUVQ19+SRwodVDTKqhi9VA+PkPvqHcJtMcjaxJKubF336G86LSjrY/fBhVV9Ak6Poj3QUnTp1uv9pVzLJKGrQWbTmNbQrm2QUVYZ5oygBHB1FCeAkdZp/8HDEWTobw7qdcs7Shay4CgH20/BfWgSDjLlKYZBpjUrQHGyVFWq6OSopZlmZzvuasFSZ/Vp5D3arnRNaCzbbZcSKMlZjyebqWXqPN5OxGgkLO7MNkvIj6HUP7oBVNcioGr5UDYyqXPSfdIosdUo5/z+T7bTqSbcVTNNlkdJTUaOQ0lNxoxDSDExII9hISgNsQJ6bThIaYMioCLnJCglqEOAKV4W1RldRuNNp1ytWXU2FnaYr8wrBJ1FB91QqGVJG0ha7HdI7ZrnkdaNGsaIRshB1TQV6KvIJrKipZ7txlkurl69nQ9Yrr3Dj/Ss6mT6IYR1vJ0xhvQJsqOAPrAp9w5BVqCfvSIasSr2eGM4mojGcDWaT0KjXOSvzapwkulGjuFDa0WwC3VGYoJTQN4w6CKnrNBDUCVNAg4F1i67Qy3ckGEWNXOpTBfrnwktpQ3aFXn7vkuAiPblCfu+Sktc9Kz99Stnrnhf87CkFr3uB/PSHHwtuMtgdP9hdhwqhdqgQalCFRG3+J4HNbG0U1Do0ZrKqMzscDr/PpyGCNQ4vnMH3EMHg+o9Ww6uCKWZl2GxuZdJfaQg0m1PwZYS2lUgzJGMDuLWWrIAp/qDWH1SoPK7X1dYW9NQq97qfctt9NGaz4iCjavhSNTBSFrqnrwtJY/LCSge+F7qRXDjwx3yhrLVTlD3LZakKvflmbm5j7+8rQ2/mvtlwK7m3nj62+4+xYqd8tyBgPR3seyO38fMzlaE3ckM3euHto2O/joPLqL43R2/0Jlm9HW82go9hqO9WlqFG63tzgQj8R2q0q6vBd+NwBe1PWPdJZeuNrEraD88VbxWDIVxvQoI3r8ZqT6j+YpMd/lsTUJzkx3eLwMm9SNaB9I/dTJuJ7qGn1n0upnndwoULPz8DNwu/OP3rsb+/t3DhqT/+Hh6d+rW45nWnToG+3i+QZnTnc0nNNmR0nt2eZ01Ie6MF/tfYbWBzlajNUPI+n97qNFyG2ij0ay3O5MshqdroeqOv1YJC2DMt2NdKowdd4vXc16OtSU6+1fAm24Jvhrx2Z++NUVHYCyH2b4RyUd9IPoX6xhtdPdr65LpnxWyu701u6XsT97reFQB3db35ZjjBXihaG3/8Y/7p06cjj/G906fz8/8oIpTosxLyPYB3825l4d1ij1l4N/d4t1ozdn+9Au4WvvvbqQ0xW6i1Sup28wYZO7kVaLBbm08kaGCk/vdUR4F5jmvOdM10v3XZ7OVyQ+7/fqVC7/gnwMs1a2BETdDIDeZTK16p178QBNhvz9bRRwrkviZ8NKIT1s9ZY0Gs3BfWdKrAR1e+Uk8b7MBa+Kw5FBtMcTql+U+HvjKrwlnjBPY/eWEYN9XpZm8yp/CiZU6H+bpgFbpM0TmtdCukyOJo86Zly+pwbItQynIOhsAo6w1OmChzOo0uV5OL+2hzyuy6g1jn7IMRzXNAauphc19lXv2c+orLvKpbzrxn2bKDHPzCC8th2sbpdBnzvOeWv/ACb78kPkeAgJAQCZIrYMERWmfMc9orX6nx1hbE1Zx5E4iZg4/AHJ2dNuTRha/UaGvZNjEf5FmzPFobtDPLvmbO+jmfAZ3nxTE9zZtmG2dvMsc3ytOILWh0zflnD6LXFGBr65bpQiKwc5l9jbkgoalmOQQLLVxWuZyxom42ewpk5sMHb/XAyYZjkwP2X/p8mzYxz4ciLc2zZjpEw0Y1oFmObC0o4Apj5jQe1G0iPtlePpsXm1MJNoc2Ra1WPI03L5+8qPlWYFUXvA/wXDRy+Z9cozwvGplYyKrRK86L6khhPC+Ktg+jLceKMJ4XzS6sqIApOAIYNO+soen6nYRwlho4u7KmppLUDPICTuNXnVKQH140EpeSCKJkoAhbMn/JP/yQod8JrByMNAqX7jqxVV74cPefFYQPn/jzXFl55AHCSQ9M8zPk8C94w5cS/MhTvIER4Edk5BdPSa0uOVXkXbI7DeR5l0RhXt4l8H+1KMD8NC5VWos8HEnjYqFpCJBBE2m2QE5iDaR5tpDAdFUtmpVppYlspv3mgoIgmRmg2uwwE8P+oMXfaiGtOjqaaoignhVbUCUs7jVk2CnqKuATFYlYcHHB7pCY9bRkNL+400QI/i8VNVEW1pPDem1NdPlNGXbWRFZN5GF9XmVhtquSW1FTgO2uLFgbzSOCgTZkZdWTmYFCB1W6Kklh2FNszyOuDb1Wz6u6n5K34M9Fz0XFYbS6JHouWvW0+OoSfykqZiEqT9ZfNEuwxqW36gwy/qKycKy/qDwc4y8qDyep0zwJT8KT8LcOP7gDVtUgo2r4UjUwUlbnOiJxWoFFCypEss5KuRYSi4s6TA4fptaRw+vUwQtXEMtCdbFnxTa+WG/MuSC29SUetlxY1PSJ7cyZAQsBPHCmuWnhjcTmMwPK8MCZ4cTChQv3nxk+c0EJtgwsqispWbEwsaRuUZwhsbD1zKLDiRWHFzYDfMauAF9obj58Y86cy9du1DU3X1CCzyyqu4GW2G8cPnNGCbYn9My8cf7y4Pkb52cleBVgrePcwYWHax3rFt56waFUQNqf4ri8yeHYdPkFlOZKqVGCy5c7UmpfWF4bJGhBGlIu+Ry1viBJ36Bpr++zcz6tWEeqEOmKFfg3/ml1nf/BHYOqhgJVg4yq4SsyMC6U/WUGRlV7l546z0tEpJNLSQWD+YuQOmm9PG4wcl8TUyCbkLxyYwl7dTgN5zCSVW5wpifmGJmvtilMBqXzRik6p2ltelNOVLOcciPEj13bjB3UIjBSHkMbkTc1xLuFeK9rS3IEcJxyo7PJiQLelkAAWcYQPhxjORQsvbk5saQZWDAEcnhF4OrqOOWgE2RHibGpqSSxuckQgTemTdnIKo/UuTEHh7ttysnJYbz1WLg6PKsxjO+08ZSjsq1txt/fOJMYB3fQ9NlqZEt1Nc9yZEhiDu8UgoHTEhLCYEdHYwdKJsUpNxqbmUoTwIifAm+x0Ta4jdY5BApuMsTA6OMRVD3LNospJ6vcaGhyGoXwxnDaRmxLWnhKOKZBDUadEA6DwfB6GH1EdTQNVlxvQXB1C013VFeHtWerY5J5xfQWDIcbZ4UBtrVUx+bYAuWxZqRVV0uEh25Le4unnIXTpN4hUB7tSFM6qpWUc3B1OMEyK00UjyqPwNB4jUqWJ0Wau6WlQwpGypPWo87PJXerlqwSRvns9eufEU0bJ2H5k+oS0qlainqyNUVDvMj1c5gxLCBdPpuqhTOBAjPZwtxUNHvaQ0RjWIuc5TSkMNAkxZzOTaJCHsgCUhiUexWLOZ03e6n1FZhJYeVisjAzsQTFNGuUYMgrxMzgKRQTw5A9Kf1CtJjyMGRNgrxJkWLK5JUGGND0fdwuAdoqk7F6KsrHtG9fGTeLVuOUyYWNamMgfcDOshXZ2TILRlN5c596bWGW7J6aqfyLRVeWUUcEI3OzFNatpkZYOXOFsIK5AhiZa9ARwcrmRmGImK1kbmQhQw9ONSQsykdPZC53RU9k7tfKARpZXXp6xK2YMSR6eI8UKQXoi64uKcEQbmUqOTzjW4JRtEZCGMDu7vFuEthdND5ks3g7AwSw2z1kobVD490Emt3uThTzq8jtbncrw0M0bWNCf490K8DucQttQfch9B4EZeMHmReBkRGo2sbHAxA6bWS8XRrGMeA6ixhrYBT2jrtl4HEghoqYjwC2W84MMNmCNacWjaBIaEWpsrDXwtjs7vQGOm3jsppTPTR7fwTqelzWjNSiIZqNdoTUQ9A72arrhmUM2sPExS9yDwXcci2ICga6A0jliMej0JFQVEgLTXs9Hi8/+pJEFy0a9zCX/4IA9VKd3+0eH+rsHBoRBPSXPqzcKOWN2/0gDlgxWNUgo2r4UjUwqtsBqib9k6rEUpOBL35ckT3U5GsrVCEPMF/bJPy14QcXPuhhyUdvG3yl127vXTWz6J1tcvJBFUXZ3nlnbJXd/srf33nnzkpZelsV5UKU3R5+552/LxTAK1dOTLThO1cmWN2UYeeuou1e7faiXTsPR7G0bdvart68Gd62Mu3SzassXE5ZkKDlDotFyzz3Gqa2XblyZWPXym1t4Ym7H7IfSVnz8mw2C22zwX/mqbYTE22vfdg2sW3jl2kTE9tWfti2Mq2NgXtXjb3zjleLirmOVbCyOC18586VD7uq79557cOJ8J2r4ZUsfAc4qx3ecYct4Mo7V6/CyxNpkBAkPHEVCVsYCqph5iqrZdXMd95h3z9xevfuSyvDwNy8+iHYf/PmFSjzNigltb3oMDSKpfeVw2yjrLz061+fnlh5czdI+LXTv969+8S2iZuXxsBsCvY2tZyl6RNzoK6x5iunf/3rSx+eQOzuK2Nwg94J778CcILFkgC1kQDnZ41Mze2+eXqi+DRib36I9F/6cGU4fDWMbKZnzaLpWY205WyCHlsxcbXtzsQEVnzpCnrPiQ/h6fAVBgYjWhrhL0GLW29lWzj8WpiB4T2nd4c/DIPg2qAbkeYEmES1Ic0fbvsQ6uEOC7eBKTdPoOpjYNDZ2Ihxy6xtV9pWgh03b95BKm9Cp9h9805b2x2owysYnmVBVoPFtKUFqiIcvrLy9K9vTlwK34VPmLh5B1qH6SsIhqnLs8hqMKQDqg4+MgylutoFbyq+E564MxG+itqIgaEL0bTNS9M2LVPA8E1UBVfvTHRNrEQmnN6N6xjD9lln7fazs6Bp5niZp9Ku3jx9+irYfJW7c5fror28ZQ22v4RRh4AdWzevoht4z+kTLLzwt/dWnFrx21P3frviE6gK9IEfhm/uRvRNrBnYS3CsTFzB8Jl7N898fvPzeys+mZjo6Ji4MtEBherouHn6xLkTNy+dO7f16rlzExPoD1aX7t08ferU6TOnfvvJuXmg99w59q+DvbON+7uO4FP3PgEj7v0WzNh2fd628uvz8OH5t3Loxdc/mBc94PG61W9XALoC2bxt27wPPkDPX//gg+svfwA3865/sG3lNriD4HX3wOZTp8BmrBmpvL6NVTgP0G0ryz9gtZdTdStO3YQCgs1IM3o/UnYdQGgh9v42xrAPqLyF9858/sm9U7+9dw/BL19n9cxDb4C/cmwAO3xReXW/h2U0vJaGPop7rRzfvc7+sQMjZfE6MouLixvm9PbOaYA7xY4byRWa4lhpcABsT66kg5m5mZlz1q2bk5mZC/s/DdaqTBEprkI7QJ32qsW5DJybcmNnId1aLAZnOqjizFBdb4XFl3l53brLxbB3tMYbys2NALy7mQ0UWJdyObkQNoAuXJgAdyxrFkMRIsDmzV/0RezAO0BtVtj4WbNwYY0VtlWi/Z8JEbrr7n/x4GRuAyis5uF/+DF+MQ2wrr6+vq7MzFwGFl3x+2QLvDZ28W5mZrhlMJyZeelum4Lmsa+AaAuPdWV2nb57N2oz2gCKbLaD8baIzZvv3m0Lf/VV29ilS325GNYUZ2rWWAqTL6PagMhLyZdTinFt5LbdBbhlbCzc/+nF/i4MZ+aGvGhXZzGq58weS0VvXYgpD6C5XV/0j93NTLt08RKjuZUu3HkjhW3u3MVVdifsB2Vqra0rPNYBpv/HlIt9GPZaDfBitG9kBunKnbOZ1vvq9KeXOlqOftX2VR9TdRXrZofwS9gMhISq8uq2YNWXLnWHO0KhMK44BHdtie01uZkN+Kmui6cn3l+55wp8Ed69yxRQvIMhCV/qem3llUvd718Zy7wbVoChml9b2X3o0MoPL42dHlOAoe7+c+WhhD0TH/bdPK1kBlTvf97/auzuoQ9zscny8KWL4e6vbn711ZW7dzcrwl2X+r66e+mrr8K5d3MV4cyxrrt3v4JW79qcqQx3pW0GxV9ljmUSwJk3u+5cugRdlAi+1JULR8BYRHNDprwIhgJHJrE4qKpiUrYYJZlzNBQTCB4YKeuyVb8jkFXL8kDx+6sX/o5IVuVR899///3R3xPRH1Fvv4/kLQL2vd9R7zOyeiYBzmpG+Lr/9xWQVZI/r7zCaUYyv8pilxU+/P77L2tlg8FFzcDy9hFZ+P0YeXsNgea3346arqj5yGc8063iEoG1R/i2QCOtihdsxvwjLx+htS+//HK0tKIdhtH8MuNeNJ9f0tGFEvD78y00XSWsRc1CqeZ+G8368VEZM94/UvX2fJ4Vb4v3QhZ+GRGfRasuT7zq3o5tQpJGUdXc6juSUhcVdn554R1WM/FhJSdf54B9i2jgYAYZsjEpW93wxR8Y3/vdKviRuEUDYzQw/vZdpYqeTpGQ+wArTSxEg/krwTBlMYMcnqYGTnpgmn9McHv3rlIDIdy+Z5+p2Wkggtu7IbC8KZEM3nAIwc2EmlOPZ5hMPIcpeZu7TzaXGI2ktQFVZ5zsGw/FAatqkFE1fKkaGCGk86NEgjOGPDqPUB6FjCHziOVn1KPk8KPfHC4HIYQBvH59nggeD5eX3w4cO378WOB2HB4Hl88LlJlMZegvMK9cHi6fdw3S3mMpM12LoePga6b0iJiuycLltzm9jO7b5XIwX3GcaiFcfv14GR8uO369XBq+LWCBvv1twdfThWaky5kx7xi/gEtMx+aVy9RGQFgbAdmqu76E3yhLrpfLtiCvVWLbRKQjBUwMDl0pUK7YRW8fSzeBpB+7Xa7c+cvn3Q5cuxa4Pa+c6LAqLxc/rh59gEe3qkFG1fClamCczBgymTGEPGMIOCnqdGKxcMXzHWdVwi9Z3iUrCpdcbyBKpaTPy0Z5l7LziGCtE0IrFzq1REma9DXgqJhdQ5p3yVpZaZ3MGDKZMYTnFjXnf8nJL4WeTvSct+Tkfwk8nSwK9C8F/Zmmb8iq5sO09sZbpLDeJs8KYDrhLXJYkf5fwgLmHVQBa2eTm+GdraI2Dj6w2rCpqg3v7AcDqzFDVQFpNVWnqlHUNbeqjqSmi6qqDVWHlaoDlmAoUDXIqBq+VA2MlP3a/LdjZP7evfHPXUOBS/fuvXgu9pVPP4195oWLe/faqZf37N37aUvMSxcvxjzR8unevXtepua/7YA37ZGHQeFFx9vzKfZ9QlNOnowxgflsaj731hYpuAU++HV8j2KfAVv2iMN7kAVMhVDzowouvhAB9vBMiH4kFVXx+slIrUTglk9Pvh6taopf+46L7Me3jLDmcBbEacYqT+JXW/BHOE4Ka1SoGdm4B3EOH3rHntiWpWLbFWs9d47TLoTjegzofX3+/Ncd8c/Pp/Z++ulFkJMnT+7Zs2ewpcXnODf/3Hz4PefwtbQMwpPwEiI+/XQvtZehT2Ia4BaAX5g58wWAWzB8koGB3QvndXEfVwtLCgtr456G87p409hFjbfeVi7gC5GVioUvxBVQXK24cqHmF9YJFzrWvSCt+WD8ushBKc2iKzszRTVvklhvXrUpXrPMgtHMGM0h2WXsVSG+ZsXFpbcYzZ8xzaskqPk/o6reJluzAuVVKpbdrTGZlP9y9gm+NMetLvFPif9yNj8jKqZmnVF4RS842RbCGUIYrugfm0+qGS54HyPXnPTANE+b1DypeVLzt605SZ3mn5FrfkZu+MqIG75UDYw/lnlRI0TZMBrQjfLspUFXkpioa0pMLNEZlWCIT7LDtKOpBG5KDEYlGJRmmEpKTBklTToZOAnt8jZChBJTRiJ6Q47RKLUXPInaxEhovymjGfrOcMomaaHwzvTB4cF9TN85PjjcIr2BHYVjXD24wxTplztaVsuGKF8d4ndiydQ9bDzz1cNRzYOrFYKfr+6IwBkdSrA5pZlTvF86gRAXVn31IKvaJFk8HswVcV9IDmbDnP6TKaJp6z8LJEVDBVm5xqSgaET3WyV+I9OzlgEs8rlWeTv05ZPzfV83wanaIKlq66WqTZ2TO0C/76nPP1Mh1OsqZHIhQwC/+hdieZVyqBDmS5NMkiZ3gD6UO0B/mJ5O5fMY9wwSGNw/jmMnEQK4/HZGfn4GchMhgQNw0ZB/jRC+jeBAOaHNgYyMa+S1cZvxViFzI2G9VQCGe7I/5Yx3C9xV6aDy+HFieZx6IoNYnpiEvyP4kAqhNqgQnr+ooszg+Ysqyr/z/EUVFT/F8xdVEByNRA2sygxVBVRVdSIwRJGJjdAkgLujRLe7e5x77GZDO7n5sHtkZCQwNBJwdw+NjEBAmyGPp3N8JBAYd0MQo5FxNxPoJ6IZXvZovanjnsCId2TI09kJwY6GvLaRca/HZhvyYJqB3SPjwAZsnnHPSMCj7e4cGhrRasch0NBIkYfu9HRqx/lwJ+hFHx0AeMgGygIBG1jTGYA3dA6Ne3hwe3dnp8XmGRqCgD1g+xAgQ27vUGonxmmP2zPi5hXQPWIbCoD6TvjzpI6MeOjxTss4mOMOdGpt7s5AEQ8GVZ1e2qK1DY10dgZGPLahoiH4fLDd4wHtQ3wYIiEhyzyB8aKRzhEvTXvhI0agfJ3ucbBO6xHARSPaESjleHenFhgUAsrTOTJuC4BSUOyx8GCoOqhnm6cTAkQFoGY7oUXcneOpnqGAx+sdGnd7hqJwEZhsg6JBEb1DXmgI7zi03ogX1V93IDAy4uXX83igu9MzBLXgDnhGIHDRyHg3qOss6u4cL4JSeAL85nYzwvzHcbDwP/htxzGP3NJdVCAj/GhRM6LRkMTETQfegX/CLhqQEroTvdbNb+6ARfZyxsaHU1H4MjFJ7aaH3PBP0Pm5+oiTVO8ICj9GWBtKR/f3YBQliC+6evrgE88/SZSP3ry6AyboMp54EqdE4dJriiaLNq9OGczA80bPM5NOPQ4c79LRY5ZSy3wPToe5riBdBbQGcinFJuUGtcMmbhLtJNJc0IqSI5k1tdrYfN+ro2oz9u2ZgWCzw+cwm30pKT5frUagNsRT271hBpOSuwDlBm9NKdAI1bbs49Djhza0p85gZ9XM5irabzZLqd2TugH3DSaNeIq5J+jj59lebY6q3Y/URmBUdWaIRBqpOlC7P0YtC6Oq8/OrLtoMPLWcZlx15hSu6njNwFPLwbjqcJpyH7yHrxbqqz1VCKeY2cipEBJV2AztG4RHynRh69YKmqE9VRqG+oqqPSRUGwPHtm57qjQs1gwSsEjrSsISzSAGSzaDCAxqIxbs75ZQy8DCZpBUi2G+2pMyajHcIdcMsfAThGox/Dx3kCmoZSLjPcGqJRpFn3z+CWiGrzGKrh4ULEU1xa3R8/oofyUBWr8pJ3ZigZ9YireQABvzmmKXeJ6hJBXHsTAZwu/8fMXxLEyzROHVHbJ6hZr5Sx8lYktSPJi38iHO8mFzRLEEy7M5qlicNWZnOyMHrJnrqqKsMTvLVWHl4IhiMdaQle2qt8CM63ShYhEWoTUWPD07XaAYWEMsaiis4eZyp/MVx7HZgOZFJ36Z1aUWUTY7y8n3e3+a/QLCik2JfNYYg3Iwo1ioF9WVPXb+GX1NpCDFfL1sXdEiMFYM21sNcqjXMzSCv9qaTTyWV1d8sBtO8gBGq2ERVlBXURDHiYWB0VzbbOLY7CxdZRRFMXAhaGgkFigaRQdZVlhXts7AeKq7SBhf1BzatyPRmINbgK0rLQZjo4viIXdwR6Iux5ANFYA/2sNoFLt6nEGFYHE9B1CoAL0Nrk1SBZ8cA/8qw5CzvrBGjzS64yMGx4yiy9YXzmFtJBhFfzU+AxSSjaKqMoac0JUST8/++/YTdQr7jfn76LenEtJ4W+72dqWd3fxtue3bt5aWEmpGNEkxI7uDt59IUjQ8upWYoJi8fce4mAp7l6KXKe3us1ar/N4l3jVN+/Yh0dSY0b1LggugohHRzIqRFTHh1VJRt4cmhuEqsdNiIYVh0kJLCrvBaguhGW4cTZoMLkrtpIlrY0SvsD7Ig90dZ1tkhQdDrhMFicLhaqU8GVMicJoiy8Fz3QQsB4dJWBYOVxPl9piCrujTyNi0F6mn3KTslKfUZgzh3KL2o9PPc6/KbXTiHK5enX8cnRic+4vcFirOlUsZhs1Zj5HDj03CXx+OriNjeL7cSjMvhTGGfXICaxMm/MO/QJH4eaBLJCaTwJB8k+TvE9T+iDAXvHKitlFeZX84+FWpn8ku+g1gVYOMquFL1cCo3l8U8lIrZzph/EWN2U7INwgJw7INyv6i2YVafX1loc7gUooIlKTLdsH2aMjNkqWzVu40yDtOGGFbdGEWuGdWFha6Kl0GWf8NI+zkdmZDljhr5SugO1sBztNDTm9IQFfodBUaFTxRsyv1NVBzWU5rYX19trwZOoOhRl9T6AJxulyKPifZhkqrtb4Q/hsMyg4qBvThBqPyybaquPH1KuSbbuefzCkwCT9c/qLWeroqtGXBgi0JvQsrQwsWLBi9nHy4ng4uEMqWkI2iqi5nJdfQrX0LFiSsW1GZsqD4lqvXZdE6FsTJFhsVWhC6AWlG6Z5iBIdCN3qT8+jglgUiEqJGIfByozO5nvZaAa5yJVfQWkdfcZ8IvgXF30iACMY18LduRWFePcR4hCfy8i6Lwb1MNtRIMHF8AzJTDF7HSxa7MJpZ9r1PxOCk5OTkwyBwAyoPY4Gnss5zyH+NXTp68uSl8BaAbX5/go2mLTVWVECattdYtX6/39bDwSf37j0Jf3u3AgylHvXT9cmGyzaA/VqLa92NW/yqAPD0iauf7r2E4C1B2lrXeyO0BdXzaF8rXZPceyNFAF+8epqBfVq6sNd5q5hrwQWhKrqyt+5sHwfvOXbs5KWTx4+dAJiu702+PLoA9433cN/Y4tNbXDtnc7APQon+W8/LRxwA3/jkRoh5dtbMT26M4nt9Qf/lSG3c2Tr4crDn3zAMNSLWD6JPfnFv7N+CwZ4jKUxtyMsX9+509PjCB/tI4P+6eqct/MWXX2whgRfcuXqlq2uibwERvCV85cq2K1vI4AXFV+4jlgxesKWB7XUkcKSL/uDhEDkcomzEqmH4omyhLUSCBsYfjde9hRxms5OTwLS/1d8T9Ld6LURwgUajKYD1bhKve78G1rA1DouS1z1y3Pa1ovVuja+1VsHBG31+Sitamtf0BIs1ssKs1LT2FKSYNa09GoVUpAjW1Pp9mpTWoGKSU7xgpHG0tgJLBkNWVp9DY04hg/HKfwoxTJRMdrkKoTapkEmv+++/173V9VFW1k7046L9XV1do3r7R/Ag7s+FEt3v5MJXr3LSrbm5uX16q3h4651WyvUKKfyKi/pIDF71Co5Av4r3C/IRtZNQM/A7GXhVvGbuWb7RkpojfMQKKXiVeHUQ28zA0RjyPM2ispMyfMQJtCAD2z/K+khMDJRgBMawTPDzKr4EEWyrkhKqLzcqXbmy0kfFAG/iX3HpohS0CeE4M96UtKZPXQFVVZ2qRlHV3Oo60jeG1fbnVXG/8sdgvOaPJG1exd1wb/1IfJBZxQK/jRlkyIavVczwhQfGnSCCgTFW2IFxcgfoN4PR5mQ9c6MI661WoCry4CZP+Vy03lhZ4QKPkwpXoV7hXLR2Td7OLJgmhinrnYV6hXPR4iN5XFburEKvpkD2XLSAD+tr5fekf0ewV2FrfEHQbmQntLMq1ijA5loIg8r4DOksQY3Cueg/X6Zxcvns7Lw1yueiMCvjygJXpBr9rVHFc9FsQ72+3lloh/zqBOeihqxCCMVar8smOmM0ZukKXQop3nmnlwaC5PWT56LCHaA/iL1LPyzYrUIojwpRt0N/ciHjawc3mIzS/CON0vzwnYvaVXR+/QUrMazXD1wQO3UUg+0XBjLKBi4owxaY7BzIhyg7GflwlkDTFlnY49UP5KdnpGdkWPW0xyuj2UIPjXv12vR82MB/QW+xof2aMnAgoNXb0zMG0jMu6GnbOOxgtEjA4Pvs6ayygssHwPkDWth4OdIpAYPe8aER2wAXTOwCbBe18aeOBZpp2PQZsHPeR/kAwyZST3Rmmj8i2T022O9pL4vAsLV0vNtt541IH0Tl/sjt8fsfHOPM+Lfr9+/fvn+fB6C9/5zcv3+/fcO2AAPnH4PHkKrjb9HXhXv/7yOZt5+hb19PvX/9fqpU9Ib78Or1++XX9zGhD1JT0XuvS8DX0Wv370O0hvx9gXJ46/3U63+bJwmjDwZD5gWul2OTZghooRnwmX+7jt4Ehb0O9/7WnnpfCp73N+aVv11H2uehB9evK4anYGCyWBbX74NuYpj9+4FkDOGfi27YoxBflH9GtWFPhmx8UcG5qBCOjy86I5VUsyAZlqLmpAemedpDrXnPfnLN+1L3EGs2ncRJ5AjgfRBqubs9dc/JPfsVYdO+QxvQbr/2DRtOkphxqB0nqNtPZPM+vMXgJFkBj6dCQIz2/WTwng2HTu5B94hg7sb0wDrSD6E/J6nT/O/kmp+RG77E4ouqGBhVnbiqOiVWdbI9eZ3yrcKvHvnsVVL41fn0kdfJYAiX9zK9Bm5fVYRf/ezIkSNemj7y8stxpsTD0TTDLyvC8199lck0rP3sdRKbP2P0vk5SwFcZ+DMi+PUj9JqX/bSfTPORI69C7R15lbBRXmX+Jvvz9+OKfnJe9GvPXhYRy4OcvcyzEkseNc0gIk2wiTxe0LaCWDEYckoyjEDHviCy3GBsampqNpU4m5xG5bUJUMtIk0EZNhpKTDh2g4Fk1cOgg63kYkmVReEmOC3ZIQqL7EH4yZnsrJISsT0ILldhzI8L76EodMW/oq65VcEBFUIVqZCH5Rh8aGI6qdgu+tSUtDTijagvphHLi9QUcngKNaoGnp4yqgZOWdynAk4hVD6Fc00cVQNjvFpeXuKiu6O/Hpu3SlbwqnSoZbV5tTnlhZ4ahR1GGM7oMHd0mM0Fo2+B34fM3qXpKIAR7KLEAePNy1MO6pYZJZdWp5tDg+iyeZiJF798+abZUlu/MIyDgETi4S9fflCCnobNaEHJgtmA+GBInbRmFPvGNBxq6UD1t9y8qW7ZsvhvCPZrAtfGMMSfwt6om2YjVEK44DPYPcDs8P+3/b+lZSq/BSdgklhWosFnQjNSlb7HOTMWbyAZkaYzFpANX9NJUQSnpITIB8bpE9/HUfQX5PCTuyCaBqkZz5TWdW8nLeA0iP9xYjth1YHDQqlx6/Z2Ihidb5SWbm1vJ4V1xlKSYrIw0HXK9IzIaU9pkmIxozAU88T2dlnhwbpSw65j++U3g/POvoylJdFt77zIWNE96fxTNWNOE/eS6eizcfeeiDmvy3E2MzGYMvq3MilHTKb+MTaWWiysy9EloiF1bKw6bevWZt49MRh0oz3v/ZvTqjdvhcwn+8fQvbF9YrABrMZ5Q6o3bx7DsZuauXtxMJxmY/tMR9O29o9lsPfGxsQKCAazBR+GGhjGnz0MwbqGm+NgY+n6Zi6GHNrjb4q5x4eh5x3aIy/RjlS6q327UsTjabxuRNr5k06Qdn6irs8dsMhcwgO21EB2cAP8TKnzBBmLYjoRD0h4FP2FmlF0cl704YPVuL6ocqr5xp5OA7CkT+gLoUcuC/kDZPno7eBToL+QYSdKMW/NQPnoM4iS12u1GQPglJFBaPMF7IJAmo/ePjBgn/R0mpwX/bFkr/te7ZhLFka/M0g+QJHx8lSIMAwI7R3ih8Yb8tKSYUAsNN3p9rL+W/DA5vYInLmmChKU2yB4fwBC0wNggYj/gSIIi8/zuOLDdCdabYe4kMh/i/bgsPHu9k5awoeqE8WZZ6PuYdrt7pRyuLLQEG+9aIh9mQ7AgxFJJzGLtts9Aq9buHeOpHZrLVKjqBfCBHqG2Af6ANgDlccfRRN40phgg5+ICB4goV6SnK9Ji5/AUTX39YOHVU0bqpqQVBkZjyDWPZKfPkUU657b6vGUIEqzgvwU5r7MOLo78yOUmBdUbn/er0LUBWGb5iSWaXHLOsZSEFisgTnF7PhlHeGwul5Xd/58HezHKaysdGVny47P6+v629raqvthawu4xNY7s6VgSIdaOrutDbrMxhY9rUdetFZnFi9JahSG1KUlJU1piK0Oc16i+pqflJSUcCtHfBie3orYtOpZdMRDNxHBBiGM8rKC9GM4LSEywkEILuYVHmxwNmOBC3kktig8cAa/kIhcVSJwIpLmMQxXJ/Bh/AofZs0ofQubsbElYrPdmRNnBlfLRmx0NWeHXi8I/xXTKLhNQHXYxnxNCSN6xbWg7nx/Wlr/eWeFVWuvKRRG/4rvG+uT6up06yFct8tpjIm1BucbObFSWor/ZWXFvpBEoUYm/aF2qBBqUIVQq1WIukFG1fClamCkaG9oFElCcnICvhOaYyhMGY0TH0p0n1yjxVFU5rz33hwcJ6Wut167RTwoSs+N3kK6dQsHF9/qddr9oxLhVrZsuZWcnOcNLbj83nuXkdoKfc8WmagvozfWVdLBOStWzLmVbLBWjUpHfUmAkBdVeRCOO2/Firy8eppOCMIz4iGFqOReJId7eyG4E0Rp6mUeSmiOxnziiwT8ezmYq+NI0KoaJHBbsWJFRV5NPXqcN4exectxJt/ucfYhCoc12kpXJM9JWLEiwUsXJl9e/H/bOxvnpq5r0Z8KWkA3aUqoHJjrvjZD6Mu7wpziAlbwtQQZGdlhrgaHSZHFwOEZlNS1Rv4Qx0ziAihINoJHI0HGdnxdMFcSgwXGpeA8A44ZxwZbodihzo0ZV8RJDXOHTOa9f+Gtvc+HjqTzsdVCH2m9bMuy9NPS2mvts62zz95r7d69m1eVNzbWPfZoJq9ddF3c77Cc+XI38nN7i915YJnoO4CdxWOPHolwvIuuPXM4IkQwwpYtXSqklsJwt0Sz1+U+g3JFCX0DMk05zyzjn83rfm5sbGasWIADBw5z2XhwuHEXYJsEP+d1dz96NDMmaj54UHjP1L3dQgD7u7sfPOju7ifKCPRx9+jvfj3a3UEEx7dO/e7XU1vjZLmG+qd+/eupfsLERPGRb74ZiZNmMRpau3aIPOVRPD6X0+mx5HTyRuIkKZ3iEW9WxZBS9VX3aVVtrpSqrrpP+zeRDmevul+4klRzWl0PTc2Ln5jmBXOa5zTPaX7cmhfnpvmfyTX/UG34klt1n8PASDFt8c4hnH7NcQ3l3Tw81Ckn8TaUcq9z165dnThznANn67wW3yUvnQwV2UUK74pQneRw5xycBe/stIvwdjV4KA4SY+0gDpwc9bAWnCbikzt5ybBZVg5GYrHYEPohgHfp+bnFEAG8s3NoyEC3xWLwJhqwL9gJRvtofXDXziF9RB3u0h/cFUdwKL5ziIlo2hwzHgzRrRH2IG+HegPDXSE6otd37dRs4M4uOmhn7Ayrp4c04U7G0BYEx/na9AYCP+/aeZChDWQR3BWP74ywnbuGDhLAnXrsvSFjF4nmtjaMdMVIYORqX6e0i0ZUYZ9R0rvbuOFL2e74QenwhQdGAsEDY8bVpcWHVVc6LeYLgXHjtmXxqpMqK534cd1ZoAXjlU44rY7H7jFrwXjhBFxjiTbQDVG42qIBL4BU9JAw3kE7PDBBadWCzR7h8qvLY37Trb6MxGpu4Olai9XiVivJDQ20RjnaCdNXFndacY3MGVeUjggbYkcTmxa36vQsCkgt7YAqcpDSXxu2FJQ1uUs8ZbUQRW3NBWgi1lzgKSDQXMDVNMAzt+rwmxlySM0bH2eKmp9/mymPrfT50wKfJBaATxELFN/sIZYnWvMlF/gn5PBP+BqgRIq/j2uAEgkqjvx3f43+CZa9yGXVkJclFm9ul88WlhNLjhfm5uC/DayrJBYd5ctBnuCuKGcOktsx+K3MjDe30umpX+kku8TpMax0EmRigrTgEbAVa+VSqcrADrjEjJJhTbgIYEhBhdROVFzShE3GS2vQslJY2pm1FjULdjjk78vAsApVXK4Ki1HXOtTXi166JH+fG2Ry2vCbkevw5En5+1wixLkckk/j3iVv9ZHdBHKk2ktR3t3rsNjWacluL1XN3z2iCMWFO9UUB9lW+hXo+FShcPcIxVtxpGu3LNvbPZWyQ4AVbJ7auLFQBpY1YWZj9+g6MrhwdGP3xhkluOtfpcYMd2/s7t44lQGLfvDpbFJzu7uzYFvEv1u2ad1ycKUvG+2c4dhsM2TcMMqzKg3MZrs1XVe4NcV2d8dV4XndUnZjrxpcmMZKW5gNF3ZnyKgyHJ/MhFN2ZMJSP2Q5T4R3/6sCK/GHANuqjdAv5FlRtQjrWnavK5yUY4Gel21zb7eSjGbBwxs3KsG8ISm4dzRbto5OTk5ykYl3Ipjv+YVTU8Oq0ouGAn6QmTfDy6iCTKFBxqt4xIqTnEgK42j4ymlgzK0e/fCeQ5ushJ9FX2qN5e2xbCL7LDqvsLVw5D03ifIFaF1ua+FA6R6rNr4YL+KFrYKn3zu6yUKiGdGwVfG5Ag3lC4Tlwa29PaDcooqLMBjef7r0OVVbUjBuZunaPSq2SGDUTNhADg3dpAE38s2EXYjKtnDw8eNCM4d7UH1iBacjuLEtFAo2Cobjre/ytmA4xtJsTKQH8K7I545aFTTTNB0Uiokf7MWXYE/vya5jim1uSxgTokeGbyDF7x1VamDj8bbY8ZT3FFso9A1JXAB1y/tOGhToHxc5N2/SjCDayHq6VK0zpWBk7mnVriHpooUD0OncqgeAALfOu4i7M0nnRweK9lHI+bmxQ8sC8YAFc1U6cZpmGGT6ScYB7hr98J7vEA9fuea6/+65N+GPN8/9liSn02/PvYk25p7jNqTCThK1nE7p8IcfnKpTyemUBp/cS5+qUvnML4FB50c3b+5trpOzJgMGppn+6Cb9QdXND29WqcN1zSyo/agOcgavamY/rFOHP7R/hPTVwaWrqmb6wyp1m1edYvfyCqv20jfrVOGqU4wIN8PuHXXN2CECvFfDjFWnhPeu+oBmNOC6mx9wHq46BTt3tMyo27u3rqqurgo2JcG2IS34JmR2vnmzmaFpZpVmA2GLEW1HixLYDM/JwUDvRWh255ODoQ/d/OijU1V1q0jgVSgfSJ12F9U+h52D/zL4R+Twj7KHL40zevKB8R9xXtQKU4wWK9nsJVxwdrsLzGYC2FLiqXXQdgdUS9JM72bBV/ddLpq2N2TWps+ErSVwBd5pMbudAZquLbGqwiVOusm8wdPkKAs4aHzRXhm2WF0uS9QpVBl1WNW2yZidtDPq5naNlzWBarMKXBKg3SV4RYKrzOkps9eWqMFNdjO8AFkAxYHcjoAqHLAjf+B1EdFoLa2uuYH2RLlFF4GG2gDdoAZb3HSgxBzgnWG3u1U3DQHojGLaBf6rVd9QZrY46AZztMDjrLXTDos6XGB2l9F2sLcMHO02a/U6s6UWB8VRazFr92cLVGByOj0FJURJBVEhrxKzZa7ukvbVpR8/nyG1SxVH0ezLeOm9WGrGj2lSGBooKG7yiAe1ErxAhD1Qq08DXszDjiZYsVNbZifR7DDjAmXcKKAFBzagZV/mqJsEdnncBVar2x0gayAs+yppIvaGc0OJgxh21AZoYpgggn89HFCEZa76eiyKF+ayL/uan/aLiX/38D9CJeUzRIIKhjJfz9zaQiRnHFTs9c+nx8hwN/X166+//mArEX6G+hzg178elcE3Z9EcDKZsVdS+ORNGpmzVNEaEX/96RhNPwdgUdVwCI1MqVHEMf35cYkqFMs5pTsTgpvBzbEqFMs7BIXtvoT4heEUR5+BeNPYfl5oiiyP48160vj4h9UqFbFMB/jqBdyCw8wR6ukJBN8Cff/3nXoZmGLaXxAyQIPv158eROwga+LohJLVX3XWv9x4nD4qk52mGO/eOlEsXzaHzqx1WmTCYQHJ8aw4FZzZLhgKtQWazdJDRkw9fZbkNjH8nZ/QW2VN0uX9tFihtC6focp9Qss+tLM4ApJIvkzlHzz6VdnMfG+0uV22Bxhl9Cf7AXeZ0F7g9Aaf6iRjsRECf1CwoaQlMLKhqtprL8Kc6TiNkMraqwHDuT9MOoRavxZ1ptRS24HNX/oTYYo46aXfUbFWA4aQcf47GrKfBWYbOMKTnx+kwNM/FPWvmJwwcJDA4BtHp57zpsIvftYBbizzjjCo20NJEixMgZg9dVks3lVgVXYdOU8q4U12zp8Fa4mmwKMKWAhf2nYWbnbEUqOaTwVGB038+3Oq9zsqdLwU80FM9DW6NXmeF6svcfhKHo6FAqwCBFYp4NzmAJen8XPVlxcMq+4C1wiI969/RZ1FNeKmn6fn5IZwASssMs7XBZAqia57zfqDRQDPsnjGxocbjXNIqNddBNe1arJa7QLpC7QTBbHaWmbxtjfxl18Y2Zc2WEnfAZDLwauEVhvmKMKhlTExbY6OglqEZBZhTmyjkLTg+zwBJfBTOgEosDSytb+MbdrwxxMLQapZdeAz+ajIZU2pjQZOpFo5J2blcS4OJ1sckak1lOBeUzKyaNAxIrd5kbCjA40cmDBOztcZUGI4XJoyglj9sMidRzR6G9krV0izM7FrlBpmSgkAquvCKBPhLcuCmDYwoDF4xDMchDKxTOtak4Ozoglp3iWwyJbMZwuAXwgDR9aIwyI51OAymjDBkzTJyMKg1pkfXxHiyR0YEY7VsSKrWWCszeYlgcwFSmx5dp+y0BcxveJj06NJsg6XEKj8iSQ8yHN0mmfFTnJORhsEPas1m5bFONQyZo+gKSXQZp7Ja7ho93zCktqDEonGNHq8VCGmq5ffRvzQvZnh+fu2CpQSj6L/Mr64sz/fkL9Qt9DuuLrurVjD0XzbUmqr/BPA2Xb2rxOOtUStFOr92Q8C0vAVgv8tcYL9eo1bk1EcjWn8ov95uLqDD21TLp1b66IYNAdrisiO9ldvuqsG6d6pNDSW17iY3sO9owOFwi5dGSc7cDjrcEn5B3uYaDoYSOocsbqvVDBtL4e4XNYoswPkgTQE021oWyA/UBuU1J2cxvHz5tnoaNqx6rGXs7W3Lb8vpnR1ce6O5BjWw8jpdYC1zuxo2NLH7jyy/K2fE4Na19zF8nXabXbSlDKZRm4z7s7xRM9tcUwNFeDAchktErvr8Q/mfAg2WZNoMJoDBNagi7veo5xFbGfTk/6kL0fU16QbUzFZUDIreOHTVUa+rzP9OoLwS6Gh+TZoJszX3Bwehbbyf2/r6bv/b7T5f3+3b/9bX11YtQe833xicvX+/5j68CuHfo6BSMtQMhjrJd/FtjTQOgxVQ9hjU3p8dbL6vUrS3ZvY+OKHnxiywNbM3KtZiP8vDoAt8ADaAx+BVyYobqxVhaBZYsBpb1Zxcfb95dva+suaa5ooesADUNfesHbzPtSUbruHdC4KImtm1FckaharE2Ek1yVmsC8IM/oMbeRg7aTaJO1nNffR7dcqbGTB20mwN18ngDSoqZmuUiyNzTmo+n8RwczKpBq9unoVY3a/hyi6DF+6rVVLmGpZ26P2NKilnptHb9vs3FNeLZm1sA1hpMBfTrZTrytXhVE6nct3KavhRhYUUMbryFq/R34WVK8KLhaI2YZq203SXjkCzzodz9dLG/eUEcAvOMGm3+3SPG67mzGBXEphRXt6CT4Z9JA1EtJ/1+yrLSWAUlP2kQSEK9wJqW5b8b2V4WbYol1J6Q0bmrgHNXV16wmf05JtnBdbIBBk82W+0s0Yj/2034mTfrN4o0PDDBIOJIIYZvSGhDxr0BvgO6hMGPX7QAI/gewDbmVCC0esN+GW710Uqd0d2w3dlZN1urCEIWcETbSwHB0N6hmGChiBNs22/SpMIwPpEEJ7WJ/Q0TbHwlgxoTgT1WDMgNsS1w886pBmZBQBYylLGRIgNGpBiBBvWATOEbxCcwDCoNgTZUIKl2DYDA4nMgYc2sBGkNBRZt24osY4zAx4GPUE9A0opeyjEMDjtedBg5MwYchgMLvQyW5AxGoJcVnQm0Wak7AZsP7gKvMqAPjA2omfakOJfgRlIix55wBCiKWQuosEymjcDjF2X5g3MBpkghcyF5oJucA6jjx+USBy8wfAsihOV0LPBhAHZrDew7L3NaXIF24yCAI5jDJQhhO7DH2BJ0HsuHb6Dmw7KDAaGTSQoYyihR10C+Q5is2Tz5kePEIdul0D/wGoBgQYaKdpoCIVQv4EWGBgw49H09PTmzXAD9BW9AbUc3YCHca8zwpvZWUNIH2TAjEdTHYA96piC23NgRcjA2JHhfBflc9cnkPuXwPuDTriB2yUoHgkm1fu5DosuiYEpyAzBZuwN1Iu4Hs9rRp4MsTRSzVzZvnn7ZvF7O5iR4J4xoN+oP0PogkYO1p+7dg99H7537Vz+4XNBDjYaOApgA5/2Sh8KQghx5nxGSJ9vhyODf9YgakYCnkaugfT9rD7IcgULUEOEZ3mb8Yuhb9izD39jkHuWQU6hMGaA4zsUNNq5jo07MLIHHd1sMBREDtQLfoboQ9CNCAsFDSED/AUR04O9ECegUYjpVFDsRnTIM8jVAEO/gv6Ajjz0PnbefGkEjeAnxqjXs1zhAhiR9PAnPGhPiyAvDCMzvtkZNnuwIxsYCbaLXs57triDqwGqsRH12KrzFRUDKB35PK1KyiePXc6rKB4ubOXmRReRqeXmRVXgkyex2sZWYS+ICnxs1QioLWwV93cUK8LHTl4ursgbbuXVNg7nVeQpwCePncpQW1HR/0/y8LGT57FabiaotXG4uOKi7+xrcjBWW9xRKDSsF9Re+fnZ1+Q0c2p7BbWFHcVbkVpUp2aRbBgkavMqKhI/P8sVtVmUFYbiVBhAbUUFpzYbBrXFaWGANwm9dlYsl7MoKwy9af66ffa1n8vAx7jotqapPXtWWohnkVoYJGqlcEYYWlEYUtamwZzaDlGtEIafy8DZ0d2a5zv7WnbxoEVIbZ5cdGUqDS3CYUiLbioMmTD2V0ejJLrFmQ1LwecrMqLbL68Ww6phyIRVw5AJzxPDAAeZiloMv5RSK+uv9LpL83hr83zqKFd3CSqGDBQXX/mnsyT16Oeq183BjwE+m4PklpioNAehnllDLM/Mwd96+CfkMGTGI1b9DM6M9wyR4Mx438J69DnBeTkIBR+gSL+KqbxiYsnLDS7OQaijmWI+2jAxMeH8ztFsoRZkVNuBfTImXKApq0DPpuz9VpYyE5fYqdasvUjMyWd+Mhnd2Uu5DqXL1YCQnMnUcDXjuUNUb7r8OV+ojEQn/pzxXC+14kSaHE/QQim7tuPpT53IqgQnFpWiGWHDvEqva0zgM2QaFGf3uhWtGXLcVw8O8Ud2ZT7RuoIayJSO6YFLly4OTA9kP0M9W5EtY2PFMo9WPPsku2gFsTxL7clBsrqoijxFK51+ulwnvbikqw/Apf2lgfr0Rxf+FCkuceb7+AsN3BUeL9pyUhLwSh4r1/nynUu/T73sib5R27JcuNYgC+uWt9Qeih56mVoebngj6sn3bdMpwTqkNnq1IVxN6bb58kF5Q1hQnglzaj2Brm06uOpRuTxci5R3ccrTYZ3uU07t8kou/SZS7sTK0cWXNLgS1L7BqRVzSEofk8C6bZ9KtIgJJ3W629y73a6sFGHBvk/5xqeyU6baUc/B9ZW+AOfWynIhO6WYe/LIO8vveaIbPPdYDmbvOdFf1e/sFhHqekrWXzeVBWCbIQej3UxNJngwJRSsFhTFgf8oQ0tGYZmBQ3xEeFoum5+FWyAlk83vb5pUUNkMT7agRZcWt8wT0v1WdhONL1aizVloOyqaezPZpZnxqkXZf9sf8LidTSYONukb3J5a/6f7UwSl46Wyshr69VXnvZVCuMtbnFehZ1RDYlFehL5RKXYNsSNVbutCh0VtWOgcfEcSjxw4XFJdtDytN/NwuU76oLTzS5VwMHrEwx85WYdVyjwdgnXph2DmAStVTpWLrVAcCgTlC6mfZgwbMoMMPuauXnW+TH0/Ta3C8FW5rSVwKIoGu5d95QQDY/XLeO+S+0DW0v1XXsl66IDbQVFlMgXYNt+6tVnm4TLKnfnQLe4/ZvHYrcxn3JnF3TaPSf7RZqjfkgHfSvvHV5xOv5IO38r8P7lZRXPWv9sxZfgzHtnK/4DcUjRD5v/4mJLmWym9qTubFTSnmrc1pfqWgubPpNzWbPiVLDhTHqVp/l+CYJhzBPribkCzCGyhlvxBlEcj2ecEI5Lnl1CV7xBLJfUncvhPucBzmv8KzVc6iOUKVUr+KbeUukQOX6Jc5LCLolyXyPLiX3LhlU67bZ02m/DD/frz+5lyAK906vLZbP647YjfZvO1wN2IrdPfmQ2///41WOnU2VndKf5EhvAv25dNMvJDanenrWWo0xa2dQ612Dq7InAX4C65K2JllM0LnHHINmQEzGuzsT7bEWP8N/8lJ5QNamt2RjqH4vCD78JPtU3O5vffp6DxYdwmWyRss7Wg1h6x2XoPywllY8BUFsxgwQzwCFttO8LGu+Qv49mqI3FbF2Qw7LJ1RqqhaUNxW4vN55ATZIafNwP0hn1wF8xQstkPZnjBDC/4EHAvmOE9ogS3+Dohgp0QwU5fF9gNnvbbvpRP6SxvhkIDd1VDhH2d+Aca2Ok7gu72/h85oWy+CLi309YJnSgCXm4ZAv1KDfy/svI/5TXTOUhuCa7fz0Fygx05SG4NPJyD5Gbzf+UgVBm5yWWUp4lYPNQPr5FafA2d0ZccIEEPlPwF2Ujmp8nzfuWyy9/PzFFOe8sVCzr/WEiPbjRxU2SKMJSK5hW7Ji5dcrnU4YUcbLqEK8DgtOea8ASAIEAD7FcuxzAfpVDv4aeYe9bAtBcbVhIMX+oRZ6RdwvIL2QoLALvWiHDPRHa6+LQc7CZHaqq755IGbDRKzHCY0IJUeZnP2VwhaaAGbJwQjO65hPwsORFNFwybXGsqetZAVFDzwM86BeEjCMHuWYPS4RNEEGfCd2l1pIWp9PUmrS4qhcX+rN430sXOdrUoiEyZAPW+QSrzc4NzKgISzkFyq3Ly5IqtPC316HNZog+L/2tWX/fW96W2pNSsrlFY/P/f4Jl6+npfH7c/5u761ev7Vq9X2LsEiq/T6/+d3x1R01e/ur7vbr3CDiPYgsCaVtcQbUJAsNEo/ImV1q9X0VxTT/f9O9c2MLyPu1GE7xqNfavvrr7bRwADXc/W9/Ft8yIzvHcVYNh6w+2+4b+5Gzn5HrUMf5JYtkz4TLFMvMmSZVRDDiJfXkRenuRQ8ERhE+E3wOTemE95DhGLh+rIQaj/yEGo7/6MWL77rYRfJIdfpH5ArPq7aLB78btE8iIaRV37NmaLS35xqWvjRlKYpvblAm/8dsBp63I1YOZK0kgMJwcGGCLYTruY/oGBJGMngF3JZPLKwEAima8nMCN4JahPJvVBwRI12GhIJNEy6/7pfgLNsA7fwCSvJEk0owvfzLkB1mgnc51r4I+/J3OdMdnf33/uC7S/QRue6E/259/Lv4dWsmvCDOgtu9eUnxAWeavBprKkvuncF016hiHsdcmyHLro4docYGfZt+8Y/MsHmZyGr5wGRskH11+GSrPKhJ4/lpbrPvWRGOCsedbzx6TJoiUftjVgSEO9kBxeNAc/RvjyZQ7jfqvD548dO89R+LcqjJ48Bjovo9/nNeDLUviylhmX0dufP4/MuEzUQGwvSQN5gGslASzYSxaUy8cEliSCQmDIwt3zD9qfcxpkchq+choYc1pcmtOy1cwFsa9m/KQtiNVS/KrwLazLfTXtMUXd39KFx28RyzNUm4xEQOQep8p/mS3bunzbZB7+ZfYMVbkONvfTsHakXHs6q7y6unx/S9fKlb79mnD5fi8N+RN05V10eGW5Bqwr93ur0dobH9tSqQHrwAju3v79YJBODdZV2437dXw799vt6fTCjL3/y+v9y+Xuc0L9JgehFqdv+zeb5e8jWTy3j/6p3Efvon0Hi9qL2vO3bMlvR3e+PLw0P17UnikRBtilHns4XlRku7dly732oqKhL854XOEiGWlnqOq2pUub2EhREYKLiiKHz9SafEWyEqHai4aWHXC6WuIIjv/+jNvhj++Uh+PU0FB85T23k/bqt2/X51saaP9QfCguC7dTcCkvX99U21RWu317bVOgrAlyKzVBS2XhLTJrtrb/oegxwEtRQtcDB86cgVdtQb+RXFOA/Xp92O+yNzmatm9vol2BMm9Y7w8r2Bwv2jnkdbmX3svfvj0/TDec+WIIxVEePlhUzQbOHP5NO45ghLvPORpqHxYWniiE2zgPD4VpD2jjIti+Mx52cX/Cc7GHDx5y34U8bG9aurQN3taWv3kzdq/PFLh6GN1pP/Fw+uHDjodwe4KH7y1ZhvUUffmHP3yJbR0K6+8UcfCDhzEmBLcnRJuzW9PeLsIfOwwSWL7hHPzgm4chJvSADH74IPaxK0aoGdoWYmOSBqprfmigE6Q2P3iYoIMPvyGAi+IYZuE2rgnHBjrAdaGPHz74uD+uAcdHuzvaoI0PT7QNdA+0q8I74x0dozMdH8c+HpiZ6eho17K5fRiX7pwZiKX6c5o+yS0yJQbVP2Pt4lAQKSKWCMW0k7IwfFFMpJ1I0MD4F2QjIaTRJB6beWVyYsKYleXAyMETIzeSE5J5Rzo5OjkopY3MpcHJQT4vxCSSQTH3SXJ0ZnKcSZHJG+j5JAezI+gPqNg6ODGBGDY5eWF8AoMTE0COYmUTfL4CFv05Ojo5Po4V0MnxC+PoNwNaxsdH8bNJMbkBehQUXLgwOT5ppFm4Mz4I7zE4Pgkv41h7KhPCBDYEnhmfDBqTFy7A3QnaP3IBvR7Bg7zrUG02O9Y9ijXu1sWglHR8OLZyXWj8AlY8yredMra0MJDGz+8aHEWqJ4PrhMQsUIZ5cPwC1JEd0dP2cAtOIhHu89Pr+1i6OTgyOgNPrkvlcZm6gNhk2E/br/fhLBlMn59df91OV53SD46Ojk+ipWLoH5YuPjQD7EjS/wJw4fUYNq6/7u/zM6dib98Eh4+OHkWp/a7VwlcDqJ0M+vquQ7N4GH63rGftdW+/HWt2gO4BuPb1xbUGgJMzoHd9V5chrBdhfx+8lg6+/XZVCHx8KZmCYX44vH6264UWowiz69f7IS6xt6tiaP5zcAkPL5lBtfF8XV19jGgzain8xcaq3q66aUe96AsMNzyaHDHSfp+vJUiL3uB9CLX4wOqgHrydxPA9aN0g3eJrQQER/CzmOakD1bEp1JWXALxEz4Br9L4uIy2TJcOYiL39u6nxkRE2OTOw5NzUIJscGR/tYGg5mKYNhvNTcISA1ZCZBdxGM4mpGSWYpl3NdQwNvp6ZHIVhKzw76zPYFWEaKjx+yMygqKM+4Vv/aZhWgekPm9HxCvCIkXmh71O/KswdseOjgyyt982+YNSEaWYwyaVPCdPaMG3P+K0K//WD3T9m9bqn5gzImgNstVrJYcueoxZS2FKwZs8mItgKm+6O7nsPbrWTn1vdsJvvvX1r9hzdc9SqCRe8t28fzGXs27fvqGbhPyi69xyG1xzdRNDATW48TZLNyhZ3cyMbCOFNe/Y9d/S5fc+Rad4DVcU37dljtRIFBQr+KhR0XkDYi+bO6J+qXPfS/KJ3Dh86RGrGj1ob7xQcspI18Jl+yCazjEj5AmrN6bWQJaaXxJbFVMfF06d7Ok603lmsiS+gVhR2rD1denGYwHSosg1JcvpLT5cOzMOma9ajhyw1F0sJTBeKfRd29Jw+/R6Y3qtiulhiHtV0l5hulZNUNXOwBZnej0xXHMxTO8chIdF7nOmN8pK2zRzbAkXgBzo6BmS/0vek87iCvJULXCprhpLINvCEvKzIcl1v64mYYoXfzKC0xlTKAaeFu1EF5eFURyqsUy80LHZRFWNFWOz8rRoogrnDqlEbRfAaAmNF+Jl+bWNF+L8TWSBcXSJF+UrKi4gEX13yLofNXH6hpiaIJyonJahIkxfv6OJg944NGzZE3RvkJeqgqonhDR5+l18GHN2Af6Tf6BF+95m2ZsQrwlGZFyjA0Q0bsqwA+B0ZOCpnRFTFDDk7VBsYzXgZ9c6vMuANEjiA9914dgjwSrzq3Y+X1TuhtI+lwCOwlh0WXCBoR0kJD7uztp6XCHDAucPsoJ07SsosPBxVigDAAFqAddBmHi7ZoCgBmnbuQMrtjwWWxEzBjKzApjfQYdE2w7rDnOG6kkyNqbfYEW3KCIqg+UyWFTLhzjLjDP8TzW651IwoR8n1t2iG5mjWr6wXcfCZ9BdIf0clLxQ0R7PeU67zm9OfjUqaKbaAf+Mo5clUmW6ttCUeyqH0plGZ4YtyeEoyx8CMeyXiwEj9c0Sa5/43b6h9FuXWFQjXRQFW+yzKXQDdX64Nw2dRrLfFC1dUUbITVZhLq64L0z4dXHbVgLlc9+X7q8EOuA6s09ZcXo7TrYS9+8s14XLxErC2zXB1G2ethzfQhsv3+9HFai5tPInNqI0t1eWksK6a9ZH5mQviypXksI4Azshzrw5nJrq3qsGEee7nMtLPndH//zqjn5sX/dvAMomJlGRpbpvBn89lA863dDvS07CbUp+DQL02YlnxBHNIfhvhnNJv5pTYM6eUodQP/sfe5+c7ly4lmhddVFfXjOpUlpgJ5kVXraqrOvWBiYaaf2atURQnEq+rurmXpms1avktoBadxJMXdXUf7aVdToWahsIoev7UMQ6vqms20WLRSnnNz5aeX8Wtva2rWvUBqlGriC+ghvNKey6fFHBV02HGtbGjp/TiZd6WuipkOtTLtSrNuKIpvRHR9FXYdPlRFCfwhtmvDNP/U0Yc/BQc5OovvSEx/QNZEfpzK5ovE22pq5IVsfNzpoteV5s25BOw96+9cXkVEQy2HOwoLR1ZdZIEBrvz1o5cJtGMEquDR7DNGg1slfhaw3XIFaW8K5SDMh/DyMlCwCHcdtpfLZeBoBxgbCzf83BH+s+u8kr5bebzBGNPCl20ZWVlucKe9Hlil+OMDe+v1CluYH9W6MxwWCFjFVEE830NH7CsT95YEV5EYKwI84OMqrGpffTc8OWt1kK5ffRoYPQt1JHto89hu2hOG1E1tri+C5La4qqu+N1PBgcHP3mXaKftu5+gxegjpPDgjTVvDZLBYPLgW2/dINzw++7Pbrz11qs/e5cMxkZ/QgqPnD8/QghzjtZuIL/zWvKSd5XhU5eRrKo7efJk3apPsCjD7jeR3EE1I1qH93E7BRThw2/Cv5FDd05wMLcHYQ6eg5XgF8nhnygPX1kwynWvNDAetsBnykN3VsDH0BXD+/hc9+wnXxHJJyywX/2CUL5iqU9+QSyfUF+Rw1/lAv/iMcDQeEL4qylYUTo+OfUVATw1zsmF8SlNmGM3fjb22VgWnQljtvvWrVe2vHKrO5POhJG5n72CZMutsY2TqjBS3L0FsTtuPfosU7UMPPbKjh1Y962N6vAoatwtpBgS2Z651T2qBY/PPPgjsnhsrHt8VMsMgKfHuruxCzVtHp9+MHqBj8yUlusmYZkmz05qBmV0evrB9KSMYrlwz0yPTj94MD06rhluoKenL2wE+o/TUyT9Gboo2P3N4+/8T/QYVBoKchpkchi+9uY2MOb2WbQuh8+iLxXWkadbmQflGogTuaBz2FgOcGHjvLweoooh3IkYKvJFUKpjXqpyFikMJ3kdxWPPFY+pfeWlzjRP3NFansWtR0KVJ4DutRyyqgmCGwshM9Aw0l14WD3ZEII7Tu87fQOVzzhRuEw9O+W8xt4br65569VeXGvjhJpwk3sd+9a8NdxKNlHWOgBwB1fFQ0tzY+FFWPM5wJlReEdFMNx/8eINDJ9AC8pUvSHKiROwmkwzKDzbeufNN9XKXiyWTCwUDmgW1BAXXKFCg+pSLC64Gi6u0C4CwnV+6M6knb+xEJ2IXNb6uowP2MKT//EuieQ2FLxUGMshp1PdE8rp9P8A10HNPon0JEEAAAAASUVORK5CYII=";o.ZP.div`
  display: inline-flex;
  align-items: center;
  justify-content: center;
  background-color: ${({theme:e})=>e.colors.alibabaGrey};
  border-radius: 4px;
  padding: 1px 5px;
  margin-left: ${({theme:e})=>e.padding.default};
  font-size: ${({theme:e})=>e.fontSize.extraSmall};
  font-weight: bold;
`,o.ZP.img`
  height: 12px;
  width: 15px;
  margin-right: 2px;
  background-size: cover;
  background-image: url(${Rt});
  background-position: ${({code:e})=>Gt[e]};
`;var Ft=Object.defineProperty,Ut=Object.defineProperties,Vt=Object.getOwnPropertyDescriptors,qt=Object.getOwnPropertySymbols,Yt=Object.prototype.hasOwnProperty,Wt=Object.prototype.propertyIsEnumerable,Ht=(e,t,r)=>t in e?Ft(e,t,{enumerable:!0,configurable:!0,writable:!0,value:r}):e[t]=r;const Qt=o.ZP.div`
  min-width: 92px;
  display: inline-block;
  color: ${({theme:e})=>e.colors.white};
  font-size: 14px;
  font-weight: bold;
  position: relative;
  padding: 6px 8px 6px 12px;
  text-align: center;
  box-sizing: border-box;
  background-color: ${e=>e.background};

  &::before {
    content: "";
    position: absolute;
    left: -1px;
    top: -1px;
    border-right: 12px solid transparent;
    border-top: 34px solid #fff;
  }
`;Object.defineProperty,Object.getOwnPropertySymbols,Object.prototype.hasOwnProperty,Object.prototype.propertyIsEnumerable,o.ZP.div`
  display: flex;
  align-items: center;
  justify-content: center;
`,(0,o.ZP)(I)`
  color: ${({theme:e})=>e.colors.darkGrey};
`,(0,o.ZP)(I)`
  font-weight: 800;
  color: ${({theme:e})=>e.colors.black};
  margin-right: ${({theme:e})=>e.padding.large};
`,Object.defineProperty,Object.getOwnPropertySymbols,Object.prototype.hasOwnProperty,Object.prototype.propertyIsEnumerable,o.ZP.footer`
  background-color: ${({theme:e})=>e.colors.white};
  padding: ${({theme:e})=>e.padding.default} 0;
  border-top: 1px solid ${({theme:e})=>e.colors.lightGrey};
  display: flex;
  align-items: center;
  justify-content: space-between;
`,(0,o.ZP)(it)`
  padding-left: ${({theme:e})=>e.padding.large};
  height: 40px;
`,o.ZP.div`
  flex: 1;
`,r(5002),o.ZP.ul`
  margin: 0;
  padding: 20px 0;
  display: flex;
  list-style: none;
  justify-content: center;
`,o.ZP.li`
  font-size: 13px;
  font-weight: 600;  
  margin: 0 4px;
  cursor: pointer;
  text-decoration: underline;
  color: ${({active:e})=>e?"#0081ff":"#3a3a3a"};
  list-style: none;

  &:hover {
    color: ${({active:e})=>e?"#0081ff":"#737373"};
    text-decoration: none;
  }
}
`,o.ZP.div`
  display: flex;
  flex-direction: column;
`,(0,o.ZP)(N)`
  font-size: 12px;
  text-align: ${({align:e})=>e};
  color: ${({theme:e})=>e.colors.lightRed};

  line-height: 20px;
`;const Xt=(["KeyX","KeyC","KeyA"].concat(["KeyV"]),[".",","]);["Backspace","ArrowLeft","ArrowRight","Delete","Tab","Control"].concat(Xt);const Kt={small:{padding:"8px",fontSize:"14px",height:"28px",arrowMargin:"0 5px"},middle:{padding:"8px",fontSize:"14px",height:"34px",arrowMargin:"0 10px"},large:{padding:"12px",fontSize:"18px",height:"40px",arrowMargin:"0 15px"}};o.ZP.div`
  display: flex;
  flex-direction: ${({isColumn:e})=>e?"column":"row"};
  align-items: ${({isColumn:e})=>e?"flex-start":"center"};
`,(0,o.ZP)((function(e){return a.createElement("svg",q({viewBox:"0 0 14 8",fill:"none",xmlns:"http://www.w3.org/2000/svg"},e),V||(V=a.createElement("path",{d:"M9.72.11l-.221.22a.375.375 0 000 .531l2.621 2.61H.375A.375.375 0 000 3.844v.312c0 .207.168.375.375.375h11.746L9.5 7.14a.374.374 0 000 .53l.22.221a.375.375 0 00.531 0l3.64-3.625a.374.374 0 000-.53L10.25.11a.374.374 0 00-.53 0z",fill:"#343a40"})))}))`
  width: 14px;
  height: 8px;
  margin: ${({controlSize:e})=>Kt[e||"small"].arrowMargin};
`,o.ZP.div`
  ${({isColumn:e})=>e?"\n      margin-top: 4px;\n      margin-left: 0px;\n      ":"\n      margin-left: 5px;\n      "};
  display: flex;
  flex-direction: row;
  align-items: center;

  &:-webkit-autofill {
    color: #fff !important;
  }
`,o.ZP.input`
  box-sizing: border-box;
  width: 100%;
  padding: 0 ${({controlSize:e})=>Kt[e||"small"].padding};
  font-size: ${({controlSize:e})=>Kt[e||"small"].fontSize};
  border: ${({theme:e})=>`1px solid ${e.colors.middleBeige}`};
  height: ${({controlSize:e})=>Kt[e||"small"].height};
  border-radius: 4px;
  transition: border-color 0.2s ease;

  &::placeholder {
    color: ${({theme:e})=>e.colors.grey};
  }

  &::-webkit-outer-spin-button,
  &::-webkit-inner-spin-button {
    -webkit-appearance: none;
  }

  &:hover,
  &:focus {
    outline: none;
  }

  &:focus {
    border-color: ${({theme:e})=>e.colors.blue};
  }
`;var Jt=Object.defineProperty,$t=Object.getOwnPropertySymbols,_t=Object.prototype.hasOwnProperty,er=Object.prototype.propertyIsEnumerable,tr=(e,t,r)=>t in e?Jt(e,t,{enumerable:!0,configurable:!0,writable:!0,value:r}):e[t]=r;Object.defineProperty,Object.getOwnPropertySymbols,Object.prototype.hasOwnProperty,Object.prototype.propertyIsEnumerable,o.ZP.div`
  cursor: pointer;
  display: flex;
  align-items: center;
`,o.ZP.img`
  width: 100%;
  height: auto;
  max-width: 87px;
  max-height: 19px;
`,(0,o.ZP)(j)`
  color: ${({theme:e})=>e.colors.white};
`,o.ZP.div`
  height: 460px;
  display: flex;
  align-items: center;
  justify-content: center;
`,o.ZP.h3``,o.ZP.h3`
  text-align: center;
  margin-bottom: 30px;
  line-height: 30px;
`,o.ZP.div`
  width: 80px;
  height: 80px;
  display: flex;
  border-radius: 50%;
  margin-bottom: 50px;
`,(0,o.ZP)((function(e){return a.createElement("svg",((e,t)=>{for(var r in t||(t={}))_t.call(t,r)&&tr(e,r,t[r]);if($t)for(var r of $t(t))er.call(t,r)&&tr(e,r,t[r]);return e})({viewBox:"0 0 512 512",fill:"none",xmlns:"http://www.w3.org/2000/svg"},e),a.createElement("path",{d:"M256 8C119.043 8 8 119.083 8 256c0 136.997 111.043 248 248 248s248-111.003 248-248C504 119.083 392.957 8 256 8zm0 448c-110.532 0-200-89.431-200-200 0-110.495 89.472-200 200-200 110.491 0 200 89.471 200 200 0 110.53-89.431 200-200 200zm0-338c23.196 0 42 18.804 42 42s-18.804 42-42 42-42-18.804-42-42 18.804-42 42-42zm56 254c0 6.627-5.373 12-12 12h-88c-6.627 0-12-5.373-12-12v-24c0-6.627 5.373-12 12-12h12v-64h-12c-6.627 0-12-5.373-12-12v-24c0-6.627 5.373-12 12-12h64c6.627 0 12 5.373 12 12v100h12c6.627 0 12 5.373 12 12v24z"}))}))`
  margin: auto;
  fill: ${({theme:e})=>e.colors.darkBlue};
`,Object.defineProperty,Object.getOwnPropertySymbols,Object.prototype.hasOwnProperty,Object.prototype.propertyIsEnumerable,o.ZP.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
`,o.ZP.div`
  width: ${({width:e})=>e}px;
  background-color: ${({theme:e})=>e.colors.lightGrey};
  border-radius: 4px;
  overflow: hidden;
`,o.ZP.div`
  background: ${({theme:e})=>e.colors.blue};
  height: 6px;
  transition: width 0.2s ease;
  width: ${({loaded:e,length:t})=>100*e/t+"%"};
`,(0,o.ZP)(P)`
  margin-bottom: 8px;
  line-height: 1;
  color: ${({theme:e})=>e.colors.darkGrey};
`,o.ZP.div`
  display: inline-flex;
  flex-direction: row;
  align-items: center;
  margin-left: ${({theme:e})=>e.padding.button};
  border-radius: 4px;
  padding: 1px ${({theme:e})=>e.padding.small};
  background-color: ${({theme:e})=>e.colors.alibabaOrangeBackground};
  color: ${({theme:e})=>e.colors.alibabaOrange};
  font-size: ${({theme:e})=>e.fontSize.label};
  font-weight: bold;
`,o.ZP.div`
  font-size: 12px;
  margin-left: 2px;
`,kt()(At()),Lt()(At()),It()(At()),Et()(At()),o.ZP.div`
  animation: appear 0.6s ease;

  @keyframes appear {
    0% {
      opacity: 0;
    }
    100% {
      opacity: 1;
    }
  }
`,o.ZP.div`
  cursor: pointer;
  display: flex;
  align-items: center;
`,o.ZP.div`
  height: ${({height:e})=>e+"px"};
`,(0,o.ZP)(j)`
  color: ${({theme:e})=>e.colors.white};
`,kt()(At()),Lt()(At()),It()(At()),Et()(At()),kt()(At()),Lt()(At()),It()(At()),Et()(At());const rr=o.ZP.div`
  ::-webkit-scrollbar {
    width: 8px;
    height: 8px;
  }

  ::-webkit-scrollbar-track {
    background: ${({theme:e})=>e.colors.scroll.track};
  }

  ::-webkit-scrollbar-thumb {
    border-radius: 4px;
    background: ${({theme:e})=>e.colors.scroll.thumb};

    &:hover {
      background: ${({theme:e})=>e.colors.scroll.thumbHover};
    }

    &:active {
      background: ${({theme:e})=>e.colors.scroll.thumbActive};
    }
  }
`;var nr,ar;function or(){return(or=Object.assign||function(e){for(var t=1;t<arguments.length;t++){var r=arguments[t];for(var n in r)Object.prototype.hasOwnProperty.call(r,n)&&(e[n]=r[n])}return e}).apply(this,arguments)}function ir(){return(ir=Object.assign||function(e){for(var t=1;t<arguments.length;t++){var r=arguments[t];for(var n in r)Object.prototype.hasOwnProperty.call(r,n)&&(e[n]=r[n])}return e}).apply(this,arguments)}kt()(At()),Lt()(At()),It()(At()),Et()(At()),window.location.hostname.includes("pinterest.com"),r(4631),Object.defineProperty,Object.defineProperties,Object.getOwnPropertyDescriptors,Object.getOwnPropertySymbols,Object.prototype.hasOwnProperty,Object.prototype.propertyIsEnumerable,o.ZP.div`
  position: relative;
  color: ${({theme:e})=>e.colors.darkGrey};

  & > div {
    max-width: 100%;
    display: block !important;
  }
`,o.ZP.input`
  padding: 15px 132px 15px 72px;
  border: solid 1px #dddddd;
  border-radius: 4px;
  font-size: ${({theme:e})=>e.fontSize.headerLarge};
  color: ${({theme:e})=>e.colors.darkGrey};
  width: 100%;
  box-sizing: border-box;
  font-family: ${({theme:e})=>e.fontFamily.NunitoSans};

  &:focus {
    outline: none;
  }

  ::placeholder {
    color: #6a6c6f;
    opacity: 0.5;
    letter-spacing: -0.1px;
  }
`,o.ZP.div`
  font-size: ${({theme:e})=>e.fontSize.headerSmall};
  background-color: ${({highlighted:e,theme:t})=>e?t.colors.lightGrayBackground:"none"};
  padding: 6px 16px 6px 72px;
  transition: all 0.2s ease-in-out;
`,o.ZP.div`
  border-radius: 3px;
  box-shadow: rgba(0, 0, 0, 0.1) 0 2px 12px;
  background: ${({theme:e})=>e.colors.white};
  padding: 2px 0;
  font-size: 90%;
  //position: fixed;
  overflow: auto;
  max-height: 200px;
  transform: translateY(6px);
  position: absolute;
  left: 0 !important;
  top: 100% !important;
`,D.colors.middleBeige,D.colors.grey,D.colors.blue,Object.defineProperty,Object.getOwnPropertySymbols,Object.prototype.hasOwnProperty,Object.prototype.propertyIsEnumerable,o.ZP.div`
  font-size: ${({theme:e})=>e.fontSize.small};
  width: 100%;
  * {
    box-sizing: border-box;
  }

  &,
  * {
    &::-webkit-scrollbar {
      width: 7px;
      height: 7px;
    }

    &::-webkit-scrollbar-button {
      width: 0;
      height: 0;
    }

    &::-webkit-scrollbar-track {
      background: #e5e5e5;
      border: 0 none #fff;
    }

    &::-webkit-scrollbar-thumb {
      background: rgba(100, 100, 100, 0.3);
      border: 0 none #fff;
      border-radius: 3px;

      &:hover {
        background: rgba(100, 100, 100, 0.4);
      }

      &:active {
        background: rgba(100, 100, 100, 0.45);
      }
    }

    &::-webkit-scrollbar-corner {
      background: transparent;
    }
  }
`,o.ZP.div`
  max-width: calc(100% - 5px);
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  width: 100%;
`,Object.defineProperty,Object.defineProperties,Object.getOwnPropertyDescriptors,Object.getOwnPropertySymbols,Object.prototype.hasOwnProperty,Object.prototype.propertyIsEnumerable,o.ZP.div`
  width: 23px;
  height: 15.8px;
  margin-right: 8px;
  background-size: cover;
  background-image: url(${Rt});
  background-position: ${({code:e})=>Gt[e]};
`,o.ZP.div`
  display: flex;
  align-items: center;
`,Object.defineProperty,Object.getOwnPropertySymbols,Object.prototype.hasOwnProperty,Object.prototype.propertyIsEnumerable,o.ZP.div`
  text-align: center;
  font-size: 10px;
`,o.ZP.input`
  display: none;
`,(0,o.ZP)((function(e){return a.createElement("svg",ir({"aria-hidden":"true","data-prefix":"fas","data-icon":"star",className:"star-solid_svg__svg-inline--fa star-solid_svg__fa-star star-solid_svg__fa-w-18",xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 576 512"},e),ar||(ar=a.createElement("path",{fill:"currentColor",d:"M259.3 17.8L194 150.2 47.9 171.5c-26.2 3.8-36.7 36.1-17.7 54.6l105.7 103-25 145.5c-4.5 26.3 23.2 46 46.4 33.7L288 439.6l130.7 68.7c23.2 12.2 50.9-7.4 46.4-33.7l-25-145.5 105.7-103c19-18.5 8.5-50.8-17.7-54.6L382 150.2 316.7 17.8c-11.7-23.6-45.6-23.9-57.4 0z"})))}))`
  color: ${({theme:e})=>e.colors.gold};
  width: 34px;
  height: 34px;
`,(0,o.ZP)((function(e){return a.createElement("svg",or({"aria-hidden":"true","data-prefix":"far","data-icon":"star",className:"star-regular_svg__svg-inline--fa star-regular_svg__fa-star star-regular_svg__fa-w-18",xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 576 512"},e),nr||(nr=a.createElement("path",{fill:"currentColor",d:"M528.1 171.5L382 150.2 316.7 17.8c-11.7-23.6-45.6-23.9-57.4 0L194 150.2 47.9 171.5c-26.2 3.8-36.7 36.1-17.7 54.6l105.7 103-25 145.5c-4.5 26.3 23.2 46 46.4 33.7L288 439.6l130.7 68.7c23.2 12.2 50.9-7.4 46.4-33.7l-25-145.5 105.7-103c19-18.5 8.5-50.8-17.7-54.6zM388.6 312.3l23.7 138.4L288 385.4l-124.3 65.3 23.7-138.4-100.6-98 139-20.2 62.2-126 62.2 126 139 20.2-100.6 98z"})))}))`
  color: ${({theme:e})=>e.colors.gold};
  width: 34px;
  height: 34px;
`,o.ZP.div`
  cursor: pointer;
  display: flex;
  flex-direction: column;
  align-items: center;
  user-select: none;
`,o.ZP.div`
  height: 19px;
  margin: 8px;
  font-size: ${({theme:e})=>e.fontSize.medium};
  font-weight: bold;
  letter-spacing: 0.3px;
  color: ${({theme:e})=>e.colors.blue};
  cursor: pointer;

  .arrow {
    margin-left: 8px;
  }
`;var lr=Object.defineProperty,sr=Object.getOwnPropertySymbols,cr=Object.prototype.hasOwnProperty,ur=Object.prototype.propertyIsEnumerable,dr=(e,t,r)=>t in e?lr(e,t,{enumerable:!0,configurable:!0,writable:!0,value:r}):e[t]=r;const gr=e=>{var t=e,{disabled:r,checked:n,onChange:o,children:i,text:l}=t,s=((e,t)=>{var r={};for(var n in e)cr.call(e,n)&&t.indexOf(n)<0&&(r[n]=e[n]);if(null!=e&&sr)for(var n of sr(e))t.indexOf(n)<0&&ur.call(e,n)&&(r[n]=e[n]);return r})(t,["disabled","checked","onChange","children","text"]);const c=(0,a.useCallback)((()=>{o(!n)}),[n,o]);return a.createElement(wr,((e,t)=>{for(var r in t||(t={}))cr.call(t,r)&&dr(e,r,t[r]);if(sr)for(var r of sr(t))ur.call(t,r)&&dr(e,r,t[r]);return e})({onClick:c},s),a.createElement(hr,{type:"checkbox",disabled:r,checked:n,onChange:()=>{}}),a.createElement(mr,null),i||(l?a.createElement(pr,null,l):null))},pr=o.ZP.div`
  padding: 0 6px;
`,mr=o.ZP.span``,hr=o.ZP.input`
  display: none;
`,wr=o.ZP.div`
  cursor: pointer;
  display: flex;
  align-items: center;
  user-select: none;

  & ${hr} {
    position: absolute;
    width: 0;
    height: 0;
  }

  & ${mr} {
    flex: 0 0 auto;
    width: 36px;
    height: 24px;
    background-color: ${({theme:e})=>e.colors.lightGrayBackground};
    display: inline-block;
    position: relative;
    border-radius: 15px;
    transition: 150ms linear;
  }

  & ${mr}::after {
    content: "";
    top: 4px;
    left: 4px;
    border-radius: 8px;
    width: 16px;
    height: 16px;
    position: absolute;
    background-color: ${({theme:e})=>e.colors.white};
    transition: 150ms linear;
  }

  & ${hr}:checked + ${mr} {
    background-color: ${({theme:e})=>e.colors.blue};
  }

  & ${hr}:disabled + ${mr} {
    background-color: ${({theme:e})=>e.colors.lightGrayBackground};
    cursor: no-drop;
  }

  & ${hr}:checked + ${mr}::after {
    left: 16px;
  }
`;o.ZP.div`
  display: inline-flex;
  align-items: center;
  justify-content: center;
  margin-left: ${({theme:e})=>e.padding.default};
  font-weight: 550;
`;const fr=new $.Z({en:{common:{xRay:"Xray - Amazon Product Research",xRayWalmart:"Xray — Walmart Product Research",profitabilityCalculator:"Profitability Calculator",inventoryLevels:"Inventory Levels",asinGrabber:"ASIN Grabber",reviewInsights:"Review Insights",switchTitle:"Switch to another account",search:"Search",extensionToggle:"Enable/disable Helium 10 Extension",myDashboard:"My Dashboard",extension:"Extension",beforeStarted:"Before you get started…",enablePermissions:"You’ll need to enable permissions for the Extension to work on Amazon, Alibaba.com, Walmart and other sites",answeredBy:"Answered By",get:"Get",getMoreAnswers:{one:"Get {number} More Answer",other:"Get {number} More Answers"},votes:"Votes",by:"By",selected:"Selected",xRayShortName:"Xray",nowOn:"Now on",reviewGrath:"Review Graph",getConnectedForInsights:"Get Connected for More Insights"},auth:{welcome:"Welcome to the<br/>Helium 10 Chrome Extension",logInText:"Please log in to launch the extension tools.",logIntoAccount:"Log into My Account",or:"OR",signUp:"Sign up for Free"},buttons:{save:"Save",open:"Open",cancel:"Cancel",enable:"Enable",clear:"Clear",apply:"Apply",browseAmazon:"Browse Amazon Marketplace",demandAnalyzeOnAmazon:"Analyze Product Demand on Amazon",extractReviews:"Extract Reviews",reloadPage:"Reload page",browseWalmart:"Browse on Walmart"},options:{title:"Helium 10 extension",version:"Version {version}",options:"Options",extendedInformation:"Display extended information on the search page",showScore:"Show Listing Health Score",showBsrGraph:"Show BSR graph",successScoreSetting:"Success score setting",multiFactorScore:"Multi factor success score",twoFactorScore:"Two factor success score",revenue:"Revenue",reviews:"Reviews",optionsSaved:"Options saved",runDiagnostics:"Run diagnostics",language:"Language",languages:{en:"English – EN",de:"Deutsch – DE",it:"Italiano – IT",es:"Español – ES"},headerTitle:"Helium 10 Extension Options"},filters:{grabberStars:"4 Stars And Above",sponsoredProducts:"Sponsored Products",boughtTogether:"Frequently Bought Together",selectDateRange:"Select the date range",booleanFilters:"Select filters",sort:"Sort",stars:"Select ratings",searchKeywords:"Enter a keyword",isVerified:"Only Verified Purchase",isHelpful:"Only Helpful",isImages:"Only With Images",isVideos:"Only With Videos",reviewsRating:{allStars:"All stars",star5:"5 stars only",star4:"4 stars only",star3:"3 stars only",star2:"2 stars only",star1:"1 star only",allPositive:"All positive",allCritical:"All critical"},sortOptions:{date:"Most recent",helpful:"Top reviews"},mediaOptions:{allFormats:"Text, image, video",mediaOnly:"Image and video reviews only"},reviewFormats:"All variations",allReviews:"All reviews",verifiedOnly:"Verified purchase only"},reviewInsight:{tooltips:{reviews:"This will save all reviews to a CSV file",questions:"This will save all questions to a CSV file",analysis:"This will save all keyword phrases below and the number of times they appear in reviews to a CSV file",phrase:"Use this to export this keyword and reviews where it appears to the CSV",variations:"This will save all variations to a CSV file"},header:{avgRating:"Average Rating",totalReviews:"Total Reviews Found",reviewsFound:"Reviews Found",export:"Export",questions:"Questions",maxReviewsLength:"No more than 5,000 reviews can be downloaded from Amazon",isOnlyVerifiedEnabled:"Only Verified",isOnlyHelpfulEnabled:"Only Helpful",isOnlyWithImagesEnabled:"Only With Images",isOnlyWithVideosEnabled:"Only With Videos",isStar1Enabled:"1 Star",isStar2Enabled:"2 Stars",isStar3Enabled:"3 Stars",isStar4Enabled:"4 Stars",isStar5Enabled:"5 Stars"},categories:{overview:"overview",reviews:"reviews",questions:"questions",analysis:"analysis",variations:"variations"},overview:{topPhrases:"Top Phrases",topReviews:"Top Helpful Reviews",noReviews:"No Reviews",setUpFilters:"Set up filters to run Review Insights",fountHelpful:"people found this review helpful"},reviews:{noResults:"No results",noResultsForFilter:"No results found for this filtering",loadMore:"Load 100 More",reviewsNotFound:"Reviews not found"},questions:{votes:"By votes",answerCount:"By answer count"},ratingTable:{rating:"Rating",count:"Rating Count",asinCount:"ASINs",seeAll:"See All",distribution:"Distribution",asinDistribution:"ASIN Distribution"},analysis:{by:"By",noPhrases:"No Phrases"},variations:{noVariations:"No variations found for this product",asin:"ASIN",variations:"Variations",reviewCount:"Review Count",reviewShare:"Review Share",rating:"Rating",noDescription:"No Descriptions"},navTitles:{overview:"Overview",allReviews:"All Reviews",allQuestions:"All Questions",reviewAnalysis:"Review Analysis",asinVariations:"Product Variations"},exportAccess:{reviews:"Starter Plan or higher is required in order to access reviews beyond 100.",variations:"Starter Plan or higher is required in order to access variations beyond 100.",questions:"Starter Plan or higher is required in order to access questions beyond 100.",analysis:"Starter Plan or higher is required in order to access analysis beyond 100."}},errors:{reloadRageText:"Reload the page to update the extension and activate Demand Analyzer.",request:"Some of your requests have been blocked by Amazon. Please try again later to get all of them.",limit:"Requests limit exceeded"},exports:{titles:{asin:"ASIN",description:"Description",reviewCount:"Review Count",reviewShare:"Review Share",date:"Date",author:"Author",verified:"Verified",helpful:"Helpful",title:"Title",body:"Body",rating:"Rating",images:"Images",videos:"Videos",url:"URL",variation:"Variation",style:"Style",question:"Question",answer:"Answer",votes:"Votes",countAnswers:"Total answers",allAnswersLink:"All answers",phrase:"Keyword Phrase",analysisCount:"Appeared"}},tag:{new:"New",beta:"Beta"},newsFeed:{whatsNew:"What's new"}},de:{common:{xRay:"Xray - Amazon Produktrecherche",xRayWalmart:"Xray — Walmart Produktrecherche",profitabilityCalculator:"Rentabilitätsrechner",inventoryLevels:"Inventory Levels",asinGrabber:"ASIN Grabber",reviewInsights:"Review Insights",switchTitle:"Zu einem anderen Konto wechseln",search:"Suchen",extensionToggle:"Erweiterung aktivieren/deaktivieren",myDashboard:"Mein Dashboard",extension:"Erweiterung",beforeStarted:"Bevor Sie loslegen …",enablePermissions:"Damit die Erweiterung auf einer Amazon-, Alibaba.com- oder Shopify-Website funktioniert, müssen Sie die Zugriffsrechte aktivieren.",answeredBy:"Beantwortet von",get:"Anzeige von",getMoreAnswers:{one:"{number} weitere Antwort anzeigen",other:"{number} weitere Antworten anzeigen"},votes:"Stimmen",by:"Von",selected:"Ausgewählt",xRayShortName:"Xray",nowOn:"Jetzt auf",reviewGrath:"Bewertungsgrafik",getConnectedForInsights:"Vernetzen Sie sich für mehr Einblicke"},auth:{welcome:"Willkommen bei der<br/>Helium 10 Chrome Erweiterung",logInText:"Bitte melden Sie sich an, um die Erweiterungs-Tools zu starten.",logIntoAccount:"Bei meinem Konto einloggen",or:"ODER",signUp:"Kostenlos registrieren"},buttons:{save:"Speichern",open:"Öffnen",cancel:"Abbrechen",enable:"Aktivieren",clear:"Löschen",apply:"Anwenden",browseAmazon:"Amazon Marketplace durchsuchen",demandAnalyzeOnAmazon:"Produktnachfrage analysieren",extractReviews:"Extrahieren",reloadPage:"Seite neu laden",browseWalmart:"Walmart durchsuchen"},options:{title:"Helium 10 Erweiterung",version:"Version {version}",options:"Optionen",extendedInformation:"Erweiterte Informationen auf der Suchseite anzeigen",showScore:"Listing Health Score anzeigen",showBsrGraph:"BSR-Graph anzeigen",successScoreSetting:"Erfolgsscore-Einstellung",multiFactorScore:"Multi-Faktoren-Erfolgsscore",twoFactorScore:"Zwei-Faktoren-Erfolgsscore",revenue:"Umsatz",reviews:"Bewertungen",optionsSaved:"Optionen gespeichert",runDiagnostics:"Diagnose ausführen",language:"Sprache",languages:{en:"English",de:"Deutsch",it:"Italiano",es:"Español"},headerTitle:"Helium 10 Erweiterung Optionen"},filters:{grabberStars:"4 Sterne und mehr",sponsoredProducts:"Gesponserte Produkte",boughtTogether:"Häufig zusammen gekauft",selectDateRange:"Bitte wählen Sie den Datumsbereich",booleanFilters:"Filter auswählen",sort:"Sortieren",stars:"Bewertungen",searchKeywords:"Geben Sie ein Keyword ein.",isVerified:"Nur verifizierter Kauf",isHelpful:"Nur hilfreich",isImages:"Nur mit Bildern",isVideos:"Nur mit Videos",reviewsRating:{allStars:"Alle Sterne",star5:"Nur 5 Sterne",star4:"Nur 4 Sterne",star3:"Nur 3 Sterne",star2:"Nur 2 Sterne",star1:"Nur 1 Stern",allPositive:"Alle positiven",allCritical:"Alle kritischen"},sortOptions:{date:"Neueste",helpful:"Top-Bewertungen"},mediaOptions:{allFormats:"Text, Bild, Video",mediaOnly:"Nur Bild- und Videobewertungen"},reviewFormats:"Alle Varianten",allReviews:"Alle Bewertungen",verifiedOnly:"Nur verifizierter Kauf"},reviewInsight:{tooltips:{reviews:"Dies speichert alle Bewertungen in einer CSV-Datei.",questions:"Dies speichert alle Fragen in einer CSV-Datei.",analysis:"Dies speichert alle unten aufgeführten Keyword-Wortgruppen und die Anzahl, wie oft sie in Bewertungen erscheinen, in einer CSV-Datei.",phrase:"Verwenden Sie diese Option, um dieses Keyword und Rezensionen dorthin zu exportieren, wo sie in der CSV-Datei erscheinen.",variations:"Dies speichert alle Varianten in einer CSV-Datei."},header:{avgRating:"Durchschnittliche Bewertung",totalReviews:"Gesamtzahl der gefundenen Bewertungen",reviewsFound:"Gefundene Bewertungen",export:"Export",questions:"Fragen",maxReviewsLength:"Es können nicht mehr als 5.000 Rezensionen von Amazon heruntergeladen werden.",isOnlyVerifiedEnabled:"Nur verifiziert",isOnlyHelpfulEnabled:"Nur hilfreich",isOnlyWithImagesEnabled:"Nur mit Bildern",isOnlyWithVideosEnabled:"Nur mit Videos",isStar1Enabled:"1 Stern",isStar2Enabled:"2 Sterne",isStar3Enabled:"3 Sterne",isStar4Enabled:"4 Sterne",isStar5Enabled:"5 Sterne"},categories:{overview:"Übersicht",reviews:"bewertungen",questions:"Fragen",analysis:"Analyse",variations:"Varianten"},overview:{topPhrases:"Top Wortgruppen",topReviews:"Top Hilfreiche Bewertungen",noReviews:"Keine Bewertungen",setUpFilters:"Richten Sie Filter ein, um Review Insights auszuführen.",fountHelpful:"Personen fanden diese Bewertung hilfreich"},reviews:{noResults:"Keine Ergebnisse",noResultsForFilter:"Keine Ergebnisse für diese Filterung gefunden",loadMore:"100 weitere laden",reviewsNotFound:"Bewertungen nicht gefunden"},questions:{votes:"Nach Stimmen",answerCount:"Nach Anzahl der Antworten"},ratingTable:{rating:"Bewertung",count:"Gesamtzahl der Verkäuferbewertungen",asinCount:"ASINs",seeAll:"Alle anzeigen",distribution:"Verteilung",asinDistribution:"ASIN-Verteilung"},analysis:{by:"Von",noPhrases:"Keine Wortgruppen"},variations:{noVariations:"Keine Varianten für dieses Produkt gefunden",asin:"ASIN",variations:"Varianten",reviewCount:"Bewertungsanzahl",reviewShare:"Bewertungs-Verteilung",rating:"Bewertung",noDescription:"Keine Beschreibungen"},navTitles:{overview:"Übersicht",allReviews:"Alle Bewertungen",allQuestions:"Alle Fragen",reviewAnalysis:"Bewertungsanalyse",asinVariations:"Produktvarianten"},exportAccess:{reviews:"Für den Zugriff auf mehr als 100 Bewertungen ist Starter Plan oder höher erforderlich.",variations:"Für den Zugriff auf mehr als 100 Varianten ist Starter Plan oder höher erforderlich.",questions:"Für den Zugriff auf mehr als 100 Fragen ist Starter Plan oder höher erforderlich.",analysis:"Für den Zugriff auf mehr als 100 Analysen ist Starter Plan oder höher erforderlich."}},errors:{reloadRageText:"Laden Sie die Seite neu, um die Erweiterung zu aktualisieren und den Demand Analyzer zu aktivieren.",request:"Einige Ihrer Anfragen wurden von Amazon blockiert. Bitte versuchen Sie es später erneut, um alle zu erhalten.",limit:"Anfragelimit überschritten"},exports:{titles:{asin:"ASIN",description:"Beschreibung",reviewCount:"Anzahl der Bewertungen",reviewShare:"Bewertungs-Verteilung",date:"Datum",author:"Autor",verified:"Verifiziert",helpful:"Hilfreich",title:"Titel",body:"Textkörper",rating:"Bewertung",images:"Bilder",videos:"Videos",url:"URL",variation:"Variante",style:"Stil",question:"Frage",answer:"Antwort",votes:"Stimmen",countAnswers:"Antworten insgesamt",allAnswersLink:"Alle Antworten",phrase:"Keyword-Begriff",analysisCount:"Erscheint"}},tag:{new:"Neu",beta:"Beta"},newsFeed:{whatsNew:"Was gibt es Neues?"}},es:{common:{xRay:"Xray – Búsqueda de Amazon",xRayWalmart:"Xray — Búsqueda de productos",profitabilityCalculator:"Calculador de rentabilidad",inventoryLevels:"Inventory Levels",asinGrabber:"ASIN Grabber",reviewInsights:"Review Insights",switchTitle:"Cambiar a otra cuenta",search:"Búsqueda",extensionToggle:"Habilitar/Inhabilitar extensión",myDashboard:"Mi tablero",extension:"Extensión",beforeStarted:"Antes de empezar…",enablePermissions:" Deberás habilitar permisos para que la extensión funcione en el sitio de Amazon, Alibaba.com o Shopify",answeredBy:"Respondido por",get:"Obtener",getMoreAnswers:{one:"Obtener {number} Respuesta Más",other:"Obtener {number} Respuestas Más"},votes:"Votos",by:"Por",selected:"Seleccionado",xRayShortName:"Xray",nowOn:"Ahora en",reviewGrath:"Gráfico de reseñas",getConnectedForInsights:"Conéctese para obtener más información"},auth:{welcome:"Bienvenido a la <br/> Extensión Helium 10 de Chrome",logInText:"Por favor, inicia sesión para usar las herramientas de la extensión.",logIntoAccount:"Iniciar sesión en Mi Cuenta",or:"O",signUp:"Suscríbete gratis"},buttons:{save:"Guardar",open:"Abrir",cancel:"Cancelar",enable:"Habilitar",clear:"Limpiar",apply:"Aplicar",browseAmazon:"Navegar por Amazon Marketplace",demandAnalyzeOnAmazon:"Analizar la demanda en Amazon",extractReviews:"Obtener reseñas",reloadPage:"Recargar página",browseWalmart:"Navegar en Walmart"},options:{title:"Extensión Helium 10",version:"Versión {version}",options:"Opciones",extendedInformation:"Mostrar información extendida en la página de búsqueda",showScore:"Mostrar puntuación de estado del listing",showBsrGraph:"Motrar gráfico BSR",successScoreSetting:"Configuración de la puntuación de éxito",multiFactorScore:"Puntuación de éxito multifactor",twoFactorScore:"Puntuación de éxito de dos factores",revenue:"Ingreso",reviews:"Reseñas",optionsSaved:"Opciones guardadas",runDiagnostics:"Ejecutar diagnósticos",language:"Idioma",languages:{en:"English",de:"Deutsch",it:"Italiano",es:"Español"},headerTitle:"Opciones de Extensión Helium 10"},filters:{grabberStars:"4 estrellas y más",sponsoredProducts:"Productos auspiciados",boughtTogether:"Frecuentemente comprados juntos",selectDateRange:"Por favor, selecciona rango de fecha",booleanFilters:"Seleccionar filtros",sort:"Ordenar",stars:"Selecciona calificaciones",searchKeywords:"Ingresa una palabra clave",isVerified:"Solo compra verificada",isHelpful:"Solo útil",isImages:"Solo con imágenes ",isVideos:"Solo con videos",reviewsRating:{allStars:"Todas las estrellas",star5:"Solo 5 estrellas",star4:"Solo 4 estrellas",star3:"Solo 3 estrellas",star2:"Solo 2 estrellas",star1:"Solo 1 estrella",allPositive:"Todos los comentarios positivos",allCritical:"Todas las críticas"},sortOptions:{date:"Más reciente",helpful:"Reseñas principales"},mediaOptions:{allFormats:"Texto, imagen, video",mediaOnly:"Solo reseñas de imagen y vídeo"},reviewFormats:"Todas las variaciones",allReviews:"Todas las reseñas",verifiedOnly:"Solo compra verificada"},reviewInsight:{tooltips:{reviews:"Esto guardará todas las reseñas en un archivo CSV",questions:"Esto guardará todas las preguntas en un archivo CSV",analysis:"Esto guardará en un archivo CSV todas las frases claves de abajo y la cantidad de veces que aparecen en las reseñas",phrase:"Usa esto para exportar estas palabras claves y reseñas donde aparezcan en el archivo CSV",variations:"Esto guardará todas las variaciones en un archivo CSV"},header:{avgRating:"Calificación promedio",totalReviews:"Total de reseñas encontradas",reviewsFound:"Reseñas encontradas",export:"Exportar",questions:"Preguntas",maxReviewsLength:"No se pueden descargar más de 5000 reseñas de Amazon",isOnlyVerifiedEnabled:"Verificados solamente",isOnlyHelpfulEnabled:"Solo útil",isOnlyWithImagesEnabled:"Solo con imágenes ",isOnlyWithVideosEnabled:"Solo con videos",isStar1Enabled:"1 estrella",isStar2Enabled:"2 estrellas",isStar3Enabled:"3 estrellas",isStar4Enabled:"4 estrellas",isStar5Enabled:"5 estrellas"},categories:{overview:"vista general",reviews:"reseñas",questions:"preguntas",analysis:"análisis",variations:"variaciones"},overview:{topPhrases:"Frases principales",topReviews:"Principales reseñas útiles",noReviews:"Sin reseñas",setUpFilters:"Configurar filtros para ejecutar la revisión de reseñas",fountHelpful:"otras personas encontraron esta reseña muy útil"},reviews:{noResults:"No hay resultados",noResultsForFilter:"No se encontraron resultados para este filtro",loadMore:"Cargar 100 más",reviewsNotFound:"Reseñas no encontradas"},questions:{votes:"Por votos",answerCount:"Por número de respuestas"},ratingTable:{rating:"Clasificación",count:"Cuenta de clasificación",asinCount:"ASINs",seeAll:"Ver todo",distribution:"Distribución",asinDistribution:"Distribución de ASINs"},analysis:{by:"Por",noPhrases:"Sin frases"},variations:{noVariations:"No se encontraron variaciones para este producto",asin:"ASIN",variations:"Variaciones",reviewCount:"Cuenta de reseñas",reviewShare:"Cuota de reseñas",rating:"Clasificación",noDescription:"No hay descripciones"},navTitles:{overview:"Vista general",allReviews:"Todas las reseñas",allQuestions:"Todas las preguntas",reviewAnalysis:"Análisis de reseñas",asinVariations:"Variaciones de producto"},exportAccess:{reviews:"Se necesita el Plan Iniciante o superior para acceder a más de 100 reseñas.",variations:"Se necesita el Plan Iniciante o superior para acceder a más de 100 variaciones.",questions:"Se necesita el Plan Iniciante o superior para acceder a más de 100 preguntas.",analysis:"Se necesita el Plan Iniciante para acceder a más de 100 análisis."}},errors:{reloadRageText:"Recargar la página para actualizar la extensión y activar Demand Analyzer.",request:"Amazon ha bloqueado algunas de tus solicitudes. Vuelve a intentarlo más tarde para obtenerlas todas.",limit:"Se superó el límite de solicitudes"},exports:{titles:{asin:"ASIN",description:"Descripción",reviewCount:"Recuento de reseñas",reviewShare:"Cuota de reseñas",date:"Fecha",author:"Autor",verified:"Verificado",helpful:"Útil",title:"Título",body:"Cuerpo",rating:"Clasificación",images:"Imágenes",videos:"Vídeos",url:"URL",variation:"Variación",style:"Estilo",question:"Pregunta",answer:"Respuesta",votes:"Votos",countAnswers:"Total de respuestas",allAnswersLink:"Todas las respuestas",phrase:"Frase clave",analysisCount:"Apareció"}},tag:{new:"Nuevo",beta:"Beta"},newsFeed:{whatsNew:"Qué hay de nuevo"}},it:{common:{xRay:"Xray - Ricerca prodotti Amazon",xRayWalmart:"Xray — Ricerca dei prodotti",profitabilityCalculator:"Calcolatore di redditività",inventoryLevels:"Inventory Levels",asinGrabber:"ASIN Grabber",reviewInsights:"Review Insights",switchTitle:"Passa ad un altro account",search:"Cerca",extensionToggle:"Abilita / disabilita l'estensione",myDashboard:"Dashboard",extension:"Estensione",beforeStarted:"Prima di iniziare...",enablePermissions:"Dovrai concedere le autorizzazioni per poter utilizzare l'estensione su Amazon, Alibaba.com o Shopify",answeredBy:"Risposta da",get:"Ottieni",getMoreAnswers:{one:"Ottieni {number} altra risposta",other:"Ottieni altre {number} risposte"},votes:"Voti",by:"Da",selected:"Selezionato",xRayShortName:"Xray",nowOn:"Ora su",reviewGrath:"Grafico di recensioni",getConnectedForInsights:"Connettiti per ulteriori informazioni"},auth:{welcome:"Benvenuto nell'estensione Chrome di <br/>Helium 10",logInText:"Accedi per avviare gli strumenti dell'estensione.",logIntoAccount:"Accedi al mio account",or:"O",signUp:"Iscriviti gratuitamente"},buttons:{save:"Salva",open:"Apri",cancel:"Cancella",enable:"Abilita",clear:"Elimina",apply:"Applica",browseAmazon:"Sfoglia il marketplace di Amazon",demandAnalyzeOnAmazon:"Analizza la domanda su Amazon",extractReviews:"Estrai recensioni",reloadPage:"Ricarica la pagina",browseWalmart:"Sfoglia su Walmart"},options:{title:"Estensione Helium 10",version:"Versione {version}",options:"Opzioni",extendedInformation:"Visualizza informazioni estese nella pagina di ricerca",showScore:"Mostra l'Healt Score del listing",showBsrGraph:"Mostra grafico BSR",successScoreSetting:"Impostazione del success score",multiFactorScore:"Success score multifattoriale",twoFactorScore:"Success score a due fattori",revenue:"Fatturato",reviews:"Recensioni",optionsSaved:"Impostazioni salvate",runDiagnostics:"Esegui diagnostica",language:"Lingua",languages:{en:"English",de:"Deutsch",it:"Italiano",es:"Español"},headerTitle:"Opzioni di Estensione Helium 10"},filters:{grabberStars:"4 stelle e oltre",sponsoredProducts:"Prodotti sponsorizzati",boughtTogether:"Spesso acquistati insieme",selectDateRange:"Seleziona l'intervallo di date",booleanFilters:"Seleziona filtri",sort:"Ordina",stars:"Seleziona la valutazione",searchKeywords:"Inserisci una parola chiave",isVerified:"Solo acquisto verificato",isHelpful:"Solo utile",isImages:"Solo con immagini",isVideos:"Solo con video",reviewsRating:{allStars:"Tutte",star5:"Solo 5 stelle",star4:"Solo 4 stelle",star3:"Solo 3 stelle",star2:"Solo 2 stelle",star1:"Solo 1 stella",allPositive:"Solo positive",allCritical:"Solo critiche"},sortOptions:{date:"Più recenti",helpful:"Recensioni migliori"},mediaOptions:{allFormats:"Testo, immagine, video",mediaOnly:"Solo recensioni con immagini e video"},reviewFormats:"Tutte le varianti",allReviews:"Tutte le recensioni",verifiedOnly:"Solo acquisto verificato"},reviewInsight:{tooltips:{reviews:"Salva tutte le recensioni in un file CSV",questions:"Salva tutte le domande in un file CSV",analysis:"Salva tutte le keyword e il numero di occorrenze nelle recensioni in un file CSV",phrase:"Esporta nel file CSV la keyword e le recensioni in cui è usata",variations:"Salva tutte le varianti in un file CSV"},header:{avgRating:"Valutazione media",totalReviews:"Tutte le recensioni trovate",reviewsFound:"Recensioni trovate",export:"Esporta",questions:"Domande",maxReviewsLength:"Non è possibile scaricare più di 5.000 recensioni da Amazon",isOnlyVerifiedEnabled:"Solo verificate",isOnlyHelpfulEnabled:"Solo utile",isOnlyWithImagesEnabled:"Solo con immagini",isOnlyWithVideosEnabled:"Solo con video",isStar1Enabled:"1 stella",isStar2Enabled:"2 stelle",isStar3Enabled:"3 stelle",isStar4Enabled:"4 stelle",isStar5Enabled:"5 stelle"},categories:{overview:"panoramica",reviews:"recensioni",questions:"domande",analysis:"analisi",variations:"varianti"},overview:{topPhrases:"Keyword principali",topReviews:"Recensioni utili migliori",noReviews:"Nessuna recensione",setUpFilters:"Imposta i filtri per eseguire Review Insights",fountHelpful:"persone hanno trovato questa recensione utile"},reviews:{noResults:"Nessun risultato",noResultsForFilter:"Nessun risultato trovato con questi filtri",loadMore:"Carica altre 100",reviewsNotFound:"Recensioni non trovate"},questions:{votes:"Per voti",answerCount:"Per numero di risposte"},ratingTable:{rating:"Valutazioni",count:"Numero di valutazioni",asinCount:"ASIN",seeAll:"Visualizza",distribution:"Distribuzione",asinDistribution:"Distribuzione dell'ASIN"},analysis:{by:"Da",noPhrases:"Nessun risultato"},variations:{noVariations:"Nessuna variante trovata per questo prodotto",asin:"ASIN",variations:"Varianti",reviewCount:"Numero di recensioni",reviewShare:"Condivisioni",rating:"Valutazioni",noDescription:"Nessuna descrizione"},navTitles:{overview:"Panoramica",allReviews:"Tutte le recensioni",allQuestions:"Tutte le domande",reviewAnalysis:"Analisi delle recensioni",asinVariations:"Varianti del prodotto"},exportAccess:{reviews:"Per visualizzare più di 100 recensioni è necessario uno Starter Plan o superiore.",variations:"Per visualizzare più di 100 varianti è necessario uno Starter Plan o superiore.",questions:"Per visualizzare più di 100 domande è necessario uno Starter Plan o superiore.",analysis:"Per visualizzare più di 100 analisi è necessario uno Starter Plan o superiore."}},errors:{reloadRageText:"Ricarica la pagina per aggiornare l'estensione e attivare Demand Analyzer.",request:"Alcune delle tue richieste sono state bloccate da Amazon. Riprova più tardi per ottenerle tutte.",limit:"Limite di richieste superato"},exports:{titles:{asin:"ASIN",description:"Descrizione",reviewCount:"Numero di recensioni",reviewShare:"Condivisioni",date:"Data",author:"Autore",verified:"Verificato",helpful:"Utile",title:"Titolo",body:"Corpo",rating:"Valutazioni",images:"Immagini",videos:"Video",url:"URL",variation:"Variante",style:"Stile",question:"Domanda",answer:"Risposta",votes:"Voti",countAnswers:"Risposte totali",allAnswersLink:"Tutte le risposte",phrase:"Keyword",analysisCount:"Occorrenze"}},tag:{new:"Nuovo",beta:"Beta"},newsFeed:{whatsNew:"Cosa c'è di nuovo"}}},{logsEnabled:!1}),br=({children:e})=>a.createElement(J.DO,{strings:fr,TranslateContext:vr},e),vr=(0,a.createContext)(null),yr=()=>(0,a.useContext)(vr);var Mr=r(9298);const xr=(e="")=>-1===(e=e.replace(/https?:\/\/(www.)?/i,"")).indexOf("/")?e:e.split("/").length&&e.split("/")[0],zr={enabled:!0,setEnabled:e=>{console.log(e)}},jr=(0,a.createContext)(zr);var Nr=r(8581);const Or="https://helium10.groupbuyamz.com",Dr="https://www.amazon.com/",Ar="https://www.walmart.com";var Pr=Object.defineProperty,Ir=Object.getOwnPropertySymbols,Cr=Object.prototype.hasOwnProperty,Er=Object.prototype.propertyIsEnumerable,Sr=(e,t,r)=>t in e?Pr(e,t,{enumerable:!0,configurable:!0,writable:!0,value:r}):e[t]=r,Lr=(e,t)=>{for(var r in t||(t={}))Cr.call(t,r)&&Sr(e,r,t[r]);if(Ir)for(var r of Ir(t))Er.call(t,r)&&Sr(e,r,t[r]);return e};const Tr=(e,t,r=!1)=>"GET"!==e&&t?{body:r?t:JSON.stringify(t)}:{},kr=(e,t,r)=>"GET"===e&&r?ct.stringifyUrl({url:t,query:r}):t,Zr=e=>{return t=void 0,r=[e],n=function*({url:e,params:t,method:r="GET",headers:n={},type:a="background-request",form:o,rawParams:i}){return new Promise(((l,s)=>{const c={url:kr(r,e,t),params:i||Lr({method:r,headers:n,form:o,credentials:"same-origin"},Tr(r,t,o))};chrome.runtime.sendMessage(Lr({type:a},c),(e=>{((e,t,r)=>{var n,a;200===(null==e?void 0:e.status)?(a=e.data,l(a)):(n={data:null==e?void 0:e.data,status:null==e?void 0:e.status},s(n))})(e)}))}))},new Promise(((e,a)=>{var o=e=>{try{l(n.next(e))}catch(e){a(e)}},i=e=>{try{l(n.throw(e))}catch(e){a(e)}},l=t=>t.done?e(t.value):Promise.resolve(t.value).then(o,i);l((n=n.apply(t,r)).next())}));var t,r,n};Object.defineProperty,Object.getOwnPropertySymbols,Object.prototype.hasOwnProperty,Object.prototype.propertyIsEnumerable;const Br=`https://helium10.groupbuyamz.com/extension/check-login?appId=${chrome.runtime.id}`;["1","2","3","4","5"].map((e=>`isStar${e}Enabled`));var Gr=Object.defineProperty,Rr=Object.defineProperties,Fr=Object.getOwnPropertyDescriptors,Ur=Object.getOwnPropertySymbols,Vr=Object.prototype.hasOwnProperty,qr=Object.prototype.propertyIsEnumerable,Yr=(e,t,r)=>t in e?Gr(e,t,{enumerable:!0,configurable:!0,writable:!0,value:r}):e[t]=r,Wr=(e,t)=>{for(var r in t||(t={}))Vr.call(t,r)&&Yr(e,r,t[r]);if(Ur)for(var r of Ur(t))qr.call(t,r)&&Yr(e,r,t[r]);return e},Hr=(e,t)=>Rr(e,Fr(t)),Qr=(e,t,r)=>new Promise(((n,a)=>{var o=e=>{try{l(r.next(e))}catch(e){a(e)}},i=e=>{try{l(r.throw(e))}catch(e){a(e)}},l=e=>e.done?n(e.value):Promise.resolve(e.value).then(o,i);l((r=r.apply(e,t)).next())}));const Xr=(0,Nr.HA)("checkLogin/GET_STARTED",((e,t)=>Qr(void 0,[e,t],(function*(e,{dispatch:t}){try{const r=yield Zr({url:Br,params:{accountId:e}});t(null!=r?Kr(r):Jr({data:r,error:new Error("Error request")}))}catch(e){const r=new Error(401===e.status?"Unauthorized":"Error request");t(Jr({error:r,data:null}))}})))),Kr=(0,Nr.HA)("invocation/GET_DONE",(e=>{const t=e.plan.split("_");if(isNaN(Number(t[t.length-1])))chrome.storage.local.set({subscription:e.plan,isUserLogged:e.logged}),chrome.storage.sync.set({subscription:e.plan,isUserLogged:e.logged});else{t.pop();const r=t.join("_");chrome.storage.local.set({subscription:r,isUserLogged:e.logged}),chrome.storage.sync.set({subscription:r,isUserLogged:e.logged})}})),Jr=(0,Nr.HA)("CheckUser/GET_FAILED"),$r=(0,Nr.HA)("accounts/Started",((e,t)=>Qr(void 0,[e,t],(function*(e,{dispatch:t}){try{const e=yield Zr({url:"https://helium10.groupbuyamz.com/api/v1/customers/accounts"}),r=e?yield rn(e.results):null;e&&r?(t(tn({accountId:r})),t(_r(e.results)),t(Xr(r))):(t(en(new Error("Request error"))),t(Xr(null)))}catch(e){t(en(new Error(e))),t(Xr(null))}})))),_r=(0,Nr.HA)("accounts/Done"),en=(0,Nr.HA)("accounts/Failed"),tn=(0,Nr.HA)("account/setAccountId",(e=>Qr(void 0,[e],(function*({accountId:e,sendEvent:t,reloadTabs:r}){var n,a;if(null==(a=null==(n=null==chrome?void 0:chrome.storage)?void 0:n.local)||a.set({accountId:e}),t)try{yield Zr({url:"https://helium10.groupbuyamz.com/extension/account-switched",params:{accountId:e}})}catch(e){}r&&chrome.tabs.query({active:!0,currentWindow:!0},(function(e){e.length>0&&chrome.tabs.update(e[0].id||0,{url:e[0].url})}))})))),rn=e=>new Promise((t=>{var r,n;const a=on(e);try{null==(n=null==(r=null==chrome?void 0:chrome.storage)?void 0:r.local)||n.get(["accountId"],(e=>{var r;e.accountId&&a.some((t=>t.accountId===e.accountId))?t(e.accountId):t(null==(r=a[0])?void 0:r.accountId)}))}catch(e){t(null)}})),nn=(0,Nr.xy)("mainAtom",{user:{content:null,status:"loading"},accountId:-1,accounts:{content:{},status:"init"}},(e=>[e(Xr,(e=>Hr(Wr({},e),{user:{content:e.user.content||null,status:"loading"}}))),e(Kr,((e,t)=>Hr(Wr({},e),{user:{content:t,status:"loaded"}}))),e(Jr,((e,{error:t,data:r})=>Hr(Wr({},e),{user:{content:r,status:"error",error:t}}))),e($r,(e=>Hr(Wr({},e),{accounts:Hr(Wr({},e.accounts),{status:"loading"})}))),e(_r,((e,t)=>Hr(Wr({},e),{accounts:{status:"loaded",content:t}}))),e(en,((e,t)=>Hr(Wr({},e),{accounts:{status:"error",content:{},error:t}}))),e(tn,((e,{accountId:t})=>Hr(Wr({},e),{accountId:t})))])),an=(0,Nr.UI)(nn,(e=>e.user)),on=e=>Object.values(e).sort(((e,t)=>e.role-t.role)),ln=(0,Nr.UI)("accountsSelector",nn,(e=>({accounts:on(e.accounts.content),current:e.accounts.content[e.accountId],accountId:e.accountId})));var sn,cn,un,dn;function gn(){return(gn=Object.assign||function(e){for(var t=1;t<arguments.length;t++){var r=arguments[t];for(var n in r)Object.prototype.hasOwnProperty.call(r,n)&&(e[n]=r[n])}return e}).apply(this,arguments)}function pn(e){return a.createElement("svg",gn({xmlns:"http://www.w3.org/2000/svg",width:16,height:16},e),sn||(sn=a.createElement("path",{fill:"#8c8c8c",d:"M8 10.645c-.818 0-1.484.666-1.484 1.484S7.182 13.613 8 13.613s1.484-.666 1.484-1.484S8.818 10.645 8 10.645m.215-8c-1.758 0-2.88.74-3.76 2.057-.114.17-.076.4.088.524l1.119.849a.388.388 0 00.538-.068c.576-.731.97-1.155 1.848-1.155.659 0 1.474.424 1.474 1.063 0 .483-.399.731-1.05 1.096-.758.425-1.762.955-1.762 2.28v.128c0 .214.173.387.387.387h1.806a.387.387 0 00.387-.387v-.043c0-.918 2.684-.956 2.684-3.44 0-1.872-1.941-3.29-3.76-3.29M16 8c0 4.42-3.582 8-8 8s-8-3.58-8-8a8.001 8.001 0 0116 0",fillRule:"evenodd"})))}function mn(){return(mn=Object.assign||function(e){for(var t=1;t<arguments.length;t++){var r=arguments[t];for(var n in r)Object.prototype.hasOwnProperty.call(r,n)&&(e[n]=r[n])}return e}).apply(this,arguments)}function hn(e){return a.createElement("svg",mn({xmlns:"http://www.w3.org/2000/svg",width:18,height:16},e),cn||(cn=a.createElement("path",{fill:"#0081ff",d:"M17.834 7.384L9.836.322a1.242 1.242 0 00-1.67 0l-8 7.062a.499.499 0 00-.038.706l.67.745c.184.205.5.222.705.037l7.167-6.32a.496.496 0 01.661 0l7.166 6.32a.499.499 0 00.706-.038l.67-.744a.5.5 0 00-.039-.706zM9 3.594L2.171 9.616c-.05.046-.115.067-.17.105V15.5a.5.5 0 00.5.5h4a.5.5 0 00.5-.5v-4a.5.5 0 01.5-.5h3a.5.5 0 01.5.5v4a.5.5 0 00.5.5H15.5a.5.5 0 00.5-.5V9.722c-.053-.036-.116-.057-.164-.1L9 3.594z",fillRule:"evenodd"})))}function wn(){return(wn=Object.assign||function(e){for(var t=1;t<arguments.length;t++){var r=arguments[t];for(var n in r)Object.prototype.hasOwnProperty.call(r,n)&&(e[n]=r[n])}return e}).apply(this,arguments)}function fn(e){return a.createElement("svg",wn({xmlns:"http://www.w3.org/2000/svg",xmlnsXlink:"http://www.w3.org/1999/xlink",width:15,height:15},e),un||(un=a.createElement("defs",null,a.createElement("path",{id:"settings_svg__a",d:"M13.186 8.557l1.284.741a.36.36 0 01.164.421 7.45 7.45 0 01-1.647 2.85.362.362 0 01-.447.067l-1.282-.74a5.8 5.8 0 01-1.83 1.058v1.481c0 .17-.118.316-.283.353a7.53 7.53 0 01-3.29 0 .362.362 0 01-.283-.353v-1.481a5.764 5.764 0 01-1.83-1.059l-1.282.741a.36.36 0 01-.447-.068A7.443 7.443 0 01.366 9.72.36.36 0 01.53 9.3l1.284-.742a5.778 5.778 0 010-2.114L.53 5.702a.36.36 0 01-.164-.421 7.45 7.45 0 011.647-2.85.362.362 0 01.447-.067l1.282.74a5.8 5.8 0 011.83-1.058V.565c0-.17.118-.316.283-.353a7.53 7.53 0 013.29 0 .362.362 0 01.283.353v1.481c.67.237 1.29.596 1.83 1.059l1.282-.741a.36.36 0 01.447.068 7.439 7.439 0 011.647 2.849.36.36 0 01-.164.42l-1.284.742c.13.699.13 1.415 0 2.114zM9.91 7.5A2.413 2.413 0 007.5 5.09 2.413 2.413 0 005.09 7.5 2.413 2.413 0 007.5 9.91 2.413 2.413 0 009.91 7.5z"}))),dn||(dn=a.createElement("g",{fill:"none",fillRule:"evenodd"},a.createElement("mask",{id:"settings_svg__b",fill:"#fff"},a.createElement("use",{xlinkHref:"#settings_svg__a"})),a.createElement("g",{fill:"#242A42",mask:"url(#settings_svg__b)"},a.createElement("path",{fill:"#8c8c8c",d:"M0 0h15v15H0z"})))))}const bn=/https?:\/{2}(?:w{3}\.)?(amazon\.[\w.]{2,})/,vn=/https?:\/{2}(?:w{3}\.)?(walmart\.com)/,yn=/https?:\/\/(?:w{3}\.)?((?:[\w]*\.)?helium10\.com)/,Mn=/https?:\/\/(?:w{3}\.)?((?:[\w-]*\.)?ci.helium10-dev\.com)/,xn=()=>{const[e,t]=(0,a.useState)(!1),[r,n]=(0,a.useState)(!1),[o,i]=(0,a.useState)(!1),[l,s]=(0,a.useState)(!1);return(0,a.useLayoutEffect)((()=>{chrome.tabs.query({currentWindow:!0,active:!0},(e=>{var r,a,o,l;const c=e[0],u=!!(null==(r=null==c?void 0:c.url)?void 0:r.match(yn))||!!(null==(a=null==c?void 0:c.url)?void 0:a.match(Mn)),d=!!(null==(o=null==c?void 0:c.url)?void 0:o.match(bn)),g=!!(null==(l=null==c?void 0:c.url)?void 0:l.match(vn));t(u),n(d),s(g);const p=e[0].id;!p||u||d||g||chrome.scripting.executeScript({files:["detect.js"],target:{tabId:p}},(()=>{chrome.tabs.sendMessage(p,{action:"isDemand"},(e=>{return void 0,null,t=function*(){const t=yield e;t&&i(t.platform)},new Promise(((e,r)=>{var n=e=>{try{o(t.next(e))}catch(e){r(e)}},a=e=>{try{o(t.throw(e))}catch(e){r(e)}},o=t=>t.done?e(t.value):Promise.resolve(t.value).then(n,a);o((t=t.apply(undefined,null)).next())}));var t}))}))}))}),[]),{isHelium:e,isAmazon:r,isDemand:o,isWalmart:l}},zn=(0,o.ZP)(Se)`
  line-height: normal;
  letter-spacing: 0.73px;
  font-weight: normal;
  width: 100%;
  margin-bottom: 16px;
  box-shadow: 0 1px 4px 0 rgba(56, 56, 56, 0.5);
  border-radius: 8px;

  &:hover {
    background-color: #f4f4f4;
  }
`,jn=(0,o.ZP)(I)`
  color: ${({theme:e})=>e.colors.darkBlue};
  font-weight: bold;
  display: flex;
  align-items: center;
`,Nn=o.ZP.div`
  cursor: pointer;
  border-radius: ${({theme:e})=>e.borderRadius.small};
  padding: 6px 12px;
  transition: background-color 0.2s ease-in-out;

  &:hover {
    background-color: #f4f4f4;
  }
`,On=(0,o.ZP)(Se)`
  line-height: 1.2;
  padding: 8px 24px;
  border-radius: 4px;
  border: 2px solid ${({theme:e})=>e.colors.darkBlue};
  background: ${({theme:e})=>e.colors.darkBlue};
  color: #fff;

  &:hover {
    background: ${({theme:e})=>e.colors.middleBlue};
    border-color: ${({theme:e})=>e.colors.middleBlue};
  }
`,Dn=((0,o.ZP)(I)`
  color: ${({theme:e})=>e.colors.darkBlue};
  font-weight: bold;
  justify-content: center;
  align-items: center;
  display: flex;
  width: 100%;
`,o.ZP.span`
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  display: block;
`),An=o.ZP.div`
  background-color: #49e095;
  color: #364f4b;
  font-size: 12px;
  line-height: 1;
  padding: 3px 6px;
  font-weight: bold;
  text-transform: uppercase;
  border-radius: 6px;
`,Pn=({onOpenNewsFeed:e})=>{const{t}=yr(),{isAmazon:r,isHelium:n}=xn();return a.createElement(In,null,r||!r&&!n?a.createElement(Tn,{onClick:()=>{chrome.runtime.sendMessage({type:"open-page",params:{url:Or}})}},a.createElement(hn,null),a.createElement(kn,null,t("common.myDashboard"))):a.createElement(Zn,null),a.createElement(En,null,a.createElement(Ln,{onClick:()=>{chrome.runtime.sendMessage({type:"open-page",params:{url:"https://kb.helium10.com/hc/en-us/sections/360005055314"}})}},a.createElement(pn,null)),a.createElement(Sn,{onClick:()=>{var e,t;null==(t=(e=chrome.runtime).openOptionsPage)||t.call(e)}},a.createElement(fn,null))))},In=o.ZP.div`
  flex: 0 0 auto;
  border-top: 1px solid #ebf0f2;
  padding: 12px 20px 12px 12px;
  display: flex;
  justify-content: space-between;
  align-items: center;
`,Cn=(0,o.ZP)(Se)`
  line-height: normal;
  letter-spacing: 0.73px;
  font-weight: normal;
  margin-left: 12px;
`,En=o.ZP.div`
  display: flex;
  align-items: center;
`,Sn=(0,o.ZP)(Nn)`
  padding: 4px;
  font-size: 0;
`,Ln=(0,o.ZP)(Nn)`
  margin-right: 4px;
  padding: 4px;
  font-size: 0;
`,Tn=(0,o.ZP)(Nn)`
  display: flex;
  align-items: center;
  padding: 11px 14px;
  border-radius: 8px;
`,kn=(0,o.ZP)(A)`
  margin-left: 8px;
  color: ${({theme:e})=>e.colors.darkBlue};
  position: relative;
  top: 1px;
`,Zn=o.ZP.div``;var Bn;function Gn(){return(Gn=Object.assign||function(e){for(var t=1;t<arguments.length;t++){var r=arguments[t];for(var n in r)Object.prototype.hasOwnProperty.call(r,n)&&(e[n]=r[n])}return e}).apply(this,arguments)}function Rn(e){return a.createElement("svg",Gn({width:28,height:32,xmlns:"http://www.w3.org/2000/svg"},e),Bn||(Bn=a.createElement("g",{fill:"none",fillRule:"evenodd"},a.createElement("path",{d:"M9.5 14h-5V9.5C4.5 4.263 8.762 0 14 0s9.5 4.263 9.5 9.5V14h-5V9.5a4.5 4.5 0 10-9 0V14z",fill:"#003873"}),a.createElement("path",{d:"M28 17v12a3 3 0 01-3 3H3a3 3 0 01-3-3V17a3 3 0 013-3h22a3 3 0 013 3",fill:"#0081FF"}))))}const Fn=()=>{const{t:e}=yr();return a.createElement(Un,null,a.createElement(Vn,null,a.createElement(Rn,null)),a.createElement(qn,null,e("common.beforeStarted")),a.createElement(Yn,null,e("common.enablePermissions")),a.createElement(Qn,null,a.createElement(Wn,{colorType:"white",onClick:()=>{window.close()}},e("buttons.cancel")),a.createElement(Hn,{onClick:()=>{window.close(),chrome.windows.getCurrent((e=>{e.id&&chrome.windows.update(e.id,{focused:!0}),chrome.permissions.request({origins:["*://*/*"]})}))}},e("buttons.enable"))))},Un=o.ZP.div`
  padding: 24px;
  display: flex;
  flex-direction: column;
`,Vn=o.ZP.div`
  width: 80px;
  height: 80px;
  border-radius: 50%;
  background-color: rgba(0, 129, 255, 0.15);
  margin: auto;
  display: flex;
  align-items: center;
  justify-content: center;
`,qn=(0,o.ZP)(P)`
  margin: 18px auto;
  color: ${({theme:e})=>e.colors.darkBlue};
`,Yn=(0,o.ZP)(I)`
  color: #343a40;
  margin-bottom: 24px;
  text-align: center;
`,Wn=(0,o.ZP)(zn)`
  flex-grow: 1;
  flex-basis: 0;
  display: flex;
  justify-content: center;
  margin-bottom: 0;
  color: ${({theme:e})=>e.colors.darkBlue};
  font-weight: bold;
`,Hn=(0,o.ZP)(Se)`
  flex-grow: 1;
  flex-basis: 0;
  display: flex;
  justify-content: center;
  letter-spacing: 0.73px;
  box-shadow: 0 1px 4px 0 rgba(56, 56, 56, 0.5);
  font-weight: bold;
`,Qn=o.ZP.div`
  flex-grow: 1;
  display: flex;

  ${Wn} {
    margin-right: 16px;
  }
`,Xn=()=>{const{t:e}=yr();return a.createElement(a.Fragment,null,a.createElement(Kn,null,a.createElement(Jn,{dangerouslySetInnerHTML:{__html:e("auth.welcome")}}),a.createElement(Yn,null,e("auth.logInText")),a.createElement($n,{onClick:()=>{chrome.runtime.sendMessage({type:"open-page",params:{url:"https://helium10.groupbuyamz.com/user/signin"}})}},e("auth.logIntoAccount")),a.createElement(_n,null,e("auth.or")),a.createElement($n,{onClick:()=>{chrome.runtime.sendMessage({type:"open-page",params:{url:"https://helium10.groupbuyamz.com/user/signup"}})}},e("auth.signUp"))))},Kn=o.ZP.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 1.375rem 1.25rem 2.4rem;
`,Jn=(0,o.ZP)(qn)`
  text-align: center;
  margin-bottom: 0;
`,$n=(0,o.ZP)(Cn)`
  margin-right: 12px;
  width: 100%;
  align-items: center;
  justify-content: center;
  font-size: 16px;
  font-weight: 600;
`,_n=o.ZP.div`
  margin-top: 12px;
  margin-bottom: 12px;
  font-size: 16px;
  width: 100%;
  overflow: hidden;
  text-align: center;

  &::before,
  &::after {
    content: "";
    display: inline-block;
    vertical-align: middle;
    box-sizing: border-box;
    width: 100%;
    height: 2px;
    background: #e4e5e7;
    border: solid #fff;
    border-width: 0 10px;
  }

  &::before {
    margin-left: -100%;
  }

  &::after {
    margin-right: -100%;
  }
`;var ea,ta,ra,na,aa,oa;function ia(){return(ia=Object.assign||function(e){for(var t=1;t<arguments.length;t++){var r=arguments[t];for(var n in r)Object.prototype.hasOwnProperty.call(r,n)&&(e[n]=r[n])}return e}).apply(this,arguments)}function la(){return(la=Object.assign||function(e){for(var t=1;t<arguments.length;t++){var r=arguments[t];for(var n in r)Object.prototype.hasOwnProperty.call(r,n)&&(e[n]=r[n])}return e}).apply(this,arguments)}function sa(e){return a.createElement("svg",la({xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 20 23"},e),ta||(ta=a.createElement("path",{d:"M4.972 0c2.747 0 4.971 2.25 4.971 5.031 0 2.78-2.224 5.032-4.971 5.032C2.224 10.063 0 7.812 0 5.03 0 2.251 2.224 0 4.972 0zm0 2.875c-1.177 0-2.131.966-2.131 2.156 0 1.19.954 2.157 2.13 2.157 1.177 0 2.131-.966 2.131-2.157 0-1.19-.954-2.156-2.13-2.156zm9.943 10.063c2.747 0 4.971 2.25 4.971 5.03 0 2.781-2.224 5.032-4.971 5.032-2.748 0-4.972-2.25-4.972-5.031 0-2.78 2.224-5.032 4.972-5.032zm0 2.874c-1.177 0-2.13.966-2.13 2.157 0 1.19.953 2.156 2.13 2.156 1.176 0 2.13-.966 2.13-2.156 0-1.19-.954-2.157-2.13-2.157zM17.414.009l1.403-.005c.86-.004 1.371.98.874 1.699L3.436 22.533c-.2.287-.524.458-.87.458l-1.483.005c-.865 0-1.372-.984-.874-1.699L16.544.467c.2-.287.524-.458.87-.458z",fill:"#0081FF",fillRule:"nonzero"})))}function ca(){return(ca=Object.assign||function(e){for(var t=1;t<arguments.length;t++){var r=arguments[t];for(var n in r)Object.prototype.hasOwnProperty.call(r,n)&&(e[n]=r[n])}return e}).apply(this,arguments)}function ua(){return(ua=Object.assign||function(e){for(var t=1;t<arguments.length;t++){var r=arguments[t];for(var n in r)Object.prototype.hasOwnProperty.call(r,n)&&(e[n]=r[n])}return e}).apply(this,arguments)}function da(){return(da=Object.assign||function(e){for(var t=1;t<arguments.length;t++){var r=arguments[t];for(var n in r)Object.prototype.hasOwnProperty.call(r,n)&&(e[n]=r[n])}return e}).apply(this,arguments)}function ga(e){return a.createElement("svg",da({xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 62 54"},e),oa||(oa=a.createElement("path",{fill:"#0081ff",fillRule:"evenodd",d:"M31.13 19.99C17.383 4.933 18.68 0 0 0c8.302 9.087 16.343 17.913 24.645 27C16.343 36.087 8.302 44.913 0 54c18.677 0 17.382-4.932 31.13-19.99C44.62 49.067 43.323 54 62 54c-8.043-9.087-16.343-17.913-24.645-27C45.657 17.913 53.957 9.087 62 0 43.322 0 44.618 4.932 31.13 19.99z"})))}const pa=e=>{const[t,r]=(0,a.useState)(!1),[n,o]=(0,a.useState)(!1),{enabled:i,setEnabled:l}=(0,a.useContext)(jr),[s,c]=(0,a.useState)(1),[u]=(0,Mr.Z)(s,1e3),{plan:d}=Bt();return(0,a.useEffect)((()=>{chrome.storage.sync.get(["appId","extensionEnabled"],(e=>{l("undefined"===e.extensionEnabled||e.extensionEnabled)}))}),[l]),(0,a.useEffect)((()=>{chrome.tabs.query({currentWindow:!0,active:!0},(t=>{var n;chrome.tabs.sendMessage((null==(n=t[0])?void 0:n.id)||0,{type:`on-${e}-product-page`},(e=>{i?e?"product"===e.status?o(!0):"listing"===e.status?r(!0):c((e=>e<15?e+1:e)):c((e=>e<15?e+1:e)):(o(!1),r(!1))}))}))}),[i,u,e,d]),{isProductPage:n,isSearchPage:t}};var ma;function ha(){return(ha=Object.assign||function(e){for(var t=1;t<arguments.length;t++){var r=arguments[t];for(var n in r)Object.prototype.hasOwnProperty.call(r,n)&&(e[n]=r[n])}return e}).apply(this,arguments)}var wa=Object.defineProperty,fa=Object.getOwnPropertySymbols,ba=Object.prototype.hasOwnProperty,va=Object.prototype.propertyIsEnumerable,ya=(e,t,r)=>t in e?wa(e,t,{enumerable:!0,configurable:!0,writable:!0,value:r}):e[t]=r;const Ma=e=>{var t,r=e,{content:n,children:o,disabled:i,open:l,onChange:s}=r,c=((e,t)=>{var r={};for(var n in e)ba.call(e,n)&&t.indexOf(n)<0&&(r[n]=e[n]);if(null!=e&&fa)for(var n of fa(e))t.indexOf(n)<0&&va.call(e,n)&&(r[n]=e[n]);return r})(r,["content","children","disabled","open","onChange"]);const u=(0,a.useRef)(null),[d,g]=(0,a.useState)((null==(t=u.current)?void 0:t.scrollHeight)||0);return a.createElement(xa,((e,t)=>{for(var r in t||(t={}))ba.call(t,r)&&ya(e,r,t[r]);if(fa)for(var r of fa(t))va.call(t,r)&&ya(e,r,t[r]);return e})({disabled:i},c),a.createElement(ja,{isOpen:l,colorType:"white",disabled:i,onClick:()=>{var e;s(!l),g((null==(e=u.current)?void 0:e.scrollHeight)||0)}},a.createElement(jn,null,n)),a.createElement(za,{ref:u,open:l,height:d},o))},xa=o.ZP.div`
  border-radius: 8px;
  box-shadow: ${({disabled:e})=>`0 1px 4px 0 rgba(56, 56, 56, ${e?.25:.5})`};
  margin-bottom: 16px;
`,za=o.ZP.div`
  overflow: hidden;
  transition: height 0.2s ease-in-out;
  height: ${({open:e,height:t})=>e?t+"px":0};
  letter-spacing: 0.73px;
  font-weight: normal;
  width: 100%;
  border-bottom-right-radius: 8px;
  border-bottom-left-radius: 8px;
`,ja=(0,o.ZP)(zn)`
  border-bottom-left-radius: ${({isOpen:e})=>e?0:"8px"};
  border-bottom-right-radius: ${({isOpen:e})=>e?0:"8px"};
  border-bottom: solid rgb(235, 240, 242) ${({isOpen:e})=>e?"1px":0};
  box-shadow: none;
  margin-bottom: 0;
`;var Na=Object.defineProperty,Oa=Object.getOwnPropertySymbols,Da=Object.prototype.hasOwnProperty,Aa=Object.prototype.propertyIsEnumerable,Pa=(e,t,r)=>t in e?Na(e,t,{enumerable:!0,configurable:!0,writable:!0,value:r}):e[t]=r,Ia=(e,t)=>{for(var r in t||(t={}))Da.call(t,r)&&Pa(e,r,t[r]);if(Oa)for(var r of Oa(t))Aa.call(t,r)&&Pa(e,r,t[r]);return e};const Ca=({onOpenModal:e})=>{const{t}=yr(),{isProductPage:r,isSearchPage:n}=pa("amazon"),[o,i]=(0,a.useState)(!1),[l,s]=(0,a.useState)(Ea),[c,u]=(0,a.useState)(Sa),[d,g]=(0,a.useState)(1),[p]=(0,Mr.Z)(d,400);(0,a.useEffect)((()=>{chrome.tabs.query({currentWindow:!0,active:!0},(e=>{var t;chrome.tabs.sendMessage((null==(t=e[0])?void 0:t.id)||0,{type:"get-asin-origins"},(e=>{e?u(e):g((e=>e<15?e+1:e))}))}))}),[p]);const m=(0,a.useCallback)((()=>{e("open-asin-grabber",l)}),[e,l]),h=(0,a.useCallback)((e=>{s((t=>Ia(Ia({},t),e)))}),[]);return a.createElement(La,null,a.createElement(Ma,{disabled:!(r||n),open:o,onChange:()=>{o?i(!1):r&&(c.boughtTogether||c.fourAndAbove||c.sponsored)?i(!0):m()},content:a.createElement(jn,null,a.createElement(Ga,null),t("common.asinGrabber"))},a.createElement(Ta,null,c.fourAndAbove&&a.createElement(Za,{checked:l.fourAndAbove,onChange:e=>{h({fourAndAbove:e})}},a.createElement(Ba,null,t("filters.grabberStars"))),c.sponsored&&a.createElement(Za,{checked:l.sponsored,onChange:()=>h({sponsored:!l.sponsored})},a.createElement(Ba,null,t("filters.sponsoredProducts"))),c.boughtTogether&&a.createElement(Za,{checked:l.boughtTogether,onChange:()=>h({boughtTogether:!l.boughtTogether})},a.createElement(Ba,null,t("filters.boughtTogether"))),a.createElement(ka,{onClick:m},t("buttons.open")))))},Ea={variation:!0,sponsored:!0,fourAndAbove:!0,boughtTogether:!0},Sa={sponsored:!1,fourAndAbove:!1,boughtTogether:!1},La=o.ZP.div``,Ta=o.ZP.div`
  display: flex;
  flex-direction: column;
  padding: 16px;
  font-size: 12px;
`,ka=(0,o.ZP)(On)`
  display: flex;
  justify-content: center;
  flex-grow: 1;
  margin-top: 4px;
`,Za=(0,o.ZP)(gr)`
  margin-bottom: 4px;
`,Ba=o.ZP.div`
  padding-left: 4px;
`,Ga=(0,o.ZP)((function(e){return a.createElement("svg",ha({xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 20 18"},e),ma||(ma=a.createElement("path",{d:"M2.413 14.742l.683-.805a.804.804 0 00.199-.567v-.132c0-.294-.15-.454-.443-.454H.625a.316.316 0 00-.313.32v.639c0 .176.14.32.313.32h.892c-.152.156-.295.32-.43.491l-.219.28c-.156.202-.205.405-.11.594l.042.078c.117.23.245.314.478.314h.185c.403 0 .623.098.623.363 0 .189-.165.329-.561.329a1.593 1.593 0 01-.605-.125c-.253-.155-.458-.14-.61.125l-.217.372c-.146.245-.125.468.102.637.301.187.796.377 1.446.377 1.334 0 1.894-.91 1.894-1.763-.001-.574-.356-1.189-1.122-1.393zM19.167 7.67h-12.5a.632.632 0 00-.625.64v1.278c0 .353.28.64.625.64h12.5a.633.633 0 00.625-.64V8.31c0-.353-.28-.64-.625-.64zm0-6.392h-12.5a.632.632 0 00-.625.64v1.278c0 .353.28.64.625.64h12.5a.633.633 0 00.625-.64V1.918c0-.353-.28-.64-.625-.64zm0 12.785h-12.5a.632.632 0 00-.625.639v1.278c0 .353.28.64.625.64h12.5a.633.633 0 00.625-.64v-1.278c0-.353-.28-.64-.625-.64zM.625 5.114h2.5a.316.316 0 00.313-.32v-.64a.316.316 0 00-.313-.319H2.5V.32C2.5.143 2.36 0 2.187 0H1.25a.312.312 0 00-.279.177L.66.816a.322.322 0 00.013.31.309.309 0 00.265.152h.313v2.557H.625a.316.316 0 00-.313.32v.639c0 .177.14.32.313.32zm-.153 6.392h2.653a.316.316 0 00.313-.32v-.64a.316.316 0 00-.313-.319h-1.51c.128-.41 1.887-.746 1.887-2.255 0-1.16-.976-1.58-1.737-1.58-.834 0-1.32.4-1.58.75-.17.222-.117.432.11.613l.334.275c.22.182.43.099.63-.097a.517.517 0 01.37-.154c.13 0 .362.062.362.35C1.992 8.637 0 9 0 10.89v.16c0 .296.198.456.472.456z",fill:"#0081FF",fillRule:"nonzero"})))}))`
  margin: 0 18px 0 2px;
  width: 23px;
`,Ra=({onOpenModal:e})=>{const{t}=yr(),{isProductPage:r,isSearchPage:n}=pa("amazon"),[o,i]=(0,a.useState)(0);return(0,a.useEffect)((()=>{var e,t;null==(t=null==(e=null==chrome?void 0:chrome.storage)?void 0:e.local)||t.get("showXrayWalmart",(e=>{var t,r,n;const a=(null==(t=e.showXrayWalmart)?void 0:t.count)||0;null==(n=null==(r=null==chrome?void 0:chrome.storage)?void 0:r.local)||n.set({showXrayWalmart:{count:a+1}}),i(a+1)}))}),[]),a.createElement(Fa,null,a.createElement(zn,{colorType:"white",disabled:!(r||n),onClick:()=>e("open-black-box")},o>10?a.createElement(jn,null,a.createElement(Ya,null),t("common.xRay")):a.createElement(Ua,null,a.createElement(jn,null,a.createElement(Ya,null),t("common.xRayShortName")),a.createElement(Va,null,t("common.nowOn"),a.createElement(Wa,null),a.createElement(qa,null,t("tag.beta"))))),a.createElement(Ca,{onOpenModal:e}),a.createElement(zn,{colorType:"white",disabled:!r,onClick:()=>e("open-calculator")},a.createElement(jn,null,a.createElement(Ha,null),t("common.profitabilityCalculator"))),a.createElement(zn,{colorType:"white",disabled:!r,onClick:()=>e("open-inventory")},a.createElement(jn,null,a.createElement(Qa,null),t("common.inventoryLevels"))),a.createElement(zn,{colorType:"white",disabled:!r,onClick:()=>e("open-review-insights")},a.createElement(jn,null,a.createElement(Xa,null),t("common.reviewInsights"))))},Fa=o.ZP.div``,Ua=o.ZP.div`
  width: 100%;
  display: flex;
  justify-content: space-between;
  align-items: center;
`,Va=o.ZP.div`
  color: #003873;
  font-size: 16px;
  display: flex;
  align-items: center;
`,qa=(0,o.ZP)(An)`
  background-color: #a5dbff;
`,Ya=(0,o.ZP)(ga)`
  margin: 0 19px 0 4px;
  width: 20px;
`,Wa=(0,o.ZP)((function(e){return a.createElement("svg",ua({viewBox:"0 0 95 23",fill:"none",xmlns:"http://www.w3.org/2000/svg"},e),na||(na=a.createElement("path",{d:"M34.164 8.18v1.304h.039c.458-.698 1.22-1.52 2.907-1.52 1.313 0 2.32.684 2.751 1.716h.04a4.116 4.116 0 011.264-1.196c.56-.332 1.184-.522 1.97-.522 1.776 0 3.35 1.182 3.35 4.164v5.655h-2.71v-5.26c0-1.511-.533-2.385-1.642-2.385-.812 0-1.403.525-1.627 1.17a2.538 2.538 0 00-.114.78v5.698h-2.71v-5.476c0-1.284-.512-2.175-1.606-2.175-.875 0-1.424.663-1.648 1.232a2.165 2.165 0 00-.126.784v5.632h-2.713v-9.6h2.575zm26.305 0v1.812h.075c.498-1.384 1.679-2.027 2.716-2.027.26 0 .404.02.614.06v2.515c-.249-.035-.48-.07-.803-.07-1.175 0-1.993.658-2.2 1.688-.045.213-.06.444-.06.709v4.917H58.03V8.18h2.44zM67.65 5.5v2.522l1.85.003v2.443h-1.85v3.607c0 1.168.309 1.733 1.226 1.733.432 0 .75-.052 1.025-.118l.036 2.027c-.369.133-1.154.277-1.951.277-.938 0-1.72-.314-2.197-.802-.545-.556-.797-1.467-.797-2.765L65 5.5h2.65zM29.701 17.78h-2.697V5.5H29.7v12.28zm-7.193-3.428c0 .176-.015.36-.066.52-.21.665-.926 1.228-1.819 1.228-.746 0-1.34-.407-1.34-1.27 0-1.317 1.51-1.683 3.228-1.675v1.197h-.003zm2.695-2.298c0-2.178-.965-4.09-4.23-4.09-1.675 0-3.005.453-3.73.857l.53 1.748c.662-.404 1.72-.736 2.721-.736 1.657-.003 1.927.903 1.927 1.482v.139c-3.611-.006-5.892 1.197-5.892 3.648 0 1.497 1.16 2.898 3.18 2.898 1.244 0 2.28-.476 2.904-1.24h.06s.414 1.658 2.685 1.024c-.12-.692-.159-1.428-.159-2.313v-3.417h.003zM2.979 5.5c.279 1.353 1.07 4.78 1.07 4.78.333 1.615.638 3.308.87 4.646h.041c.225-1.422.579-2.768.956-4.435L7 5.5h3.244l1.205 5.132c.327 1.566.587 2.774.794 4.23h.04c.224-1.47.518-2.728.838-4.337L14 5.5h3.242l-3.6 12.28c-2.235.47-3.092-.394-3.398-1.767-.306-1.376-.905-3.991-.905-3.991-.309-1.433-.549-2.443-.716-3.913H8.58c-.24 1.456-.492 2.477-.863 3.91l-1.472 5.765c-2.284.438-3.075-.21-3.513-1.973C2.356 14.303.5 5.5.5 5.5h2.48zm50.555 8.852c0 .176-.015.36-.066.52-.21.665-.926 1.228-1.82 1.228-.745 0-1.339-.407-1.339-1.27 0-1.317 1.51-1.683 3.228-1.675v1.197h-.003zm2.694-2.298c0-2.178-.965-4.09-4.229-4.09-1.675 0-3.006.453-3.73.857l.53 1.748c.662-.404 1.72-.736 2.721-.736 1.654-.003 1.927.903 1.927 1.482v.139c-3.608-.006-5.89 1.197-5.89 3.648 0 1.497 1.164 2.898 3.18 2.898 1.241 0 2.282-.476 2.902-1.24h.063s.413 1.658 2.685 1.024c-.12-.692-.159-1.428-.159-2.313v-3.417z",fill:"#0071dc"})),aa||(aa=a.createElement("path",{d:"M80.934 13.379c.266.467.248.988-.036 1.226l-4.905 3.466c-.51.298-1.276-.064-1.709-.82-.436-.758-.358-1.605.152-1.903l5.432-2.547c.34-.133.8.111 1.066.578zm6.456 0c.269-.467.726-.708 1.067-.581l5.434 2.547c.51.298.585 1.145.152 1.903-.436.756-1.204 1.115-1.712.82l-4.905-3.466c-.28-.235-.302-.76-.036-1.223zm-3.23 1.88c.535 0 .975.276 1.034.64l.53 6.017c0 .596-.691 1.084-1.56 1.084-.867 0-1.56-.488-1.56-1.084l.526-6.017c.06-.364.499-.64 1.03-.64zm3.266-6.86l4.905-3.47c.508-.298 1.276.06 1.712.82.433.758.359 1.605-.152 1.903l-5.434 2.55c-.34.127-.801-.114-1.067-.581-.266-.467-.245-.988.036-1.223zm-7.558 1.803l-5.431-2.55c-.508-.298-.586-1.145-.153-1.904.433-.758 1.201-1.117 1.709-.819l4.905 3.47c.284.231.302.755.036 1.222-.266.467-.726.708-1.066.581zm3.262-3.101l-.526-6.017c0-.596.69-1.084 1.56-1.084.869 0 1.56.488 1.56 1.084l-.53 6.017c-.06.36-.499.641-1.033.641-.532 0-.971-.28-1.031-.641z",fill:"#FFC124"})))}))`
  margin: 0 15px 0 4px;
  width: 80px;
`,Ha=(0,o.ZP)(sa)`
  margin: 0 20px 0 5px;
  width: 18px;
`,Qa=(0,o.ZP)((function(e){return a.createElement("svg",ia({viewBox:"0 0 32 32",xmlns:"http://www.w3.org/2000/svg"},e),ea||(ea=a.createElement("g",{fill:"none",fillRule:"evenodd"},a.createElement("path",{fill:"#0081FF",d:"M0 4v23.996h32V26H2V4z"}),a.createElement("path",{fill:"#0081FF",d:"M6 16h4v8H6zm6-8h4v16h-4zm6 4h4v12h-4zm6-6h4v18h-4z"}),a.createElement("path",{d:"M0 0h32v32H0z"}))))}))`
  margin: 0 16px 0 2px;
  width: 25px;
`,Xa=(0,o.ZP)((function(e){return a.createElement("svg",ca({xmlns:"http://www.w3.org/2000/svg",width:20,height:18},e),ra||(ra=a.createElement("g",{fill:"#0081FF",fillRule:"evenodd"},a.createElement("path",{fillRule:"nonzero",d:"M19.375 14.063H.625a.633.633 0 00-.625.639v1.278c0 .352.281.64.625.64h18.75a.634.634 0 00.625-.64v-1.278a.634.634 0 00-.625-.64zm0-6.393H.625A.634.634 0 000 8.31v1.278c0 .352.281.64.625.64h18.75a.634.634 0 00.625-.64V8.31a.634.634 0 00-.625-.64zm0-6.392H.625a.634.634 0 00-.625.64v1.278c0 .352.281.64.625.64h18.75a.634.634 0 00.625-.64V1.918a.634.634 0 00-.625-.64z"}),a.createElement("rect",{width:2.5,height:5.114,x:8.75,rx:1.042}),a.createElement("rect",{width:2.5,height:5.114,x:13.75,y:6.392,rx:1.042}),a.createElement("rect",{width:2.5,height:5.114,x:3.75,y:12.784,rx:1.042}))))}))`
  margin: 0 16px 0 2px;
  width: 25px;
`;var Ka,Ja;function $a(){return($a=Object.assign||function(e){for(var t=1;t<arguments.length;t++){var r=arguments[t];for(var n in r)Object.prototype.hasOwnProperty.call(r,n)&&(e[n]=r[n])}return e}).apply(this,arguments)}function _a(e){return a.createElement("svg",$a({xmlns:"http://www.w3.org/2000/svg",width:20,height:20},e),Ka||(Ka=a.createElement("g",{fillRule:"nonzero",fill:"none"},a.createElement("path",{fill:"#231F20",d:"M10.215 0c4.046 0 5.175 2.545 5.175 3.674v6.567c0 1.228 1.489 2.357 1.489 2.357l-2.618 2.5c-.456-.415-1.788-1.634-2.087-2.09-2.083 3.162-8.456 2.96-8.456-1.928 0-4.553 5.566-5.165 7.81-5.245 0-1.755.24-3.09-1.635-3.085h-.021c-.2.01-1.774.143-2.477 2.21l-3.387-.304C4.008 2.456 6.16 0 10.215 0zm1.314 7.897c-1.553.05-3.88.474-3.88 2.58 0 2.269 3.88 2.804 3.88-.767z"}),a.createElement("path",{fill:"#F78F00",d:"M17.796 17.009C17.44 17.455 14.57 20 9.754 20c-4.815 0-8.502-3.192-9.63-4.509-.314-.344.045-.504.253-.37 3.377 1.986 8.654 5.258 17.165 1.352.346-.165.613.09.254.536z"}),a.createElement("path",{fill:"#F78F00",d:"M19.63 17.107c-.3.706-.737 1.197-.977 1.384-.253.201-.438.12-.3-.17.139-.29.89-2.075.586-2.455-.3-.37-1.705-.192-2.212-.143-.498.045-.6.09-.645-.013-.106-.255 1-.692 1.728-.781.723-.08 1.89-.036 2.12.254.17.228 0 1.21-.3 1.924z"}))))}function eo(){return(eo=Object.assign||function(e){for(var t=1;t<arguments.length;t++){var r=arguments[t];for(var n in r)Object.prototype.hasOwnProperty.call(r,n)&&(e[n]=r[n])}return e}).apply(this,arguments)}function to(e){return a.createElement("svg",eo({xmlns:"http://www.w3.org/2000/svg",width:22,height:23},e),Ja||(Ja=a.createElement("path",{d:"M7.782 13.379c.266.467.248.988-.036 1.226L2.841 18.07c-.511.298-1.276-.064-1.71-.82-.435-.758-.358-1.605.153-1.903l5.431-2.547c.34-.133.801.111 1.067.578zm6.456 0c.269-.467.726-.708 1.066-.581l5.434 2.677c.511.298.586 1.015.153 1.774-.436.755-1.204 1.114-1.712.819l-4.905-3.466c-.281-.235-.302-.76-.036-1.223zm-3.23 1.88c.535 0 .974.276 1.034.64l.386 6.017c0 .596-.547 1.084-1.417 1.084-.866 0-1.474-.488-1.474-1.084l.44-6.017c.06-.364.5-.64 1.031-.64zm3.266-6.86l4.905-3.47c.508-.298 1.276.06 1.712.82.433.758.358 1.453-.152 1.751l-5.435 2.702c-.34.127-.8-.114-1.066-.581-.266-.467-.245-.988.036-1.223zm-7.559 1.803L1.348 7.5c-.508-.298-.65-.993-.216-1.752C1.565 4.99 2.34 4.702 2.848 5l4.898 3.398c.284.232.302.756.036 1.223-.266.467-.726.708-1.067.581zm3.263-3.101l-.441-6.017C9.537.488 10.142 0 11.01 0c.87 0 1.417.488 1.417 1.084l-.386 6.017c-.06.36-.499.641-1.034.641-.531 0-.97-.28-1.03-.641z",fill:"#FFC124"})))}const ro=({onOpenPage:e})=>{const{t}=yr();return a.createElement(no,null,a.createElement(zn,{colorType:"white",onClick:()=>e(Dr)},a.createElement(jn,null,a.createElement(ao,null),t("buttons.browseAmazon"))),a.createElement(zn,{colorType:"white",onClick:()=>e(Ar)},a.createElement(io,null,a.createElement(jn,null,a.createElement(oo,null),t("buttons.browseWalmart")),a.createElement(An,null,t("tag.new")))))},no=o.ZP.div``,ao=(0,o.ZP)(_a)`
  margin-right: 16px;
`,oo=(0,o.ZP)(to)`
  margin-right: 16px;
`,io=o.ZP.div`
  display: flex;
  width: 100%;
  justify-content: space-between;
  align-items: center;
`;var lo;function so(){return(so=Object.assign||function(e){for(var t=1;t<arguments.length;t++){var r=arguments[t];for(var n in r)Object.prototype.hasOwnProperty.call(r,n)&&(e[n]=r[n])}return e}).apply(this,arguments)}function co(e){return a.createElement("svg",so({xmlns:"http://www.w3.org/2000/svg",width:21,height:20},e),lo||(lo=a.createElement("path",{fill:"#0081ff",d:"M8.647 11.25V1.98c0-.372-.324-.679-.689-.627-4.6.658-8.116 4.725-7.953 9.599.169 5.005 4.428 9.11 9.377 9.047a9.122 9.122 0 005.221-1.72c.305-.219.325-.673.06-.94l-6.016-6.09zm11.116-2.531C19.445 4.052 15.76.323 11.15 0c-.352-.024-.649.276-.649.633v8.74h8.638c.353 0 .65-.3.625-.655zm.611 2.53h-9.16l6.1 6.174a.614.614 0 00.857.026 9.388 9.388 0 002.823-5.502.623.623 0 00-.62-.697z",fillRule:"evenodd"})))}const uo=({onOpenPage:e,onOpenModal:t})=>{const{t:r}=yr(),{isDemand:n}=xn(),{enabled:o}=(0,a.useContext)(jr);return a.createElement(go,null,a.createElement(zn,{colorType:"white",onClick:()=>e(Dr)},a.createElement(jn,null,a.createElement(mo,null),r("buttons.browseAmazon"))),a.createElement(zn,{colorType:"white",onClick:()=>e(Ar)},a.createElement(wo,null,a.createElement(jn,null,a.createElement(ho,null),r("buttons.browseWalmart")),a.createElement(An,null,r("tag.new")))),a.createElement(zn,{colorType:"white",disabled:!n||!o,onClick:()=>t("open-analyzer")},a.createElement(jn,null,a.createElement(po,null),r("buttons.demandAnalyzeOnAmazon"))))},go=o.ZP.div``,po=(0,o.ZP)(co)`
  margin-right: 7px;
`,mo=(0,o.ZP)(_a)`
  margin-right: 16px;
`,ho=(0,o.ZP)(to)`
  margin-right: 16px;
`,wo=o.ZP.div`
  display: flex;
  width: 100%;
  justify-content: space-between;
  align-items: center;
`,fo=({onOpenModal:e})=>{const{t}=yr(),{isProductPage:r,isSearchPage:n}=pa("walmart"),{enabled:o}=(0,a.useContext)(jr);return a.createElement(bo,null,a.createElement(zn,{colorType:"white",disabled:!(r||n),onClick:()=>e("open-xray-walmart")},a.createElement(jn,null,a.createElement(vo,null),t("common.xRayWalmart"))),a.createElement(zn,{colorType:"white",disabled:!r,onClick:()=>e("open-calculator")},a.createElement(jn,null,a.createElement(yo,null),t("common.profitabilityCalculator"))),a.createElement(zn,{colorType:"white",disabled:!o,onClick:()=>e("open-analyzer")},a.createElement(jn,null,a.createElement(Mo,null),t("buttons.demandAnalyzeOnAmazon"))))},bo=o.ZP.div``,vo=(0,o.ZP)(ga)`
  margin: 0 19px 0 4px;
  width: 20px;
`,yo=(0,o.ZP)(sa)`
  margin: 0 20px 0 5px;
  width: 18px;
`,Mo=(0,o.ZP)(co)`
  margin-right: 7px;
`,xo=()=>{const{isHelium:e,isAmazon:t,isWalmart:r}=xn(),n=e=>{window.close(),chrome.runtime.sendMessage({type:"open-page",params:{url:e}})},o=(0,a.useCallback)(((e,t)=>{chrome.tabs.query({currentWindow:!0,active:!0},(r=>{const n=r[0];window.close(),chrome.tabs.sendMessage((null==n?void 0:n.id)||0,{type:e,params:t})}))}),[]);return a.createElement(zo,null,e?a.createElement(ro,{onOpenPage:n}):t?a.createElement(Ra,{onOpenModal:o}):r?a.createElement(fo,{onOpenModal:o}):a.createElement(uo,{onOpenPage:n,onOpenModal:o}))},zo=(0,o.ZP)(rr)`
  flex-grow: 1;
  padding: 24px 24px 8px 24px;
  overflow: auto;
`,jo=()=>{const{t:e}=yr(),{enabled:t,setEnabled:r}=(0,a.useContext)(jr);(0,a.useEffect)((()=>{chrome.storage.sync.get(["extensionEnabled"],(e=>{r(e.extensionEnabled)}))}),[r]);const n=(0,a.useCallback)((()=>{chrome.storage.sync.set({extensionEnabled:!t}),r(!t)}),[t,r]);return a.createElement(No,null,a.createElement(Oo,null,e("common.extensionToggle")),a.createElement(gr,{checked:t,onChange:n}))},No=o.ZP.div`
  flex: 0 0 auto;
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 16px 24px;
  border-bottom: 1px solid #ebf0f2;
`,Oo=(0,o.ZP)(I)`
  color: #343a40;
`;var Do;function Ao(){return(Ao=Object.assign||function(e){for(var t=1;t<arguments.length;t++){var r=arguments[t];for(var n in r)Object.prototype.hasOwnProperty.call(r,n)&&(e[n]=r[n])}return e}).apply(this,arguments)}function Po(e){return a.createElement("svg",Ao({xmlns:"http://www.w3.org/2000/svg",width:12,height:7},e),Do||(Do=a.createElement("path",{d:"M.806 0h10.36c.717 0 1.076.89.568 1.412L6.556 6.743a.792.792 0 01-1.14 0L.238 1.413C-.27.89.088 0 .806 0",fill:"#646464",fillRule:"evenodd"})))}const Io=({onOpenSwitcher:e,isLogged:t=!1})=>{const{t:r}=yr(),{accounts:o,current:i}=(0,n.KO)(ln);return(0,a.useEffect)((()=>{const e=document.querySelector("#extension svg");null==e||e.setAttribute("viewBox","0 0 168 28"),null==e||e.removeAttribute("width"),null==e||e.removeAttribute("height")}),[]),a.createElement(Eo,null,a.createElement(So,{id:"extension"},a.createElement(To,{type:"logoModalDark"}),a.createElement(Zo,null,r("common.extension"))),t&&o.length>1&&a.createElement(Lo,{onClick:e},a.createElement(ko,{dangerouslySetInnerHTML:{__html:null==i?void 0:i.accountName}}),a.createElement(Po,null)),t&&1===o.length&&a.createElement(Co,null))},Co=(0,o.ZP)((e=>{var t=e,{plan:r}=t,n=((e,t)=>{var r={};for(var n in e)Yt.call(e,n)&&t.indexOf(n)<0&&(r[n]=e[n]);if(null!=e&&qt)for(var n of qt(e))t.indexOf(n)<0&&Wt.call(e,n)&&(r[n]=e[n]);return r})(t,["plan"]);const{t:o}=(0,a.useContext)(te),{plan:i}=Bt(),l=(0,a.useMemo)((()=>(r||i)===bt.Elite?D.colors.black:D.colors.darkBlue),[r,i]);return a.createElement(Qt,(s=((e,t)=>{for(var r in t||(t={}))Yt.call(t,r)&&Ht(e,r,t[r]);if(qt)for(var r of qt(t))Wt.call(t,r)&&Ht(e,r,t[r]);return e})({},n),Ut(s,Vt({background:l}))),o(`plans.${r||i}`));var s}))`
  margin-right: -12px;
`,Eo=o.ZP.div`
  flex: 0 0 auto;
  border-bottom: 1px solid #ebf0f2;
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 16px 12px 16px 24px;
`,So=o.ZP.div`
  display: flex;
  align-items: center;
`,Lo=(0,o.ZP)(Nn)`
  display: flex;
  align-items: center;
  user-select: none;
`,To=(0,o.ZP)(it)`
  width: 120px;
  line-height: normal;
`,ko=(0,o.ZP)(Dn)`
  font-size: 14px;
  font-weight: bold;
  color: #343a40;
  margin-right: 8px;
  max-width: 90px;
  min-height: 19px;
  display: block;
`,Zo=o.ZP.div`
  font-family: "Titillium Web", -apple-system, serif;
  color: #0081ff;
  margin-left: 8px;
  font-size: 18px;
  letter-spacing: 1px;
`;var Bo,Go;function Ro(){return(Ro=Object.assign||function(e){for(var t=1;t<arguments.length;t++){var r=arguments[t];for(var n in r)Object.prototype.hasOwnProperty.call(r,n)&&(e[n]=r[n])}return e}).apply(this,arguments)}function Fo(){return(Fo=Object.assign||function(e){for(var t=1;t<arguments.length;t++){var r=arguments[t];for(var n in r)Object.prototype.hasOwnProperty.call(r,n)&&(e[n]=r[n])}return e}).apply(this,arguments)}const Uo=({title:e,onClose:t,children:r})=>a.createElement(qo,null,a.createElement(Wo,null,e,a.createElement(Yo,{onClick:t},a.createElement(Ho,{viewBox:"0 0 10 10"}))),a.createElement(Vo,null,r)),Vo=o.ZP.div`
  overflow: auto;
  flex: 1;
  background-color: #fff;
  display: flex;
  flex-direction: column;
`,qo=o.ZP.div`
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  width: 100%;
  height: 100%;
  background-color: #fff;
  display: flex;
  flex-direction: column;

  * {
    box-sizing: border-box;
  }
`,Yo=(0,o.ZP)(Nn)`
  width: 31px;
  height: 31px;
  padding: 0;
  display: flex;
  align-items: center;
  justify-content: center;
`,Wo=o.ZP.div`
  height: 64px;
  font-size: 18px;
  line-height: 25px;
  letter-spacing: 0.82px;
  color: #003873;
  font-weight: bold;
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0 12px 0 24px;
  border-bottom: 1px solid #ebf0f2;
`,Ho=(0,o.ZP)((function(e){return a.createElement("svg",Fo({viewBox:"0 0 10 10",fill:"none",xmlns:"http://www.w3.org/2000/svg"},e),Go||(Go=a.createElement("path",{clipRule:"evenodd",d:"M9.775 1.47L6.267 4.976l3.508 3.507a.607.607 0 010 .86l-.43.43a.605.605 0 01-.86 0L4.976 6.268 1.47 9.775a.607.607 0 01-.86 0l-.43-.43a.605.605 0 010-.86l3.508-3.508L.18 1.47a.605.605 0 010-.86L.61.18a.605.605 0 01.86 0l3.508 3.508L8.484.18a.605.605 0 01.86 0l.43.43a.614.614 0 010 .86"})))}))`
  width: 10px;
  height: 10px;
  fill: #646464;
`;var Qo=Object.defineProperty,Xo=Object.getOwnPropertySymbols,Ko=Object.prototype.hasOwnProperty,Jo=Object.prototype.propertyIsEnumerable,$o=(e,t,r)=>t in e?Qo(e,t,{enumerable:!0,configurable:!0,writable:!0,value:r}):e[t]=r;const _o=o.ZP.div`
  width: 32px;
  height: 32px;
  border-radius: 100px;
  overflow: hidden;
`,ei=o.ZP.img`
  width: 100%;
  height: 100%;
  object-fit: cover;
`,ti=({onClose:e})=>{const{t}=yr(),{accounts:r,accountId:o}=(0,n.KO)(ln),i=(0,n.BH)(tn),l=(0,n.BH)(Xr);return a.createElement(Uo,{title:t("common.switchTitle"),onClose:e},r.map((t=>a.createElement(ni,{onClick:()=>{return r=t.accountId,i({accountId:r,sendEvent:!0,reloadTabs:!0}),l(r),void e();var r}},a.createElement(ri,{key:t.accountId,active:t.accountId===o,name:t.accountName,label:t.accountId})))))},ri=({active:e,name:t,label:r,avatar:n})=>a.createElement(ai,{active:e},a.createElement(oi,{url:n}),a.createElement(ni,null,a.createElement(ii,{dangerouslySetInnerHTML:{__html:t}}),a.createElement(li,null,r)),e&&a.createElement(si,{viewBox:"0 0 14 14"})),ni=o.ZP.div``,ai=o.ZP.div`
  position: relative;
  cursor: pointer;
  display: flex;
  align-items: center;
  height: 72px;
  border-left: 4px solid transparent;
  transition: background-color 0.1s ease;
  padding-left: 24px;
  padding-right: 24px;
  user-select: none;

  ${({active:e})=>e&&o.iv`
      background-color: rgba(0, 165, 255, 0.1);
      border-color: #0081ff;
    `}
  &:hover {
    background-color: rgba(0, 165, 255, 0.1);
  }
`,oi=(0,o.ZP)((e=>{var t=e,{url:r}=t,n=((e,t)=>{var r={};for(var n in e)Ko.call(e,n)&&t.indexOf(n)<0&&(r[n]=e[n]);if(null!=e&&Xo)for(var n of Xo(e))t.indexOf(n)<0&&Jo.call(e,n)&&(r[n]=e[n]);return r})(t,["url"]);const[o,i]=(0,a.useState)(!1),[l,s]=(0,a.useState)(!1);return a.createElement(_o,((e,t)=>{for(var r in t||(t={}))Ko.call(t,r)&&$o(e,r,t[r]);if(Xo)for(var r of Xo(t))Jo.call(t,r)&&$o(e,r,t[r]);return e})({},n),!o&&a.createElement(U,null),a.createElement(ei,{src:!r||l?"https://helium10.groupbuyamz.com/images/avatars/profile-default.svg":Or+r,onLoad:()=>i(!0),onError:()=>s(!0)}))}))`
  margin-right: 16px;
`,ii=(0,o.ZP)(Dn)`
  font-size: 16px;
  font-weight: 600;
  color: #343a40;
  line-height: 1.5;
`,li=(0,o.ZP)(Dn)`
  font-size: 13px;
  font-weight: bold;
  line-height: 1.23;
  color: #646464;
`,si=(0,o.ZP)((function(e){return a.createElement("svg",Ro({viewBox:"0 0 14 14",fill:"none",xmlns:"http://www.w3.org/2000/svg"},e),Bo||(Bo=a.createElement("path",{clipRule:"evenodd",d:"M12.485 1.11l-8.04 8.196-2.956-3.01a.362.362 0 00-.519 0l-.865.88a.381.381 0 000 .53l4.08 4.156a.362.362 0 00.518 0l9.164-9.342a.381.381 0 000-.53l-.864-.88a.362.362 0 00-.52 0"})))}))`
  width: 14px;
  height: 14px;
  fill: #0081ff;
  position: absolute;
  top: 50%;
  right: 22px;
  transform: translateY(-50%);
`,ci=()=>{const{status:e,content:t}=(0,n.KO)(an),r=(0,n.BH)($r),[o,l]=(0,a.useState)(!1),[s,c]=(0,a.useState)(!1),[u,d]=(0,a.useState)(!1),{permission:g}=(()=>{const[e,t]=(0,a.useState)(!1);return(0,a.useEffect)((()=>{chrome.tabs.query({currentWindow:!0,active:!0},(e=>{var r;if(null==(r=e[0].url)?void 0:r.includes("chrome"))t(!0);else{const r=["*://*."+xr(e[0].url)+"/*"];chrome.permissions.contains({origins:r},(e=>{t(e)}))}}))}),[]),{permission:e}})(),[p]=(0,Mr.Z)("loading"!==e,20);return(0,a.useEffect)((()=>{r()}),[r]),a.createElement(jr.Provider,{value:{enabled:u,setEnabled:d}},a.createElement(ui,null,"loading"===e?a.createElement(di,null,a.createElement(i,null)):a.createElement(gi,{visible:p,unmountOnExit:!0},a.createElement(Io,{onOpenSwitcher:()=>l(!0),isLogged:null==t?void 0:t.logged}),(null==t?void 0:t.logged)?g?a.createElement(a.Fragment,null,a.createElement(jo,null),a.createElement(xo,null)):a.createElement(Fn,null):a.createElement(Xn,null),a.createElement(Pn,{onOpenNewsFeed:()=>c(!0)})),a.createElement(gi,{visible:o,unmountOnExit:!0},a.createElement(ti,{onClose:()=>l(!1)}))))},ui=o.ZP.div`
  width: 400px;
  min-height: 300px;
  max-height: 600px;
  display: flex;
  flex-direction: column;
  position: relative;
`,di=o.ZP.div`
  align-items: center;
  flex-grow: 1;
  display: flex;
  justify-content: center;
`,gi=(0,o.ZP)((e=>{var t=e,{visible:r,timeout:n=0,children:o,unmountOnExit:i=!0}=t,l=((e,t)=>{var r={};for(var n in e)Z.call(e,n)&&t.indexOf(n)<0&&(r[n]=e[n]);if(null!=e&&k)for(var n of k(e))t.indexOf(n)<0&&B.call(e,n)&&(r[n]=e[n]);return r})(t,["visible","timeout","children","unmountOnExit"]);return a.createElement(E.ZP,{in:r,timeout:n,unmountOnExit:i,mountOnEnter:!0},(e=>{return a.createElement(R,(t=((e,t)=>{for(var r in t||(t={}))Z.call(t,r)&&G(e,r,t[r]);if(k)for(var r of k(t))B.call(t,r)&&G(e,r,t[r]);return e})({},l),L(t,T({state:e}))),o);var t}))}))`
  display: flex;
  flex-direction: column;
  flex-grow: 1;
  overflow: hidden;
`,pi=(0,Nr.$e)({main:nn}),{store:mi}={store:(0,Nr.MT)(pi)};function hi(){return a.createElement(a.Suspense,{fallback:a.createElement(a.Fragment,null)},a.createElement(n.Do.Provider,{value:mi},a.createElement(o.f6,{theme:D},a.createElement(ee,null,a.createElement(br,null,a.createElement(ci,null))),a.createElement(ut,null))))}Q.render(a.createElement(a.Fragment,null,a.createElement(hi,null)),document.getElementById("popup-root"))}},r={};function n(e){var a=r[e];if(void 0!==a)return a.exports;var o=r[e]={exports:{}};return t[e].call(o.exports,o,o.exports,n),o.exports}n.m=t,e=[],n.O=(t,r,a,o)=>{if(!r){var i=1/0;for(u=0;u<e.length;u++){for(var[r,a,o]=e[u],l=!0,s=0;s<r.length;s++)(!1&o||i>=o)&&Object.keys(n.O).every((e=>n.O[e](r[s])))?r.splice(s--,1):(l=!1,o<i&&(i=o));if(l){e.splice(u--,1);var c=a();void 0!==c&&(t=c)}}return t}o=o||0;for(var u=e.length;u>0&&e[u-1][2]>o;u--)e[u]=e[u-1];e[u]=[r,a,o]},n.n=e=>{var t=e&&e.__esModule?()=>e.default:()=>e;return n.d(t,{a:t}),t},n.d=(e,t)=>{for(var r in t)n.o(t,r)&&!n.o(e,r)&&Object.defineProperty(e,r,{enumerable:!0,get:t[r]})},n.g=function(){if("object"==typeof globalThis)return globalThis;try{return this||new Function("return this")()}catch(e){if("object"==typeof window)return window}}(),n.o=(e,t)=>Object.prototype.hasOwnProperty.call(e,t),n.r=e=>{"undefined"!=typeof Symbol&&Symbol.toStringTag&&Object.defineProperty(e,Symbol.toStringTag,{value:"Module"}),Object.defineProperty(e,"__esModule",{value:!0})},n.j=42,(()=>{var e={42:0};n.O.j=t=>0===e[t];var t=(t,r)=>{var a,o,[i,l,s]=r,c=0;if(i.some((t=>0!==e[t]))){for(a in l)n.o(l,a)&&(n.m[a]=l[a]);if(s)var u=s(n)}for(t&&t(r);c<i.length;c++)o=i[c],n.o(e,o)&&e[o]&&e[o][0](),e[i[c]]=0;return n.O(u)},r=globalThis.webpackChunkhelium10_main_tool=globalThis.webpackChunkhelium10_main_tool||[];r.forEach(t.bind(null,0)),r.push=t.bind(null,r.push.bind(r))})();var a=n.O(void 0,[216],(()=>n(2035)));a=n.O(a)})();