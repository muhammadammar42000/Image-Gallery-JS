
chrome.runtime.onMessage.addListener(
    function (request, sender, sendResponse) {
        console.log(request);
        if (request.action == "import") {
            importCookies(request.data)
            setTimeout(() => {
                sendResponse({ farewell: "loggedin" });
            }, 700);
        } else if (request.action == "deleteAll") {
            getCookieList(request.url)
        }
    }
);

//detect extension
chrome.runtime.onMessageExternal.addListener(
    function(request, sender, sendResponse) {
        if (request) {
            if (request.message) {
                if (request.message == "version") {
                    sendResponse({extName: "toolshub"});
                }
            }
        }
        return true;
    });

function getCookieList(filterURL) {

    chrome.cookies.getAll(filterURL, function (cks) {
        deleteAll(cks, filterURL );
    });
}

function importCookies(text) {
    try {
        var cookieArray = $.parseJSON(text);
        if (Object.prototype.toString.apply(cookieArray) === "[object Object]")
            cookieArray = [cookieArray];
        for (var i = 0; i < cookieArray.length; i++) {
            try {
                var cJSON = cookieArray[i];
                //console.log("cjson1 ", cJSON.domain[0], cJSON.domain);
                if (cJSON.domain[0] == ".") cJSON.domain = cJSON.domain.substr(1, cJSON.domain.length - 1)
                //console.log("cjson2 ", cJSON.domain);
                var cookie = cookieForCreationFromFullCookie(cJSON);
                console.log("cookie ", cookie);
                chrome.cookies.set(cookie);
            } catch (e) {
                console.error(e);
                return;
            }
        }
    } catch (e) {
        console.error(e);
        return;
    }

    return;
}
