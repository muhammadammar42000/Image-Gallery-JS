
console.log("ext content.js ");
var btns = document.querySelectorAll('.extensionButton')
for (let i = 0; i < btns.length; i++) {
    var btn = btns[i];
    console.log(btn);
    btn=document.querySelectorAll('.extensionButton')[i]
    btn.onclick = (() => {
        var text = document.querySelectorAll('.extensionJSONdiv')[i].innerText;
        console.log("ext ", text);

        chrome.runtime.sendMessage({ data: text, action:"import" }, function (response) {
            console.log(response);
            //click on redirect button
            open(document.querySelector('#extensionLink'+i).value);
        });
    })
}
